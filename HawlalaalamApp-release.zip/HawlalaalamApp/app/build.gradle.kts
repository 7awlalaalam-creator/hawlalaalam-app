plugins {
    id("com.android.application")
}

// التوقيع يُقرأ من متغيرات البيئة (أسرار GitHub) — لا تضع كلمات المرور هنا
val ksFile = System.getenv("KEYSTORE_FILE")
val hasSigning = !ksFile.isNullOrBlank() && file(ksFile).exists()

android {
    namespace = "com.hawlalaalam.quran"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.hawlalaalam.quran"
        minSdk = 26
        targetSdk = 36
        // رقم الإصدار يزيد تلقائيًا مع كل بناء على GitHub
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    signingConfigs {
        if (hasSigning) {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // تصغير الكود والموارد: حجم أصغر وتشغيل أسرع
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    androidResources {
        // الخط وجدول التحويل يُقرآن مباشرة من الأصول دون فك ضغط
        noCompress += listOf("woff2")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
