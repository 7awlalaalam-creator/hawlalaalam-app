# تطبيق «حول العالم | القرآن» لأندرويد

تطبيق أندرويد أصلي يفتح موقع https://7awlalaalam.com/quran/ كاملًا، مع ميزات لا يوفرها المتصفح.

## ماذا يفعل التطبيق
- يفتح كل صفحات الموقع داخله، وأي رابط خارجي (واتساب، يوتيوب، X، الإعلانات) يُفتح في تطبيقه أو المتصفح.
- أي رابط لموقعك يضغطه المستخدم في واتساب مثلًا يُفتح داخل التطبيق مباشرة (بعد رفع assetlinks.json).
- زر المشاركة في بطاقات الآيات يعمل ويفتح نافذة مشاركة أندرويد (مع الصورة)، وحفظ البطاقة يذهب إلى مجلد التنزيلات/حول العالم.
- الصفحات التي زارها المستخدم تفتح بدون إنترنت، وتظهر شاشة «لا يوجد اتصال» بتصميم الموقع لغيرها.
- التلاوة تستمر عند الخروج المؤقت من التطبيق، والفيديو يعمل بملء الشاشة.
- السحب للأسفل للتحديث، زر الرجوع يرجع للصفحة السابقة، شريط تحميل ذهبي.
- إذن الموقع الجغرافي لأدوات القبلة والمواقيت، ورفع الملفات إن احتاجته أي صفحة.
- يدعم أندرويد 8 فأحدث، ومتوافق مع متطلبات Google Play الحالية (targetSdk 35).

## البناء بدون تثبيت أي برنامج (عبر GitHub)
1. أنشئ مستودعًا جديدًا على github.com (عام أو خاص).
2. فك ضغط المشروع وارفع **محتوياته** (بما فيها مجلد `.github`) عبر «Add file ← Upload files».
3. من إعدادات المستودع: Settings ← Secrets and variables ← Actions ← New repository secret، أضف الأسرار الأربعة من ملف المفاتيح المرفق منفصلًا.
4. ادخل تبويب Actions ← «بناء تطبيق أندرويد» ← Run workflow (ويتكرر تلقائيًا مع كل تعديل).
5. بعد 4-6 دقائق تجد ملف `hawlalaalam-quran.apk` في صفحة **Releases** بالمستودع، افتحها من الجوال وثبّته.

> لو كان المستودع عامًا، رابط Releases يصلح لتنشره لزوارك كرابط تحميل مباشر.

## خطوة على الاستضافة (مهمة)
ارفع ملف `assetlinks.json` إلى:
`public_html/.well-known/assetlinks.json`
وتأكد أنه يفتح على https://7awlalaalam.com/.well-known/assetlinks.json
هذا ما يجعل روابط موقعك تُفتح في التطبيق تلقائيًا.

## الإعلانات داخل التطبيق
سياسة AdSense لا تسمح بعرض إعلاناته داخل تطبيقات WebView بالطريقة العادية.
التطبيق يضيف العلامة `HawlalaalamApp` إلى User-Agent، فاستبدل وسم سكربت AdSense في رأس الصفحات بهذا:

```html
<script>
if(!/HawlalaalamApp/.test(navigator.userAgent)){
  var s=document.createElement('script');s.async=true;s.crossOrigin='anonymous';
  s.src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5189114024279887';
  document.head.appendChild(s);
}
</script>
```
فتظهر الإعلانات في المتصفح فقط. (لاحقًا يمكن إضافة AdMob للتطبيق إن أردت ربحًا منه.)

## النشر على Google Play
- حساب مطوّر (25$ مرة واحدة)، وارفع ملف `hawlalaalam-quran.aab` من Releases.
- بعد تفعيل Play App Signing، انسخ بصمة SHA-256 التي يعرضها Play Console (App integrity) وأضفها كسطر ثانٍ داخل `sha256_cert_fingerprints` في assetlinks.json.
- Google قد ترفض التطبيقات التي هي «موقع فقط»؛ الميزات الأصلية أعلاه (المشاركة، الحفظ، العمل دون اتصال، فتح الروابط) تقوّي الطلب، وإضافة إشعارات «آية اليوم» لاحقًا تقوّيه أكثر.

## التعديل لاحقًا
- الصفحة الأولى: `HOME` في `MainActivity.java`
- الألوان: `app/src/main/res/values/colors.xml`
- الاسم: `app/src/main/res/values/strings.xml`
- الأيقونة: `app/src/main/res/drawable/ic_launcher_foreground.xml`

يمكن أيضًا فتح المشروع في Android Studio مباشرة وبناؤه من هناك.
