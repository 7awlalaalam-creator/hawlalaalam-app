/* صفحة المصحف بأسطر مصحف المدينة: البيانات من مجمع الملك فهد (رقم الصفحة وسطر بداية الآية ونهايتها) */
var HawlMushaf = (function () {
  var BASMALA = 'بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ';
  // عنوان السورة داخل خرطوشة مزخرفة (الألوان من متغيرات CSS: --mp-g ذهبي، --mp-d داكن، --mp-p الورقة، --mp-a زهري)
  var CART = '<svg viewBox="0 0 320 44" preserveAspectRatio="none" aria-hidden="true">' +
    '<path d="M2 22 L22 2 H298 L318 22 L298 42 H22Z" fill="var(--mp-d)" stroke="var(--mp-g)" stroke-width="1.6"/>' +
    '<path d="M14 22 L27 8 H293 L306 22 L293 36 H27Z" fill="var(--mp-p)" stroke="var(--mp-g)" stroke-width="1"/>' +
    '<path d="M30 22 l6 -6 l6 6 l-6 6Z M278 22 l6 -6 l6 6 l-6 6Z" fill="var(--mp-a)" stroke="var(--mp-g)" stroke-width=".8"/>' +
    '<circle cx="8" cy="22" r="2" fill="var(--mp-g)"/><circle cx="312" cy="22" r="2" fill="var(--mp-g)"/></svg>';
  /** كلمات السطر مجمّعة بحسب الآية: <span class="ay" data-k="سورة:آية"> — للضغط على الآية وتظليلها */
  function ayahSpans(ws) {
    var out = [], cur = null, buf = [];
    for (var i = 0; i < ws.length; i++) {
      var k = ws[i].s + ':' + ws[i].a;
      if (k !== cur) {
        if (buf.length) out.push('<span class="ay" data-k="' + cur + '">' + buf.join(' ') + '</span>');
        cur = k; buf = [];
      }
      buf.push(ws[i].w);
    }
    if (buf.length) out.push('<span class="ay" data-k="' + cur + '">' + buf.join(' ') + '</span>');
    return out.join(' ');
  }
  function ar(n) { return String(n).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); }

  /** يحسب محتوى الأسطر ١..١٥ لصفحة: عنوان سورة، بسملة، أو كلمات */
  function layout(data, N, measure) {
    var page = data.pages[N - 1], lines = [], i, e;
    for (i = 0; i <= 15; i++) lines.push(null);
    for (i = 0; i < page.length; i++) {
      e = page[i];
      if (e[1] !== 1) continue;
      var s = e[0], ls = e[2];
      if (s === 1) { if (ls >= 2) lines[ls - 1] = { t: 'h', s: s }; }
      else if (s === 9) { if (ls >= 2) lines[ls - 1] = { t: 'h', s: s }; }
      else if (ls >= 3) { lines[ls - 2] = { t: 'h', s: s }; lines[ls - 1] = { t: 'b' }; }
      else if (ls === 2) lines[1] = { t: 'b' };
    }
    var next = data.pages[N];
    if (next && next[0][1] === 1) {
      var ns = next[0][0], nl = next[0][2];
      if (ns === 9 && nl === 1) lines[15] = { t: 'h', s: 9 };
      else if (ns !== 9 && ns !== 1) {
        if (nl === 1) { lines[14] = { t: 'h', s: ns }; lines[15] = { t: 'b' }; }
        else if (nl === 2) lines[15] = { t: 'h', s: ns };
      }
    }
    // الكلمات بقيود أسطرها
    var words = [];
    for (i = 0; i < page.length; i++) {
      e = page[i];
      var toks = e[4].split(' ').filter(function (x) { return x.length; });
      for (var k = 0; k < toks.length; k++) words.push({ w: toks[k], ls: e[2], le: e[3], f: k === 0, l: k === toks.length - 1, s: e[0], a: e[1] });
    }
    var used = {};
    for (i = 0; i < page.length; i++) for (var L = page[i][2]; L <= page[i][3]; L++) used[L] = 1;
    var T = [];
    for (L = 1; L <= 15; L++) if (used[L] && !(lines[L] && lines[L].t !== 'x')) T.push(L);
    var sp = measure(' '), total = 0;
    for (i = 0; i < words.length; i++) { words[i].px = measure(words[i].w); total += words[i].px + sp; }
    var W = total / Math.max(1, T.length), n = words.length, INF = 1e18;
    // برمجة ديناميكية: أفضل توزيع للكلمات على الأسطر يحقق قيود المجمع ويجعل الأسطر متساوية
    var f = [], back = [];
    for (var a = 0; a <= T.length; a++) { f.push(new Array(n + 1).fill(INF)); back.push(new Array(n + 1).fill(-1)); }
    f[0][0] = 0;
    for (a = 0; a < T.length; a++) {
      L = T[a];
      for (i = 0; i < n; i++) {
        if (f[a][i] >= INF) continue;
        var wsum = 0;
        for (var j = i; j < n; j++) {
          var wd = words[j];
          if (wd.ls > L || wd.le < L) break;
          if (wd.f && wd.ls !== L) break;
          wsum += wd.px + (j > i ? sp : 0);
          if (wd.l && wd.le !== L) continue;            // آخر كلمة في الآية يجب أن تكون في سطر نهايتها
          var d = W - wsum, cost = f[a][i] + d * d;
          // الآية التالية تبدأ في هذا السطر حسب المجمع: لا يصح إنهاؤه قبلها
          if (j + 1 < n && words[j + 1].f && words[j + 1].ls === L) continue;
          if (cost < f[a + 1][j + 1]) { f[a + 1][j + 1] = cost; back[a + 1][j + 1] = i; }
        }
      }
    }
    var ok = f[T.length][n] < INF;
    if (ok) {
      var end = n;
      for (a = T.length; a > 0; a--) {
        var st = back[a][end];
        lines[T[a - 1]] = { t: 'x', w: words.slice(st, end) };
        end = st;
      }
    } else {
      // احتياط: كل آية في سطر بدايتها
      for (i = 0; i < words.length; i++) {
        L = words[i].ls;
        if (!lines[L] || lines[L].t !== 'x') lines[L] = { t: 'x', w: [] };
        lines[L].w.push(words[i]);
      }
    }
    var maxW = 0;
    for (L = 1; L <= 15; L++) if (lines[L] && lines[L].t === 'x') {
      var s2 = 0; for (i = 0; i < lines[L].w.length; i++) s2 += measure(lines[L].w[i].w) + (i ? sp : 0);
      lines[L].px = s2; if (s2 > maxW) maxW = s2;
    }
    return { lines: lines, maxW: maxW, ok: ok };
  }

  function render(data, N, root, opt) {
    opt = opt || {};
    var cv = document.createElement('canvas').getContext('2d');
    cv.font = '100px HawlHafs';
    var measure = function (s) { return cv.measureText(s).width; };
    var r = layout(data, N, measure);
    var rcs = getComputedStyle(root);
    var cw = (root.clientWidth || 360) - (parseFloat(rcs.paddingLeft) || 0) - (parseFloat(rcs.paddingRight) || 0);
    var pad = Math.round(cw * (opt.pad != null ? opt.pad : 0.04));
    var inner = cw - pad * 2;
    var fit = Math.max(14, Math.min(42, inner * 0.985 / (r.maxW / 100)));
    // تكبير الخط من إعدادات التطبيق (textZoom يضرب كل أحجام الخطوط):
    // حتى ١٠٠٪ تبقى أسطر المصحف كما هي بعرض الشاشة؛ وفوقها يكبر الخط وتنقسم الأسطر الطويلة («وضع القراءة الميسّرة»)
    var z = opt.zoom > 0 ? opt.zoom : 1;
    var flow = z > 1.04;
    var fs = flow ? fit : fit / z;
    var special = N <= 2;
    var page = data.pages[N - 1];
    var firstSura = page[0][0];
    var h = [];
    h.push('<div class="mp-top"><span>الجزء ' + ar(data.juz[N - 1]) + '</span><span>سورة ' + data.names[firstSura - 1] + '</span></div>');
    h.push('<div class="mp-page' + (special ? ' mp-special' : '') + (flow ? ' mp-flow' : '') + '" style="font-size:' + fs.toFixed(2) + 'px;padding:0 ' + pad + 'px">');
    for (var L = 1; L <= 15; L++) {
      var ln = r.lines[L];
      if (!ln) { if (!special) h.push('<div class="mp-l mp-empty"></div>'); continue; }
      if (ln.t === 'h') h.push('<div class="mp-l mp-h"><div class="mp-cart">' + CART + '<span>سورة ' + data.names[ln.s - 1] + '</span></div></div>');
      else if (ln.t === 'b') h.push('<div class="mp-l mp-b">' + BASMALA + '</div>');
      else h.push('<div class="mp-l mp-x">' + ayahSpans(ln.w) + '</div>');
    }
    h.push('</div><div class="mp-num">' + ar(N) + '</div>');
    root.innerHTML = h.join('');
    // قياس المتصفح قد يختلف قليلًا عن قياس اللوحة: نصغّر الخط حتى لا ينكسر أي سطر
    var pg = root.querySelector('.mp-page'), xs = root.querySelectorAll('.mp-x');
    for (var tries = 0; tries < 20 && !flow; tries++) {
      var broken = false;
      for (var q = 0; q < xs.length; q++) {
        var lh = parseFloat(getComputedStyle(xs[q]).lineHeight) || fs * 2.05;
        if (xs[q].scrollHeight > lh * 1.4) { broken = true; break; }
      }
      if (!broken) break;
      fs *= 0.97;
      pg.style.fontSize = fs.toFixed(2) + 'px';
    }
    return r;
  }

  var CSS =
    '.hawl-mp{direction:rtl;font-family:HawlHafs,serif;padding:12px 0 18px;border-radius:18px}' +
    '.hawl-mp .mp-top{display:flex;justify-content:space-between;font:500 13px/1.6 Tajawal,sans-serif;padding:0 16px 6px;opacity:.85}' +
    '.hawl-mp .mp-l{line-height:2.05;min-height:2.05em;overflow:hidden}' +
    '.hawl-mp .mp-x{text-align:justify;text-align-last:justify}' +
    '.hawl-mp .mp-special .mp-x{text-align:center;text-align-last:center}' +
    '.hawl-mp .mp-special{display:flex;flex-direction:column;justify-content:center;min-height:15em}' +
    '.hawl-mp .mp-b{text-align:center}' +
    '.hawl-mp .mp-h{display:flex;align-items:center;justify-content:center}' +
    '.hawl-mp .mp-cart{position:relative;width:86%;height:1.75em;display:flex;align-items:center;justify-content:center}' +
    '.hawl-mp .mp-cart svg{position:absolute;inset:0;width:100%;height:100%}' +
    '.hawl-mp .mp-cart span{position:relative;font-size:.95em;line-height:1;color:var(--mp-t)}' +
    '.hawl-mp .mp-flow .mp-x,.hawl-mp .mp-flow.mp-special .mp-x{text-align:justify;text-align-last:right}' +
    '.hawl-mp .mp-flow .mp-l{line-height:1.9;min-height:0;overflow:visible}' +
    '.hawl-mp .mp-flow .mp-empty{display:none}' +
    '.hawl-mp .mp-num{text-align:center;font:700 14px/1 Tajawal,sans-serif;margin-top:8px;opacity:.85}';
  return { layout: layout, render: render, CSS: CSS };
})();
