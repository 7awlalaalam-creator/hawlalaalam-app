"""يبني assets/quran/mushaf-offline.html: الهيكل (shell.html) + engine.js + frame2.js + offline_app.js في سكربت واحد."""
import os
D = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(D, '..', '..'))
OUT = os.path.join(ROOT, 'app/src/main/assets/quran/mushaf-offline.html')

def build():
    shell = open(os.path.join(D, 'shell.html'), encoding='utf-8').read()
    js = ''.join('\n' + open(os.path.join(D, f), encoding='utf-8').read() for f in ['engine.js', 'frame2.js', 'inflate.js', 'offline_app.js'])
    html = shell.replace('<script></script>', '<script>' + js + '\n</script>')
    open(OUT, 'w', encoding='utf-8').write(html)
    return html

if __name__ == '__main__':
    build()
