/* إطار احترافي على طراز التذهيب في المصاحف المخطوطة (تصميم أصلي، يُرسم بالكود) */
function hawlFrame(W0, H0, c) {
  var sc = c.scale || 1, w = W0 / sc, h = H0 / sc;
  var id = 'hf' + Math.random().toString(36).slice(2, 7), P = [];
  function star8(cx, cy, r, fill, stroke, sw) {
    var pts = [];
    for (var i = 0; i < 16; i++) {
      var a = Math.PI / 8 * i - Math.PI / 2, rr = i % 2 ? r * 0.72 : r;
      pts.push((cx + rr * Math.cos(a)).toFixed(2) + ',' + (cy + rr * Math.sin(a)).toFixed(2));
    }
    return '<polygon points="' + pts.join(' ') + '" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + sw + '" stroke-linejoin="round"/>';
  }
  function rosette(cx, cy, r) {
    var s = '';
    for (var i = 0; i < 8; i++) {
      s += '<ellipse cx="' + cx + '" cy="' + (cy - r * 0.5) + '" rx="' + (r * 0.2) + '" ry="' + (r * 0.42) + '" transform="rotate(' + (45 * i) + ' ' + cx + ' ' + cy + ')" fill="' + c.accent + '" stroke="' + c.gold + '" stroke-width="0.5"/>';
    }
    return s + '<circle cx="' + cx + '" cy="' + cy + '" r="' + (r * 0.22) + '" fill="' + c.gold + '"/>';
  }
  function corner(cx, cy) {
    var s = 18;
    return '<rect x="' + (cx - s) + '" y="' + (cy - s) + '" width="' + (2 * s) + '" height="' + (2 * s) + '" fill="' + c.deep + '" stroke="' + c.gold + '" stroke-width="1.4"/>' +
      '<rect x="' + (cx - s + 3) + '" y="' + (cy - s + 3) + '" width="' + (2 * s - 6) + '" height="' + (2 * s - 6) + '" fill="none" stroke="' + c.gold + '" stroke-width="0.6"/>' +
      star8(cx, cy, 14.5, c.paper, c.gold, 1.2) + star8(cx, cy, 9.8, c.deep, c.gold, 0.8) + rosette(cx, cy, 7.6);
  }
  function medallion(cx, cy, vertical) {
    var L = 34, H = 13, d;
    if (vertical) d = 'M' + cx + ' ' + (cy - L) + ' Q' + (cx + H * 1.6) + ' ' + cy + ' ' + cx + ' ' + (cy + L) + ' Q' + (cx - H * 1.6) + ' ' + cy + ' ' + cx + ' ' + (cy - L) + 'Z';
    else d = 'M' + (cx - L) + ' ' + cy + ' Q' + cx + ' ' + (cy - H * 1.6) + ' ' + (cx + L) + ' ' + cy + ' Q' + cx + ' ' + (cy + H * 1.6) + ' ' + (cx - L) + ' ' + cy + 'Z';
    var s = '<path d="' + d + '" fill="' + c.deep + '" stroke="' + c.gold + '" stroke-width="1.4"/>';
    var sc = 0.66;
    s += '<path d="' + d + '" transform="translate(' + cx * (1 - sc) + ' ' + cy * (1 - sc) + ') scale(' + sc + ')" fill="' + c.paper + '" stroke="' + c.gold + '" stroke-width="1.2"/>';
    return s + rosette(cx, cy, 8);
  }
  var o = 3, b1 = 7, b2 = 27, b3 = 30, b4 = 41, b5 = 45;
  P.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + W0 + '" height="' + H0 + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true"><defs>' +
    // سلسلة دوائر متشابكة (زخرفة هندسية) على شريط داكن
    '<pattern id="' + id + 'c" width="16" height="20" patternUnits="userSpaceOnUse">' +
      '<rect width="16" height="20" fill="' + c.deep + '"/>' +
      '<circle cx="8" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="0" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="16" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="4" cy="10" r="1.3" fill="' + c.accent + '"/><circle cx="12" cy="10" r="1.3" fill="' + c.accent + '"/>' +
    '</pattern>' +
    // شريط أزهار صغيرة على أرضية فاتحة
    '<pattern id="' + id + 'f" width="14" height="11" patternUnits="userSpaceOnUse">' +
      '<rect width="14" height="11" fill="' + c.band + '"/>' +
      '<circle cx="7" cy="3.6" r="1.5" fill="' + c.gold + '"/><circle cx="7" cy="7.4" r="1.5" fill="' + c.gold + '"/>' +
      '<circle cx="5.1" cy="5.5" r="1.5" fill="' + c.gold + '"/><circle cx="8.9" cy="5.5" r="1.5" fill="' + c.gold + '"/>' +
      '<circle cx="7" cy="5.5" r="0.9" fill="' + c.accent + '"/>' +
    '</pattern></defs>');
  function R(i, fill, stroke, sw) {
    return '<rect x="' + i + '" y="' + i + '" width="' + (w - 2 * i) + '" height="' + (h - 2 * i) + '" fill="' + fill + '"' +
      (stroke ? ' stroke="' + stroke + '" stroke-width="' + sw + '"' : '') + '/>';
  }
  P.push(R(o, c.paper, c.gold, 1.6));
  P.push(R(b1, 'url(#' + id + 'c)', c.gold, 1.2));
  P.push(R(b2, c.paper, c.gold, 0.8));
  P.push(R(b3, 'url(#' + id + 'f)', c.gold, 1));
  P.push(R(b4, c.paper, c.gold, 1.4));
  P.push(R(b5, 'none', c.deep, 0.6));
  var k = 20;
  P.push(corner(k, k) + corner(w - k, k) + corner(k, h - k) + corner(w - k, h - k));
  P.push(medallion(w / 2, k, false) + medallion(k, h / 2, true) + medallion(w - k, h / 2, true));
  // رقم الصفحة في ميدالية أسفل الإطار
  if (c.num) {
    // الميدالية تُكبَّر على الشاشات الصغيرة حتى يبقى رقم الصفحة واضحًا
    var m = Math.min(1.9, Math.max(1, 0.85 / sc)), cx = w / 2, cy = h - Math.max(k, 24 * m + 3);
    P.push('<path d="M' + (cx - 46 * m) + ' ' + cy + ' H' + (cx + 46 * m) + '" stroke="' + c.gold + '" stroke-width="1.2"/>' +
      '<circle cx="' + (cx - 40 * m) + '" cy="' + cy + '" r="' + 2.2 * m + '" fill="' + c.gold + '"/><circle cx="' + (cx + 40 * m) + '" cy="' + cy + '" r="' + 2.2 * m + '" fill="' + c.gold + '"/>' +
      star8(cx, cy, 24 * m, c.deep, c.gold, 1.4) +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + 16.5 * m + '" fill="' + c.paper + '" stroke="' + c.gold + '" stroke-width="1.2"/>' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + 13.8 * m + '" fill="none" stroke="' + c.gold + '" stroke-width="0.6"/>' +
      '<text x="' + cx + '" y="' + (cy + 5.2 * m) + '" text-anchor="middle" font-family="Tajawal,sans-serif" font-weight="700" font-size="' + ((c.num.length > 2 ? 12.5 : 15) * m) + '" fill="' + c.numColor + '">' + c.num + '</text>');
  } else P.push(medallion(w / 2, h - k, false));
  P.push('</svg>');
  return P.join('');
}
