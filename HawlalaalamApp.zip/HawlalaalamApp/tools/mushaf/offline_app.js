/* المصحف دون إنترنت: صفحات مصحف المدينة + الضغط على الآية (تفسير، استماع، نسخ، مشاركة كصورة، علامة) + العلامات + البحث */
(function () {
  var night = window.__hawlTheme ? window.__hawlTheme === 'dark'
    : (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', night ? 'dark' : 'light');
  var FC = night ? { paper: '#142A2F', gold: '#C9A876', deep: '#0D2529', band: '#1C383E', accent: '#A65444', numColor: '#E2C892' }
                 : { paper: '#FBF6E8', gold: '#B8924A', deep: '#1F4E4A', band: '#F2E6C9', accent: '#9A3A2E', numColor: '#6E5326' };
  var st = document.createElement('style');
  st.textContent = HawlMushaf.CSS;
  document.head.appendChild(st);

  var $ = function (id) { return document.getElementById(id); };
  var ar = function (n) { return String(n).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); };
  var esc = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var q = /[?&]page=(\d{1,3})/.exec(location.search);
  var N = q ? Math.min(604, Math.max(1, +q[1])) : 1;
  var data = null, wrap = $('fw'), root = $('mp');
  var frameH = 0, frameSc = 1;
  var pageOf = {}, textOf = {}, ayCount = {};      // «سورة:آية» ← الصفحة والنص
  var sel = null, playing = null;

  // ---------------------------------------------------------------- الرسم
  function textZoom() {
    var z = 1;
    try {
      var p = document.createElement('span');
      p.style.cssText = 'position:absolute;visibility:hidden;font-size:100px';
      document.body.appendChild(p);
      z = parseFloat(getComputedStyle(p).fontSize) / 100 || 1;
      p.parentNode.removeChild(p);
    } catch (e) {}
    if (Math.abs(z - 1) < 0.02 && window.__hawlZoom) z = window.__hawlZoom / 100;
    return z > 0.5 && z < 3 ? z : 1;
  }
  function drawFrame() {
    var old = wrap.querySelector(':scope > svg');
    if (old) old.remove();
    var c = {}; for (var k in FC) c[k] = FC[k];
    c.scale = frameSc; c.num = ar(N);
    frameH = wrap.clientHeight;
    wrap.insertAdjacentHTML('afterbegin', hawlFrame(wrap.clientWidth, frameH, c));
  }
  function decorate() {
    var marks = loadMarks(), mk = {};
    for (var i = 0; i < marks.length; i++) mk[marks[i].k] = 1;
    var spans = root.querySelectorAll('.ay');
    for (var j = 0; j < spans.length; j++) {
      var k = spans[j].getAttribute('data-k');
      spans[j].classList.toggle('mk', !!mk[k]);
      spans[j].classList.toggle('sel', k === sel);
      spans[j].classList.toggle('play', !!playing && k === playing);
    }
  }
  function draw() {
    if (!data) return;
    var sc = Math.max(0.45, Math.min(1, (wrap.clientWidth || 360) / 800));
    var mm = Math.min(1.9, Math.max(1, 0.85 / sc));
    var bottom = Math.max(52, 48 * mm + 10) * sc;
    root.style.padding = Math.round(54 * sc) + 'px ' + Math.round(50 * sc) + 'px ' + Math.round(bottom) + 'px';
    HawlMushaf.render(data, N, root, { pad: 0.012, zoom: textZoom() });
    frameSc = sc;
    drawFrame();
    decorate();
    $('pg').value = N;
    document.title = 'صفحة ' + ar(N) + ' من المصحف الشريف';
    $('sura').value = String(data.pages[N - 1][0][0]);
  }
  function go(n, keepScroll) {
    n = Math.min(604, Math.max(1, n | 0));
    if (n === N && data && root.firstChild) return;
    N = n;
    try { history.replaceState(null, '', location.pathname + '?page=' + N); } catch (e) {}
    draw();
    if (!keepScroll) window.scrollTo(0, 0);
  }
  function goAyah(k) {
    var p = pageOf[k];
    if (!p) return;
    sel = k;
    if (p !== N) go(p); else decorate();
    var el = root.querySelector('.ay[data-k="' + k + '"]');
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  // ---------------------------------------------------------------- أدوات
  function toast(t) {
    var el = $('toast');
    el.textContent = t; el.classList.add('on');
    clearTimeout(toast.t); toast.t = setTimeout(function () { el.classList.remove('on'); }, 2200);
  }
  function nameOf(s) { return data.names[s - 1]; }
  function refOf(k) { var p = k.split(':'); return 'سورة ' + nameOf(+p[0]) + ' · الآية ' + ar(p[1]); }
  function plain(k) { return (textOf[k] || '').replace(/\u00a0?[\u0660-\u0669]+\s*$/, '').trim(); }
  function post(o) {
    try { if (window.HawlApp) { window.HawlApp.postMessage(JSON.stringify(o)); return true; } } catch (e) {}
    return false;
  }

  // ---------------------------------------------------------------- اللوحة السفلية
  function sheet(html) {
    $('sheetBody').innerHTML = html;
    $('sheet').classList.add('on');
    $('shade').classList.add('on');
  }
  function closeSheet() {
    $('sheet').classList.remove('on');
    $('shade').classList.remove('on');
    sel = null; decorate();
  }
  $('shade').onclick = closeSheet;
  $('sheetX').onclick = closeSheet;

  function ayahSheet(k) {
    sel = k; decorate();
    sheet('<div class="sh-t">' + esc(refOf(k)) + '</div>' +
      '<div class="acts">' +
      '<button data-act="tafsir">📖<span>التفسير</span></button>' +
      '<button data-act="listen">🎧<span>استمع من هنا</span></button>' +
      '<button data-act="copy">📋<span>نسخ</span></button>' +
      '<button data-act="image">🖼️<span>مشاركة كصورة</span></button>' +
      '<button data-act="mark">🔖<span>علامة وملاحظة</span></button>' +
      '</div>');
    $('sheetBody').querySelectorAll('[data-act]').forEach(function (b) {
      b.onclick = function () {
        var a = b.getAttribute('data-act');
        if (a === 'tafsir') tafsir(k);
        else if (a === 'listen') { closeSheet(); listen(k); }
        else if (a === 'copy') copy(k);
        else if (a === 'image') shareImage(k);
        else if (a === 'mark') markEditor(k);
      };
    });
  }
  root.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('.ay') : null;
    if (t) ayahSheet(t.getAttribute('data-k'));
  });

  // ---------------------------------------------------------------- التفسير (الميسر — دون إنترنت)
  var taf = null;
  function tafsir(k) {
    var show = function () {
      var p = k.split(':'), t = taf.s[+p[0] - 1][+p[1] - 1] || '';
      var prev = (+p[1] > 1) ? p[0] + ':' + (+p[1] - 1) : null, next = (+p[1] < ayCount[+p[0]]) ? p[0] + ':' + (+p[1] + 1) : null;
      sheet('<div class="sh-t">التفسير الميسر · ' + esc(refOf(k)) + '</div>' +
        '<div class="aya-q">' + esc(plain(k)) + '</div>' +
        '<div class="taf">' + esc(t).replace(/\n/g, '<br>') + '</div>' +
        '<div class="src">' + esc(taf.src) + '</div>' +
        '<div class="row2">' + (next ? '<button data-k="' + next + '">الآية التالية ←</button>' : '<span></span>') +
        (prev ? '<button data-k="' + prev + '">→ الآية السابقة</button>' : '<span></span>') + '</div>');
      $('sheetBody').querySelectorAll('[data-k]').forEach(function (b) {
        b.onclick = function () { var nk = b.getAttribute('data-k'); goAyah(nk); tafsir(nk); };
      });
      sel = k; decorate();
    };
    if (taf) return show();
    sheet('<div class="sh-t">جارٍ فتح التفسير…</div>');
    fetch('/__hawl/tafsir.json?v=1').then(function (r) { return r.json(); })
      .then(function (d) { taf = d; show(); })
      .catch(function () { sheet('<div class="sh-t">تعذّر فتح التفسير</div>'); });
  }

  // ---------------------------------------------------------------- الاستماع (يحتاج إنترنت)
  var audio = new Audio(), reciter = 'Alafasy_128kbps';
  function pad3(n) { return ('00' + n).slice(-3); }
  function listen(k) {
    playing = k;
    var p = k.split(':');
    audio.src = 'https://everyayah.com/data/' + reciter + '/' + pad3(p[0]) + pad3(p[1]) + '.mp3';
    audio.play().catch(function () { stopAudio(); toast('الاستماع يحتاج اتصالًا بالإنترنت'); });
    $('player').classList.add('on');
    $('plLabel').textContent = refOf(k);
    $('plPause').textContent = '⏸';
    if (pageOf[k] !== N) go(pageOf[k]);
    decorate();
    var el = root.querySelector('.ay[data-k="' + k + '"]');
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function stopAudio() {
    audio.pause(); playing = null;
    $('player').classList.remove('on');
    decorate();
  }
  audio.onended = function () {
    if (!playing) return;
    var p = playing.split(':'), s = +p[0], a = +p[1];
    if (a < ayCount[s]) listen(s + ':' + (a + 1)); else { stopAudio(); toast('انتهت السورة'); }
  };
  audio.onerror = function () { if (playing) { stopAudio(); toast('تعذّر التشغيل — تأكد من الاتصال بالإنترنت'); } };
  $('plStop').onclick = stopAudio;
  $('plPause').onclick = function () {
    if (audio.paused) { audio.play(); this.textContent = '⏸'; } else { audio.pause(); this.textContent = '▶'; }
  };

  // ---------------------------------------------------------------- النسخ
  function copy(k) {
    var t = '﴿' + plain(k) + '﴾\n[' + refOf(k) + ']';
    var ok = function () { toast('نُسخت الآية'); closeSheet(); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(ok, function () { fallbackCopy(t) ? ok() : toast('تعذّر النسخ'); });
    } else if (fallbackCopy(t)) ok(); else toast('تعذّر النسخ');
  }
  function fallbackCopy(t) {
    try {
      var ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;top:-100px;opacity:0';
      document.body.appendChild(ta); ta.select();
      var r = document.execCommand('copy'); ta.remove(); return r;
    } catch (e) { return false; }
  }

  // ---------------------------------------------------------------- مشاركة كصورة مزخرفة
  function shareImage(k) {
    var W = 1080, pad = 110, fs = 58, lh = fs * 2.0;
    var c = document.createElement('canvas'), g = c.getContext('2d');
    g.font = fs + 'px HawlHafs';
    var words = plain(k).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (g.measureText(t).width > W - pad * 2 && cur) { lines.push(cur); cur = words[i]; } else cur = t;
    }
    if (cur) lines.push(cur);
    var H = Math.max(900, pad * 2 + 140 + lines.length * lh + 170);
    c.width = W; c.height = H;
    var P = night ? { bg: '#0D2529', paper: '#142A2F', ink: '#EFE4CF', gold: '#C9A876', deep: '#1F4E4A' }
                  : { bg: '#1F4E4A', paper: '#FBF6E8', ink: '#16241F', gold: '#B8924A', deep: '#1F4E4A' };
    g.fillStyle = P.bg; g.fillRect(0, 0, W, H);
    g.fillStyle = P.paper; g.fillRect(36, 36, W - 72, H - 72);
    g.strokeStyle = P.gold; g.lineWidth = 6; g.strokeRect(52, 52, W - 104, H - 104);
    g.lineWidth = 2; g.strokeRect(66, 66, W - 132, H - 132);
    var star = function (x, y, r) {
      g.beginPath();
      for (var j = 0; j < 16; j++) { var an = Math.PI / 8 * j - Math.PI / 2, rr = j % 2 ? r * 0.72 : r; g.lineTo(x + rr * Math.cos(an), y + rr * Math.sin(an)); }
      g.closePath(); g.fillStyle = P.gold; g.fill();
    };
    star(66, 66, 24); star(W - 66, 66, 24); star(66, H - 66, 24); star(W - 66, H - 66, 24);
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = P.gold; g.font = '700 40px Tajawal, sans-serif';
    var y0 = Math.max(pad, (H - 60 - (110 + lines.length * lh)) / 2);   // النص في وسط البطاقة
    g.fillText('﴿ ' + refOf(k) + ' ﴾', W / 2, y0 + 40);
    g.fillStyle = P.ink; g.font = fs + 'px HawlHafs';
    for (var L = 0; L < lines.length; L++) g.fillText(lines[L], W / 2, y0 + 150 + L * lh);
    g.fillStyle = P.gold; g.font = '500 30px Tajawal, sans-serif';
    g.fillText('تطبيق حول العالم | القرآن الكريم', W / 2, H - pad + 10);
    var b64 = c.toDataURL('image/png').split(',')[1];
    var sent = post({ cmd: 'share', title: 'مشاركة آية', text: refOf(k),
      files: [{ type: 'image/png', name: 'aya-' + k.replace(':', '-') + '.png', data: b64 }] });
    if (!sent) toast('المشاركة متاحة داخل التطبيق');
    closeSheet();
  }

  // ---------------------------------------------------------------- العلامات والملاحظات
  var KINDS = ['ورد', 'حفظ', 'تدبّر', 'عامة'];
  function loadMarks() { try { return JSON.parse(localStorage.getItem('hawl_marks') || '[]'); } catch (e) { return []; } }
  function saveMarks(m) { try { localStorage.setItem('hawl_marks', JSON.stringify(m)); } catch (e) { toast('تعذّر الحفظ'); } }
  function markEditor(k) {
    var marks = loadMarks(), m = null;
    for (var i = 0; i < marks.length; i++) if (marks[i].k === k) m = marks[i];
    var kind = m ? m.kind : 'عامة';
    var chips = KINDS.map(function (x) { return '<button class="chip' + (x === kind ? ' on' : '') + '" data-kind="' + x + '">' + x + '</button>'; }).join('');
    sheet('<div class="sh-t">علامة · ' + esc(refOf(k)) + '</div>' +
      '<div class="chips">' + chips + '</div>' +
      '<textarea id="note" rows="3" placeholder="ملاحظة قصيرة (اختياري)">' + esc(m ? m.note : '') + '</textarea>' +
      '<div class="row2"><button id="mkSave" class="pri">حفظ</button>' + (m ? '<button id="mkDel">حذف العلامة</button>' : '<span></span>') + '</div>');
    $('sheetBody').querySelectorAll('[data-kind]').forEach(function (b) {
      b.onclick = function () {
        kind = b.getAttribute('data-kind');
        $('sheetBody').querySelectorAll('[data-kind]').forEach(function (x) { x.classList.toggle('on', x === b); });
      };
    });
    $('mkSave').onclick = function () {
      var all = loadMarks().filter(function (x) { return x.k !== k; });
      all.unshift({ k: k, p: pageOf[k], kind: kind, note: $('note').value.trim().slice(0, 300), t: Date.now() });
      saveMarks(all); toast('حُفظت العلامة'); closeSheet();
    };
    if (m) $('mkDel').onclick = function () {
      saveMarks(loadMarks().filter(function (x) { return x.k !== k; })); toast('حُذفت العلامة'); closeSheet();
    };
  }
  function marksList() {
    var marks = loadMarks();
    if (!marks.length) {
      sheet('<div class="sh-t">العلامات</div><div class="empty">لا توجد علامات بعد.<br>اضغط على أي آية ثم «علامة وملاحظة».</div>');
      return;
    }
    var h = marks.map(function (m) {
      return '<button class="res" data-k="' + m.k + '"><b>' + esc(m.kind) + ' · ' + esc(refOf(m.k)) + ' · صفحة ' + ar(m.p) + '</b>' +
        (m.note ? '<span>' + esc(m.note) + '</span>' : '<span class="dim">' + esc(plain(m.k).slice(0, 70)) + '…</span>') + '</button>';
    }).join('');
    sheet('<div class="sh-t">العلامات (' + ar(marks.length) + ')</div><div class="list">' + h + '</div>');
    $('sheetBody').querySelectorAll('[data-k]').forEach(function (b) {
      b.onclick = function () { var k = b.getAttribute('data-k'); closeSheet(); goAyah(k); };
    });
  }

  // ---------------------------------------------------------------- البحث دون إنترنت
  var idx = null;
  var norm = function (t) {
    return String(t).replace(/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
      .replace(/\s+/g, ' ').trim();
  };
  function search() {
    sheet('<div class="sh-t">البحث في القرآن</div>' +
      '<input id="sq" type="search" placeholder="اكتب كلمة أو جزءًا من آية" autocomplete="off">' +
      '<div class="dim" id="sinfo">يعمل دون إنترنت، ولا يلزم التشكيل.</div><div class="list" id="sres"></div>');
    var inp = $('sq'), tm = 0;
    setTimeout(function () { inp.focus(); }, 150);
    var run = function () {
      var qv = norm(inp.value);
      if (qv.length < 2) { $('sres').innerHTML = ''; $('sinfo').textContent = 'يعمل دون إنترنت، ولا يلزم التشكيل.'; return; }
      var out = [], total = 0;
      for (var i = 0; i < idx.length; i++) {
        if (idx[i][4].indexOf(qv) >= 0) { total++; if (out.length < 60) out.push(idx[i]); }
      }
      $('sinfo').textContent = total ? 'عدد النتائج: ' + ar(total) + (total > 60 ? ' (يظهر أول ٦٠)' : '') : 'لا نتائج';
      $('sres').innerHTML = out.map(function (r) {
        return '<button class="res" data-k="' + r[0] + ':' + r[1] + '"><b>سورة ' + esc(nameOf(r[0])) + ' · ' + ar(r[1]) +
          ' · صفحة ' + ar(r[2]) + '</b><span>' + esc(r[3]) + '</span></button>';
      }).join('');
      $('sres').querySelectorAll('[data-k]').forEach(function (b) {
        b.onclick = function () { var k = b.getAttribute('data-k'); closeSheet(); goAyah(k); };
      });
    };
    inp.oninput = function () { clearTimeout(tm); tm = setTimeout(run, 180); };
    if (!idx) {
      $('sinfo').textContent = 'جارٍ التحضير…';
      fetch('/__hawl/search.json?v=1').then(function (r) { return r.json(); }).then(function (d) {
        for (var i = 0; i < d.length; i++) d[i].push(norm(d[i][3]));
        idx = d; $('sinfo').textContent = 'يعمل دون إنترنت، ولا يلزم التشكيل.'; run();
      }).catch(function () { $('sinfo').textContent = 'تعذّر فتح البحث'; });
    }
  }
  $('btnSearch').onclick = search;
  $('btnMarks').onclick = marksList;

  // ---------------------------------------------------------------- التنقل
  var sx = 0, sy = 0, t0 = 0;
  wrap.addEventListener('touchstart', function (e) { var t = e.touches[0]; sx = t.clientX; sy = t.clientY; t0 = Date.now(); }, { passive: true });
  wrap.addEventListener('touchend', function (e) {
    var t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5 && Date.now() - t0 < 800) go(N + (dx > 0 ? 1 : -1));
  }, { passive: true });
  $('next').onclick = function () { go(N + 1); };
  $('prev').onclick = function () { go(N - 1); };
  $('pg').onchange = function () { go(+this.value); };
  $('sura').onchange = function () { var s = +this.value; goAyah(s + ':1'); sel = null; decorate(); };
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 200); });
  try { new ResizeObserver(function () { if (Math.abs(wrap.clientHeight - frameH) > 2) drawFrame(); }).observe(root); } catch (e) {}

  Promise.all([
    fetch('/__hawl/mushaf.json?v=18').then(function (r) { return r.json(); }),
    document.fonts ? document.fonts.load('100px HawlHafs') : Promise.resolve()
  ]).then(function (res) {
    data = res[0];
    for (var p = 0; p < 604; p++) {
      var pg = data.pages[p];
      for (var i = 0; i < pg.length; i++) {
        var k = pg[i][0] + ':' + pg[i][1];
        if (!pageOf[k]) pageOf[k] = p + 1;
        textOf[k] = pg[i][4];
        ayCount[pg[i][0]] = Math.max(ayCount[pg[i][0]] || 0, pg[i][1]);
      }
    }
    var h = '';
    for (var s = 0; s < 114; s++) h += '<option value="' + (s + 1) + '">' + ar(s + 1) + ' · ' + data.names[s] + '</option>';
    $('sura').innerHTML = h;
    var hp = '';
    for (var n = 1; n <= 604; n++) hp += '<option value="' + n + '">صفحة ' + ar(n) + '</option>';
    $('pg').innerHTML = hp;
    draw();
  }).catch(function () {
    root.innerHTML = '<p style="text-align:center;padding:40px 10px">تعذّر فتح المصحف. أعد تشغيل التطبيق.</p>';
  });
})();
