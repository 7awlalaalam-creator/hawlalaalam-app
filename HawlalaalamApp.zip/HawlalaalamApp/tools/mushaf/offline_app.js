/* المصحف دون إنترنت: صفحات مصحف المدينة + الضغط على الآية (تفسير، استماع، نسخ، مشاركة كصورة، علامة) + العلامات + البحث */
(function () {
  var night = window.__hawlTheme ? window.__hawlTheme === 'dark'
    : (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', night ? 'dark' : 'light');
  var FC = night ? { paper: '#142A2F', gold: '#C9A876', deep: '#0D2529', band: '#1C383E', accent: '#A65444', numColor: '#E2C892' }
                 : { paper: '#FBF6E8', gold: '#B8924A', deep: '#1F4E4A', band: '#F2E6C9', accent: '#9A3A2E', numColor: '#6E5326' };
  var st = document.createElement('style');
  st.textContent = HawlMushaf.CSS;
  document.head.appendChild(st);

  var $ = function (id) { return document.getElementById(id); };
  var ar = function (n) { return String(n).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); };
  var esc = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var q = /[?&]page=(\d{1,3})/.exec(location.search);
  var N = q ? Math.min(604, Math.max(1, +q[1])) : 1;
  // أداة مطلوبة من شاشات التطبيق تُقرأ ثم تُحذف من العنوان، حتى لا يحفظها «تابع القراءة» فتُفتح كل مرة
  var startTool = /[?&]hifz=1/.test(location.search) ? 'hifz' : (/[?&]find=1/.test(location.search) ? 'find' : '');
  var restoreReq = /[?&]restore=1/.test(location.search);    // التطبيق استعاد نسخة احتياطية: نطلب بياناتها بعد التحميل
  if (startTool || restoreReq) { try { history.replaceState(null, '', location.pathname + '?page=' + N); } catch (e) {} }
  var data = null, wrap = $('fw'), root = $('mp');
  var frameH = 0, frameSc = 1;
  var pageOf = {}, textOf = {}, ayCount = {};      // «سورة:آية» ← الصفحة والنص
  var sel = null, playing = null;

  // ---------------------------------------------------------------- وضع القراءة: نص منساب بخط كبير + الشريط الرفيع + لوحة Aa
  // الأحجام الخمسة بالبكسل الفعلي؛ المسافة بين الأسطر لكل حجم (متقاربة، متوسطة، واسعة)
  var RD_SIZES = [24, 28, 32, 38, 44];
  var RD_LH = [[1.95, 2.2, 2.45], [1.95, 2.2, 2.45], [1.9, 2.15, 2.4], [1.85, 2.05, 2.3], [1.8, 2.0, 2.2]];
  var RD_NAMES = ['صغير', 'متوسط', 'كبير', 'كبير جدًا', 'الأكبر'];
  var RD_SP = ['متقاربة', 'متوسطة', 'واسعة'];
  var RD_BASMALA = 'بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ';
  var RD_CART = '<svg viewBox="0 0 320 44" preserveAspectRatio="none" aria-hidden="true">' +
    '<path d="M2 22 L22 2 H298 L318 22 L298 42 H22Z" fill="var(--mp-d)" stroke="var(--mp-g)" stroke-width="1.6"/>' +
    '<path d="M14 22 L27 8 H293 L306 22 L293 36 H27Z" fill="var(--mp-p)" stroke="var(--mp-g)" stroke-width="1"/>' +
    '<path d="M30 22 l6 -6 l6 6 l-6 6Z M278 22 l6 -6 l6 6 l-6 6Z" fill="var(--mp-a)" stroke="var(--mp-g)" stroke-width=".8"/>' +
    '<circle cx="8" cy="22" r="2" fill="var(--mp-g)"/><circle cx="312" cy="22" r="2" fill="var(--mp-g)"/></svg>';
  var rd = $('rd');
  function loadRS() {
    // أول فتح: وضع القراءة، وحجم الخط يبدأ من «حجم الخط» في إعدادات التطبيق
    var z = (window.__hawlZoom || 100) / 100;
    var d = { mode: 'read', size: z < 1.1 ? 2 : (z < 1.3 ? 3 : 4), sp: 1, paper: 'white', taf: 'muyassar', tr: '' };
    try {
      var o = JSON.parse(localStorage.getItem('hawl_reader') || 'null');
      if (o) for (var k in d) if (o[k] != null) d[k] = o[k];
    } catch (e) {}
    d.size = Math.max(0, Math.min(4, d.size | 0));
    d.sp = Math.max(0, Math.min(2, d.sp | 0));
    if (d.mode !== 'mushaf' && d.mode !== 'tafsir' && d.mode !== 'tajweed') d.mode = 'read';
    if (typeof d.taf !== 'string' || !d.taf) d.taf = 'muyassar';
    if (typeof d.tr !== 'string') d.tr = '';
    if (d.paper !== 'cream') d.paper = 'white';
    return d;
  }
  var RS = loadRS();
  function saveRS() { try { localStorage.setItem('hawl_reader', JSON.stringify(RS)); } catch (e) {} }
  function reading() { return RS.mode !== 'mushaf'; }       // «القراءة» و«مع التفسير» كلاهما نص منساب
  function withTafsir() { return RS.mode === 'tafsir'; }
  function withTajweed() { return RS.mode === 'tajweed'; }
  function scopeEl() { return reading() ? rd : root; }
  // أندرويد يضرب أحجام الخطوط في «حجم الخط» (textZoom)، وآيفون لا يفعل: نقيس الضرب الفعلي ونقسم عليه
  function cssZoom() {
    var z = 1;
    try {
      var p = document.createElement('span');
      p.style.cssText = 'position:absolute;visibility:hidden;font-size:100px';
      document.body.appendChild(p);
      z = parseFloat(getComputedStyle(p).fontSize) / 100 || 1;
      p.parentNode.removeChild(p);
    } catch (e) {}
    return z > 0.5 && z < 3 ? z : 1;
  }
  function applyMode() {
    var h = document.documentElement;
    h.classList.toggle('reading', reading());
    h.classList.toggle('cream', reading() && !night && RS.paper === 'cream');
    if (!reading()) h.classList.remove('chrome');
  }
  function drawRead() {
    var again = function () { if (reading()) { drawRead(); decorate(); } };
    if (withTafsir() && !tafReady(RS.taf)) {              // التفسير يُحمَّل مرة ثم يُعاد الرسم
      rd.innerHTML = '<p class="rd-wait">جارٍ فتح التفسير…</p>';
      tafLoad(RS.taf, again, function () { RS.taf = 'muyassar'; saveRS(); again(); });
      return;
    }
    if (withTajweed() && !tj) {
      rd.innerHTML = '<p class="rd-wait">جارٍ فتح مصحف التجويد…</p>';
      tjLoad(again, function () { RS.mode = 'read'; saveRS(); again(); });
      return;
    }
    if (RS.tr && !trReady(RS.tr)) {
      rd.innerHTML = '<p class="rd-wait">جارٍ فتح الترجمة…</p>';
      trLoad(RS.tr, again, function () { RS.tr = ''; saveRS(); again(); });
      return;
    }
    var trOn = !!RS.tr && !withTajweed();
    var page = data.pages[N - 1], z = cssZoom();
    tafShown = {};
    var fs = RD_SIZES[RS.size] / z, lh = RD_LH[RS.size][RS.sp];
    var h = [], para = [];
    var flush = function () { if (para.length) { h.push('<p class="rd-p">' + para.join(' ') + '</p>'); para = []; } };
    h.push('<div class="rd-top"><span>سورة ' + esc(nameOf(page[0][0])) + '</span><span>الجزء ' + ar(data.juz[N - 1]) + '، صفحة ' + ar(N) + '</span></div>');
    h.push('<div class="rd-body' + (withTafsir() || trOn ? ' tf' : '') + (withTajweed() ? ' tjm' : '') + '" style="font-size:' + fs.toFixed(2) + 'px;line-height:' + lh + ';text-align:' + (RS.size === 0 || withTafsir() ? 'justify' : 'center') + ';--tf:' + Math.max(15, Math.min(22, fs * 0.5)).toFixed(1) + 'px">');
    for (var i = 0; i < page.length; i++) {
      var e = page[i], s = e[0], a = e[1];
      if (a === 1) {
        flush();
        h.push('<div class="rd-cart">' + RD_CART + '<span>سورة ' + esc(nameOf(s)) + '</span></div>');
        if (s !== 1 && s !== 9) h.push('<div class="rd-bas">' + RD_BASMALA + '</div>');
      }
      // آخر كلمة ورقم الآية لا ينفصلان: لا يبدأ سطر برقم آية
      var k = s + ':' + a, body;
      if (withTajweed() && tj.a[k]) body = tjHtml(k) + '\u00a0<span class="nw">' + ar(a) + '</span>';
      else body = wordsHtml(e[4]);
      para.push('<span class="ay' + (withTajweed() ? ' tjw' : '') + '" data-k="' + k + '">' + body + '</span>');
      // «مع التفسير»: كل آية ثم تفسيرها تحتها بخط الواجهة (التفسير المختار من المكتبة)
      if (withTafsir()) { flush(); h.push(tafBlock(k)); }
      if (trOn) { flush(); h.push(trBlock(k)); }
    }
    flush();
    h.push('</div>');
    rd.innerHTML = h.join('');
  }
  function updateSlim() {
    var s = data.pages[N - 1][0][0];
    $('slPg').textContent = 'صفحة ' + ar(N);
    $('slSub').textContent = 'سورة ' + nameOf(s) + '، الجزء ' + ar(data.juz[N - 1]);
  }
  function rsRedraw() {
    // إعادة الرسم مع الإبقاء على موضع القراءة تقريبًا
    var de = document.documentElement, ratio = de.scrollHeight > innerHeight ? scrollY / (de.scrollHeight - innerHeight) : 0;
    draw();
    if (ratio > 0) window.scrollTo(0, ratio * Math.max(0, de.scrollHeight - innerHeight));
  }
  function seg(name, items, cur) {
    return '<div class="seg" role="radiogroup" aria-label="' + name + '">' + items.map(function (it) {
      return '<button type="button" role="radio" data-v="' + it[0] + '" aria-checked="' + (String(it[0]) === String(cur)) + '">' + it[1] + '</button>';
    }).join('') + '</div>';
  }
  function readerSheet() {
    var h = '<div class="sh-t">إعدادات القراءة</div>' +
      '<div class="rs-sec" data-g="mode">' + seg('طريقة العرض', [['read', 'القراءة'], ['tafsir', 'التفسير'], ['tajweed', 'التجويد'], ['mushaf', 'المصحف']], RS.mode) + '</div>';
    if (withTafsir()) h += '<div class="rs-h"><span>التفسير</span><b>' + esc(tafName(RS.taf)) + '</b></div><div class="chips" id="rsTaf">' + tafChips(RS.taf) + '</div>';
    if (withTajweed()) h += '<div class="dim rs-note">ألوان أحكام التجويد برواية حفص عن عاصم. <button class="lnk" id="rsTjKey">دليل الألوان</button></div>';
    if (reading() && !withTajweed()) h += '<div class="rs-h"><span>ترجمة المعاني تحت كل آية</span><b>' + (RS.tr ? esc(trShort(RS.tr)) : 'بدون') + '</b></div><div class="chips" id="rsTr">' + trChips(RS.tr) + '</div>';
    if (reading()) {
      h += '<div class="rs-h"><label for="rsz">حجم الخط</label><b id="rsName">' + RD_NAMES[RS.size] + '</b></div>' +
        '<div class="rs-row"><span class="a1" aria-hidden="true">أ</span>' +
        '<input id="rsz" type="range" min="0" max="4" step="1" value="' + RS.size + '" aria-valuetext="' + RD_NAMES[RS.size] + '">' +
        '<span class="a2" aria-hidden="true">أ</span></div>' +
        '<div class="rs-h"><span>المسافة بين الأسطر</span></div>' +
        '<div class="rs-sec" data-g="sp">' + seg('المسافة بين الأسطر', RD_SP.map(function (t, i) { return [i, t]; }), RS.sp) + '</div>';
      if (!night) h += '<div class="rs-h"><span>لون الورقة</span></div>' +
        '<div class="rs-sec" data-g="paper">' + seg('لون الورقة', [['white', 'أبيض'], ['cream', 'كريمي']], RS.paper) + '</div>';
      else h += '<div class="dim">ألوان الصفحة تتبع الوضع الليلي في التطبيق.</div>';
    } else {
      h += '<div class="dim rs-note">صفحة المصحف مطابقة لأسطر مصحف المدينة، فيكون خطها بعرض الشاشة. للخط الأكبر اختر «وضع القراءة»، أو اقلب الجوال أفقيًا.</div>';
    }
    h += '<button class="as-start" id="rsAuto">' + (AS.on ? '■ إيقاف التمرير التلقائي' : '▶ التمرير التلقائي للصفحات') + '</button>';
    h += '<div class="row2"><button id="rsLib">📚 التفاسير والترجمات</button><button id="rsSrc">المصادر</button></div>';
    sheet(h);
    $('rsAuto').onclick = function () { closeSheet(); if (AS.on) asStop(); else asStart(); };
    $('rsLib').onclick = function () { libSheet(); };
    $('rsSrc').onclick = sourcesSheet;
    if ($('rsTjKey')) $('rsTjKey').onclick = tjLegend;
    var pickTaf = $('rsTaf'), pickTr = $('rsTr');
    if (pickTaf) pickTaf.querySelectorAll('[data-taf]').forEach(function (b) {
      b.onclick = function () { var v = b.getAttribute('data-taf'); if (v === '+') { libSheet('taf'); return; } RS.taf = v; saveRS(); rsRedraw(); readerSheet(); };
    });
    if (pickTr) pickTr.querySelectorAll('[data-tr]').forEach(function (b) {
      b.onclick = function () { var v = b.getAttribute('data-tr'); if (v === '+') { libSheet('tr'); return; } RS.tr = v; saveRS(); rsRedraw(); readerSheet(); };
    });
    $('shade').classList.add('clear');
    var body = $('sheetBody');
    body.querySelectorAll('.rs-sec').forEach(function (sec) {
      var g = sec.getAttribute('data-g');
      sec.querySelectorAll('[data-v]').forEach(function (b) {
        b.onclick = function () {
          var v = b.getAttribute('data-v');
          if (g === 'mode') {
            if (v === RS.mode) return;
            RS.mode = v; saveRS(); draw(); window.scrollTo(0, 0); readerSheet(); return;
          }
          if (g === 'sp') RS.sp = +v; else RS.paper = v;
          saveRS();
          sec.querySelectorAll('[data-v]').forEach(function (x) { x.setAttribute('aria-checked', String(x === b)); });
          rsRedraw();
        };
      });
    });
    var rng = $('rsz');
    if (rng) rng.oninput = function () {
      RS.size = +rng.value; saveRS();
      $('rsName').textContent = RD_NAMES[RS.size];
      rng.setAttribute('aria-valuetext', RD_NAMES[RS.size]);
      rsRedraw();
    };
  }

  // ---------------------------------------------------------------- التمرير التلقائي (اختياري: يشغّله القارئ ويحدّد سرعته)
  // ينزل بالصفحة بسرعة ثابتة، وفي آخرها ينتقل إلى الصفحة التالية. لمس الشاشة يوقفه مؤقتًا ما دام الإصبع عليها.
  var AS = { on: false, run: false, hold: false, t: 0, acc: 0, raf: 0, wait: 0,
    sp: (function () { try { var v = +localStorage.getItem('hawl_autoscroll'); return v >= 1 && v <= 10 ? v : 3; } catch (e) { return 3; } })() };
  function asPx() { return 6 + (AS.sp - 1) * 6; }            // بكسل في الثانية: ١ ← ٦ … ١٠ ← ٦٠
  function asUi() {
    var b = $('asb'); if (!b) return;
    b.classList.toggle('on', AS.on);
    document.documentElement.classList.toggle('autoscroll', AS.on);
    $('asPlay').textContent = AS.run ? '⏸' : '▶';
    $('asPlay').setAttribute('aria-label', AS.run ? 'إيقاف مؤقت' : 'متابعة');
    $('asSp').textContent = 'السرعة ' + ar(AS.sp);
  }
  function asTick(ts) {
    AS.raf = 0;
    if (!AS.on || !AS.run) return;
    var dt = AS.t ? Math.min(0.1, (ts - AS.t) / 1000) : 0;
    AS.t = ts;
    var de = document.documentElement;
    var sheetOn = $('sheet').classList.contains('on');
    if (!AS.hold && !sheetOn && !AS.wait) {
      awake();
      var end = de.scrollHeight - innerHeight - 2;
      if (scrollY >= end) {
        if (N >= 604) { asStop(); toast('صدق الله العظيم'); return; }
        AS.wait = setTimeout(function () { AS.wait = 0; if (AS.on && AS.run) { go(N + 1); AS.acc = 0; } }, 1500);
      } else {
        AS.acc += asPx() * dt;
        var step = Math.floor(AS.acc);
        if (step >= 1) { AS.acc -= step; window.scrollBy(0, step); }
      }
    }
    AS.raf = requestAnimationFrame(asTick);
  }
  function asRun(v) {
    AS.run = v; AS.t = 0;
    if (!v) { clearTimeout(AS.wait); AS.wait = 0; }
    if (v && !AS.raf) AS.raf = requestAnimationFrame(asTick);
    asUi();
  }
  function asStart() {
    if (!$('asb')) {
      var b = document.createElement('div');
      b.className = 'asb'; b.id = 'asb';
      b.setAttribute('role', 'toolbar'); b.setAttribute('aria-label', 'التمرير التلقائي');
      b.innerHTML = '<button id="asPlay"></button><span id="asSp"></span>' +
        '<span class="as-pm"><button id="asMinus" aria-label="أبطأ">−</button><button id="asPlus" aria-label="أسرع">+</button></span>' +
        '<button id="asX" aria-label="إغلاق التمرير التلقائي">✕</button>';
      document.body.appendChild(b);
      var setSp = function (d) {
        AS.sp = Math.max(1, Math.min(10, AS.sp + d));
        try { localStorage.setItem('hawl_autoscroll', String(AS.sp)); } catch (e) {}
        asUi();
      };
      $('asPlay').onclick = function () { asRun(!AS.run); };
      $('asMinus').onclick = function () { setSp(-1); };
      $('asPlus').onclick = function () { setSp(1); };
      $('asX').onclick = asStop;
    }
    AS.on = true; AS.acc = 0;
    asRun(true);
  }
  function asStop() {
    AS.on = false;
    asRun(false);
    if (AS.raf) { cancelAnimationFrame(AS.raf); AS.raf = 0; }
  }
  // لمسة أو تمرير تلقائي: نمدّد بقاء الشاشة مضاءة (تنطفئ بعد ١٠ دقائق دون نشاط توفيرًا للبطارية)
  var awakeAt = 0;
  function awake() { var n = Date.now(); if (n - awakeAt > 60000) { awakeAt = n; post({ cmd: 'awake' }); } }
  window.addEventListener('touchstart', awake, { passive: true });
  // الإصبع على الشاشة: يقرأ القارئ أو يحرّك الصفحة بنفسه، فنتوقف حتى يرفعه
  window.addEventListener('touchstart', function (e) {
    if (AS.on && !(e.target.closest && e.target.closest('#asb'))) AS.hold = true;
  }, { passive: true });
  var asRel = function () { if (AS.hold) setTimeout(function () { AS.hold = false; AS.t = 0; }, 600); };
  window.addEventListener('touchend', asRel, { passive: true });
  window.addEventListener('touchcancel', asRel, { passive: true });
  document.addEventListener('visibilitychange', function () { if (document.hidden && AS.on && AS.run) asRun(false); });
  function playPage() {
    var e = data.pages[N - 1][0];
    if (playing) { stopAudio(); return; }
    listen(e[0] + ':' + e[1]);
  }

  // ---------------------------------------------------------------- الرسم
  function textZoom() {
    var z = 1;
    try {
      var p = document.createElement('span');
      p.style.cssText = 'position:absolute;visibility:hidden;font-size:100px';
      document.body.appendChild(p);
      z = parseFloat(getComputedStyle(p).fontSize) / 100 || 1;
      p.parentNode.removeChild(p);
    } catch (e) {}
    if (Math.abs(z - 1) < 0.02 && window.__hawlZoom) z = window.__hawlZoom / 100;
    return z > 0.5 && z < 3 ? z : 1;
  }
  function drawFrame() {
    var old = wrap.querySelector(':scope > svg');
    if (old) old.remove();
    if (reading() || wrap.clientWidth < 60 || wrap.clientHeight < 60) return;   // الإطار لصفحة المصحف فقط (مخفي في وضع القراءة)
    var c = {}; for (var k in FC) c[k] = FC[k];
    c.scale = frameSc; c.num = ar(N);
    frameH = wrap.clientHeight;
    wrap.insertAdjacentHTML('afterbegin', hawlFrame(wrap.clientWidth, frameH, c));
  }
  function decorate() {
    var marks = loadMarks(), mk = {}, hl = hlLoad(), wk = hzWeakSet();
    for (var i = 0; i < marks.length; i++) mk[marks[i].k] = 1;
    var spans = scopeEl().querySelectorAll('.ay');
    for (var j = 0; j < spans.length; j++) {
      var k = spans[j].getAttribute('data-k');
      spans[j].classList.toggle('mk', !!mk[k]);
      for (var c = 1; c <= 4; c++) spans[j].classList.toggle('hl' + c, hl[k] === c);
      spans[j].classList.toggle('wk', !!wk[k]);
      spans[j].classList.toggle('sel', k === sel);
      spans[j].classList.toggle('play', !!playing && k === playing);
    }
  }
  function draw() {
    if (!data) return;
    applyMode();
    if (reading()) {
      drawRead();
      decorate();
      $('pg').value = N;
      document.title = 'صفحة ' + ar(N) + ' من المصحف الشريف';
      $('sura').value = String(data.pages[N - 1][0][0]);
      updateSlim();
      return;
    }
    var sc = Math.max(0.45, Math.min(1, (wrap.clientWidth || 360) / 800));
    var mm = Math.min(1.9, Math.max(1, 0.85 / sc));
    var bottom = Math.max(52, 48 * mm + 10) * sc;
    root.style.padding = Math.round(54 * sc) + 'px ' + Math.round(50 * sc) + 'px ' + Math.round(bottom) + 'px';
    HawlMushaf.render(data, N, root, { pad: 0.012, zoom: textZoom() });
    frameSc = sc;
    drawFrame();
    decorate();
    $('pg').value = N;
    document.title = 'صفحة ' + ar(N) + ' من المصحف الشريف';
    $('sura').value = String(data.pages[N - 1][0][0]);
    updateSlim();
  }
  function go(n, keepScroll) {
    n = Math.min(604, Math.max(1, n | 0));
    if (n === N && data && root.firstChild) return;
    N = n;
    try { history.replaceState(null, '', location.pathname + '?page=' + N); } catch (e) {}
    draw();
    if (!keepScroll) window.scrollTo(0, 0);
  }
  function goAyah(k) {
    var p = pageOf[k];
    if (!p) return;
    sel = k;
    if (p !== N) go(p); else decorate();
    var el = scopeEl().querySelector('.ay[data-k="' + k + '"]');
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  // ---------------------------------------------------------------- أدوات
  function toast(t) {
    var el = $('toast');
    el.textContent = t; el.classList.add('on');
    clearTimeout(toast.t); toast.t = setTimeout(function () { el.classList.remove('on'); }, 2200);
  }
  function nameOf(s) { return data.names[s - 1]; }
  function refOf(k) { var p = k.split(':'); return 'سورة ' + nameOf(+p[0]) + ' · الآية ' + ar(p[1]); }
  function plain(k) { return (textOf[k] || '').replace(/\u00a0?[\u0660-\u0669]+\s*$/, '').trim(); }
  function post(o) {
    try { if (window.HawlApp) { window.HawlApp.postMessage(JSON.stringify(o)); return true; } } catch (e) {}
    return false;
  }

  // ---------------------------------------------------------------- جسر الحالة (النسخ الاحتياطي والمزامنة)
  // كل ما تحفظه الصفحة مفاتيح localStorage تبدأ بـ hawl_؛ نرسل نسخة منها للتطبيق بعد أي تغيير (مؤجّلة ثانية)
  // فيحفظها مع نسخته الاحتياطية، وعند الاستعادة يعيدها عبر window.__hawlRestore
  var stT = 0;
  function stateDump() {
    var o = {};
    try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k && k.indexOf('hawl_') === 0) o[k] = localStorage.getItem(k); } } catch (e) {}
    return o;
  }
  function stateNow() { clearTimeout(stT); post({ cmd: 'state', data: stateDump() }); }
  function stateSoon() { clearTimeout(stT); stT = setTimeout(stateNow, 1000); }
  try {
    var lsSet = Storage.prototype.setItem, lsRm = Storage.prototype.removeItem;
    Storage.prototype.setItem = function (k, v) { lsSet.call(this, k, v); if (this === window.localStorage && /^hawl_/.test(k)) stateSoon(); };
    Storage.prototype.removeItem = function (k) { lsRm.call(this, k); if (this === window.localStorage && /^hawl_/.test(k)) stateSoon(); };
  } catch (e) {}
  window.__hawlRestore = function (o) {
    try { if (typeof o === 'string') o = JSON.parse(o); } catch (e) { return false; }
    if (!o || typeof o !== 'object') return false;
    try {
      var old = [];
      for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k && k.indexOf('hawl_') === 0) old.push(k); }
      old.forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(o, k)) localStorage.removeItem(k); });
      Object.keys(o).forEach(function (k) {
        if (k.indexOf('hawl_') === 0 && o[k] != null) localStorage.setItem(k, typeof o[k] === 'string' ? o[k] : JSON.stringify(o[k]));
      });
    } catch (e) { toast('تعذّرت الاستعادة'); return false; }
    if ($('sheet').classList.contains('on')) closeSheet();
    RS = loadRS();
    if (data) { draw(); if (Object.keys(hzLoad()).length) hzSave(hzLoad()); else post({ cmd: 'hifz', due: 0, total: 0, held: 0, pct: 0, next: -1, today: hzDay() }); }
    stateNow();
    toast('استُعيدت بياناتك');
    return true;
  };

  // ---------------------------------------------------------------- اللوحة السفلية
  function sheet(html) {
    $('sheetBody').innerHTML = html;
    $('sheet').classList.add('on');
    $('shade').classList.add('on');
  }
  function closeSheet() {
    if (ts && ts.state === 'listening') tsStop();
    ts = null;
    $('sheet').classList.remove('on');
    $('shade').classList.remove('on', 'clear');
    sel = null; decorate();
  }
  $('shade').onclick = closeSheet;
  $('sheetX').onclick = closeSheet;

  function ayahSheet(k) {
    sel = k; decorate();
    sheet('<div class="sh-t">' + esc(refOf(k)) + '</div>' +
      '<div class="acts">' +
      '<button data-act="tafsir">📖<span>التفسير</span></button>' +
      '<button data-act="listen">🎧<span>استمع من هنا</span></button>' +
      '<button data-act="copy">📋<span>نسخ</span></button>' +
      '<button data-act="image">🖼️<span>مشاركة كصورة</span></button>' +
      '<button data-act="mark">🔖<span>علامة وملاحظة</span></button>' +
      '<button data-act="hl">🖍️<span>' + (hlOf(k) ? 'تظليل ✓' : 'تظليل بلون') + '</span></button>' +
      '<button data-act="col">🗂️<span>أضف لمجموعة</span></button>' +
      '<button data-act="hifz">🧩<span>' + (hifzHas(k) ? 'في حفظي ✓' : 'أضفها لحفظي') + '</span></button>' +
      '<button data-act="tasmee">🎙️<span>سمّع من هنا</span></button>' +
      '<button data-act="words">🔤<span>معاني الكلمات</span></button>' +
      (mutOf(k).length ? '<button data-act="mut">≈<span>متشابهات (' + ar(mutOf(k).length) + ')</span></button>' : '') +
      '</div>');
    $('sheetBody').querySelectorAll('[data-act]').forEach(function (b) {
      b.onclick = function () {
        var a = b.getAttribute('data-act');
        if (a === 'tafsir') tafsir(k);
        else if (a === 'listen') { closeSheet(); listen(k); }
        else if (a === 'copy') copy(k);
        else if (a === 'image') shareImage(k);
        else if (a === 'mark') markEditor(k);
        else if (a === 'hl') hlEditor(k);
        else if (a === 'col') colEditor(k);
        else if (a === 'hifz') hifzAdd(k);
        else if (a === 'words') wordsSheet(k);
        else if (a === 'mut') mutSheet(k);
        else if (a === 'tasmee') { var pk = [], pp = k.split(':'); for (var x = +pp[1]; x <= Math.min(ayCount[+pp[0]], +pp[1] + 4); x++) pk.push(pp[0] + ':' + x); tasmee(pk, true); }
      };
    });
  }
  root.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('.ay') : null;
    if (t) ayahSheet(t.getAttribute('data-k'));
  });
  // وضع القراءة: لمس الآية يفتح أدواتها، ولمس الصفحة يُظهر أدوات التنقل والبحث أو يخفيها
  rd.addEventListener('click', function (e) {
    if (lpFired) { lpFired = false; e.preventDefault(); return; }
    var t = e.target.closest ? e.target.closest('.ay') : null;
    if (t) { ayahSheet(t.getAttribute('data-k')); return; }
    document.documentElement.classList.toggle('chrome');
  });
  $('slAa').onclick = readerSheet;
  $('slPlay').onclick = function () { if (data) playPage(); };

  // ---------------------------------------------------------------- التفسير (الميسر — دون إنترنت)
  var taf = null, tafWait = [];
  function loadTafsir(cb) {
    if (taf) { cb(); return; }
    tafWait.push(cb);
    if (tafWait.length > 1) return;
    fetch('/__hawl/tafsir.json?v=1').then(function (r) { return r.json(); })
      .then(function (d) { taf = d; var w = tafWait; tafWait = []; w.forEach(function (f) { f(); }); })
      .catch(function () { tafWait = []; toast('تعذّر فتح التفسير'); });
  }
  function tafOf(k) { var p = k.split(':'); return (taf && taf.s[+p[0] - 1] && taf.s[+p[0] - 1][+p[1] - 1]) || ''; }
  // ---------------------------------------------------------------- مكتبة التفاسير والترجمات (المرحلة ج)
  // الميسر والسعدي والإنجليزية مدمجة في التطبيق؛ ابن كثير والطبري والبغوي والقرطبي وبقية الترجمات تُحمَّل عند الطلب
  // من DATA_BASES (ملفات json.gz) وتُحفظ في IndexedDB على الجهاز. لا يُرسل شيء عن القارئ.
  var DATA_BASES = ['https://raw.githubusercontent.com/7awlalaalam-creator/hawlalaalam-app/main/data/'];
  var TAFS = [
    { id: 'muyassar', name: 'الميسر', full: 'التفسير الميسر', bundled: 1 },
    { id: 'saadi', name: 'السعدي', full: 'تفسير السعدي', bundled: 1, file: 'tafsir-saadi.json' },
    { id: 'ibn_kathir', name: 'ابن كثير', full: 'تفسير ابن كثير', file: 'tafsir-ibn_kathir.json.gz', size: 5257423 },
    { id: 'tabari', name: 'الطبري', full: 'تفسير الطبري', file: 'tafsir-tabari.json.gz', size: 8187185 },
    { id: 'baghawi', name: 'البغوي', full: 'تفسير البغوي', file: 'tafsir-baghawi.json.gz', size: 3224213 },
    { id: 'qurtubi', name: 'القرطبي', full: 'تفسير القرطبي', file: 'tafsir-qurtubi.json.gz', size: 7372357 }
  ];
  var TRS = [
    { id: 'en_saheeh', lang: 'en', short: 'English', name: 'English — Saheeh International', bundled: 1, file: 'tr-en_saheeh.json' },
    { id: 'en_hilali_khan', lang: 'en', short: 'English (Hilali & Khan)', name: 'English — Hilali & Muhsin Khan', file: 'tr-en_hilali_khan.json.gz', size: 347024 },
    // QuranEnc: يُعاد جلبه من الواجهة الرسمية قبل تفعيله (شرط أحدث إصدار دون تعديل)
    // { id: 'fr_hamidullah', lang: 'fr', short: 'Français', name: 'Français — Muhammad Hamidullah', file: 'tr-fr_hamidullah.json.gz', size: 302307 },
    { id: 'ur_junagarhi', lang: 'ur', short: 'اردو', name: 'اردو — محمد جوناگڑھی', file: 'tr-ur_junagarhi.json.gz', size: 338011, rtl: 1 },
    // QuranEnc: يُعاد جلبه من الواجهة الرسمية قبل تفعيله (شرط أحدث إصدار دون تعديل)
    // { id: 'id_kfgqpc', lang: 'id', short: 'Indonesia', name: 'Bahasa Indonesia — Kompleks Raja Fahd', file: 'tr-id_kfgqpc.json.gz', size: 302879 },
    { id: 'tr_diyanet', lang: 'tr', short: 'Türkçe', name: 'Türkçe — Diyanet İşleri', file: 'tr-tr_diyanet.json.gz', size: 263546 },
    // QuranEnc: يُعاد جلبه من الواجهة الرسمية قبل تفعيله (شرط أحدث إصدار دون تعديل)
    // { id: 'tr_shaban_britch', lang: 'tr', short: 'Türkçe (Britch)', name: 'Türkçe — Şaban Piriş', file: 'tr-tr_shaban_britch.json.gz', size: 272086 },
    // QuranEnc: يُعاد جلبه من الواجهة الرسمية قبل تفعيله (شرط أحدث إصدار دون تعديل)
    // { id: 'es_montada', lang: 'es', short: 'Español', name: 'Español — Noor International', file: 'tr-es_montada.json.gz', size: 343587 },
    // QuranEnc: يُعاد جلبه من الواجهة الرسمية قبل تفعيله (شرط أحدث إصدار دون تعديل)
    // { id: 'bn_zakaria', lang: 'bn', short: 'বাংলা', name: 'বাংলা — আবু বকর যাকারিয়া', file: 'tr-bn_zakaria.json.gz', size: 367740 },
    { id: 'ru_kuliev', lang: 'ru', short: 'Русский', name: 'Русский — Эльмир Кулиев', file: 'tr-ru_kuliev.json.gz', size: 321981 }
  ];
  function libItem(kind, id) { var L = kind === 'tr' ? TRS : TAFS; for (var i = 0; i < L.length; i++) if (L[i].id === id) return L[i]; return null; }
  function mb(n) { var v = n / 1048576; return ar(v < 1 ? v.toFixed(1) : Math.round(v)) + ' م.ب'; }

  // التخزين: IndexedDB إن وُجد، وإلا الذاكرة فقط (حتى إغلاق الصفحة)
  var lib = {}, libDl = {}, libWait = {}, idbP = null, idbOk = true;
  function idb() {
    if (idbP) return idbP;
    idbP = new Promise(function (ok, no) {
      try {
        var r = indexedDB.open('hawl_lib', 1);
        r.onupgradeneeded = function () { r.result.createObjectStore('files'); };
        r.onsuccess = function () { ok(r.result); };
        r.onerror = function () { no(r.error); };
      } catch (e) { no(e); }
    });
    idbP.catch(function () { idbOk = false; });
    return idbP;
  }
  function idbDo(mode, f) {
    return idb().then(function (db) {
      return new Promise(function (ok, no) {
        var tx = db.transaction('files', mode), st = tx.objectStore('files'), out = f(st);
        tx.oncomplete = function () { ok(out && out.result !== undefined ? out.result : undefined); };
        tx.onerror = tx.onabort = function () { no(tx.error); };
      });
    });
  }
  function libKeys() {
    return idbDo('readonly', function (st) { return st.getAllKeys ? st.getAllKeys() : null; })
      .then(function (k) { libDl = {}; (k || []).forEach(function (x) { libDl[x] = 1; }); return libDl; })
      .catch(function () { return libDl; });
  }
  function have(kind, id) { var it = libItem(kind, id); return !!it && (it.bundled || libDl[kind + ':' + id] || lib[kind + ':' + id]); }

  // فك الضغط: DecompressionStream إن وُجد، وإلا tiny-inflate (مضمّن)
  function gunzip(buf) {
    var u = new Uint8Array(buf);
    if (u[0] !== 0x1f || u[1] !== 0x8b) return Promise.resolve(new TextDecoder().decode(u));   // الخادم فكّه مسبقًا
    if (typeof DecompressionStream === 'function') {
      return new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
    }
    var flg = u[3], i = 10;
    if (flg & 4) i += 2 + (u[i] | (u[i + 1] << 8));
    if (flg & 8) { while (u[i++]); }
    if (flg & 16) { while (u[i++]); }
    if (flg & 2) i += 2;
    var n = u.length, size = (u[n - 4] | (u[n - 3] << 8) | (u[n - 2] << 16) | (u[n - 1] << 24)) >>> 0;
    var out = window.__tinf(u.subarray(i, n - 8), new Uint8Array(size));
    return Promise.resolve(new TextDecoder().decode(out));
  }
  function fetchProgress(url, onP) {
    return fetch(url, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('http ' + r.status);
      var total = +r.headers.get('content-length') || 0;
      if (!r.body || !r.body.getReader) return r.arrayBuffer();
      var rd2 = r.body.getReader(), parts = [], got = 0;
      var pump = function () {
        return rd2.read().then(function (x) {
          if (x.done) {
            var all = new Uint8Array(got), o = 0;
            parts.forEach(function (p) { all.set(p, o); o += p.length; });
            parts = null;                                      // لا نُبقي نسختين في الذاكرة
            return all.buffer;
          }
          parts.push(x.value); got += x.value.length; if (onP) onP(got, total);
          return pump();
        });
      };
      return pump();
    });
  }
  // تحميل ملف من أول مصدر يعمل
  function download(kind, id, onP) {
    var it = libItem(kind, id), key = kind + ':' + id, i = 0;
    var tryNext = function (err) {
      if (i >= DATA_BASES.length) return Promise.reject(err || new Error('no source'));
      var u = DATA_BASES[i++] + it.file;
      return fetchProgress(u, function (g, t) { onP && onP(g, t || it.size); }).then(gunzip).catch(tryNext);
    };
    return tryNext().then(function (txt) {
      var o = JSON.parse(txt); txt = null;
      if (kind === 'taf' && (!o.t || !o.g)) throw new Error('bad file');
      if (kind === 'tr' && (!o.s || o.s.length !== 114)) throw new Error('bad file');
      if (kind === 'taf') return tafStore(id, o);
      lib[key] = prep(kind, o);
      return idbDo('readwrite', function (st) { st.put(o, key); }).then(function () { libDl[key] = 1; return 'saved'; },
        function () { idbOk = false; return 'memory'; });
    });
  }
  // التفاسير المحمّلة كبيرة (الطبري ≈ ٣٧ م.ب): تُخزَّن سورةً سورة، ولا يبقى في الذاكرة إلا سور الصفحة الحالية
  var TAF_KEEP = 4;
  function tafSplit(o) {
    var per = {};
    var bucket = function (S) { return per[S] || (per[S] = { t: {}, g: {} }); };
    for (var k in o.t) bucket(+k.split(':')[0]).t[k] = o.t[k];
    for (var k2 in o.g) bucket(+k2.split(':')[0]).g[k2] = o.g[k2];
    return per;
  }
  function tafStore(id, o) {
    var key = 'taf:' + id, per = tafSplit(o), meta = { v: 2, src: o.src || '', n: 114 };
    o = null;
    var mem = { src: meta.src, per: {}, order: [] };
    return idbDo('readwrite', function (st) {
      for (var S in per) st.put(per[S], key + ':' + S);
      st.put(meta, key);
    }).then(function () { per = null; lib[key] = mem; libDl[key] = 1; return 'saved'; }, function () {
      // دون IndexedDB: نبقيه في الذاكرة حتى إغلاق الصفحة
      idbOk = false;
      for (var S in per) tafPut(mem, +S, per[S], true);
      lib[key] = mem; return 'memory';
    });
  }
  function tafPut(mem, S, obj, keepAll) {
    var e = {};
    for (var f in obj.g) { var a = +f.split(':')[1], to = obj.g[f]; if (!e[to] || a > e[to]) e[to] = a; }
    obj.end = e;
    mem.per[S] = obj;
    mem.order = mem.order.filter(function (x) { return x !== S; }); mem.order.push(S);
    if (!keepAll) while (mem.order.length > TAF_KEEP) delete mem.per[mem.order.shift()];
  }
  function tafHas(id, ss) {
    var m = lib['taf:' + id]; if (!m) return false;
    if (!m.per) return true;                                   // تفسير مضمّن (كامل في الذاكرة)
    for (var i = 0; i < ss.length; i++) if (!m.per[ss[i]]) return false;
    return true;
  }
  function tafLoadSurahs(id, ss, cb, fail) {
    var key = 'taf:' + id;
    var go = function () {
      var m = lib[key];
      if (!m.per) { cb(); return; }
      var need = ss.filter(function (S) { return !m.per[S]; });
      if (!need.length) { ss.forEach(function (S) { tafPut(m, S, m.per[S]); }); cb(); return; }
      var got = {};
      idbDo('readonly', function (st) {
        need.forEach(function (S) { var r = st.get(key + ':' + S); r.onsuccess = function () { got[S] = r.result; }; });
      }).then(function () {
        need.forEach(function (S) { tafPut(m, S, got[S] || { t: {}, g: {} }); });
        ss.forEach(function (S) { if (m.per[S]) tafPut(m, S, m.per[S]); });
        cb();
      }, function () { if (fail) fail(); });
    };
    if (lib[key]) return go();
    idbDo('readonly', function (st) { return st.get(key); }).then(function (meta) {
      if (!meta) throw 0;
      if (meta.t && meta.g) {                                  // صيغة قديمة (الملف كله في مفتاح واحد): نقسمه مرة واحدة
        return tafStore(id, meta).then(go);
      }
      lib[key] = { src: meta.src || '', per: {}, order: [] };
      go();
    }).catch(function () { toast('هذا التفسير غير محمّل على جهازك'); delete libDl[key]; if (fail) fail(); });
  }
  function pageSurahs() {
    var out = [], pg = data && data.pages && data.pages[N - 1];
    (pg || []).forEach(function (e) { if (out.indexOf(e[0]) < 0) out.push(e[0]); });
    return out;
  }

  function libDelete(kind, id) {
    var key = kind + ':' + id;
    delete lib[key]; delete libDl[key];
    if (kind === 'taf' && RS.taf === id) { RS.taf = 'muyassar'; saveRS(); }
    if (kind === 'tr' && RS.tr === id) { RS.tr = ''; saveRS(); }
    return idbDo('readwrite', function (st) {
      st.delete(key);
      if (kind === 'taf' && typeof IDBKeyRange !== 'undefined') st.delete(IDBKeyRange.bound(key + ':', key + ':\uffff'));
    }).catch(function () {});
  }
  // تجهيز ما يُحمَّل: آخر آية في كل مجموعة تفسير (لعرض «تفسير الآيات ٣–٥»)
  function prep(kind, o) {
    if (kind === 'taf') {
      o.end = {};
      for (var k in o.g) { var f = o.g[k], a = +k.split(':')[1]; if (!o.end[f] || a > o.end[f]) o.end[f] = a; }
    }
    return o;
  }
  function libLoad(kind, id, cb, fail) {
    var it = libItem(kind, id), key = kind + ':' + id;
    if (!it) { if (fail) fail(); return; }
    if (lib[key]) { cb(); return; }
    (libWait[key] = libWait[key] || []).push([cb, fail]);
    if (libWait[key].length > 1) return;
    var done = function (ok) { var w = libWait[key] || []; delete libWait[key]; w.forEach(function (f) { var g = ok ? f[0] : f[1]; if (g) g(); }); };
    if (it.bundled) {
      fetch('/__hawl/' + it.file + '?v=1').then(function (r) { if (!r.ok) throw 0; return r.json(); })
        .then(function (o) { lib[key] = prep(kind, o); done(true); })
        .catch(function () { toast('تعذّر فتح ' + (kind === 'tr' ? 'الترجمة' : 'التفسير')); done(false); });
      return;
    }
    idbDo('readonly', function (st) { return st.get(key); }).then(function (o) {
      if (!o) throw 0;
      lib[key] = prep(kind, o); done(true);
    }).catch(function () { toast('هذا ' + (kind === 'tr' ? 'الترجمة' : 'التفسير') + ' غير محمّل على جهازك'); delete libDl[key]; done(false); });
  }

  // ---- التفسير
  function tafReady(id, ss) { return id === 'muyassar' ? !!taf : tafHas(id, ss || pageSurahs()); }
  function tafLoad(id, cb, fail, ss) {
    if (id === 'muyassar') return loadTafsir(cb);
    var it = libItem('taf', id);
    if (it && it.bundled) return libLoad('taf', id, cb, fail);
    tafLoadSurahs(id, ss || pageSurahs(), cb, fail);
  }
  function tafName(id) { var it = libItem('taf', id); return it ? it.full : 'التفسير الميسر'; }
  function tafChips(cur) {
    var h = TAFS.filter(function (t) { return have('taf', t.id); }).map(function (t) {
      return '<button class="chip' + (t.id === cur ? ' on' : '') + '" data-taf="' + t.id + '">' + t.name + '</button>';
    }).join('');
    return h + '<button class="chip add" data-taf="+">＋ تفاسير أخرى</button>';
  }
  function tafFmt(t) {
    return esc(t).replace(/\{(\d+)\}/g, function (m, n) { return '﴿' + ar(n) + '﴾'; })
      .replace(/\[\[([\s\S]*?)\]\]/g, '<span class="fn">$1</span>')
      .replace(/\n{2,}/g, '<br><br>').replace(/\n/g, ' ');
  }
  // نص التفسير لآية: {t, from, to, inGroup}
  function tafEntry(id, k) {
    if (id === 'muyassar') return { t: tafOf(k), from: k, to: +k.split(':')[1] };
    var o = lib['taf:' + id]; if (!o) return { t: '' };
    if (o.per) { o = o.per[+k.split(':')[0]]; if (!o) return { t: '' }; }
    var f = o.g[k] || k, p = f.split(':');
    return { t: o.t[f] || '', from: f, to: o.end[f] || +p[1], member: f !== k };
  }
  function rangeTxt(e) {
    var p = e.from.split(':');
    return +p[1] === e.to ? '' : 'تفسير الآيات ' + ar(p[1]) + '–' + ar(e.to);
  }
  var tafShown = {};                                         // في صفحة واحدة: نص المجموعة يُكتب مرة واحدة
  function tafBlock(k) {
    var e = tafEntry(RS.taf, k);
    if (e.member && tafShown[e.from]) return '';
    tafShown[e.from] = 1;
    if (!e.t) return '<div class="rd-tf dim">لا يوجد تفسير لهذه الآية في هذا الكتاب.</div>';
    var r = rangeTxt(e), long = e.t.length > 900;
    return '<div class="rd-tf' + (long ? ' long' : '') + '">' + (r ? '<b class="tf-r">' + r + '</b>' : '') + tafFmt(e.t) +
      (long ? '<button class="more" type="button">اقرأ المزيد</button>' : '') + '</div>';
  }
  function tafsir(k, id) {
    if (!id || !have('taf', id)) id = have('taf', RS.taf) ? RS.taf : 'muyassar';
    var show = function () {
      var p = k.split(':'), e = tafEntry(id, k), r = rangeTxt(e);
      var prev = (+p[1] > 1) ? p[0] + ':' + (+p[1] - 1) : null, next = (+p[1] < ayCount[+p[0]]) ? p[0] + ':' + (+p[1] + 1) : null;
      var src = id === 'muyassar' ? taf.src : (lib['taf:' + id] && lib['taf:' + id].src) || '';
      sheet('<div class="sh-t">' + esc(tafName(id)) + ' · ' + esc(refOf(k)) + '</div>' +
        '<div class="chips tf-pick">' + tafChips(id) + '</div>' +
        '<div class="aya-q">' + esc(plain(k)) + '</div>' +
        (r ? '<div class="tf-r">' + r + '</div>' : '') +
        '<div class="taf">' + (e.t ? tafFmt(e.t) : '<span class="dim">لا يوجد تفسير لهذه الآية في هذا الكتاب.</span>') + '</div>' +
        '<div class="src">' + esc(src) + '</div>' +
        '<div class="row2">' + (next ? '<button data-k="' + next + '">الآية التالية ←</button>' : '<span></span>') +
        (prev ? '<button data-k="' + prev + '">→ الآية السابقة</button>' : '<span></span>') + '</div>');
      $('sheetBody').querySelectorAll('[data-k]').forEach(function (b) {
        b.onclick = function () { var nk = b.getAttribute('data-k'); goAyah(nk); tafsir(nk, id); };
      });
      $('sheetBody').querySelectorAll('[data-taf]').forEach(function (b) {
        b.onclick = function () { var v = b.getAttribute('data-taf'); if (v === '+') libSheet('taf', k); else tafsir(k, v); };
      });
      sel = k; decorate();
    };
    var ss = [+k.split(':')[0]];
    if (tafReady(id, ss)) return show();
    sheet('<div class="sh-t">جارٍ فتح ' + esc(tafName(id)) + '…</div>');
    tafLoad(id, show, function () { if (id !== 'muyassar') tafsir(k, 'muyassar'); }, ss);
  }

  // ---- الترجمة
  function trReady(id) { return !!lib['tr:' + id]; }
  function trLoad(id, cb, fail) { libLoad('tr', id, cb, fail); }
  function trShort(id) { var it = libItem('tr', id); return it ? it.short : ''; }
  function trChips(cur) {
    var h = '<button class="chip' + (!cur ? ' on' : '') + '" data-tr="">بدون</button>';
    h += TRS.filter(function (t) { return have('tr', t.id); }).map(function (t) {
      return '<button class="chip' + (t.id === cur ? ' on' : '') + '" data-tr="' + t.id + '" lang="' + t.lang + '">' + esc(t.short) + '</button>';
    }).join('');
    return h + '<button class="chip add" data-tr="+">＋ لغات أخرى</button>';
  }
  function trBlock(k) {
    var o = lib['tr:' + RS.tr], it = libItem('tr', RS.tr), p = k.split(':');
    var t = o && o.s[+p[0] - 1] ? o.s[+p[0] - 1][+p[1] - 1] : '';
    if (!t) return '';
    return '<div class="rd-tr" lang="' + it.lang + '" dir="' + (it.rtl ? 'rtl' : 'ltr') + '"><span class="tr-n">' + p[1] + '</span> ' + esc(t) + '</div>';
  }

  // ---- شاشة المكتبة: ما هو محمّل، والتحميل بشريط تقدّم، والحذف
  var libBusy = {};
  function libSheet(tab, backK) {
    tab = tab === 'tr' ? 'tr' : 'taf';
    libKeys().then(function () {
      var L = tab === 'tr' ? TRS : TAFS;
      var rows = L.map(function (it) {
        var key = tab + ':' + it.id, on = have(tab, it.id), busy = libBusy[key];
        var right = it.bundled ? '<span class="lb-s">مدمج في التطبيق</span>'
          : busy ? '<span class="lb-s" id="pg_' + it.id + '">' + (busy.p ? ar(busy.p) + '٪' : '…') + '</span>'
          : on ? '<button class="lb-b del" data-del="' + it.id + '">حذف</button>'
          : '<button class="lb-b" data-dl="' + it.id + '">تحميل ' + mb(it.size) + '</button>';
        return '<div class="lb-r"><div class="lb-n"' + (tab === 'tr' ? ' lang="' + it.lang + '"' : '') + '><b>' + esc(tab === 'tr' ? it.name : it.full) + '</b>' +
          (busy ? '<div class="hz-bar"><span id="pb_' + it.id + '" style="width:' + (busy.p || 2) + '%"></span></div>' : '') + '</div>' + right + '</div>';
      }).join('');
      sheet('<div class="sh-t">التفاسير والترجمات</div>' +
        '<div class="seg" id="lbTab">' + [['taf', 'التفاسير'], ['tr', 'ترجمات المعاني']].map(function (x) {
          return '<button type="button" role="radio" data-v="' + x[0] + '" aria-checked="' + (x[0] === tab) + '">' + x[1] + '</button>'; }).join('') + '</div>' +
        '<div class="list">' + rows + '</div>' +
        '<div class="dim">' + (tab === 'taf' ? 'التفاسير الكبيرة تُحمَّل مرة واحدة وتعمل بعدها دون إنترنت. يُفضَّل التحميل عبر Wi‑Fi.'
          : 'ترجمات معاني القرآن الكريم تُعرض تحت كل آية في وضع القراءة.') + (idbOk ? '' : '<br>تنبيه: المساحة غير متاحة في هذا الجهاز، فيبقى المحمَّل حتى إغلاق المصحف فقط.') + '</div>' +
        '<div class="row2">' + (backK ? '<button id="lbBack">→ العودة للتفسير</button>' : '') + '<button id="lbSrc">المصادر</button></div>');
      $('lbTab').querySelectorAll('[data-v]').forEach(function (b) { b.onclick = function () { libSheet(b.getAttribute('data-v'), backK); }; });
      $('lbSrc').onclick = sourcesSheet;
      if (backK) $('lbBack').onclick = function () { tafsir(backK); };
      $('sheetBody').querySelectorAll('[data-dl]').forEach(function (b) {
        b.onclick = function () {
          var id = b.getAttribute('data-dl'), key = tab + ':' + id;
          libBusy[key] = { p: 0 };
          libSheet(tab, backK);
          download(tab, id, function (g, t) {
            var p = t ? Math.min(99, Math.round(g * 100 / t)) : 0;
            libBusy[key].p = p;
            var a = $('pb_' + id), c = $('pg_' + id);
            if (a) a.style.width = Math.max(2, p) + '%';
            if (c) c.textContent = ar(p) + '٪';
          }).then(function (how) {
            delete libBusy[key];
            toast(how === 'memory' ? 'حُمّل (مؤقتًا حتى إغلاق المصحف)' : 'حُمّل ويعمل الآن دون إنترنت');
            if ($('lbTab')) libSheet(tab, backK);
          }, function () {
            delete libBusy[key];
            toast('تعذّر التحميل — تأكد من الاتصال بالإنترنت');
            if ($('lbTab')) libSheet(tab, backK);
          });
        };
      });
      $('sheetBody').querySelectorAll('[data-del]').forEach(function (b) {
        b.onclick = function () { libDelete(tab, b.getAttribute('data-del')).then(function () { toast('حُذف من جهازك'); rsRedraw(); libSheet(tab, backK); }); };
      });
    });
  }

  // ---------------------------------------------------------------- مصحف التجويد (نص تنزيل العثماني بألوان الأحكام)
  var tj = null, tjWait = [];
  var TJ = [  // ترتيب ملف tajweed.json: rules
    ['ghunnah', 'غنّة', 'الغنة في النون والميم المشددتين بمقدار حركتين.', '#E6731A', '#FF9A4D'],
    ['hamzat_wasl', 'همزة وصل', 'تُكتب ولا تُنطق عند وصل الكلام بما قبلها.', '#A3A9AB', '#7F9197'],
    ['idghaam_ghunnah', 'إدغام بغنّة', 'النون الساكنة أو التنوين قبل (ي ن م و): تُدغم مع الغنة.', '#169777', '#3CC6A0'],
    ['idghaam_mutajanisayn', 'إدغام متجانسين', 'حرفان مخرجهما واحد وصفاتهما مختلفة، يُدغم الأول في الثاني.', '#A1A1A1', '#8A9A9F'],
    ['idghaam_mutaqaribayn', 'إدغام متقاربين', 'حرفان متقاربان مخرجًا وصفة، يُدغم الأول في الثاني.', '#A1A1A1', '#8A9A9F'],
    ['idghaam_no_ghunnah', 'إدغام بلا غنّة', 'النون الساكنة أو التنوين قبل اللام أو الراء: تُدغم دون غنة.', '#169200', '#4FC23A'],
    ['idghaam_shafawi', 'إدغام شفوي', 'الميم الساكنة قبل الميم: تُدغم مع الغنة.', '#58B800', '#7FD63A'],
    ['ikhfa', 'إخفاء', 'النون الساكنة أو التنوين قبل حروف الإخفاء الخمسة عشر: تُخفى مع الغنة.', '#9400A8', '#C65BD6'],
    ['ikhfa_shafawi', 'إخفاء شفوي', 'الميم الساكنة قبل الباء: تُخفى مع الغنة.', '#D500B7', '#EF5FD4'],
    ['iqlab', 'إقلاب', 'النون الساكنة أو التنوين قبل الباء: تُقلب ميمًا مخفاة مع الغنة.', '#1E9FD8', '#5FD0FF'],
    ['lam_shamsiyyah', 'لام شمسية', 'لام «ال» قبل الحروف الشمسية: تُكتب ولا تُنطق.', '#A3A9AB', '#7F9197'],
    ['madd_2', 'مدّ طبيعي', 'يُمدّ بمقدار حركتين.', '#537FFF', '#86A2FF'],
    ['madd_246', 'مدّ جائز ٢–٤–٦', 'المد العارض للسكون ومد اللين: حركتان أو أربع أو ست.', '#4050FF', '#7A86FF'],
    ['madd_6', 'مدّ لازم', 'يُمدّ ست حركات لزومًا.', '#000EBC', '#6B76FF'],
    ['madd_munfasil', 'مدّ منفصل', 'حرف المد في آخر كلمة والهمزة أول التي بعدها: أربع أو خمس حركات.', '#3B5BDB', '#7E9BFF'],
    ['madd_muttasil', 'مدّ متصل', 'حرف المد والهمزة في كلمة واحدة: أربع أو خمس حركات وجوبًا.', '#2144C1', '#6E8CF5'],
    ['qalqalah', 'قلقلة', 'حروف «قطب جد» الساكنة تُنطق باهتزاز.', '#DD0008', '#FF5A5F'],
    ['silent', 'حرف لا يُنطق', 'حرف مكتوب لا يُنطق في الوصل.', '#A3A9AB', '#7F9197']
  ];
  function tjLoad(cb, fail) {
    if (tj) { cb(); return; }
    tjWait.push([cb, fail]);
    if (tjWait.length > 1) return;
    fetch('/__hawl/tajweed.json?v=1').then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .then(function (d) {
        tj = d;
        // اسم القاعدة ← لونها (ترتيب الملف قد يختلف عن ترتيب الجدول)
        tj.col = d.rules.map(function (n) { for (var i = 0; i < TJ.length; i++) if (TJ[i][0] === n) return i; return -1; });
        var w = tjWait; tjWait = []; w.forEach(function (f) { f[0](); });
      })
      .catch(function () { var w = tjWait; tjWait = []; toast('تعذّر فتح مصحف التجويد'); w.forEach(function (f) { if (f[1]) f[1](); }); });
  }
  function tjHtml(k) {
    var a = tj.a[k], t = a[0], r = a[1], mark = new Array(t.length);
    for (var i = 0; i < r.length; i += 3) { var c = tj.col[r[i]]; for (var j = r[i + 1]; j < r[i + 2] && j < t.length; j++) mark[j] = c; }
    var out = '', cur = -2, buf = '';
    var put = function () { if (buf) out += cur >= 0 ? '<span class="tj' + cur + '">' + esc(buf) + '</span>' : esc(buf); };
    for (var x = 0; x < t.length; x++) {
      var m = mark[x] === undefined ? -1 : mark[x];
      if (m !== cur) { put(); buf = ''; cur = m; }
      buf += t[x];
    }
    put();
    return out;
  }
  (function () {   // ألوان الأحكام للوضعين
    var css = TJ.map(function (r, i) { return '.tj' + i + '{color:' + r[3] + '}html[data-theme=dark] .tj' + i + '{color:' + r[4] + '}'; }).join('');
    var e = document.createElement('style'); e.textContent = css; document.head.appendChild(e);
  })();
  function tjLegend() {
    var seen = {};
    sheet('<div class="sh-t">دليل ألوان التجويد</div><div class="list">' + TJ.filter(function (r) {
      var key = r[3]; if (seen[key + r[1]]) return false; seen[key + r[1]] = 1; return true;
    }).map(function (r) {
      var i = TJ.indexOf(r);
      return '<div class="res tj-l"><b><span class="dot" style="background:' + (night ? r[4] : r[3]) + '"></span> <span class="tj' + i + '">' + r[1] + '</span></b><span>' + r[2] + '</span></div>';
    }).join('') + '</div><div class="src">بيانات الأحكام: مشروع quran-tajweed (CC BY 4.0) على نص المصحف العثماني من مشروع تنزيل. الألوان للتيسير، والمرجع الأصيل التلقي من المتقنين.</div>');
  }

  // ---------------------------------------------------------------- معاني الكلمات: الجذر والأصل ونوع الكلمة (المدونة القرآنية)
  var morph = null, morphWait = [];
  var POS_AR = { N: 'اسم', V: 'فعل', P: 'حرف' };
  function morphLoad(cb) {
    if (morph) { cb(); return; }
    morphWait.push(cb);
    if (morphWait.length > 1) return;
    fetch('/__hawl/morph.json?v=1').then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .then(function (d) { morph = d; var w = morphWait; morphWait = []; w.forEach(function (f) { f(); }); })
      .catch(function () { morphWait = []; toast('تعذّر فتح معاني الكلمات'); });
  }
  var LETTER = /[ء-يٱ]/;
  // كلمات الآية (بلا علامة الحزب ۞ ونحوها) مع رقم كل كلمة
  function ayahWords(k) { return plain(k).split(/\s+/).filter(function (w) { return LETTER.test(w); }); }
  function wordsHtml(txt) {
    var m = /^([\s\S]*?)(\S+) ([٠-٩]+)\s*$/.exec(txt);
    var head = m ? m[1] : txt, last = m ? m[2] : '', num = m ? m[3] : '', i = 0;
    var wrapW = function (w) { return LETTER.test(w) ? '<span class="w" data-i="' + (i++) + '">' + esc(w) + '</span>' : esc(w); };
    var out = head.split(/(\s+)/).map(function (p) { return /^\s*$/.test(p) ? p : wrapW(p); }).join('');
    return m ? out + '<span class="nw">' + wrapW(last) + ' ' + num + '</span>' : out;
  }
  function wordInfo(k, i) {
    var a = morph && morph.a[k], w = ayahWords(k);
    if (!a || a.length !== w.length || !a[i]) return null;    // ترتيب الكلمات لا يطابق (٧ آيات فقط): لا نعرض شيئًا غير مؤكد
    return { w: w[i], root: a[i][0], lemma: a[i][1], pos: POS_AR[morph.pos[a[i][2]]] || '' };
  }
  function wordRow(x) {
    var parts = [];
    if (x.root) parts.push('الجذر: <b>' + esc(x.root.split('').join(' ')) + '</b>');
    if (x.lemma) parts.push('الأصل: <b>' + esc(x.lemma) + '</b>');
    return '<div class="wd"><b class="wd-w">' + esc(x.w) + '</b><span>' + (x.pos ? '<i>' + x.pos + '</i> ' : '') + parts.join(' · ') + '</span></div>';
  }
  function wordsSheet(k) {
    sheet('<div class="sh-t">معاني الكلمات · ' + esc(refOf(k)) + '</div><div class="empty">…</div>');
    morphLoad(function () {
      var w = ayahWords(k), rows = [];
      for (var i = 0; i < w.length; i++) { var x = wordInfo(k, i); if (x) rows.push(wordRow(x)); }
      sheet('<div class="sh-t">معاني الكلمات · ' + esc(refOf(k)) + '</div>' +
        (rows.length ? '<div class="list">' + rows.join('') + '</div>' : '<div class="empty">لا تتوفر بيانات مؤكدة لكلمات هذه الآية.</div>') +
        '<div class="dim">في وضع القراءة: اضغط مطولًا على أي كلمة لترى جذرها وأصلها.</div>' +
        '<div class="src">الجذور والصرف: المدونة القرآنية العربية corpus.quran.com (رخصة GNU GPL).</div>' +
        '<div class="row2"><button id="wdBack">→ العودة للآية</button></div>');
      $('wdBack').onclick = function () { ayahSheet(k); };
    });
  }
  // الضغط المطوّل على كلمة في وضع القراءة: بطاقة صغيرة فوقها
  var lpT = 0, lpFired = false, lpX = 0, lpY = 0;
  function wordPop(el) {
    var ay = el.closest('.ay'); if (!ay) return;
    var k = ay.getAttribute('data-k'), i = +el.getAttribute('data-i');
    morphLoad(function () {
      var x = wordInfo(k, i), pop = $('wpop');
      if (!x) { toast('لا تتوفر بيانات مؤكدة لهذه الكلمة'); return; }
      if (!pop) { pop = document.createElement('div'); pop.id = 'wpop'; pop.className = 'wpop'; document.body.appendChild(pop); }
      pop.innerHTML = wordRow(x);
      pop.classList.add('on');
      var r = el.getBoundingClientRect();
      var top = r.top - pop.offsetHeight - 8; if (top < 8) top = r.bottom + 8;
      pop.style.top = (top + scrollY) + 'px';
      pop.style.left = Math.max(8, Math.min(innerWidth - pop.offsetWidth - 8, r.left + r.width / 2 - pop.offsetWidth / 2)) + 'px';
      el.classList.add('wsel');
      setTimeout(function () { lpFired = false; }, 700);
      clearTimeout(wordPop.t);
      wordPop.t = setTimeout(function () { pop.classList.remove('on'); el.classList.remove('wsel'); }, 4500);
      var off = function () { pop.classList.remove('on'); el.classList.remove('wsel'); document.removeEventListener('touchstart', off, true); };
      setTimeout(function () { document.addEventListener('touchstart', off, true); }, 50);
    });
  }
  rd.addEventListener('touchstart', function (e) {
    var w = e.target.closest ? e.target.closest('.w') : null;
    if (!w || withTajweed()) return;
    var t = e.touches[0]; lpX = t.clientX; lpY = t.clientY;
    clearTimeout(lpT);
    lpT = setTimeout(function () { lpFired = true; wordPop(w); }, 480);
  }, { passive: true });
  rd.addEventListener('touchmove', function (e) {
    var t = e.touches[0]; if (Math.abs(t.clientX - lpX) > 10 || Math.abs(t.clientY - lpY) > 10) clearTimeout(lpT);
  }, { passive: true });
  rd.addEventListener('touchend', function () { clearTimeout(lpT); }, { passive: true });
  rd.addEventListener('contextmenu', function (e) {
    var w = e.target.closest ? e.target.closest('.w') : null;
    if (!w || withTajweed()) return;
    e.preventDefault(); wordPop(w);
  });
  // «اقرأ المزيد» للتفاسير الطويلة في وضع «التفسير»
  rd.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('.more') : null;
    if (!b) return;
    e.stopPropagation();
    var box = b.parentNode; box.classList.toggle('open'); b.textContent = box.classList.contains('open') ? 'إخفاء' : 'اقرأ المزيد';
  }, true);

  // ---------------------------------------------------------------- الآيات المتشابهات (للحفاظ)
  var MUT = null;
  function mutLoad(cb) {
    if (MUT) { if (cb) cb(); return; }
    fetch('/__hawl/mutashabihat.json?v=1').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (d) {
      var idx = {}, arr = function (x) { return Array.isArray(x) ? x : [x]; };
      var add = function (from, to) {
        var key = to.join(',');
        from.forEach(function (k) { var L = idx[k] = idx[k] || []; if (!L.some(function (y) { return y.join(',') === key; }) && to.indexOf(k) < 0) L.push(to); });
      };
      Object.keys(d.m).forEach(function (k) {
        d.m[k].forEach(function (e) {
          var src = arr(e.src);
          (e.muts || []).forEach(function (m) { var mm = arr(m); add(src, mm); add(mm, src); });
        });
      });
      MUT = idx; if (cb) cb();
    }).catch(function () { MUT = {}; });
  }
  function mutOf(k) { return (MUT && MUT[k]) || []; }
  function mutRef(g) {
    var a = g[0].split(':'), b = g[g.length - 1].split(':');
    return 'سورة ' + nameOf(+a[0]) + ' · ' + (g.length > 1 && a[0] === b[0] ? 'الآيات ' + ar(a[1]) + '–' + ar(b[1]) : 'الآية ' + ar(a[1]));
  }
  function mutSheet(k, back) {
    var L = mutOf(k);
    sheet('<div class="sh-t">الآيات المتشابهة · ' + esc(refOf(k)) + '</div>' +
      '<div class="aya-q sm">' + esc(plain(k)) + '</div>' +
      '<div class="list">' + L.map(function (g) {
        return '<button class="res" data-k="' + g[0] + '"><b>' + esc(mutRef(g)) + '</b><span class="mq">' + esc(g.map(plain).join(' ')) + '</span></button>';
      }).join('') + '</div>' +
      '<div class="dim">انتبه للفروق بينها عند الحفظ والمراجعة.</div>' +
      '<div class="src">بيانات المتشابهات: مشروع Quran Revision Companion لـ Waqar Ahmed (رخصة MIT).</div>' +
      (back ? '<div class="row2"><button id="mtBack">→ العودة للمراجعة</button></div>' : ''));
    $('sheetBody').querySelectorAll('[data-k]').forEach(function (b) { b.onclick = function () { var nk = b.getAttribute('data-k'); closeSheet(); goAyah(nk); }; });
    if (back) $('mtBack').onclick = back;
  }

  // ---------------------------------------------------------------- المصادر
  function sourcesSheet() {
    var S = [
      ['نص المصحف وخطه', 'مصحف المدينة النبوية برواية حفص عن عاصم، وخط المصحف من مجمع الملك فهد لطباعة المصحف الشريف (منصة مطوّري المجمع، الإصدار ١٨).'],
      ['التفسير الميسر', 'نخبة من العلماء، مجمع الملك فهد لطباعة المصحف الشريف.'],
      ['التفاسير (السعدي، ابن كثير، الطبري، البغوي، القرطبي)', 'النصوص الرقمية من المكتبة القرآنية الشاملة QUL ‏(qul.tarteel.ai) عبر مشروع Tafsir API ‏(github.com/spa5k/tafsir_api).'],
      ['ترجمات معاني القرآن', 'موسوعة القرآن الكريم QuranEnc.com ومجمع الملك فهد لطباعة المصحف الشريف (الفرنسية: حميد الله v1.0.0، الإندونيسية: المجمع v1.0.0، التركية: شعبان بريتش v1.1.0، الإسبانية: نور الدولية v1.0.0، البنغالية: أبو بكر زكريا)، ومشروع تنزيل tanzil.net/trans (الإنجليزية: صحيح إنترناشيونال، والهلالي وخان، والأردية: جوناگڑھی، والتركية: ديانت، والروسية: كولييف). للاستخدام غير التجاري.'],
      ['أحكام التجويد', 'مشروع quran-tajweed لـ Collin Fair ‏(CC BY 4.0) على نص المصحف العثماني من مشروع تنزيل tanzil.net.'],
      ['الجذور والصرف', 'المدونة القرآنية العربية Quranic Arabic Corpus ‏(corpus.quran.com) لـ Kais Dukes، رخصة GNU GPL.'],
      ['الآيات المتشابهات', 'مشروع Quran Revision Companion لـ Waqar Ahmed (رخصة MIT).'],
      ['التلاوات', 'everyayah.com وmp3quran.net.'],
      ['فك الضغط', 'tiny-inflate لـ Devon Govett (رخصة MIT).']
    ];
    sheet('<div class="sh-t">المصادر</div><div class="list">' + S.map(function (x) {
      return '<div class="res"><b>' + esc(x[0]) + '</b><span class="sn">' + esc(x[1]) + '</span></div>';
    }).join('') + '</div><div class="dim">جزى الله القائمين عليها خيرًا. التطبيق مجاني بلا إعلانات، صدقة جارية.</div>');
  }

  // ---------------------------------------------------------------- الاستماع (يحتاج إنترنت)
  var audio = new Audio(), reciter = 'Alafasy_128kbps';
  var REPS = [1, 3, 5, 10], repIdx = 0, repDone = 0;           // تكرار كل آية: ١، ٣، ٥، ١٠ مرات (للحفظ)
  function repLabel() {
    var b = $('plRep');
    if (!b) return;
    b.textContent = ar(REPS[repIdx]) + '×';
    b.setAttribute('aria-label', REPS[repIdx] === 1 ? 'تكرار الآية: مرة واحدة' : 'تكرار كل آية ' + ar(REPS[repIdx]) + ' مرات');
  }
  function pad3(n) { return ('00' + n).slice(-3); }
  function listen(k, again) {
    if (!again) repDone = 0;
    playing = k;
    var p = k.split(':');
    audio.src = 'https://everyayah.com/data/' + reciter + '/' + pad3(p[0]) + pad3(p[1]) + '.mp3';
    audio.play().catch(function () { stopAudio(); toast('الاستماع يحتاج اتصالًا بالإنترنت'); });
    $('player').classList.add('on');
    document.documentElement.classList.add('playing');
    $('plLabel').textContent = refOf(k);
    $('plPause').textContent = '⏸';
    if (pageOf[k] !== N) go(pageOf[k]);
    decorate();
    var el = scopeEl().querySelector('.ay[data-k="' + k + '"]');
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  function stopAudio() {
    audio.pause(); playing = null;
    $('player').classList.remove('on');
    document.documentElement.classList.remove('playing');
    decorate();
  }
  audio.onended = function () {
    if (!playing) return;
    repDone++;
    if (repDone < REPS[repIdx]) { listen(playing, true); return; }
    var p = playing.split(':'), s = +p[0], a = +p[1];
    if (a < ayCount[s]) listen(s + ':' + (a + 1));
    else if (s < 114) { toast('سورة ' + nameOf(s + 1)); listen((s + 1) + ':1'); }   // نتابع السورة التالية وتنقلب الصفحة معها
    else { stopAudio(); toast('صدق الله العظيم'); }
  };
  audio.onerror = function () { if (playing) { stopAudio(); toast('تعذّر التشغيل — تأكد من الاتصال بالإنترنت'); } };
  $('plStop').onclick = stopAudio;
  $('plRep').onclick = function () {
    repIdx = (repIdx + 1) % REPS.length; repDone = 0; repLabel();
    toast(REPS[repIdx] === 1 ? 'دون تكرار' : 'كل آية تُكرَّر ' + ar(REPS[repIdx]) + ' مرات');
  };
  repLabel();
  $('plPause').onclick = function () {
    if (audio.paused) { audio.play(); this.textContent = '⏸'; } else { audio.pause(); this.textContent = '▶'; }
  };

  // ---------------------------------------------------------------- النسخ
  function copy(k) {
    var t = '﴿' + plain(k) + '﴾\n[' + refOf(k) + ']';
    var ok = function () { toast('نُسخت الآية'); closeSheet(); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(ok, function () { fallbackCopy(t) ? ok() : toast('تعذّر النسخ'); });
    } else if (fallbackCopy(t)) ok(); else toast('تعذّر النسخ');
  }
  function fallbackCopy(t) {
    try {
      var ta = document.createElement('textarea');
      ta.value = t; ta.style.cssText = 'position:fixed;top:-100px;opacity:0';
      document.body.appendChild(ta); ta.select();
      var r = document.execCommand('copy'); ta.remove(); return r;
    } catch (e) { return false; }
  }

  // ---------------------------------------------------------------- مشاركة كصورة مزخرفة
  function shareImage(k) {
    var W = 1080, pad = 110, fs = 58, lh = fs * 2.0;
    var c = document.createElement('canvas'), g = c.getContext('2d');
    g.font = fs + 'px HawlHafs';
    var words = plain(k).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (g.measureText(t).width > W - pad * 2 && cur) { lines.push(cur); cur = words[i]; } else cur = t;
    }
    if (cur) lines.push(cur);
    var H = Math.max(900, pad * 2 + 140 + lines.length * lh + 170);
    c.width = W; c.height = H;
    var P = night ? { bg: '#0D2529', paper: '#142A2F', ink: '#EFE4CF', gold: '#C9A876', deep: '#1F4E4A' }
                  : { bg: '#1F4E4A', paper: '#FBF6E8', ink: '#16241F', gold: '#B8924A', deep: '#1F4E4A' };
    g.fillStyle = P.bg; g.fillRect(0, 0, W, H);
    g.fillStyle = P.paper; g.fillRect(36, 36, W - 72, H - 72);
    g.strokeStyle = P.gold; g.lineWidth = 6; g.strokeRect(52, 52, W - 104, H - 104);
    g.lineWidth = 2; g.strokeRect(66, 66, W - 132, H - 132);
    var star = function (x, y, r) {
      g.beginPath();
      for (var j = 0; j < 16; j++) { var an = Math.PI / 8 * j - Math.PI / 2, rr = j % 2 ? r * 0.72 : r; g.lineTo(x + rr * Math.cos(an), y + rr * Math.sin(an)); }
      g.closePath(); g.fillStyle = P.gold; g.fill();
    };
    star(66, 66, 24); star(W - 66, 66, 24); star(66, H - 66, 24); star(W - 66, H - 66, 24);
    g.direction = 'rtl'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = P.gold; g.font = '700 40px Tajawal, sans-serif';
    var y0 = Math.max(pad, (H - 60 - (110 + lines.length * lh)) / 2);   // النص في وسط البطاقة
    g.fillText('﴿ ' + refOf(k) + ' ﴾', W / 2, y0 + 40);
    g.fillStyle = P.ink; g.font = fs + 'px HawlHafs';
    for (var L = 0; L < lines.length; L++) g.fillText(lines[L], W / 2, y0 + 150 + L * lh);
    g.fillStyle = P.gold; g.font = '500 30px Tajawal, sans-serif';
    g.fillText('تطبيق القرآن حول العالم', W / 2, H - pad + 10);
    var b64 = c.toDataURL('image/png').split(',')[1];
    var sent = post({ cmd: 'share', title: 'مشاركة آية', text: refOf(k),
      files: [{ type: 'image/png', name: 'aya-' + k.replace(':', '-') + '.png', data: b64 }] });
    if (!sent) toast('المشاركة متاحة داخل التطبيق');
    closeSheet();
  }

  // ---------------------------------------------------------------- العلامات والملاحظات
  var KINDS = ['ورد', 'حفظ', 'تدبّر', 'عامة'];
  function loadMarks() { try { return JSON.parse(localStorage.getItem('hawl_marks') || '[]'); } catch (e) { return []; } }
  function saveMarks(m) { try { localStorage.setItem('hawl_marks', JSON.stringify(m)); } catch (e) { toast('تعذّر الحفظ'); } }
  function markEditor(k) {
    var marks = loadMarks(), m = null;
    for (var i = 0; i < marks.length; i++) if (marks[i].k === k) m = marks[i];
    var kind = m ? m.kind : 'عامة';
    var chips = KINDS.map(function (x) { return '<button class="chip' + (x === kind ? ' on' : '') + '" data-kind="' + x + '">' + x + '</button>'; }).join('');
    sheet('<div class="sh-t">علامة · ' + esc(refOf(k)) + '</div>' +
      '<div class="chips">' + chips + '</div>' +
      '<textarea id="note" rows="3" placeholder="ملاحظة قصيرة (اختياري)">' + esc(m ? m.note : '') + '</textarea>' +
      '<div class="row2"><button id="mkSave" class="pri">حفظ</button>' + (m ? '<button id="mkDel">حذف العلامة</button>' : '<span></span>') + '</div>');
    $('sheetBody').querySelectorAll('[data-kind]').forEach(function (b) {
      b.onclick = function () {
        kind = b.getAttribute('data-kind');
        $('sheetBody').querySelectorAll('[data-kind]').forEach(function (x) { x.classList.toggle('on', x === b); });
      };
    });
    $('mkSave').onclick = function () {
      var all = loadMarks().filter(function (x) { return x.k !== k; });
      all.unshift({ k: k, p: pageOf[k], kind: kind, note: $('note').value.trim().slice(0, 300), t: Date.now() });
      saveMarks(all); toast('حُفظت العلامة'); closeSheet();
    };
    if (m) $('mkDel').onclick = function () {
      saveMarks(loadMarks().filter(function (x) { return x.k !== k; })); toast('حُذفت العلامة'); closeSheet();
    };
  }
  // ---------------------------------------------------------------- التظليل بالألوان والمجموعات و«ملاحظاتي»
  var HL = [null, 'أصفر', 'أخضر', 'أزرق', 'وردي'];
  function hlLoad() { try { return JSON.parse(localStorage.getItem('hawl_hl') || '{}') || {}; } catch (e) { return {}; } }
  function hlSave(h) { try { localStorage.setItem('hawl_hl', JSON.stringify(h)); } catch (e) { toast('تعذّر الحفظ'); } }
  function hlOf(k) { return hlLoad()[k] || 0; }
  function ayatN(n) { return n === 1 ? 'آية واحدة' : n === 2 ? 'آيتان' : ar(n) + (n % 100 >= 3 && n % 100 <= 10 ? ' آيات' : ' آية'); }
  function hlEditor(k) {
    var cur = hlOf(k);
    sheet('<div class="sh-t">تظليل · ' + esc(refOf(k)) + '</div>' +
      '<div class="hl-pick">' + [1, 2, 3, 4].map(function (c) {
        return '<button class="hl-sw hlc' + c + (c === cur ? ' on' : '') + '" data-c="' + c + '" aria-label="' + HL[c] + '" aria-pressed="' + (c === cur) + '"><span>' + HL[c] + '</span></button>';
      }).join('') + '</div>' +
      (cur ? '<div class="row2"><button id="hlDel">إزالة التظليل</button></div>' : '') +
      '<div class="dim">يظهر اللون على الآية في وضع القراءة وصفحة المصحف، وتجدها في «ملاحظاتي».</div>');
    $('sheetBody').querySelectorAll('[data-c]').forEach(function (b) {
      b.onclick = function () { var h = hlLoad(); h[k] = +b.getAttribute('data-c'); hlSave(h); toast('ظُلّلت الآية'); closeSheet(); };
    });
    if (cur) $('hlDel').onclick = function () { var h = hlLoad(); delete h[k]; hlSave(h); toast('أُزيل التظليل'); closeSheet(); };
  }
  function colLoad() { try { var c = JSON.parse(localStorage.getItem('hawl_cols') || '[]'); return Array.isArray(c) ? c : []; } catch (e) { return []; } }
  function colSave(c) { try { localStorage.setItem('hawl_cols', JSON.stringify(c)); } catch (e) { toast('تعذّر الحفظ'); } }
  function colEditor(k) {
    var cols = colLoad();
    var row = function (c, i) {
      var has = c.keys.indexOf(k) >= 0;
      return '<button class="res col-r' + (has ? ' on' : '') + '" data-i="' + i + '"><b>' + (has ? '✓ ' : '') + esc(c.name) + '</b><span class="dim">' + ayatN(c.keys.length) + '</span></button>';
    };
    sheet('<div class="sh-t">أضف لمجموعة · ' + esc(refOf(k)) + '</div>' +
      (cols.length ? '<div class="list">' + cols.map(row).join('') + '</div>' : '<div class="empty">اجمع الآيات في مجموعات بأسمائك، مثل «آيات الصبر» أو «أدعية قرآنية».</div>') +
      '<div class="col-new"><input id="colName" type="search" maxlength="40" placeholder="اسم مجموعة جديدة"><button class="pri" id="colAdd">أنشئ وأضف</button></div>');
    $('sheetBody').querySelectorAll('[data-i]').forEach(function (b) {
      b.onclick = function () {
        var all = colLoad(), c = all[+b.getAttribute('data-i')]; if (!c) return;
        var at = c.keys.indexOf(k);
        if (at >= 0) { c.keys.splice(at, 1); toast('أُخرجت من «' + c.name + '»'); } else { c.keys.push(k); c.keys.sort(hzSort); toast('أُضيفت إلى «' + c.name + '»'); }
        colSave(all); colEditor(k);
      };
    });
    $('colAdd').onclick = function () {
      var n = $('colName').value.replace(/\s+/g, ' ').trim().slice(0, 40);
      if (!n) { $('colName').focus(); return; }
      var all = colLoad();
      for (var i = 0; i < all.length; i++) if (all[i].name === n) { if (all[i].keys.indexOf(k) < 0) all[i].keys.push(k); colSave(all); toast('أُضيفت إلى «' + n + '»'); colEditor(k); return; }
      all.unshift({ name: n, keys: [k], t: Date.now() }); colSave(all); toast('أُنشئت «' + n + '»'); colEditor(k);
    };
  }
  var myTab = 'marks';
  function marksList(tab, qv) {
    if (tab) myTab = tab;
    var marks = loadMarks(), hl = hlLoad(), cols = colLoad(), nq = norm(qv || '');
    var match = function (k, extra) { return !nq || norm(refOf(k) + ' ' + plain(k) + ' ' + (extra || '')).indexOf(nq) >= 0; };
    var item = function (k, head, body, del) {
      return '<div class="res my" data-k="' + k + '"><b>' + head + '</b><span' + (body.dim ? ' class="dim"' : '') + '>' + esc(body.t) + '</span>' +
        (del ? '<button class="my-x" data-del="' + del + '" aria-label="حذف">✕</button>' : '') + '</div>';
    };
    var h = '', n = 0;
    if (myTab === 'marks') {
      marks.forEach(function (m) {
        if (!match(m.k, m.note + ' ' + m.kind)) return; n++;
        h += item(m.k, esc(m.kind) + ' · ' + esc(refOf(m.k)) + ' · صفحة ' + ar(m.p), m.note ? { t: m.note } : { t: plain(m.k).slice(0, 70) + '…', dim: 1 }, 'm:' + m.k);
      });
      if (!marks.length) h = '<div class="empty">لا توجد علامات بعد.<br>اضغط على أي آية ثم «علامة وملاحظة».</div>';
    } else if (myTab === 'hl') {
      Object.keys(hl).sort(hzSort).forEach(function (k) {
        if (!match(k, HL[hl[k]])) return; n++;
        h += item(k, '<i class="dot hlc' + hl[k] + '"></i> ' + esc(refOf(k)), { t: plain(k).slice(0, 80) + '…' }, 'h:' + k);
      });
      if (!Object.keys(hl).length) h = '<div class="empty">لم تظلّل آيات بعد.<br>اضغط على أي آية ثم «تظليل بلون».</div>';
    } else {
      cols.forEach(function (c, ci) {
        var keys = c.keys.filter(function (k) { return match(k, c.name); });
        if (nq && !keys.length && norm(c.name).indexOf(nq) < 0) return;
        n++;
        h += '<div class="col-h"><b>🗂️ ' + esc(c.name) + '</b><span class="dim">' + ayatN(c.keys.length) + '</span><button class="my-x" data-del="c:' + ci + '" aria-label="حذف المجموعة">✕</button></div>';
        (nq && norm(c.name).indexOf(nq) >= 0 ? c.keys : keys).forEach(function (k) { h += item(k, esc(refOf(k)), { t: plain(k).slice(0, 80) + '…' }, 'ck:' + ci + ':' + k); });
      });
      if (!cols.length) h = '<div class="empty">لا مجموعات بعد.<br>اضغط على أي آية ثم «أضف لمجموعة».</div>';
    }
    if (nq && !n) h = '<div class="empty">لا نتائج لبحثك</div>';
    var title = $('sheet').classList.contains('on') && $('myq');
    sheet('<div class="sh-t">ملاحظاتي</div>' +
      '<div class="rs-sec" id="mytab">' + seg('ملاحظاتي', [['marks', 'العلامات (' + ar(marks.length) + ')'], ['hl', 'المظلّلة (' + ar(Object.keys(hl).length) + ')'], ['cols', 'المجموعات (' + ar(cols.length) + ')']], myTab) + '</div>' +
      '<input id="myq" type="search" autocomplete="off" placeholder="ابحث في ملاحظاتك" value="' + esc(qv || '') + '">' +
      '<div class="list">' + h + '</div>');
    if (title && qv != null) { var inp = $('myq'); inp.focus(); try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) {} }
    $('mytab').querySelectorAll('[data-v]').forEach(function (b) { b.onclick = function () { marksList(b.getAttribute('data-v'), $('myq').value); }; });
    var tm = 0;
    $('myq').oninput = function () { var v = this.value; clearTimeout(tm); tm = setTimeout(function () { marksList(null, v); }, 220); };
    $('sheetBody').querySelectorAll('.my[data-k]').forEach(function (b) {
      b.onclick = function (e) { if (e.target.closest('[data-del]')) return; var k = b.getAttribute('data-k'); closeSheet(); goAyah(k); };
    });
    $('sheetBody').querySelectorAll('[data-del]').forEach(function (b) {
      b.onclick = function (e) {
        e.stopPropagation();
        var d = b.getAttribute('data-del'), p = d.split(':');
        if (p[0] === 'm') saveMarks(loadMarks().filter(function (x) { return x.k !== p[1] + ':' + p[2]; }));
        else if (p[0] === 'h') { var hh = hlLoad(); delete hh[p[1] + ':' + p[2]]; hlSave(hh); }
        else if (p[0] === 'c') { var cc = colLoad(); cc.splice(+p[1], 1); colSave(cc); }
        else if (p[0] === 'ck') { var c2 = colLoad(), cl = c2[+p[1]]; if (cl) cl.keys = cl.keys.filter(function (x) { return x !== p[2] + ':' + p[3]; }); colSave(c2); }
        toast('حُذف'); decorate(); marksList(null, $('myq').value);
      };
    });
  }

  // ---------------------------------------------------------------- البحث دون إنترنت
  var idx = null;
  var norm = function (t) {
    return String(t).replace(/[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
      .replace(/\s+/g, ' ').trim();
  };
  // البحث بالمعنى: نبحث في التفسير الميسر (يشرح الآيات بلغة اليوم) عن كلماتك، فتظهر الآيات التي معناها ما تبحث عنه
  // ولو لم ترد كلماتك في لفظها؛ مع إزالة «ال» و«و/ف/ب/ل» في أول الكلمة واللواحق الشائعة
  var STOP = ' ' + ['في', 'من', 'عن', 'على', 'إلى', 'ما', 'ماذا', 'أو', 'ثم', 'حتى', 'كل', 'عند', 'مع', 'هل', 'لا', 'لم', 'لن', 'قد', 'كيف', 'متى', 'أين',
    'أنا', 'أنت', 'نحن', 'هو', 'هي', 'هذا', 'هذه', 'ذلك', 'تلك', 'التي', 'الذي', 'الذين', 'و', 'يا'].map(function (w) { return norm(w); }).join(' ') + ' ';
  function stem(w) {
    w = norm(w);
    if (w.length > 4 && /^(وال|فال|بال|كال|لل)/.test(w)) w = w.slice(3);
    else if (w.length > 3 && w.indexOf('ال') === 0) w = w.slice(2);
    else if (w.length > 4 && /^[وفبل]/.test(w)) w = w.slice(1);
    if (w.length > 4) w = w.replace(/(ات|ون|ين|ان|ها|هم|كم|نا)$/, '');
    if (w.length > 3) w = w.replace(/[هي]$/, '');
    return w;
  }
  var tafIdx = null;
  function meaningRun(qv) {
    var terms = norm(qv).split(' ').filter(function (w) { return w.length > 1 && STOP.indexOf(' ' + w + ' ') < 0; }).map(stem)
      .map(function (w) { return w.replace(/[^\u0621-\u064A]/g, ''); })
      .filter(function (w) { return w.length > 1; });
    if (!terms.length) return { total: 0, out: [] };
    // الجذر مع حروف المد بين حروفه: «صبر» تطابق «صابر» و«صبور»، و«مرض» تطابق «مريض»
    var res = terms.map(function (t) { return new RegExp(t.length >= 3 && t.length <= 4 ? t.split('').join('[اوي]?') : t); });
    var need = terms.length <= 2 ? terms.length : Math.ceil(terms.length * 0.6), hits = [];
    for (var i = 0; i < idx.length; i++) {
      var r = idx[i], tf = tafIdx[i], score = 0, got = 0;
      for (var j = 0; j < terms.length; j++) {
        var inA = res[j].test(r[4]), inT = res[j].test(tf);
        if (inA || inT) { got++; score += (inA ? 6 : 0) + (inT ? 2 : 0); }
      }
      // الآية التي يتركّز تفسيرها على المعنى (تفسير قصير فيه الكلمات) أقرب مما ذكرها عرضًا في تفسير طويل
      if (got >= need) hits.push([got * 10 + score + 300 / (tf.length + 150), i]);
    }
    hits.sort(function (a, b) { return b[0] - a[0] || a[1] - b[1]; });
    return { total: hits.length, out: hits.slice(0, 60).map(function (h) { return idx[h[1]]; }), terms: terms };
  }
  function snippet(t, terms) {
    var n = norm(t), at = -1;
    for (var j = 0; j < terms.length && at < 0; j++) at = n.indexOf(terms[j]);
    if (at < 0) return t.slice(0, 110) + (t.length > 110 ? '…' : '');
    var a = Math.max(0, at - 45), b = Math.min(t.length, at + 85);    // النص المطبَّع أقصر قليلًا؛ تقريب يكفي للمقتطف
    return (a ? '…' : '') + t.slice(a, b) + (b < t.length ? '…' : '');
  }
  function search(startMode) {
    var mode = startMode === 'meaning' ? 'meaning' : 'word';
    sheet('<div class="sh-t">البحث في القرآن</div>' +
      '<div class="rs-sec" id="smode">' + seg('طريقة البحث', [['word', 'باللفظ'], ['meaning', 'بالمعنى']], mode) + '</div>' +
      '<input id="sq" type="search" autocomplete="off">' +
      '<div class="dim" id="sinfo"></div><div class="list" id="sres"></div>');
    var inp = $('sq'), tm = 0;
    var hint = function () {
      inp.placeholder = mode === 'meaning' ? 'المعنى بكلماتك، مثل: بر الوالدين' : 'اكتب كلمة أو جزءًا من آية';
      $('sinfo').textContent = mode === 'meaning' ? 'يبحث في معاني الآيات من التفسير الميسر · دون إنترنت' : 'يعمل دون إنترنت، ولا يلزم التشكيل.';
    };
    hint();
    setTimeout(function () { inp.focus(); }, 150);
    var show = function (res, terms) {
      $('sinfo').textContent = res.total ? 'عدد النتائج: ' + ar(res.total) + (res.total > 60 ? ' (يظهر أول ٦٠)' : '') : 'لا نتائج';
      $('sres').innerHTML = res.out.map(function (r) {
        var k = r[0] + ':' + r[1];
        return '<button class="res" data-k="' + k + '"><b>سورة ' + esc(nameOf(r[0])) + ' · ' + ar(r[1]) + ' · صفحة ' + ar(r[2]) + '</b><span>' + esc(r[3]) + '</span>' +
          (terms ? '<span class="dim sn">التفسير: ' + esc(snippet(tafOf(k), terms)) + '</span>' : '') + '</button>';
      }).join('');
      $('sres').querySelectorAll('[data-k]').forEach(function (b) {
        b.onclick = function () { var k = b.getAttribute('data-k'); closeSheet(); goAyah(k); };
      });
    };
    var run = function () {
      var raw = inp.value, qv = norm(raw);
      if (qv.length < 2) { $('sres').innerHTML = ''; hint(); return; }
      if (mode === 'meaning') {
        if (!tafIdx) return;
        var mr = meaningRun(raw);
        show(mr, mr.terms);
        return;
      }
      var out = [], total = 0;
      for (var i = 0; i < idx.length; i++) {
        if (idx[i][4].indexOf(qv) >= 0) { total++; if (out.length < 60) out.push(idx[i]); }
      }
      show({ total: total, out: out }, null);
    };
    var prep = function () {
      if (!idx) return;
      if (mode === 'meaning' && !tafIdx) {
        $('sinfo').textContent = 'جارٍ تحضير البحث بالمعنى…';
        loadTafsir(function () {
          tafIdx = idx.map(function (r) { return norm(tafOf(r[0] + ':' + r[1])); });
          hint(); run();
        });
        return;
      }
      run();
    };
    $('smode').querySelectorAll('[data-v]').forEach(function (b) {
      b.onclick = function () {
        mode = b.getAttribute('data-v');
        $('smode').querySelectorAll('[data-v]').forEach(function (x) { x.setAttribute('aria-checked', String(x === b)); });
        hint(); prep(); inp.focus();
      };
    });
    inp.oninput = function () { clearTimeout(tm); tm = setTimeout(run, 180); };
    if (!idx) {
      $('sinfo').textContent = 'جارٍ التحضير…';
      fetch('/__hawl/search.json?v=1').then(function (r) { return r.json(); }).then(function (d) {
        for (var i = 0; i < d.length; i++) d[i].push(norm(d[i][3]));
        idx = d; hint(); prep();
      }).catch(function () { $('sinfo').textContent = 'تعذّر فتح البحث'; });
    } else prep();
  }
  $('btnSearch').onclick = function () { search(); };
  $('btnMarks').onclick = function () { if (data) marksList(); };

  // ---------------------------------------------------------------- التسميع: تقرأ من حفظك فيتابعك التطبيق كلمة بكلمة (تجريبي)
  // التعرّف على الصوت يتم في الجوال نفسه (آيفون/أندرويد) ويُرسل النص هنا عبر window.__hawlSpeech
  // نقارن بالنص الإملائي (search.json) لأنه ما يكتبه المتعرّف على الصوت، مع تسامح في الحروف المتقاربة
  var ts = null;      // { keys, words:[{w,n,k}], i, state, final, hide }
  function tsNorm(w) { return norm(w).replace(/[^ء-ي]/g, '').replace(/^(ال|وال)(?=..)/, function (m) { return m; }); }
  function lev(a, b) {
    if (a === b) return 0;
    var m = a.length, n = b.length, d = [], i, j;
    for (i = 0; i <= m; i++) d[i] = [i];
    for (j = 1; j <= n; j++) d[0][j] = j;
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[m][n];
  }
  function same(heard, want) {
    if (!heard || !want) return false;
    if (heard === want) return true;
    var L = Math.max(heard.length, want.length);
    return L >= 4 ? lev(heard, want) <= (L >= 7 ? 2 : 1) : false;
  }
  /** يطابق كل الكلام المسموع من البداية مع كلمات الآيات: ينتقل للأمام حتى ٤ كلمات (التجاوز يُعلَّم «لم تُقرأ») */
  function tsAlign(text) {
    var heard = String(text).split(/\s+/).map(tsNorm).filter(Boolean), W = ts.words, i = 0;
    W.forEach(function (x) { x.s = 0; });                 // ٠ لم تُقرأ بعد، ١ سليمة، ٢ تجاوزتها
    for (var h = 0; h < heard.length && i < W.length; h++) {
      for (var j = i; j < Math.min(W.length, i + 5); j++) {
        if (same(heard[h], W[j].n)) {
          for (var x = i; x < j; x++) W[x].s = 2;
          W[j].s = 1; i = j + 1; break;
        }
      }
    }
    ts.i = i;
  }
  function tsDraw() {
    if (!ts || !$('tsBody')) return;
    var W = ts.words, html = '', lastK = '';
    W.forEach(function (x) {
      if (x.k !== lastK) { if (lastK) html += ' <span class="ts-n">﴿' + ar(lastK.split(':')[1]) + '﴾</span> '; lastK = x.k; }
      var cls = x.s === 1 ? 'ok' : x.s === 2 ? 'miss' : (x.hint ? 'hint' : (ts.hide ? 'hid' : 'todo'));
      html += '<span class="ts-w ' + cls + '">' + (cls === 'hid' ? '<i style="width:' + Math.max(1.3, Math.min(4.5, x.w.length * 0.45)).toFixed(2) + 'em"></i>' : esc(x.w)) + '</span> ';
    });
    html += '<span class="ts-n">﴿' + ar(lastK.split(':')[1]) + '﴾</span>';
    var miss = W.filter(function (x) { return x.s === 2; });
    var ok = W.filter(function (x) { return x.s === 1; }).length;
    var finished = ts.i >= W.length;
    if (finished && ts.state === 'listening') tsStop();
    var listening = ts.state === 'listening';
    $('tsBody').innerHTML = html;
    $('tsInfo').innerHTML = finished ? (miss.length ? 'انتهيت · تجاوزت ' + ar(miss.length) + (miss.length === 1 ? ' كلمة' : ' كلمات') + ' (بالبرتقالي)' : 'أحسنت، قرأتها كاملة دون تجاوز')
      : listening ? 'أستمع إليك… اقرأ بصوت واضح' : (ts.state === 'error' ? esc(ts.msg || 'تعذّر الاستماع') : 'اضغط «ابدأ» ثم اقرأ');
    $('tsGo').textContent = listening ? 'إيقاف' : (ok ? 'أعد من البداية' : 'ابدأ');
    $('tsGo').classList.toggle('rec', listening);
    if (finished && !ts.logged) {
      ts.logged = true;                                     // سجل الأخطاء: كم كلمة تجاوزت في كل آية
      var per = {};
      W.forEach(function (x) { if (!per[x.k]) per[x.k] = 0; if (x.s === 2) per[x.k]++; });
      Object.keys(per).forEach(function (kk) {
        hzErrAdd(kk, function (e) { e.n = (e.n || 0) + 1; if (per[kk]) e.m = (e.m || 0) + per[kk]; else e.m = Math.max(0, (e.m || 0) - 1); });
      });
      decorate();
    }
    if (finished && ts.onDone && !ts.reported) { ts.reported = true; ts.onDone(miss.length); }
  }
  window.__hawlSpeech = function (o) {
    if (!ts) return;
    if (o.type === 'text') {
      if (o.final) ts.final = (ts.final ? ts.final + ' ' : '') + o.text;
      tsAlign((ts.final || '') + (o.final ? '' : ' ' + (o.text || '')));
    } else if (o.type === 'state') {
      ts.state = o.state; ts.msg = o.msg || '';
    }
    tsDraw();
  };
  function tsStart() {
    ts.final = ''; ts.reported = false; ts.logged = false;
    ts.words.forEach(function (x) { x.s = 0; x.hint = 0; }); ts.i = 0;
    if (!post({ cmd: 'speech', op: 'start', lang: 'ar-SA' })) { ts.state = 'error'; ts.msg = 'التسميع يعمل داخل التطبيق فقط'; tsDraw(); return; }
    ts.state = 'listening'; tsDraw();
  }
  function tsStop() { post({ cmd: 'speech', op: 'stop' }); if (ts) { ts.state = 'stopped'; } }
  /** keys: الآيات المطلوبة بالترتيب؛ hide: إخفاء الكلمات حتى تقرأها (من حفظك)؛ onDone(عدد الكلمات المتجاوزة) */
  function tasmee(keys, hide, onDone) {
    var run = function () {
      var byK = {};
      for (var i = 0; i < idx.length; i++) byK[idx[i][0] + ':' + idx[i][1]] = idx[i][3];
      var words = [];
      keys.forEach(function (k) {
        String(byK[k] || '').split(/\s+/).filter(Boolean).forEach(function (w) { words.push({ w: w, n: tsNorm(w), k: k, s: 0 }); });
      });
      ts = { keys: keys, words: words, i: 0, state: 'idle', final: '', hide: !!hide, onDone: onDone };
      sheet('<div class="sh-t">التسميع · ' + esc(refOf(keys[0])) + (keys.length > 1 ? ' – ' + ar(keys[keys.length - 1].split(':')[1]) : '') + ' <span class="beta">تجريبي</span></div>' +
        '<div class="ts-body" id="tsBody"></div>' +
        '<div class="dim" id="tsInfo" style="text-align:center"></div>' +
        '<div class="row2"><button class="pri" id="tsGo">ابدأ</button><button id="tsHint">💡 الكلمة التالية</button><button id="tsHide">' + (ts.hide ? 'أظهر النص' : 'من حفظي (إخفاء)') + '</button></div>' +
        '<div class="dim" style="font-size:12px">التعرّف على الصوت من نظام جوالك، وقد يخطئ في بعض الكلمات؛ استعمله عونًا على المراجعة لا حكمًا على التلاوة. لا يُحفظ صوتك.</div>');
      $('shade').classList.add('clear');
      $('tsGo').onclick = function () { if (ts.state === 'listening') { tsStop(); tsDraw(); } else tsStart(); };
      $('tsHide').onclick = function () { ts.hide = !ts.hide; this.textContent = ts.hide ? 'أظهر النص' : 'من حفظي (إخفاء)'; tsDraw(); };
      // تلميح: تظهر الكلمة التي توقفت عندها (وتُسجَّل تلميحًا لتلك الآية)
      $('tsHint').onclick = function () {
        var W = ts.words, j = ts.i;
        while (j < W.length && W[j].hint) j++;
        if (j >= W.length) return;
        W[j].hint = 1;
        var kk = W[j].k; hzErrAdd(kk, function (e) { e.h = (e.h || 0) + 1; });
        tsDraw();
      };
      tsDraw();
    };
    if (idx) return run();
    fetch('/__hawl/search.json?v=1').then(function (r) { return r.json(); }).then(function (d) {
      for (var i = 0; i < d.length; i++) d[i].push(norm(d[i][3]));
      idx = d; run();
    }).catch(function () { toast('تعذّر فتح النص'); });
  }

  // ---------------------------------------------------------------- الحفظ: مراجعة متباعدة واختبار ذاتي (على الجهاز)
  // كل آية: { d: يوم المراجعة القادمة، i: الفاصل بالأيام، n: مرات الاختبار، ok: مرات الإتقان، t: وقت الإضافة }
  // «نسيتها» تعود غدًا، «بتردد» بعد ٣ أيام أو أكثر قليلًا، «متقنة» بعد أسبوع ثم تتباعد (×٢٫٥) حتى ستة أشهر
  function hzDay(ms) { var d = new Date(ms || Date.now()); return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000); }
  function hzLoad() { try { return JSON.parse(localStorage.getItem('hawl_hifz') || '{}') || {}; } catch (e) { return {}; } }
  function hzSave(h) {
    try { localStorage.setItem('hawl_hifz', JSON.stringify(h)); } catch (e) { toast('تعذّر الحفظ'); }
    // لبطاقة «مراجعة الحفظ» في شاشة «اليوم»: العدد، وأقرب يوم مراجعة (أيام منذ ١٩٧٠ بالتوقيت المحلي)
    var nx = null; for (var k in h) if (nx === null || h[k].d < nx) nx = h[k].d;
    var st = hzStats(h);
    post({ cmd: 'hifz', due: st.due, total: st.total, held: st.held, pct: st.pct, next: nx === null ? -1 : nx, today: hzDay() });
  }
  function hifzHas(k) { return !!hzLoad()[k]; }
  // سجل الأخطاء لكل آية: { m: كلمات تجاوزتها في التسميع، f: مرات «نسيتها»، h: تلميحات، n: محاولات، t: آخر مرة }
  function hzErrLoad() { try { return JSON.parse(localStorage.getItem('hawl_hzerr') || '{}') || {}; } catch (e) { return {}; } }
  function hzErrSave(e) { try { localStorage.setItem('hawl_hzerr', JSON.stringify(e)); } catch (x) {} }
  function hzErrAdd(k, f) {
    var all = hzErrLoad(), x = all[k] || { m: 0, f: 0, h: 0, n: 0 };
    f(x); x.t = Date.now();
    if (!x.m && !x.f && !x.h) delete all[k]; else all[k] = x;
    hzErrSave(all);
  }
  function hzWeakScore(x) { return x ? (x.f || 0) * 2 + (x.m || 0) + (x.h || 0) * 0.5 : 0; }
  function hzWeakSet() {
    var e = hzErrLoad(), h = hzLoad(), out = {};
    for (var k in e) if (h[k] && hzWeakScore(e[k]) >= 3) out[k] = 1;
    return out;
  }
  function hzWeakKeys() {
    var e = hzErrLoad();
    return Object.keys(hzWeakSet()).sort(function (a, b) { return hzWeakScore(e[b]) - hzWeakScore(e[a]) || hzSort(a, b); });
  }
  function hzSort(a, b) { var x = a.split(':'), y = b.split(':'); return (+x[0] - +y[0]) || (+x[1] - +y[1]); }
  function hzDueKeys(h) { var t = hzDay(), out = []; for (var k in h) if (h[k].d <= t) out.push(k); return out.sort(hzSort); }
  function hzAddKeys(keys) {
    var h = hzLoad(), t = hzDay(), n = 0;
    keys.forEach(function (k) { if (!h[k]) { h[k] = { d: t, i: 0, n: 0, ok: 0, t: Date.now() }; n++; } });
    hzSave(h);
    return n;
  }
  function hifzAdd(k) {
    var p = k.split(':'), s = +p[0], a = +p[1];
    if (hifzHas(k)) {
      sheet('<div class="sh-t">' + esc(refOf(k)) + ' في حفظك</div>' +
        '<div class="row2"><button class="pri" id="hzGo">راجع الآن</button><button id="hzDel">أخرجها من الحفظ</button></div>');
      $('hzGo').onclick = function () { hifzReview(); };
      $('hzDel').onclick = function () { var h = hzLoad(); delete h[k]; hzSave(h); var e = hzErrLoad(); delete e[k]; hzErrSave(e); toast('أُخرجت من الحفظ'); closeSheet(); };
      return;
    }
    var pageKeys = [], surahKeys = [];
    data.pages[pageOf[k] - 1].forEach(function (e) { if (e[0] === s && e[1] >= a) pageKeys.push(e[0] + ':' + e[1]); });
    for (var i = a; i <= ayCount[s]; i++) surahKeys.push(s + ':' + i);
    sheet('<div class="sh-t">ماذا تريد أن تحفظ؟</div>' +
      '<div class="list">' +
      '<button class="res" data-n="1"><b>هذه الآية فقط</b><span>' + esc(refOf(k)) + '</span></button>' +
      (pageKeys.length > 1 ? '<button class="res" data-n="2"><b>من هنا إلى آخر الصفحة</b><span>' + ar(pageKeys.length) + ' آيات</span></button>' : '') +
      (surahKeys.length > pageKeys.length ? '<button class="res" data-n="3"><b>من هنا إلى آخر سورة ' + esc(nameOf(s)) + '</b><span>' + ar(surahKeys.length) + ' آية، تُعرض عليك تباعًا</span></button>' : '') +
      '</div><div class="dim">نعرض عليك الآيات للمراجعة في أوقات متباعدة حسب إتقانك، وكل شيء محفوظ على جهازك.</div>');
    $('sheetBody').querySelectorAll('[data-n]').forEach(function (b) {
      b.onclick = function () {
        var nn = +b.getAttribute('data-n');
        var added = hzAddKeys(nn === 1 ? [k] : nn === 2 ? pageKeys : surahKeys);
        toast(added ? 'أُضيفت ' + ar(added) + (added === 1 ? ' آية' : ' آيات') + ' إلى حفظك' : 'موجودة في حفظك');
        hifzReview();
      };
    });
  }
  var hz = null;              // جلسة المراجعة: { q: الآيات المتبقية، cur، shown: عدد الكلمات الظاهرة، words، done }
  function hifzReview() {
    var h = hzLoad(), q = hzDueKeys(h);
    hz = { q: q, done: 0, total: q.length };
    hzNext();
  }
  function hzNext() {
    if (!hz.q.length) { hzSummary(); return; }
    var k = hz.q[0];
    hz.cur = k; hz.words = plain(k).split(/\s+/).filter(Boolean);
    hz.shown = Math.min(2, Math.max(1, hz.words.length - 1));
    hzDraw(false);
  }
  function hzDraw(revealed) {
    if (ts) { if (ts.state === 'listening') tsStop(); ts = null; }
    var k = hz.cur, w = hz.words, h = hzLoad(), it = h[k] || { i: 0 };
    var txt = w.map(function (x, i) {
      return revealed || i < hz.shown ? esc(x) : '<span class="hz-m" style="width:' + Math.max(1.4, Math.min(5, x.length * 0.42)).toFixed(2) + 'em"></span>';
    }).join(' ');
    var pct = hz.total ? Math.round(hz.done * 100 / hz.total) : 0;
    var next = function (g) {
      var i = it.i || 0;
      if (g === 0) return 1;
      if (g === 1) return Math.max(3, Math.round(i * 1.2));
      return i < 7 ? 7 : Math.min(180, Math.round(i * 2.5));
    };
    var when = function (d) { return d === 1 ? 'غدًا' : d < 7 ? 'بعد ' + ar(d) + ' أيام' : d === 7 ? 'بعد أسبوع' : d < 30 ? 'بعد ' + ar(d) + ' يومًا' : 'بعد ' + ar(Math.round(d / 30)) + (Math.round(d / 30) <= 2 ? ' شهر' : ' أشهر'); };
    sheet('<div class="sh-t">مراجعة الحفظ</div>' +
      '<div class="hz-bar"><span style="width:' + pct + '%"></span></div>' +
      '<div class="hz-top"><b>' + esc(refOf(k)) + '</b><span>' + ar(hz.done + 1) + ' من ' + ar(hz.total) + '</span></div>' +
      (mutOf(k).length ? '<button class="mt-chip" id="hzMut">≈ لها ' + (mutOf(k).length === 1 ? 'آية متشابهة' : ayatN(mutOf(k).length) + ' متشابهة') + '</button>' : '') +
      '<div class="hz-q">' + txt + '</div>' +
      (revealed
        ? '<div class="hz-h">كيف كان حفظك؟</div><div class="hz-g">' +
          '<button data-g="0"><b>نسيتها</b><span>' + when(next(0)) + '</span></button>' +
          '<button data-g="1"><b>بتردد</b><span>' + when(next(1)) + '</span></button>' +
          '<button data-g="2" class="pri"><b>متقنة</b><span>' + when(next(2)) + '</span></button></div>'
        : '<div class="row2"><button id="hzWord">كلمة واحدة</button><button class="pri" id="hzShow">أظهر الآية</button><button id="hzPlay" aria-label="استمع للآية">🎧</button><button id="hzMic" aria-label="سمّع بصوتك">🎙️</button></div>' +
          '<div class="dim">اقرأ الآية من حفظك أولًا، ثم أظهرها لتتأكد.</div>'));
    $('shade').classList.add('clear');
    if ($('hzMut')) $('hzMut').onclick = function () { mutSheet(k, function () { hzDraw(revealed); }); };
    if (revealed) {
      $('sheetBody').querySelectorAll('[data-g]').forEach(function (b) {
        b.onclick = function () {
          var g = +b.getAttribute('data-g'), all = hzLoad(), x = all[k] || { i: 0, n: 0, ok: 0, t: Date.now() };
          x.i = next(g); x.d = hzDay() + x.i; x.n = (x.n || 0) + 1; if (g === 2) x.ok = (x.ok || 0) + 1;
          all[k] = x; hzSave(all);
          hzErrAdd(k, function (e) {
            e.n = (e.n || 0) + 1;
            if (g === 0) e.f = (e.f || 0) + 1;
            else if (g === 2) { e.f = Math.max(0, (e.f || 0) - 1); e.m = Math.max(0, (e.m || 0) - 2); e.h = Math.max(0, (e.h || 0) - 1); }
          });
          hz.q.shift(); hz.done++;
          if (g === 0) hz.q.push(k), hz.total++;        // المنسية تعود في آخر الجلسة نفسها
          hzNext();
        };
      });
    } else {
      $('hzWord').onclick = function () { hzErrAdd(k, function (e) { e.h = (e.h || 0) + 1; }); if (hz.shown < w.length) hz.shown++; if (hz.shown >= w.length) hzDraw(true); else hzDraw(false); };
      $('hzShow').onclick = function () { hzDraw(true); };
      // التسميع: تقرأ الآية من حفظك، فإن انتهت دون تجاوز اقترحنا «متقنة»
      $('hzMic').onclick = function () { tasmee([k], true, function () { setTimeout(function () { if (ts && ts.keys[0] === k) { tsStop(); hzDraw(true); } }, 1600); }); };
      $('hzPlay').onclick = function () { if (playing) stopAudio(); audio.src = 'https://everyayah.com/data/' + reciter + '/' + pad3(k.split(':')[0]) + pad3(k.split(':')[1]) + '.mp3'; audio.play().catch(function () { toast('الاستماع يحتاج اتصالًا بالإنترنت'); }); };
    }
  }
  function hzStats(h) {
    var keys = Object.keys(h), held = 0, n = 0, ok = 0, t = hzDay(), soon = null;
    keys.forEach(function (k) { var x = h[k]; if (x.i >= 7) held++; n += x.n || 0; ok += x.ok || 0; if (x.d > t && (soon === null || x.d < soon)) soon = x.d; });
    return { total: keys.length, held: held, pct: n ? Math.round(ok * 100 / n) : 0, soon: soon, due: hzDueKeys(h).length };
  }
  function hzSummary() {
    var h = hzLoad(), st = hzStats(h);
    if (!st.total) {
      sheet('<div class="sh-t">الحفظ</div><div class="empty">لم تبدأ الحفظ بعد.<br>اضغط على أي آية ثم «أضفها لحفظي»، ونعرضها عليك للمراجعة في أوقات متباعدة حتى تثبت.</div>');
      return;
    }
    var nextTxt = st.due ? ar(st.due) + ' آيات تنتظر المراجعة' : (st.soon !== null ? 'المراجعة القادمة ' + (st.soon - hzDay() === 1 ? 'غدًا' : 'بعد ' + ar(st.soon - hzDay()) + ' أيام') : '');
    var weak = hzWeakKeys();
    sheet('<div class="sh-t">' + (hz && hz.done ? 'أحسنت، انتهت مراجعة اليوم' : 'الحفظ') + '</div>' +
      '<div class="hz-st"><div><b>' + ar(st.total) + '</b><span>آية في حفظك</span></div><div><b>' + ar(st.held) + '</b><span>ثابتة</span></div><div><b>' + ar(st.pct) + '٪</b><span>الإتقان</span></div></div>' +
      '<div class="dim" style="text-align:center">' + nextTxt + '</div>' +
      (weak.length ? '<div class="hz-weak"><b>⚠️ ' + ayatN(weak.length) + (weak.length === 2 ? ' تحتاجان' : ' تحتاج') + ' عناية</b><span>من أخطاء التسميع والنسيان والتلميحات</span></div>' : '') +
      '<div class="row2">' + (st.due ? '<button class="pri" id="hzAgain">راجع الآن</button>' : '') + (weak.length ? '<button' + (st.due ? '' : ' class="pri"') + ' id="hzWeak">راجع الضعيفة</button>' : '') + '<button id="hzList">آياتي في الحفظ</button></div>');
    if (st.due) $('hzAgain').onclick = hifzReview;
    if (weak.length) $('hzWeak').onclick = function () { hz = { q: weak.slice(), done: 0, total: weak.length }; hzNext(); };
    $('hzList').onclick = hzList;
  }
  function hzList() {
    var h = hzLoad(), keys = Object.keys(h).sort(hzSort), t = hzDay(), wk = hzWeakSet();
    sheet('<div class="sh-t">آياتي في الحفظ (' + ar(keys.length) + ')</div><div class="list">' + keys.map(function (k) {
      var x = h[k], d = x.d - t;
      return '<button class="res" data-k="' + k + '"><b>' + (wk[k] ? '⚠️ ' : '') + (mutOf(k).length ? '≈ ' : '') + esc(refOf(k)) + ' · ' + (d <= 0 ? 'للمراجعة الآن' : 'بعد ' + ar(d) + (d <= 10 ? ' أيام' : ' يومًا')) + (wk[k] ? ' · تحتاج عناية' : '') + '</b><span>' + esc(plain(k).slice(0, 70)) + '…</span></button>';
    }).join('') + '</div>');
    $('sheetBody').querySelectorAll('[data-k]').forEach(function (b) { b.onclick = function () { var k = b.getAttribute('data-k'); closeSheet(); goAyah(k); }; });
  }
  function hifzHome() { var h = hzLoad(); if (hzDueKeys(h).length) hifzReview(); else { hz = null; hzSummary(); } }
  $('btnHifz').onclick = function () { if (data) hifzHome(); };

  // ---------------------------------------------------------------- التنقل
  var sx = 0, sy = 0, t0 = 0;
  var swipeStart = function (e) { var t = e.touches[0]; sx = t.clientX; sy = t.clientY; t0 = Date.now(); };
  wrap.addEventListener('touchstart', swipeStart, { passive: true });
  rd.addEventListener('touchstart', swipeStart, { passive: true });
  var swipeEnd = function (e) {
    var t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5 && Date.now() - t0 < 800) go(N + (dx > 0 ? 1 : -1));
  };
  wrap.addEventListener('touchend', swipeEnd, { passive: true });
  rd.addEventListener('touchend', swipeEnd, { passive: true });
  $('next').onclick = function () { go(N + 1); };
  $('prev').onclick = function () { go(N - 1); };
  $('pg').onchange = function () { go(+this.value); };
  $('sura').onchange = function () { var s = +this.value; goAyah(s + ':1'); sel = null; decorate(); };
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 200); });
  try { new ResizeObserver(function () { if (Math.abs(wrap.clientHeight - frameH) > 2) drawFrame(); }).observe(root); } catch (e) {}

  Promise.all([
    fetch('/__hawl/mushaf.json?v=18').then(function (r) { return r.json(); }),
    document.fonts ? document.fonts.load('100px HawlHafs') : Promise.resolve()
  ]).then(function (res) {
    data = res[0];
    for (var p = 0; p < 604; p++) {
      var pg = data.pages[p];
      for (var i = 0; i < pg.length; i++) {
        var k = pg[i][0] + ':' + pg[i][1];
        if (!pageOf[k]) pageOf[k] = p + 1;
        textOf[k] = pg[i][4];
        ayCount[pg[i][0]] = Math.max(ayCount[pg[i][0]] || 0, pg[i][1]);
      }
    }
    var h = '';
    for (var s = 0; s < 114; s++) h += '<option value="' + (s + 1) + '">' + ar(s + 1) + ' · ' + data.names[s] + '</option>';
    $('sura').innerHTML = h;
    var hp = '';
    for (var n = 1; n <= 604; n++) hp += '<option value="' + n + '">صفحة ' + ar(n) + '</option>';
    $('pg').innerHTML = hp;
    draw();
    libKeys(); mutLoad();
    if (Object.keys(hzLoad()).length) hzSave(hzLoad());
    // عند الاستعادة نطلب البيانات أولًا ولا نرسل حالة الجهاز القديمة (كانت تمحو النسخة المستعادة)
    if (restoreReq) post({ cmd: 'restore' }); else stateNow();
    if (startTool === 'hifz') hifzHome();                     // «الحفظ» من شاشات التطبيق
    else if (startTool === 'find') search('meaning');
  }).catch(function () {
    root.innerHTML = '<p style="text-align:center;padding:40px 10px">تعذّر فتح المصحف. أعد تشغيل التطبيق.</p>';
  });
})();
