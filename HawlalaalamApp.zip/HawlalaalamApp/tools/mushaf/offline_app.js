/* المصحف دون إنترنت: صفحات مصحف المدينة من ملفات التطبيق (بيانات المجمع + خطه) */
(function () {
  var night = window.__hawlTheme ? window.__hawlTheme === 'dark'
    : (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', night ? 'dark' : 'light');
  var FC = night ? { paper: '#142A2F', gold: '#C9A876', deep: '#0D2529', band: '#1C383E', accent: '#A65444', numColor: '#E2C892' }
                 : { paper: '#FBF6E8', gold: '#B8924A', deep: '#1F4E4A', band: '#F2E6C9', accent: '#9A3A2E', numColor: '#6E5326' };
  var st = document.createElement('style');
  st.textContent = HawlMushaf.CSS;
  document.head.appendChild(st);

  var ar = function (n) { return String(n).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); };
  var q = /[?&]page=(\d{1,3})/.exec(location.search);
  var N = q ? Math.min(604, Math.max(1, +q[1])) : 1;
  var data = null, wrap = document.getElementById('fw'), root = document.getElementById('mp');
  var frameH = 0, frameSc = 1;

  function textZoom() {
    var z = 1;
    try {
      var p = document.createElement('span');
      p.style.cssText = 'position:absolute;visibility:hidden;font-size:100px';
      document.body.appendChild(p);
      z = parseFloat(getComputedStyle(p).fontSize) / 100 || 1;
      p.parentNode.removeChild(p);
    } catch (e) {}
    if (Math.abs(z - 1) < 0.02 && window.__hawlZoom) z = window.__hawlZoom / 100;
    return z > 0.5 && z < 3 ? z : 1;
  }
  function drawFrame() {
    var old = wrap.querySelector(':scope > svg');
    if (old) old.remove();
    var c = {}; for (var k in FC) c[k] = FC[k];
    c.scale = frameSc; c.num = ar(N);
    frameH = wrap.clientHeight;
    wrap.insertAdjacentHTML('afterbegin', hawlFrame(wrap.clientWidth, frameH, c));
  }
  function draw() {
    if (!data) return;
    var sc = Math.max(0.45, Math.min(1, (wrap.clientWidth || 360) / 800));
    var mm = Math.min(1.9, Math.max(1, 0.85 / sc));
    var bottom = Math.max(52, 48 * mm + 10) * sc;
    root.style.padding = Math.round(54 * sc) + 'px ' + Math.round(50 * sc) + 'px ' + Math.round(bottom) + 'px';
    HawlMushaf.render(data, N, root, { pad: 0.012, zoom: textZoom() });
    frameSc = sc;
    drawFrame();
    document.getElementById('pg').value = N;
    document.title = 'صفحة ' + ar(N) + ' من المصحف الشريف';
    var s = data.pages[N - 1][0][0];
    document.getElementById('sura').value = String(s);
  }
  function go(n, push) {
    n = Math.min(604, Math.max(1, n | 0));
    if (n === N && data && root.firstChild) return;
    N = n;
    try { history.replaceState(null, '', location.pathname + '?page=' + N); } catch (e) {}
    draw();
    window.scrollTo(0, 0);
  }
  // السحب: اليمين = الصفحة التالية (اتجاه المصحف)
  var sx = 0, sy = 0, t0 = 0;
  wrap.addEventListener('touchstart', function (e) { var t = e.touches[0]; sx = t.clientX; sy = t.clientY; t0 = Date.now(); }, { passive: true });
  wrap.addEventListener('touchend', function (e) {
    var t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5 && Date.now() - t0 < 800) go(N + (dx > 0 ? 1 : -1));
  }, { passive: true });
  document.getElementById('next').onclick = function () { go(N + 1); };
  document.getElementById('prev').onclick = function () { go(N - 1); };
  document.getElementById('pg').onchange = function () { go(+this.value); };
  document.getElementById('sura').onchange = function () {
    var s = +this.value;
    for (var p = 0; p < 604; p++) {
      var pg = data.pages[p];
      for (var i = 0; i < pg.length; i++) if (pg[i][0] === s && pg[i][1] === 1) { go(p + 1); return; }
    }
  };
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 200); });
  try { new ResizeObserver(function () { if (Math.abs(wrap.clientHeight - frameH) > 2) drawFrame(); }).observe(root); } catch (e) {}

  Promise.all([
    fetch('/__hawl/mushaf.json?v=18').then(function (r) { return r.json(); }),
    document.fonts ? document.fonts.load('100px HawlHafs') : Promise.resolve()
  ]).then(function (res) {
    data = res[0];
    var sel = document.getElementById('sura'), h = '';
    for (var i = 0; i < 114; i++) h += '<option value="' + (i + 1) + '">' + ar(i + 1) + ' · ' + data.names[i] + '</option>';
    sel.innerHTML = h;
    var pgSel = document.getElementById('pg'), hp = '';
    for (var p = 1; p <= 604; p++) hp += '<option value="' + p + '">صفحة ' + ar(p) + '</option>';
    pgSel.innerHTML = hp;
    draw();
  }).catch(function () {
    root.innerHTML = '<p style="text-align:center;padding:40px 10px">تعذّر فتح المصحف. أعد تشغيل التطبيق.</p>';
  });
})();
