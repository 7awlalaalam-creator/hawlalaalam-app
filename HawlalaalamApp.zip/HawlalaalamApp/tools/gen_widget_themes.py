#!/usr/bin/env python3
"""يولّد نسخ الويدجت النهارية (_l) والليلية (_d) من النسخة التلقائية.
النسخة التلقائية تستخدم @color/w_* التي تتبدّل مع وضع الجوال،
والنسخ الثابتة تُستخدم حين يختار المستخدم «نهاري» أو «ليلي» من التطبيق.
شغّله بعد أي تعديل على widget_prayer.xml أو widget_prayer_small.xml أو widget_verse.xml أو wdg_*.xml:
    python3 tools/gen_widget_themes.py
"""
import os, re
RES = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res')
FILES = [('layout', 'widget_prayer'), ('layout', 'widget_prayer_small'), ('layout', 'widget_verse'),
         ('drawable', 'wdg_card'), ('drawable', 'wdg_progress'), ('drawable', 'wdg_tip'), ('drawable', 'wdg_cell')]
for folder, name in FILES:
    src = open(os.path.join(RES, folder, name + '.xml'), encoding='utf-8').read()
    for suf, pre in (('_l', 'wl_'), ('_d', 'wd_')):
        out = src.replace('@color/w_', '@color/' + pre)
        out = re.sub(r'@drawable/(wdg_\w+)', lambda m: '@drawable/' + m.group(1) + suf, out)
        out = out.replace('<?xml version="1.0" encoding="utf-8"?>',
                          '<?xml version="1.0" encoding="utf-8"?>\n<!-- مولّد تلقائيًا من ' + name + '.xml — لا تعدّله يدويًا -->', 1)
        open(os.path.join(RES, folder, name + suf + '.xml'), 'w', encoding='utf-8').write(out)
print('done')
