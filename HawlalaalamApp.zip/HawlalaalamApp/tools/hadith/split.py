import re
HAR = re.compile(r'[ً-ْٰـ]')
V = {'حدثنا','حدثني','حدثناه','حدثنيه','أخبرنا','أخبرني','أخبرناه','أخبرنيه','أنبأنا','أنبأني','عن','سمعت','سمع','حدثه','أخبره','حدثهم','أخبرهم','حدث','يحدث','يعني','وهو','هو','ح','كلاهما','جميعا','كلهم','واللفظ','حدثتني','أخبرتني','حدثته','أخبرته','عنه','قراءة'}
SPEECH = {'قال','قالت','قالا','قالوا','يقول','تقول','يقولان','فقال','فقالت'}
ANN = {'أن','أنه','أنها','أنهما','أنهم'}
REPORT = {'قال','قالت','أخبره','أخبرها','حدثه','حدثها','أخبرهم','حدثهم','حدث','يحدث','أخبرته','حدثته'}

def toks(t):
    """words with their [start,end) offsets in the original text; key = plain word without و / punctuation"""
    out = []
    for m in re.finditer(r'\S+', t):
        w = HAR.sub('', m.group()).strip('،,:.؛"«»()-ـ‏')
        out.append((w, m.start(), m.end()))
    return out

def base(w):
    return w[1:] if len(w) > 2 and w.startswith('و') and (w[1:] in V or w[1:] in SPEECH) else w

def split(t):
    T = toks(t)
    if not T or base(T[0][0]) not in V: return '', t, ''
    n = len(T); i = 0; last_name = None; cur_start = None; end = None; names = []
    while i < n:
        w = base(T[i][0]); nxt = base(T[i + 1][0]) if i + 1 < n else ''
        if w in ('رضي', 'رضى') and nxt == 'الله':
            j = i + 2
            if j < n and T[j][0].startswith('عن'): j += 1
            end = T[j - 1][2]
            while j < n and T[j][0] in ('', 'ـ'): end = T[j][2]; j += 1
            break
        third = base(T[i + 2][0]) if i + 2 < n else ''
        if w in SPEECH and nxt not in V and third not in V and not (nxt in SPEECH and third in V):
            end = T[i][1]; break
        if w in ANN:
            look = [base(x[0]) for x in T[i + 1:i + 7]]
            prophet = any(x in ('رسول','النبي') for x in look[:2])
            k = next((q for q, x in enumerate(look) if x in REPORT), None)
            if look and look[0] in V and not prophet: k = 0
            if not prophet and k is not None and k <= 4:
                if cur_start is not None:
                    last_name = (cur_start, T[i - 1][2]); names.append(last_name)
                cur_start = T[i + 1][1]; i += 1; continue
            end = T[i][1]; break
        if w in ('سمعت', 'سمع', 'عن') and nxt in ('رسول', 'النبي', 'لرسول', 'للنبي') and names:
            # «... قال سمعت رسول الله ﷺ يقول»: the matn starts with the companion's own words
            prev = base(T[i - 1][0]) if i > 0 else ''
            end = T[i - 1][1] if prev in SPEECH else T[i][1]
            if cur_start is not None and cur_start < end: names.append((cur_start, end)); cur_start = None
            break
        if w in V:
            if cur_start is not None:
                last_name = (cur_start, T[i - 1][2]); names.append(last_name)
            cur_start = T[i + 1][1] if i + 1 < n else None
        i += 1
    if end is None: return '', t, ''
    if cur_start is not None and cur_start < end: last_name = (cur_start, end); names.append(last_name)
    isnad = t[:end].strip(' ،,:-ـ')
    # guards: the chain never carries the Prophet's words or the story
    pi = HAR.sub('', isnad)
    body = re.sub(r'(?:عن|سمعت)\s+(?:النبي|رسول الله)\s+صلى الله عليه وسلم\s*$', '', pi.strip(' ،,:-ـ'))
    if 'صلى الله عليه وسلم' in body or len(pi) > 0.8 * len(HAR.sub('', t)): return '', t, ''
    # the companion is the last name that is not the Prophet ﷺ
    while names and re.search(r'النبي|رسول', HAR.sub('', t[names[-1][0]:names[-1][1]])): names.pop()
    last_name = names[-1] if names else None
    matn = t[end:].strip(' ،,:-ـ"‏')
    if len(HAR.sub('', matn)) < 8 or len(HAR.sub('', isnad)) < 10: return '', t, ''
    name = ''
    if last_name:
        name = t[last_name[0]:last_name[1]]
        name = re.split(r'\s*ـ\s*|\s+(?:رَضِيَ|رضى|رضي)\s', name)[0].strip(' ،,:-ـ')
        name = re.sub(r'^(?:وَ)?(?:قَالَ|قَالَتْ)\s+', '', name)
        if len(HAR.sub('', name).split()) > 5 or not name: name = ''
    return isnad, matn, name

def nice_name(name):
    """narrator for display: no diacritics, nominative kunya (أبي/أبا → أبو)"""
    n = HAR.sub('', name).strip(' ،,:-ـ')
    n = re.sub(r'^(?:ل|ب)(?=أب|ابن|عبد)', '', n)
    n = re.sub(r'\s*[،,]\s*', ' ', n)
    n = re.sub(r'\s+(?:قال|قالت|يقول|تقول)$', '', n)
    w = n.split()
    if w and w[0] in ('أبي', 'أبا'): w[0] = 'أبو'
    return ' '.join(w)
