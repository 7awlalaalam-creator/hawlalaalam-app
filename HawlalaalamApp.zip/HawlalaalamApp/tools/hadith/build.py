"""Builds the app's hadith files (Sahih al-Bukhari, Sahih Muslim).
Text + standard numbering: fawazahmed0/hadith-api (public domain, Unlicense).
Arabic book titles: AhmedBaset/hadith-json v1.2.0 (ISC licence)."""
import json, re, sys, zlib, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from split import split, nice_name, HAR
SRC = '/tmp/claude-0/hd'
OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/hadith/out'
os.makedirs(OUT, exist_ok=True)

def clean(t):
    t = t.replace('‏', '').replace('‎', '').replace(' ', ' ')
    t = t.replace('"', '"')
    t = re.sub(r'\s+([،,:.؟])', r'\1', t)
    t = re.sub(r'\s{2,}', ' ', t)
    return t.strip()

def tidy_matn(m):
    m = m.strip(' ،,:-ـ"')
    m = re.sub(r'\s*"\s*', ' ', m)            # quotation marks from the source
    m = re.sub(r'\s+\.', '.', m)
    m = re.sub(r'\{\s*([^{}]+?)\s*\}', r'﴿\1﴾', m)      # الآيات معلَّمة في المصدر بأقواس { }
    m = re.sub(r'\s{2,}', ' ', m)
    return m.strip()

def names(path):
    d = json.load(open(path, encoding='utf-8'))
    return {c['id']: c['arabic'].replace('الوحى', 'الوحي') for c in d['chapters']}

CHAIN_ONLY = re.compile(r'بهذا الإسناد|بإسناد|مثله|نحوه|بمثله|بنحوه|بمعنى حديث')

def build(fawaz, ahmed, key, title, muslim):
    d = json.load(open(f'{SRC}/{fawaz}.json', encoding='utf-8'))
    bn = names(f'{SRC}/{ahmed}.json')
    groups = {}
    last_book = 1
    for h in d['hadiths']:
        text = clean(h.get('text') or '')
        if len(HAR.sub('', text)) < 20: continue
        book = int(h['reference']['book'])
        if muslim:
            an = h.get('arabicnumber')
            if an in (None, ''): continue
            num = int(float(an))
        else:
            if h['hadithnumber'] != int(h['hadithnumber']): continue
            num = int(h['hadithnumber'])
            if book == 0: book = last_book          # missing reference: same book as the hadith before it
            last_book = book
        groups.setdefault(num, []).append((book, text))
    rows = []
    for num in sorted(groups):
        cands = groups[num]
        # the main narration: first one that is not only another chain ("بهذا الإسناد مثله")
        pick = next((c for c in cands if not CHAIN_ONLY.search(HAR.sub('', c[1])[-120:]) or len(HAR.sub('', c[1])) > 400), cands[0])
        book, text = pick
        isnad, matn, nar = split(text)
        matn = tidy_matn(matn) if isnad else re.sub(r"\{\s*([^{}]+?)\s*\}", r"﴿\1﴾", matn)
        rows.append([num, book, isnad, matn, nice_name(nar) if nar else ''])
    counts = {}
    for r in rows: counts[r[1]] = counts.get(r[1], 0) + 1
    books = [[b, bn.get(b, 'المقدمة') if b else 'المقدمة', counts[b]] for b in sorted(counts)]
    out = {'v': 1, 'key': key, 'title': title, 'books': books, 'h': rows}
    raw = json.dumps(out, ensure_ascii=False, separators=(',', ':')).encode()
    open(f'{OUT}/hadith-{key}.json', 'wb').write(raw)
    co = zlib.compressobj(9, zlib.DEFLATED, -15)               # raw DEFLATE: Inflater(true) / NSData .zlib
    open(f'{OUT}/hadith-{key}.deflate', 'wb').write(co.compress(raw) + co.flush())
    print(key, len(rows), 'hadiths', len(books), 'books', 'split', sum(1 for r in rows if r[2]),
          'narrator', sum(1 for r in rows if r[4]), os.path.getsize(f'{OUT}/hadith-{key}.deflate') // 1024, 'KB')
    return rows

B = build('ara-bukhari', 'bukhari', 'bukhari', 'صحيح البخاري', False)
M = build('ara-muslim', 'muslim', 'muslim', 'صحيح مسلم', True)

# «حديث اليوم»: قول نبوي قصير له سند ومتن وراوٍ، من الصحيحين
daily = []
AVOID = re.compile(r'\{|قاتل|زنى|الزنا|يزني|قتل|يقتل|جلد|رجم|الخمر|الحد|سرق|يهود|نصارى|كلب|بول|غائط|حيض|الحائض|جنابة|امرأته|النساء|جماع|الدجال|عذاب|النار|لعن|ملعون|دم|بقرة|ضحى|ذبح')
START = re.compile(r'^(?:قال )?(?:قال رسول الله|قال النبي|أن رسول الله صلى الله عليه وسلم قال|أن النبي صلى الله عليه وسلم قال|عن النبي صلى الله عليه وسلم قال|عن رسول الله صلى الله عليه وسلم قال|سمعت رسول الله صلى الله عليه وسلم يقول|قال سمعت رسول الله صلى الله عليه وسلم يقول|قال سمعت النبي صلى الله عليه وسلم يقول)')
for key, rows in (('bukhari', B), ('muslim', M)):
    for r in rows:
        m = HAR.sub('', r[3])
        if r[2] and r[4] and 40 <= len(m) <= 160 and START.match(m) and not AVOID.search(m):
            daily.append([key, r[0]])
import random
random.Random(1447).shuffle(daily)
json.dump({'v': 1, 'daily': daily[:400]}, open(f'{OUT}/hadith-daily.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('daily', len(daily))
