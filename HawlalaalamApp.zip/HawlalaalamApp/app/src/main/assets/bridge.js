/* جسر التطبيق: يضيف ميزة المشاركة (navigator.share) وحفظ الصور المولَّدة داخل WebView */
(function () {
  if (window.__hawlBridge) return;
  window.__hawlBridge = true;

  // 0) Google Analytics: تمييز زوار التطبيق (قبل تحميل gtag في الصفحة)
  try {
    window.dataLayer = window.dataLayer || [];
    var gt = function () { window.dataLayer.push(arguments); };
    gt('set', 'user_properties', { client_type: 'android_app' });
    gt('set', { client_type: 'android_app' });
    if (window.__hawlInternal) gt('set', { traffic_type: 'internal' });   // جوال صاحب الموقع
  } catch (e) {}

  // ---------------------------------------------------------------- داخل التطبيق
  // العلامة HawlalaalamApp في userAgent: نُعلم الموقع بالمظهر ونخفي شريطه السفلي
  // لأن التطبيق يعرض شريطه الثابت أسفل الشاشة.
  var IN_APP = /HawlalaalamApp\//.test(navigator.userAgent);
  if (IN_APP) {
    var root = document.documentElement;
    var theme = window.__hawlTheme === 'dark' ? 'dark' : 'light';
    try {
      root.classList.add('hawl-app', 'hawl-' + theme);
      root.setAttribute('data-app', 'android');
      root.setAttribute('data-app-theme', theme);
      // الأسماء الشائعة لمفتاح الثيم، ليلتقطها قالب الموقع أيًّا كان اسمه
      root.setAttribute('data-theme', theme);
      root.setAttribute('data-mode', theme);
      root.setAttribute('data-bs-theme', theme);
      if (theme === 'dark') root.classList.add('dark', 'dark-mode'); else root.classList.remove('dark', 'dark-mode');
      try { localStorage.setItem('theme', theme); } catch (e) {}
      // مفتاح الوضع الليلي الحقيقي في قالب الموقع: html[data-hw-mode] + التخزين hw-mode
      // (بدونه كان WebView يعتّم الصفحة الفاتحة آليًا فتظهر رمادية بنص أزرق)
      root.setAttribute('data-hw-mode', theme);
      try { localStorage.setItem('hw-mode', theme); localStorage.setItem('awl_mode_manual', theme); } catch (e) {}
      window.dispatchEvent(new CustomEvent('hawl-theme', { detail: theme }));
    } catch (e) {}

    // ------------------------------------------------ توحيد ألوان الموقع مع ألوان التطبيق
    // القيم نفسها في res/values و res/values-night للتطبيق
    // محددات بأولوية أعلى من قواعد القالب (html[data-hw-mode] body.hawl-themed …) دون إفراط في !important
    var D = 'html.hawl-app[data-app][data-hw-mode="dark"] body', L = 'html.hawl-app[data-app][data-hw-mode="light"] body',
        A = 'html.hawl-app[data-app][data-hw-mode] body';
    var unify = document.createElement('style');
    unify.id = 'hawl-unify';
    unify.textContent =
      // يمنع التعتيم الآلي في WebView لأن الصفحة صار لها وضع داكن حقيقي
      'html.hawl-app[data-hw-mode="dark"]{color-scheme:dark;background:#0B1A1E!important}' +
      'html.hawl-app[data-hw-mode="light"]{color-scheme:light;background:#F6F8F9!important}' +
      // رموز الصفحات الحديثة في القالب
      D + '{--bg:#0B1A1E;--surface:#12262B;--surface-2:#1A3439;--text:#E9EEF0;--text-muted:#8FA6AC;' +
          '--accent:#C9A876;--accent-soft:#E8D5A8;--border-soft:rgba(201,168,118,.22);background:#0B1A1E!important;color:#E9EEF0}' +
      L + '{--bg:#F6F8F9;--surface:#FFFFFF;--surface-2:#F5F1E6;--text:#16353D;--text-muted:#5D747C;' +
          '--accent:#9A7332;--accent-soft:#C9A876;--border-soft:rgba(154,115,50,.22);background:#F6F8F9!important;color:#16353D}' +
      // الهيدر بلون الصفحة مثل شاشات التطبيق
      D + ' .hw-header.hw-header{background:#0B1A1E!important;border-bottom:1px solid #1F3A41!important}' +
      L + ' .hw-header.hw-header{background:#FFFFFF!important;border-bottom:1px solid #EEF0F2!important}' +
      // البطاقات: نفس لون بطاقات التطبيق وزواياه
      D + ' :is(.card-custom,.listensora,.changesoraform,footer):not(#x){background:#12262B!important;border-color:#1F3A41!important;color:#E9EEF0!important}' +
      L + ' :is(.card-custom,.listensora,.changesoraform):not(#x){background:#FFFFFF!important;border-color:#E6E9EC!important}' +
      A + ' :is(.card-custom,.listensora,.changesoraform):not(#x){border-radius:22px!important;overflow:hidden}' +
      // الحاويات الوسيطة في القالب القديم (well, card-body) شفافة حتى لا تظهر طبقة بلون مختلف
      A + ' :is(.container.well,.card-custom > .card-body):not(#x){background:transparent!important;border-color:transparent!important;box-shadow:none!important}' +
      // شريط عنوان السورة
      D + ' .card-custom .card-header:not(#x){background:#123640!important;color:#FFFFFF!important;border-color:#1F3A41!important}' +
      // بطاقة النص القرآني: عاجي دافئ لا أزرق
      D + ' .surah-text:not(#x){background:#162E33!important;border-color:#2A4A50!important;color:#EFE4CF!important}' +
      D + ' .surah-text a:not(#x){color:#EFE4CF!important}' +
      L + ' .surah-text:not(#x){background:#FFFDF8!important;border-color:#EFE4CF!important;color:#16353D!important}' +
      // الحقول والقوائم المنسدلة
      D + ' :is(select,textarea,input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=submit]):not([type=button])):not(.btn):not(#x)' +
          '{background:#1A3439!important;border-color:#2A4A50!important;color:#E9EEF0!important}' +
      A + ' :is(select,input).form-control:not(.btn):not(#x){border-radius:14px!important;min-height:46px}' +
      // الأزرار الرئيسية: كبسولة ذهبية مثل أزرار التطبيق
      A + ' .btn.btn-primary:not(#x){background:#C9A876!important;border-color:#C9A876!important;color:#0E2C31!important;' +
          'border-radius:999px!important;font-weight:700;min-height:46px}' +
      // عناصر خاصة بالمتصفح لا داعي لها داخل التطبيق: زر تبديل الوضع (التطبيق يتحكم به)، ومسار التصفح، وزر «الرئيسية»
      A + ' :is(.hw-mode-btn,.breadcrumb,nav[aria-label="breadcrumb"],.hw-home):not(#x){display:none!important}';
    (document.head || root).appendChild(unify);

    // قالب الموقع يدعم ألوانًا اختيارية (أزرق، بنفسجي…) ووضع body.mode-*؛ داخل التطبيق نثبّت هوية التطبيق
    var fixes = 0;   // حدّ أمان: إن كان سكربت القالب يعيد الوضع باستمرار، لا ندخل معه في حلقة لا تنتهي
    var syncBody = function () {
      var b = document.body;
      if (!b || fixes > 30) return;
      var want = 'mode-' + theme, other = theme === 'dark' ? 'mode-light' : 'mode-dark', changed = false;
      if (!b.classList.contains(want)) { b.classList.add(want); changed = true; }
      if (b.classList.contains(other)) { b.classList.remove(other); changed = true; }
      if (b.hasAttribute('data-theme')) { b.removeAttribute('data-theme'); changed = true; }
      if (root.getAttribute('data-hw-mode') !== theme) { root.setAttribute('data-hw-mode', theme); changed = true; }
      if (changed) fixes++;
    };
    var watchTheme = function () {
      syncBody();
      try {
        var mo = new MutationObserver(syncBody);
        mo.observe(document.body, { attributes: true, attributeFilter: ['class', 'data-theme'] });
        mo.observe(root, { attributes: true, attributeFilter: ['data-hw-mode'] });
      } catch (e) {}
    };
    if (document.body) watchTheme(); else document.addEventListener('DOMContentLoaded', watchTheme);

    var navCss = document.createElement('style');
    navCss.textContent =
      // محددات شائعة لشريط الجوال السفلي + ما يكتشفه الفحص أدناه
      '.hawl-app .bottom-nav,.hawl-app .mobile-nav,.hawl-app .bottom-bar,.hawl-app .tabbar,.hawl-app .tab-bar,' +
      '.hawl-app .nav-bottom,.hawl-app .mobile-bottom-nav,.hawl-app #bottom-nav,.hawl-app #mobile-nav,' +
      '.hawl-app [data-bottom-nav],.hawl-site-nav,.hawl-legacy{display:none!important}';
    (document.head || root).appendChild(navCss);

    // فحص ذكي: عنصر ثابت أسفل الشاشة بعرضها تقريبًا، قليل الارتفاع، وفيه 3 روابط أو أزرار فأكثر
    var hiddenH = 0;
    var scanSiteNav = function () {
      try {
        var vw = window.innerWidth, vh = window.innerHeight;
        if (!vw || !vh || !document.body) return;
        var xs = [vw * 0.15, vw * 0.5, vw * 0.85], seen = [];
        for (var k = 0; k < xs.length; k++) {
          var stack = document.elementsFromPoint(xs[k], vh - 6) || [];
          for (var n = 0; n < stack.length; n++) {
            for (var el = stack[n]; el && el !== document.body && el !== root; el = el.parentElement) {
              if (seen.indexOf(el) >= 0) break;
              seen.push(el);
              var cs = getComputedStyle(el);
              if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
              var r = el.getBoundingClientRect();
              if (r.width >= vw * 0.8 && r.height > 20 && r.height <= 140 && r.bottom >= vh - 8 &&
                  el.querySelectorAll('a,button').length >= 3) {
                el.classList.add('hawl-site-nav');
                hiddenH = Math.max(hiddenH, r.height);
              }
            }
          }
        }
        // المسافة التي حجزها الموقع أسفل الصفحة لشريطه لم تعد لازمة
        if (hiddenH && !document.body.hasAttribute('data-hawl-pad')) {
          var pb = parseFloat(getComputedStyle(document.body).paddingBottom) || 0;
          if (pb >= hiddenH - 12) {
            document.body.style.setProperty('padding-bottom', Math.max(0, pb - hiddenH) + 'px', 'important');
          }
          document.body.setAttribute('data-hawl-pad', '1');
        }
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', scanSiteNav);
    window.addEventListener('load', function () { scanSiteNav(); setTimeout(scanSiteNav, 800); setTimeout(scanSiteNav, 2000); });
    window.addEventListener('resize', scanSiteNav);

    // بقايا القالب القديم «القرآن الكريم للجميع» في صفحات السور: هيدر وشعار وبانر وسطر Powered by.
    // نخفيها داخل التطبيق فقط، مع حماية من إخفاء أي حاوية فيها عنوان الصفحة أو الآيات أو الهيدر الجديد.
    var cleanLegacy = function () {
      try {
        var vh = window.innerHeight || 800;
        var hide = function (el) {
          if (!el || el === document.body || el === root || el.classList.contains('hawl-legacy')) return;
          if (el.querySelector('h1,audio,article,img[src*="design-theme"]')) return;
          if (el.getBoundingClientRect().height > vh * 0.6) return;
          el.classList.add('hawl-legacy');
        };
        var each = function (sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); };
        each('img[src*="css/images/logo"]', function (img) {
          hide(img.closest('header,nav,.navbar,#header,.header,[class*="header"],[class*="navbar"]') || img.closest('a') || img);
        });
        each('img[src*="header-banner"]', function (img) {
          var w = img.parentElement;
          hide(w && w.children.length === 1 ? w : img);
        });
        each('a[href*="nwahy.com"]', function (a) {
          var p = a.parentElement;
          hide(p && p.textContent.trim().length < 80 ? p : a);
        });
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', cleanLegacy);
    window.addEventListener('load', cleanLegacy);
  }

  // روابط الموقع المُشارَكة من التطبيق تحمل وسم المصدر
  function tagUrl(u) {
    try {
      if (!u) return u;
      var x = new URL(u, location.href);
      if (!/(^|\.)7awlalaalam\.com$/.test(x.hostname) || x.searchParams.has('utm_source')) return u;
      x.searchParams.set('utm_source', 'app_share');
      x.searchParams.set('utm_medium', 'share');
      return x.toString();
    } catch (e) { return u; }
  }
  function tagText(t) {
    return (t || '').replace(/https?:\/\/(www\.)?7awlalaalam\.com\/[^\s]*/g, function (m) { return tagUrl(m); });
  }

  // إخفاء مساحات الإعلانات داخل التطبيق (الإعلانات نفسها محجوبة من التطبيق)
  try {
    var st = document.createElement('style');
    st.textContent = 'ins.adsbygoogle,.adsbygoogle,.google-auto-placed,.ad-slot,.ads-wrap,[id^="aswift_"],' +
      'iframe[src*="googlesyndication"],iframe[id^="google_ads_iframe"]{display:none!important;height:0!important}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}

  function send(o) {
    var B = window.HawlApp;
    if (B && B.postMessage) B.postMessage(JSON.stringify(o));
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // 1) المشاركة: WebView لا يدعم navigator.share فنوفّرها عبر نافذة مشاركة أندرويد
  var share = function (d) {
    d = d || {};
    var files = Array.prototype.slice.call(d.files || []);
    return Promise.all(files.map(function (f) {
      return toB64(f).then(function (data) {
        return { name: f.name || 'file', type: f.type || 'application/octet-stream', data: data };
      });
    })).then(function (fs) {
      send({ cmd: 'share', title: d.title || '', text: tagText(d.text), url: tagUrl(d.url || ''), files: fs });
    });
  };
  try {
    Object.defineProperty(navigator, 'share', { value: share, configurable: true, writable: true });
    Object.defineProperty(navigator, 'canShare', { value: function () { return true; }, configurable: true, writable: true });
  } catch (e) { try { navigator.share = share; } catch (e2) {} }

  // 2) حفظ الملفات المولَّدة (blob: / data:) مثل بطاقات الآيات
  window.__hawlSaveBlob = function (url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (bl) {
      return toB64(bl).then(function (data) {
        send({ cmd: 'save', name: name || 'file', type: bl.type || 'application/octet-stream', data: data });
      });
    }).catch(function () {});
  };
  function isGenerated(h) { return h.indexOf('blob:') === 0 || h.indexOf('data:') === 0; }

  // روابط مُنشأة برمجيًا ثم a.click()
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var h = this.href || '';
    if (this.hasAttribute('download') && isGenerated(h)) {
      window.__hawlSaveBlob(h, this.getAttribute('download') || 'file');
      return;
    }
    return origClick.apply(this, arguments);
  };
  // روابط <a download> موجودة في الصفحة
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (isGenerated(h)) {
      e.preventDefault();
      window.__hawlSaveBlob(h, a.getAttribute('download') || 'file');
    }
  }, true);

  // 3) التحكم بالتلاوة من شاشة القفل: نراقب عناصر الصوت ونبلّغ التطبيق بحالتها
  var lastMedia = null;
  function mediaTitle(el) {
    var t = (el && (el.getAttribute && (el.getAttribute('title') || el.getAttribute('data-title')))) || '';
    if (!t) {
      var h = document.querySelector('h1');
      t = h ? h.textContent.replace(/\s+/g, ' ').trim() : document.title;
    }
    return (t || '').slice(0, 120);
  }
  function report(el, state) {
    if (!el || el.tagName === 'VIDEO') return;
    lastMedia = el;
    send({ cmd: 'media', state: state, title: mediaTitle(el) });
  }
  function hook(el) {
    if (!el || el.__hawlHooked) return;
    el.__hawlHooked = true;
    el.addEventListener('play', function () { report(el, 'playing'); });
    el.addEventListener('playing', function () { report(el, 'playing'); });
    el.addEventListener('pause', function () { report(el, 'paused'); });
    el.addEventListener('ended', function () { report(el, 'paused'); });
  }
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    hook(this);
    return origPlay.apply(this, arguments);
  };
  document.addEventListener('play', function (e) { hook(e.target); report(e.target, 'playing'); }, true);
  window.__hawlMedia = function (cmd) {
    var m = lastMedia;
    if (!m) return;
    try {
      if (cmd === 'play') m.play();
      else m.pause();
    } catch (e) {}
  };

  // 4) زر «تحميل للاستماع بدون إنترنت» تحت مشغّل التلاوة (داخل التطبيق فقط)
  var dlButtons = {};
  function surahTitle() {
    var t = (document.title || '').split(' - ')[0].split('|')[0].replace('كاملة', '').trim();
    return t || 'تلاوة';
  }
  function reciterName() {
    var parts = (document.title || '').split('|');
    return parts.length > 1 ? parts[parts.length - 1].trim() : '';
  }
  window.__hawlDlState = function (url, state) {
    var b = dlButtons[url];
    if (!b) return;
    b.dataset.state = state;
    if (state === 'done') { b.textContent = '✓ محمّلة، تعمل بدون إنترنت'; b.disabled = true; b.style.background = '#E8F5EE'; b.style.color = '#2E7D5B'; b.style.borderColor = '#BFE3CF'; }
    else if (state === 'running') { b.textContent = 'جارٍ التحميل… تابع من الإشعار'; b.disabled = true; }
    else { b.textContent = '⬇ تحميل للاستماع بدون إنترنت'; b.disabled = false; }
  };
  function addDownload(el) {
    if (!window.HawlApp || !el || el.__hawlDl) return;
    var src = el.currentSrc || el.getAttribute('src') || (el.querySelector('source') || {}).src || '';
    if (!/mp3quran\.net\/.+\.mp3$/i.test(src)) return;
    el.__hawlDl = true;
    var b = document.createElement('button');
    b.type = 'button';
    b.style.cssText = 'display:block;width:100%;margin:10px 0 4px;min-height:46px;border-radius:23px;border:1px solid #EFE4CF;' +
      'background:#FFFDF8;color:#8A6A33;font:inherit;font-size:15px;font-weight:700;cursor:pointer';
    b.textContent = '⬇ تحميل للاستماع بدون إنترنت';
    b.addEventListener('click', function () {
      if (b.disabled) return;
      b.disabled = true;
      b.textContent = 'جارٍ بدء التحميل…';
      send({ cmd: 'download', url: src, title: surahTitle(), reciter: reciterName() });
    });
    dlButtons[src] = b;
    el.insertAdjacentElement('afterend', b);
    send({ cmd: 'dl_query', url: src });
  }
  function scanAudio() { Array.prototype.forEach.call(document.querySelectorAll('audio'), addDownload); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanAudio);
  else scanAudio();
  window.addEventListener('load', scanAudio);

  // تأخير إلغاء روابط blob حتى نلحق بقراءتها
  var origRevoke = URL.revokeObjectURL;
  URL.revokeObjectURL = function (u) { setTimeout(function () { origRevoke.call(URL, u); }, 60000); };
})();
