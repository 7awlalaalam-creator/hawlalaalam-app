/* جسر التطبيق: يضيف ميزة المشاركة (navigator.share) وحفظ الصور المولَّدة داخل WebView */
(function () {
  if (window.__hawlBridge) return;
  window.__hawlBridge = true;

  // 0) Google Analytics: تمييز زوار التطبيق (قبل تحميل gtag في الصفحة)
  try {
    window.dataLayer = window.dataLayer || [];
    var gt = function () { window.dataLayer.push(arguments); };
    gt('set', 'user_properties', { client_type: 'android_app' });
    gt('set', { client_type: 'android_app' });
    if (window.__hawlInternal) gt('set', { traffic_type: 'internal' });   // جوال صاحب الموقع
  } catch (e) {}

  // ---------------------------------------------------------------- داخل التطبيق
  // العلامة HawlalaalamApp في userAgent: نُعلم الموقع بالمظهر ونخفي شريطه السفلي
  // لأن التطبيق يعرض شريطه الثابت أسفل الشاشة.
  var IN_APP = /HawlalaalamApp\//.test(navigator.userAgent);
  if (IN_APP) {
    var root = document.documentElement;
    var theme = window.__hawlTheme === 'dark' ? 'dark' : 'light';
    try {
      root.classList.add('hawl-app', 'hawl-' + theme);
      root.setAttribute('data-app', 'android');
      root.setAttribute('data-app-theme', theme);
      // الأسماء الشائعة لمفتاح الثيم، ليلتقطها قالب الموقع أيًّا كان اسمه
      root.setAttribute('data-theme', theme);
      root.setAttribute('data-mode', theme);
      root.setAttribute('data-bs-theme', theme);
      if (theme === 'dark') root.classList.add('dark', 'dark-mode'); else root.classList.remove('dark', 'dark-mode');
      try { localStorage.setItem('theme', theme); } catch (e) {}
      window.dispatchEvent(new CustomEvent('hawl-theme', { detail: theme }));
    } catch (e) {}

    var navCss = document.createElement('style');
    navCss.textContent =
      // محددات شائعة لشريط الجوال السفلي + ما يكتشفه الفحص أدناه
      '.hawl-app .bottom-nav,.hawl-app .mobile-nav,.hawl-app .bottom-bar,.hawl-app .tabbar,.hawl-app .tab-bar,' +
      '.hawl-app .nav-bottom,.hawl-app .mobile-bottom-nav,.hawl-app #bottom-nav,.hawl-app #mobile-nav,' +
      '.hawl-app [data-bottom-nav],.hawl-site-nav{display:none!important}';
    (document.head || root).appendChild(navCss);

    // فحص ذكي: عنصر ثابت أسفل الشاشة بعرضها تقريبًا، قليل الارتفاع، وفيه 3 روابط أو أزرار فأكثر
    var hiddenH = 0;
    var scanSiteNav = function () {
      try {
        var vw = window.innerWidth, vh = window.innerHeight;
        if (!vw || !vh || !document.body) return;
        var xs = [vw * 0.15, vw * 0.5, vw * 0.85], seen = [];
        for (var k = 0; k < xs.length; k++) {
          var stack = document.elementsFromPoint(xs[k], vh - 6) || [];
          for (var n = 0; n < stack.length; n++) {
            for (var el = stack[n]; el && el !== document.body && el !== root; el = el.parentElement) {
              if (seen.indexOf(el) >= 0) break;
              seen.push(el);
              var cs = getComputedStyle(el);
              if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
              var r = el.getBoundingClientRect();
              if (r.width >= vw * 0.8 && r.height > 20 && r.height <= 140 && r.bottom >= vh - 8 &&
                  el.querySelectorAll('a,button').length >= 3) {
                el.classList.add('hawl-site-nav');
                hiddenH = Math.max(hiddenH, r.height);
              }
            }
          }
        }
        // المسافة التي حجزها الموقع أسفل الصفحة لشريطه لم تعد لازمة
        if (hiddenH && !document.body.hasAttribute('data-hawl-pad')) {
          var pb = parseFloat(getComputedStyle(document.body).paddingBottom) || 0;
          if (pb >= hiddenH - 12) {
            document.body.style.setProperty('padding-bottom', Math.max(0, pb - hiddenH) + 'px', 'important');
          }
          document.body.setAttribute('data-hawl-pad', '1');
        }
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', scanSiteNav);
    window.addEventListener('load', function () { scanSiteNav(); setTimeout(scanSiteNav, 800); setTimeout(scanSiteNav, 2000); });
    window.addEventListener('resize', scanSiteNav);
  }

  // روابط الموقع المُشارَكة من التطبيق تحمل وسم المصدر
  function tagUrl(u) {
    try {
      if (!u) return u;
      var x = new URL(u, location.href);
      if (!/(^|\.)7awlalaalam\.com$/.test(x.hostname) || x.searchParams.has('utm_source')) return u;
      x.searchParams.set('utm_source', 'app_share');
      x.searchParams.set('utm_medium', 'share');
      return x.toString();
    } catch (e) { return u; }
  }
  function tagText(t) {
    return (t || '').replace(/https?:\/\/(www\.)?7awlalaalam\.com\/[^\s]*/g, function (m) { return tagUrl(m); });
  }

  // إخفاء مساحات الإعلانات داخل التطبيق (الإعلانات نفسها محجوبة من التطبيق)
  try {
    var st = document.createElement('style');
    st.textContent = 'ins.adsbygoogle,.adsbygoogle,.google-auto-placed,.ad-slot,.ads-wrap,[id^="aswift_"],' +
      'iframe[src*="googlesyndication"],iframe[id^="google_ads_iframe"]{display:none!important;height:0!important}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}

  function send(o) {
    var B = window.HawlApp;
    if (B && B.postMessage) B.postMessage(JSON.stringify(o));
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // 1) المشاركة: WebView لا يدعم navigator.share فنوفّرها عبر نافذة مشاركة أندرويد
  var share = function (d) {
    d = d || {};
    var files = Array.prototype.slice.call(d.files || []);
    return Promise.all(files.map(function (f) {
      return toB64(f).then(function (data) {
        return { name: f.name || 'file', type: f.type || 'application/octet-stream', data: data };
      });
    })).then(function (fs) {
      send({ cmd: 'share', title: d.title || '', text: tagText(d.text), url: tagUrl(d.url || ''), files: fs });
    });
  };
  try {
    Object.defineProperty(navigator, 'share', { value: share, configurable: true, writable: true });
    Object.defineProperty(navigator, 'canShare', { value: function () { return true; }, configurable: true, writable: true });
  } catch (e) { try { navigator.share = share; } catch (e2) {} }

  // 2) حفظ الملفات المولَّدة (blob: / data:) مثل بطاقات الآيات
  window.__hawlSaveBlob = function (url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (bl) {
      return toB64(bl).then(function (data) {
        send({ cmd: 'save', name: name || 'file', type: bl.type || 'application/octet-stream', data: data });
      });
    }).catch(function () {});
  };
  function isGenerated(h) { return h.indexOf('blob:') === 0 || h.indexOf('data:') === 0; }

  // روابط مُنشأة برمجيًا ثم a.click()
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var h = this.href || '';
    if (this.hasAttribute('download') && isGenerated(h)) {
      window.__hawlSaveBlob(h, this.getAttribute('download') || 'file');
      return;
    }
    return origClick.apply(this, arguments);
  };
  // روابط <a download> موجودة في الصفحة
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (isGenerated(h)) {
      e.preventDefault();
      window.__hawlSaveBlob(h, a.getAttribute('download') || 'file');
    }
  }, true);

  // 3) التحكم بالتلاوة من شاشة القفل: نراقب عناصر الصوت ونبلّغ التطبيق بحالتها
  var lastMedia = null;
  function mediaTitle(el) {
    var t = (el && (el.getAttribute && (el.getAttribute('title') || el.getAttribute('data-title')))) || '';
    if (!t) {
      var h = document.querySelector('h1');
      t = h ? h.textContent.replace(/\s+/g, ' ').trim() : document.title;
    }
    return (t || '').slice(0, 120);
  }
  function report(el, state) {
    if (!el || el.tagName === 'VIDEO') return;
    lastMedia = el;
    send({ cmd: 'media', state: state, title: mediaTitle(el) });
  }
  function hook(el) {
    if (!el || el.__hawlHooked) return;
    el.__hawlHooked = true;
    el.addEventListener('play', function () { report(el, 'playing'); });
    el.addEventListener('playing', function () { report(el, 'playing'); });
    el.addEventListener('pause', function () { report(el, 'paused'); });
    el.addEventListener('ended', function () { report(el, 'paused'); });
  }
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    hook(this);
    return origPlay.apply(this, arguments);
  };
  document.addEventListener('play', function (e) { hook(e.target); report(e.target, 'playing'); }, true);
  window.__hawlMedia = function (cmd) {
    var m = lastMedia;
    if (!m) return;
    try {
      if (cmd === 'play') m.play();
      else m.pause();
    } catch (e) {}
  };

  // 4) زر «تحميل للاستماع بدون إنترنت» تحت مشغّل التلاوة (داخل التطبيق فقط)
  var dlButtons = {};
  function surahTitle() {
    var t = (document.title || '').split(' - ')[0].split('|')[0].replace('كاملة', '').trim();
    return t || 'تلاوة';
  }
  function reciterName() {
    var parts = (document.title || '').split('|');
    return parts.length > 1 ? parts[parts.length - 1].trim() : '';
  }
  window.__hawlDlState = function (url, state) {
    var b = dlButtons[url];
    if (!b) return;
    b.dataset.state = state;
    if (state === 'done') { b.textContent = '✓ محمّلة، تعمل بدون إنترنت'; b.disabled = true; b.style.background = '#E8F5EE'; b.style.color = '#2E7D5B'; b.style.borderColor = '#BFE3CF'; }
    else if (state === 'running') { b.textContent = 'جارٍ التحميل… تابع من الإشعار'; b.disabled = true; }
    else { b.textContent = '⬇ تحميل للاستماع بدون إنترنت'; b.disabled = false; }
  };
  function addDownload(el) {
    if (!window.HawlApp || !el || el.__hawlDl) return;
    var src = el.currentSrc || el.getAttribute('src') || (el.querySelector('source') || {}).src || '';
    if (!/mp3quran\.net\/.+\.mp3$/i.test(src)) return;
    el.__hawlDl = true;
    var b = document.createElement('button');
    b.type = 'button';
    b.style.cssText = 'display:block;width:100%;margin:10px 0 4px;min-height:46px;border-radius:23px;border:1px solid #EFE4CF;' +
      'background:#FFFDF8;color:#8A6A33;font:inherit;font-size:15px;font-weight:700;cursor:pointer';
    b.textContent = '⬇ تحميل للاستماع بدون إنترنت';
    b.addEventListener('click', function () {
      if (b.disabled) return;
      b.disabled = true;
      b.textContent = 'جارٍ بدء التحميل…';
      send({ cmd: 'download', url: src, title: surahTitle(), reciter: reciterName() });
    });
    dlButtons[src] = b;
    el.insertAdjacentElement('afterend', b);
    send({ cmd: 'dl_query', url: src });
  }
  function scanAudio() { Array.prototype.forEach.call(document.querySelectorAll('audio'), addDownload); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanAudio);
  else scanAudio();
  window.addEventListener('load', scanAudio);

  // تأخير إلغاء روابط blob حتى نلحق بقراءتها
  var origRevoke = URL.revokeObjectURL;
  URL.revokeObjectURL = function (u) { setTimeout(function () { origRevoke.call(URL, u); }, 60000); };
})();
