/* جسر التطبيق: يضيف ميزة المشاركة (navigator.share) وحفظ الصور المولَّدة داخل WebView */
(function () {
  if (window.__hawlBridge) return;
  window.__hawlBridge = true;

  // إخفاء مساحات الإعلانات داخل التطبيق (الإعلانات نفسها محجوبة من التطبيق)
  try {
    var st = document.createElement('style');
    st.textContent = 'ins.adsbygoogle,.adsbygoogle,.google-auto-placed,.ad-slot,.ads-wrap,[id^="aswift_"],' +
      'iframe[src*="googlesyndication"],iframe[id^="google_ads_iframe"]{display:none!important;height:0!important}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}

  function send(o) {
    var B = window.HawlApp;
    if (B && B.postMessage) B.postMessage(JSON.stringify(o));
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // 1) المشاركة: WebView لا يدعم navigator.share فنوفّرها عبر نافذة مشاركة أندرويد
  var share = function (d) {
    d = d || {};
    var files = Array.prototype.slice.call(d.files || []);
    return Promise.all(files.map(function (f) {
      return toB64(f).then(function (data) {
        return { name: f.name || 'file', type: f.type || 'application/octet-stream', data: data };
      });
    })).then(function (fs) {
      send({ cmd: 'share', title: d.title || '', text: d.text || '', url: d.url || '', files: fs });
    });
  };
  try {
    Object.defineProperty(navigator, 'share', { value: share, configurable: true, writable: true });
    Object.defineProperty(navigator, 'canShare', { value: function () { return true; }, configurable: true, writable: true });
  } catch (e) { try { navigator.share = share; } catch (e2) {} }

  // 2) حفظ الملفات المولَّدة (blob: / data:) مثل بطاقات الآيات
  window.__hawlSaveBlob = function (url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (bl) {
      return toB64(bl).then(function (data) {
        send({ cmd: 'save', name: name || 'file', type: bl.type || 'application/octet-stream', data: data });
      });
    }).catch(function () {});
  };
  function isGenerated(h) { return h.indexOf('blob:') === 0 || h.indexOf('data:') === 0; }

  // روابط مُنشأة برمجيًا ثم a.click()
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var h = this.href || '';
    if (this.hasAttribute('download') && isGenerated(h)) {
      window.__hawlSaveBlob(h, this.getAttribute('download') || 'file');
      return;
    }
    return origClick.apply(this, arguments);
  };
  // روابط <a download> موجودة في الصفحة
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (isGenerated(h)) {
      e.preventDefault();
      window.__hawlSaveBlob(h, a.getAttribute('download') || 'file');
    }
  }, true);

  // 3) التحكم بالتلاوة من شاشة القفل: نراقب عناصر الصوت ونبلّغ التطبيق بحالتها
  var lastMedia = null;
  function mediaTitle(el) {
    var t = (el && (el.getAttribute && (el.getAttribute('title') || el.getAttribute('data-title')))) || '';
    if (!t) {
      var h = document.querySelector('h1');
      t = h ? h.textContent.replace(/\s+/g, ' ').trim() : document.title;
    }
    return (t || '').slice(0, 120);
  }
  function report(el, state) {
    if (!el || el.tagName === 'VIDEO') return;
    lastMedia = el;
    send({ cmd: 'media', state: state, title: mediaTitle(el) });
  }
  function hook(el) {
    if (!el || el.__hawlHooked) return;
    el.__hawlHooked = true;
    el.addEventListener('play', function () { report(el, 'playing'); });
    el.addEventListener('playing', function () { report(el, 'playing'); });
    el.addEventListener('pause', function () { report(el, 'paused'); });
    el.addEventListener('ended', function () { report(el, 'paused'); });
  }
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    hook(this);
    return origPlay.apply(this, arguments);
  };
  document.addEventListener('play', function (e) { hook(e.target); report(e.target, 'playing'); }, true);
  window.__hawlMedia = function (cmd) {
    var m = lastMedia;
    if (!m) return;
    try {
      if (cmd === 'play') m.play();
      else m.pause();
    } catch (e) {}
  };

  // تأخير إلغاء روابط blob حتى نلحق بقراءتها
  var origRevoke = URL.revokeObjectURL;
  URL.revokeObjectURL = function (u) { setTimeout(function () { origRevoke.call(URL, u); }, 60000); };
})();
