package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;

import java.util.Calendar;

/**
 * «وضع المسجد»: يصمت الجوال تلقائيًا عند الإقامة، ويعود لوضعه بعد مدة يختارها المستخدم.
 * الإقامة حسب تقويم أم القرى (الفجر ٢٥ دقيقة، المغرب ١٠، والبقية ٢٠)، والجمعة من الأذان الأول ٤٥ دقيقة على الأقل.
 * يحتاج صلاحية «عدم الإزعاج» (الوصول إلى سياسة الإشعارات) ليغيّر وضع الرنين؛ لا يغيّر شيئًا آخر.
 */
final class Mosque {
    static final String ACTION_ON = Reminders.ACTION_PREFIX + "mosque_on";
    static final String ACTION_OFF = Reminders.ACTION_PREFIX + "mosque_off";
    private static final String CHANNEL = "mosque";
    private static final int[] PRAYERS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    private Mosque() { }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static boolean enabled(Context c) { return p(c).getBoolean("mosque_on", false); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("mosque_on", on).apply();
        if (!on) restore(c);
        schedule(c);
    }

    static int minutes(Context c) { return p(c).getInt("mosque_minutes", 20); }

    static void setMinutes(Context c, int m) { p(c).edit().putInt("mosque_minutes", m).apply(); }

    static boolean allowed(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    /** دقائق الإقامة بعد الأذان */
    static int iqama(int prayer) {
        switch (prayer) {
            case PrayerCalc.FAJR: return 25;
            case PrayerCalc.MAGHRIB: return 10;
            default: return 20;
        }
    }

    private static boolean isFriday(long at) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(at);
        return c.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
    }

    /** {وقت بدء الصمت، مدته بالدقائق} للصلاة القادمة */
    static long[] next(Context c) {
        long now = System.currentTimeMillis() + 30_000;
        Calendar day = Calendar.getInstance();
        for (int d = 0; d < 2; d++) {
            long[] t = Adhan.times(c, day);
            for (int k : PRAYERS) {
                boolean jumuah = k == PrayerCalc.DHUHR && isFriday(t[k]);
                long start = jumuah ? t[k] : t[k] + iqama(k) * 60_000L;
                int len = jumuah ? Math.max(45, minutes(c)) : minutes(c);
                if (start > now) return new long[]{start, len};
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        return null;
    }

    private static PendingIntent pi(Context c, String action, int req) {
        return PendingIntent.getBroadcast(c, req, new Intent(c, ReminderReceiver.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void at(Context c, long when, PendingIntent pi) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (Adhan.canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    /** يُستدعى مع جدولة الأذان (عند الفتح والإقلاع وكل صلاة) */
    static void schedule(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent on = pi(c, ACTION_ON, 230);
        if (!enabled(c) || !Adhan.hasLocation(c)) { am.cancel(on); return; }
        long[] n = next(c);
        if (n == null) { am.cancel(on); return; }
        p(c).edit().putInt("mosque_next_len", (int) n[1]).apply();
        at(c, n[0], on);
    }

    /** وقت الإقامة: نحفظ وضع الرنين ونصمت الجوال، ونجدول الإعادة */
    static void silence(Context c) {
        schedule(c);                                   // الصلاة التالية
        if (!enabled(c) || !allowed(c)) return;
        AudioManager am = c.getSystemService(AudioManager.class);
        if (am == null) return;
        int mode = am.getRingerMode();
        if (mode == AudioManager.RINGER_MODE_SILENT) return;      // صامت أصلًا: لا نلمسه
        int len = p(c).getInt("mosque_next_len", minutes(c));
        try {
            am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
        } catch (SecurityException e) {
            return;
        }
        long until = System.currentTimeMillis() + len * 60_000L;
        p(c).edit().putInt("mosque_prev_mode", mode).putLong("mosque_until", until).apply();
        at(c, until, pi(c, ACTION_OFF, 231));
        notifySilent(c, until);
    }

    /** نهاية المدة (أو إلغاء المستخدم): نعيد الوضع السابق إن كنا نحن من صمّته */
    static void restore(Context c) {
        c.getSystemService(AlarmManager.class).cancel(pi(c, ACTION_OFF, 231));
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(15);
        int prev = p(c).getInt("mosque_prev_mode", -1);
        p(c).edit().remove("mosque_prev_mode").remove("mosque_until").apply();
        if (prev < 0 || !allowed(c)) return;
        AudioManager am = c.getSystemService(AudioManager.class);
        if (am == null || am.getRingerMode() != AudioManager.RINGER_MODE_SILENT) return;   // غيّره المستخدم بنفسه
        try { am.setRingerMode(prev); } catch (SecurityException ignored) { }
    }

    private static void notifySilent(Context c, long until) {
        if (!Notifier.allowed(c)) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "وضع المسجد", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = pi(c, ACTION_OFF, 232);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(c.getColor(R.color.gold_deep))
                .setContentTitle("الجوال صامت للصلاة")
                .setContentText("يعود صوته " + Adhan.clock(until) + " تلقائيًا")
                .setOngoing(true)
                .setTimeoutAfter(Math.max(60_000L, until - System.currentTimeMillis()))
                .addAction(new Notification.Action.Builder(null, "أعد الصوت الآن", stop).build())
                .build();
        nm.notify(15, n);
    }
}
