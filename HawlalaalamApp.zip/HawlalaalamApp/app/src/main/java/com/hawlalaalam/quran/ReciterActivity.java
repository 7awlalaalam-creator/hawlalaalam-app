package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** صفحة القارئ: الرواية، «استمع للمصحف كاملًا»، والسور بزر تحميل لكل سورة */
public class ReciterActivity extends Activity implements PlayerService.Listener {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private Reciters.Reciter reciter;
    private Reciters.Moshaf moshaf;
    private LinearLayout col, list;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable poll = this::refreshStatus;
    /** حالة التحميل لكل سورة (تُقرأ من خيط خلفي باستعلام واحد) */
    private java.util.Map<String, Downloads.Item> stat = new java.util.HashMap<>();
    private android.widget.FrameLayout[] slots = new android.widget.FrameLayout[0];
    private String[] slotKey = new String[0];
    private int gen;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        reciter = Reciters.byId(this, getIntent().getIntExtra("id", 0));
        col = Kit.tabPage(this, Ui.NAV_LISTEN, this::onNav, new ScrollView[1]);
        if (reciter == null) {
            col.addView(Kit.header(this, "القارئ", null, null));
            col.addView(Ui.text(this, "تعذّر فتح بيانات القارئ، ارجع وحاول مرة أخرى", 14, getColor(R.color.muted), 400), Kit.gap(this, 20));
            return;
        }
        int want = state != null ? state.getInt("moshaf", 0) : App.prefs(this).getInt("listen_moshaf_" + reciter.id, 0);
        moshaf = reciter.moshaf(want);
        build();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (moshaf != null) out.putInt("moshaf", moshaf.id);
    }

    @Override
    protected void onResume() {
        super.onResume();
        PlayerService.addListener(this);
        if (reciter != null) { renderList(); refreshStatus(); }
    }

    @Override
    protected void onPause() {
        super.onPause();
        PlayerService.removeListener(this);
        main.removeCallbacks(poll);
    }

    @Override
    public void changed() { if (reciter != null) renderList(); }

    private void build() {
        col.removeAllViews();
        boolean fav = Reciters.isFavorite(this, reciter.id);
        ImageButton heart = Kit.roundIcon(this, fav ? R.drawable.ic_heart_fill : R.drawable.ic_heart,
                fav ? "إزالة من المفضّلين" : "إضافة إلى المفضّلين");
        if (fav) heart.clearColorFilter();
        heart.setOnClickListener(v -> { Reciters.toggleFavorite(this, reciter.id); build(); });
        col.addView(Kit.header(this, reciter.name, null, heart));

        LinearLayout h = Kit.hero(this);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView name = Ui.text(this, reciter.name, 20, 0xFFFFFFFF, 700);
        name.setGravity(Gravity.CENTER);
        h.addView(name, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = Ui.text(this, moshaf.name + " · " + Ui.arabicNum(moshaf.surahs.length) + " سورة", 13,
                getColor(R.color.on_dark_muted), 400);
        sub.setGravity(Gravity.CENTER);
        h.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        if (reciter.moshaf.size() > 1) {
            TextView change = Ui.text(this, "تغيير الرواية (" + Ui.arabicNum(reciter.moshaf.size()) + ")", 13, getColor(R.color.gold), 700);
            change.setGravity(Gravity.CENTER);
            change.setPadding(0, Ui.dp(this, 8), 0, 0);
            change.setOnClickListener(v -> pickMoshaf());
            h.addView(change, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout btns = new LinearLayout(this);
        btns.setPadding(0, Ui.dp(this, 14), 0, 0);
        LinearLayout all = Ui.pill(this, R.drawable.ic_play, "استمع للمصحف كاملًا", false);
        all.setBackground(Ui.shape(getColor(R.color.gold), 23, 0, this));
        ((TextView) all.getChildAt(1)).setTextColor(getColor(R.color.dark));
        ((android.widget.ImageView) all.getChildAt(0)).setColorFilter(getColor(R.color.dark));
        all.setOnClickListener(v -> playFrom(moshaf.surahs[0]));
        btns.addView(Ui.minH(all, 46), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout dl = Ui.pill(this, R.drawable.ic_download, "حمّل الكل", false);
        dl.setOnClickListener(v -> confirmDownloadAll());
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
        dlp.setMarginStart(Ui.dp(this, 8));
        btns.addView(Ui.minH(dl, 46), dlp);
        h.addView(btns, new LinearLayout.LayoutParams(-1, -2));
        col.addView(h, Kit.gap(this, 12));

        list = Ui.card(this);
        col.addView(list, Kit.gap(this, 12));
        renderList();
    }

    private void pickMoshaf() {
        String[] names = new String[reciter.moshaf.size()];
        int checked = 0;
        for (int i = 0; i < names.length; i++) {
            Reciters.Moshaf m = reciter.moshaf.get(i);
            names[i] = m.name + " (" + Ui.arabicNum(m.surahs.length) + ")";
            if (m.id == moshaf.id) checked = i;
        }
        new AlertDialog.Builder(this, Ui.dialogTheme(this))
                .setTitle("الرواية")
                .setSingleChoiceItems(names, checked, (d, which) -> {
                    moshaf = reciter.moshaf.get(which);
                    App.prefs(this).edit().putInt("listen_moshaf_" + reciter.id, moshaf.id).apply();
                    d.dismiss();
                    build();
                })
                .show();
    }

    private void renderList() {
        if (list == null || moshaf == null) return;
        list.removeAllViews();
        PlayerService.Track cur = PlayerService.current();
        int gold = getColor(R.color.gold_deep);
        int n = moshaf.surahs.length;
        slots = new android.widget.FrameLayout[n];
        slotKey = new String[n];
        for (int i = 0; i < n; i++) {
            int s = moshaf.surahs[i];
            String url = moshaf.url(s);
            boolean now = cur != null && url.equals(cur.url);
            android.widget.FrameLayout slot = new android.widget.FrameLayout(this);
            slots[i] = slot;
            setAction(i, s, url);
            TextView badge = Kit.badge(this, Ui.arabicNum(s), false);
            String title = (now ? "▶ " : "") + QuranText.surahName(s);
            LinearLayout row = Kit.listRow(this, badge, title, AyahPages.surahLine(s) + (now ? " · يُشغَّل الآن" : ""), slot);
            if (now) ((TextView) ((LinearLayout) row.getChildAt(1)).getChildAt(0)).setTextColor(gold);
            row.setOnClickListener(v -> playFrom(s));
            if (i > 0) list.addView(Ui.divider(this));
            list.addView(row);
        }
    }

    /** زر الطرف حسب الحالة المخزّنة؛ لا يُعاد بناؤه إن لم تتغير الحالة */
    private void setAction(int i, int s, String url) {
        Downloads.Item it = stat.get(url);
        int st = it == null ? Downloads.NONE : it.status;
        String key = st == Downloads.RUNNING ? "r" + it.percent : String.valueOf(st);
        if (key.equals(slotKey[i]) && slots[i].getChildCount() > 0) return;
        slotKey[i] = key;
        ImageButton action;
        if (st == Downloads.DONE) {
            action = Kit.roundIcon(this, R.drawable.ic_l_check, "محمّلة: احذفها");
            action.setBackground(Ui.shape(getColor(R.color.gold), 18, 0, this));
            action.setColorFilter(0xFFFFFFFF);
            action.setOnClickListener(v -> new AlertDialog.Builder(this, Ui.dialogTheme(this))
                    .setMessage("حذف «سورة " + QuranText.surahName(s) + "» من الجهاز؟")
                    .setPositiveButton("حذف", (d, w) -> { Downloads.delete(this, url); stat.remove(url); setAction(i, s, url); })
                    .setNegativeButton("إلغاء", null).show());
        } else if (st == Downloads.RUNNING) {
            action = Kit.roundIcon(this, R.drawable.ic_clock, "جارٍ التحميل " + Ui.arabicNum(it.percent) + "٪");
        } else {
            action = Kit.roundIcon(this, R.drawable.ic_download, "حمّل للاستماع دون إنترنت");
            action.setOnClickListener(v -> {
                Downloads.start(this, url, "سورة " + QuranText.surahName(s), reciter.name);
                Toast.makeText(this, "بدأ التحميل", Toast.LENGTH_SHORT).show();
                refreshStatus();
            });
        }
        slots[i].removeAllViews();
        slots[i].addView(action);
    }

    /** يقرأ حالة كل السور في خيط خلفي ثم يحدّث الأزرار التي تغيّرت فقط، ويكرر كل ثانيتين ما دام تحميل جاريًا */
    private void refreshStatus() {
        main.removeCallbacks(poll);
        if (moshaf == null) return;
        final Reciters.Moshaf m = moshaf;
        final int g = ++gen;
        final Context app = getApplicationContext();
        final List<String> urls = new ArrayList<>();
        for (int s : m.surahs) urls.add(m.url(s));
        new Thread(() -> {
            java.util.Map<String, Downloads.Item> res = Downloads.batch(app, urls);
            main.post(() -> {
                if (g != gen || m != moshaf || isFinishing() || isDestroyed()) return;
                stat = res;
                boolean any = false;
                for (int i = 0; i < m.surahs.length && i < slots.length; i++) {
                    setAction(i, m.surahs[i], urls.get(i));
                    Downloads.Item it = res.get(urls.get(i));
                    if (it != null && it.status == Downloads.RUNNING) any = true;
                }
                if (any) main.postDelayed(poll, 2000);
            });
        }, "reciter-status").start();
    }

    private void playFrom(int surah) {
        List<PlayerService.Track> q = new ArrayList<>();
        int from = 0;
        for (int x : moshaf.surahs) {
            if (x == surah) from = q.size();
            q.add(PlayerService.Track.surah(reciter, moshaf, x));
        }
        PlayerService.play(this, q, from, 0);
        startActivity(new Intent(this, PlayerActivity.class));
    }

    private void confirmDownloadAll() {
        int missing = 0;
        for (int s : moshaf.surahs) { Downloads.Item it = stat.get(moshaf.url(s)); if (it == null || it.status != Downloads.DONE) missing++; }
        if (missing == 0) { Toast.makeText(this, "كل السور محمّلة ✓", Toast.LENGTH_SHORT).show(); return; }
        final int n = missing;
        new AlertDialog.Builder(this, Ui.dialogTheme(this))
                .setTitle("تحميل " + Ui.arabicNum(n) + " سورة")
                .setMessage("المصحف كاملًا بصوت " + reciter.name + " يحتاج نحو ١ إلى ٢ جيجابايت. يُفضَّل التحميل عبر Wi-Fi.")
                .setPositiveButton("حمّل", (d, w) -> {
                    for (int s : moshaf.surahs) {
                        String url = moshaf.url(s);
                        Downloads.Item it = stat.get(url);
                        if (it == null || (it.status != Downloads.DONE && it.status != Downloads.RUNNING))
                            Downloads.start(this, url, "سورة " + QuranText.surahName(s), reciter.name);
                    }
                    refreshStatus();
                })
                .setNegativeButton("إلغاء", null).show();
    }

    private void onNav(int idx) {
        if (idx == Ui.NAV_LISTEN) { finish(); return; }
        if (idx == Ui.NAV_TODAY) startActivity(new Intent(this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
        else if (idx == Ui.NAV_MUSHAF) startActivity(Nav.mushafIntent(this, 0));
        else if (idx == Ui.NAV_TOOLS) startActivity(new Intent(this, ToolsActivity.class));
        finish();
    }
}
