package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** «أكمل من حيث توقفت» وسلسلة الأيام المتتالية مع القرآن */
final class Reading {
    private Reading() { }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("reading", Context.MODE_PRIVATE); }

    /** هل الرابط صفحة قراءة قرآن؟ */
    static boolean isQuranPage(String url) {
        if (url == null) return false;
        String u;
        try { u = java.net.URLDecoder.decode(url, "UTF-8"); } catch (Exception e) { u = url; }
        return u.contains("/سورة-") || u.contains("/surah-") || u.contains("/mushaf-page")
                || u.contains("action=quran") || u.contains("/reader-") || u.contains("/view-")
                || u.contains("/quran.html");
    }

    /** صفحة المصحف: mushaf-page-4.html أو mushaf-pages-ar.html?page=4 أو صفحة التطبيق دون إنترنت */
    private static final java.util.regex.Pattern PAGE =
            java.util.regex.Pattern.compile("mushaf-page-(\\d{1,3})|mushaf-pages[^?#]*\\?(?:[^#]*&)?page=(\\d{1,3})");

    /** عنوان قصير لبطاقة «أكمل من حيث توقفت»: اسم السورة أو رقم الصفحة، لا عنوان صفحة الموقع الطويل */
    static String cleanTitle(String url, String title) {
        String u = url == null ? "" : url;
        java.util.regex.Matcher m = PAGE.matcher(u);
        if (m.find()) return "المصحف · صفحة " + Adhan.arabic(m.group(1) != null ? m.group(1) : m.group(2));
        String t = title == null ? "" : title;
        int cut = t.length();
        for (String sep : new String[]{"|", " - ", " – ", " — ", " · "}) {
            int i = t.indexOf(sep);
            if (i > 0 && i < cut) cut = i;
        }
        t = t.substring(0, cut).trim();
        boolean index = u.contains("action=quran") || u.contains("/quran.html");
        if (index || t.isEmpty() || t.startsWith("http") || t.contains("القرآن الكريم كامل")) t = "المصحف الشريف";
        return Adhan.arabic(t);
    }

    static void record(Context c, String url, String title) {
        if (!isQuranPage(url)) return;
        p(c).edit().putString("url", url).putString("title", cleanTitle(url, title))
                .putLong("time", System.currentTimeMillis()).apply();
        markToday(c);
    }

    static String lastUrl(Context c) { return p(c).getString("url", null); }
    /** يُنظَّف عند القراءة أيضًا: عناوين حفظتها نسخ سابقة */
    static String lastTitle(Context c) { return cleanTitle(lastUrl(c), p(c).getString("title", "")); }

    static String day(long millis) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(millis)); }

    static void markToday(Context c) {
        String today = day(System.currentTimeMillis());
        String days = p(c).getString("days", "");
        if (days.contains(today)) return;
        String all = days.isEmpty() ? today : days + "," + today;
        String[] parts = all.split(",");
        StringBuilder keep = new StringBuilder();
        for (int i = Math.max(0, parts.length - 60); i < parts.length; i++) {
            if (keep.length() > 0) keep.append(',');
            keep.append(parts[i]);
        }
        p(c).edit().putString("days", keep.toString()).apply();
    }

    static boolean readOn(Context c, Calendar cal) {
        return p(c).getString("days", "").contains(day(cal.getTimeInMillis()));
    }

    /** عدد الأيام المتتالية حتى اليوم (أو حتى أمس إن لم يقرأ اليوم بعد) */
    static int streak(Context c) {
        Calendar cal = Calendar.getInstance();
        if (!readOn(c, cal)) cal.add(Calendar.DAY_OF_MONTH, -1);
        int n = 0;
        while (readOn(c, cal) && n < 365) { n++; cal.add(Calendar.DAY_OF_MONTH, -1); }
        return n;
    }
}
