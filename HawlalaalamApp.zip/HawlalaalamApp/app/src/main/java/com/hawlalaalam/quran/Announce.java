package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/**
 * إشعارات من صاحب التطبيق، دون Firebase ودون أي بيانات عن المستخدم:
 * يقرأ التطبيق ملفًا صغيرًا من الموقع (app-notice.json) كل بضع ساعات وعند فتحه،
 * فإن وجد إشعارًا جديدًا (معرّف لم يُعرض من قبل ولم تنتهِ مدته) أظهره مرة واحدة.
 * الملف يُكتب من صفحة الإدارة notify-admin.php في الموقع.
 */
final class Announce {
    static final String URL = App.HOME + "app-notice.json";
    static final String ACTION = Reminders.ACTION_PREFIX + "notice";
    static final String CHANNEL = "news";

    private Announce() { }

    /** فحص دوري كل ٣ ساعات تقريبًا (غير دقيق، لا يستهلك البطارية) */
    static void schedule(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, 207, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        c.getSystemService(AlarmManager.class).setInexactRepeating(AlarmManager.RTC,
                System.currentTimeMillis() + 15 * 60_000L, 3 * AlarmManager.INTERVAL_HOUR, pi);
    }

    /** فحص عند فتح التطبيق، مرة كل ٣٠ دقيقة على الأكثر */
    static void checkSoon(Context c) {
        final Context app = c.getApplicationContext();
        long last = App.prefs(app).getLong("notice_checked", 0);
        if (System.currentTimeMillis() - last < 30 * 60_000L) return;
        new Thread(() -> check(app)).start();
    }

    /** يُستدعى من خيط خلفي */
    static void check(Context c) {
        try {
            App.prefs(c).edit().putLong("notice_checked", System.currentTimeMillis()).apply();
            JSONObject o = new JSONObject(App.get(URL + "?t=" + (System.currentTimeMillis() / 600_000L), 20_000));
            deliver(c, o.optString("id", ""), o.optString("title", ""), o.optString("body", ""),
                    o.optString("url", ""), o.optLong("expires", 0));
        } catch (Exception ignored) { }                            // لا إنترنت أو لا يوجد إشعار: لا شيء
    }

    /**
     * يعرض الإشعار مرة واحدة لكل معرّف — سواء وصل فورًا (Firebase) أو من الفحص الدوري،
     * فلا يتكرر عند من استلمه بالطريقتين.
     */
    static synchronized void deliver(Context c, String id, String title, String body, String url, long expires) {
        id = id == null ? "" : id.trim();
        title = title == null ? "" : title.trim();
        body = body == null ? "" : body.trim();
        url = url == null ? "" : url.trim();
        if (id.isEmpty() || (title.isEmpty() && body.isEmpty())) return;
        if (id.equals(App.prefs(c).getString("notice_seen", ""))) return;
        if (expires > 0 && System.currentTimeMillis() / 1000 > expires) return;   // ثوانٍ منذ ١٩٧٠، ٠ = بلا انتهاء
        App.prefs(c).edit().putString("notice_seen", id).commit();
        show(c, title.isEmpty() ? "حول العالم" : title, body, url);
    }

    private static void show(Context c, String title, String body, String url) {
        if (!Notifier.allowed(c)) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "أخبار وتنبيهات حول العالم", NotificationManager.IMPORTANCE_DEFAULT));
        // الرابط من نطاق الموقع فقط يُفتح داخل التطبيق؛ غير ذلك يفتح الشاشة الرئيسية
        Intent open = url.startsWith(App.HOME) || url.startsWith("https://7awlalaalam.com/")
                ? App.openInApp(c, url)
                : new Intent(c, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 109, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(c.getColor(R.color.gold_deep))
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(9, n);
    }
}
