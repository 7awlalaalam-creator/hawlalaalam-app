package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** هيكل الشاشات الأصلية الجديدة: ترويسة برجوع وعنوان، ومحتوى قابل للتمرير، بنفس هوية بقية التطبيق */
final class Kit {
    private Kit() { }

    static int dp(Context c, int v) { return Ui.dp(c, v); }

    /** ترويسة: زر رجوع + عنوان (+ وصف اختياري) + عنصر اختياري في الطرف */
    static LinearLayout header(Activity a, String title, String sub, View trailing) {
        LinearLayout head = new LinearLayout(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(a, 2), dp(a, 4), dp(a, 2), dp(a, 6));
        ImageButton back = new ImageButton(a);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(a.getColor(R.color.card), 22, a.getColor(R.color.line), a));
        back.setOnClickListener(v -> a.finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(a, 14), 0, dp(a, 8), 0);
        TextView t = Ui.text(a, title, 22, a.getColor(R.color.ink), 700);
        t.setMaxLines(2);
        titles.addView(t);
        if (sub != null && !sub.isEmpty()) titles.addView(Ui.text(a, sub, 13, a.getColor(R.color.muted), 400));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) head.addView(trailing);
        return head;
    }

    /** عمود المحتوى داخل تمرير بخلفية الصفحة، ويضبط الحواف */
    static LinearLayout scrollPage(Activity a, ScrollView[] out) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 32));
        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(a.getColor(R.color.page));
        scroll.setFillViewport(true);
        scroll.addView(col);
        a.setContentView(scroll);
        Ui.applyInsets(scroll);
        if (out != null && out.length > 0) out[0] = scroll;
        return col;
    }

    /**
     * شاشة بشريط سفلي (الاستماع): المحتوى يتمرر، وفوقه شريط المشغّل المصغّر ثم شريط التبويب.
     * @return عمود المحتوى
     */
    static LinearLayout tabPage(Activity a, int nav, java.util.function.IntConsumer onNav, ScrollView[] out) {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(a.getColor(R.color.page));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 24));
        scroll.addView(col);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(MiniPlayer.bar(a), new LinearLayout.LayoutParams(-1, -2));
        root.addView(Ui.appNav(a, nav, onNav), new LinearLayout.LayoutParams(-1, -2));
        a.setContentView(root);
        Ui.applyInsets(root, false);
        if (out != null && out.length > 0) out[0] = scroll;
        return col;
    }

    static LinearLayout.LayoutParams gap(Context c, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(c, top);
        return lp;
    }

    static TextView section(Context c, String s) {
        TextView t = Ui.text(c, s, 15, c.getColor(R.color.ink), 700);
        t.setPadding(dp(c, 4), 0, dp(c, 4), dp(c, 2));
        return t;
    }

    /** بطاقة بخلفية داكنة (هوية التطبيق) */
    static LinearLayout hero(Context c) {
        LinearLayout h = new LinearLayout(c);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        h.setBackground(new Ui.PatternDrawable(c, c.getColor(R.color.dark), 22));
        return h;
    }

    /** دائرة بحرف أو رقم */
    static TextView badge(Context c, String s, boolean dark) {
        TextView t = Ui.text(c, s, 16, dark ? c.getColor(R.color.gold) : c.getColor(R.color.gold_deep), 700);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.shape(dark ? c.getColor(R.color.dark) : c.getColor(R.color.chip), 23, 0, c));
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 46), dp(c, 46)));
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return t;
    }

    /** صف: دائرة + عنوان ووصف + عنصر في الطرف */
    static LinearLayout listRow(Context c, View lead, String title, String sub, View trailing) {
        LinearLayout r = new LinearLayout(c);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(c, 10), 0, dp(c, 10));
        if (lead != null) r.addView(lead);
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(c, 12), 0, dp(c, 8), 0);
        TextView tt = Ui.text(c, title, 15, c.getColor(R.color.ink), 700);
        t.addView(tt);
        if (sub != null && !sub.isEmpty()) {
            TextView st = Ui.text(c, sub, 12, c.getColor(R.color.muted), 400);
            st.setPadding(0, dp(c, 2), 0, 0);
            t.addView(st);
        }
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) r.addView(trailing);
        r.setContentDescription(title + (sub == null ? "" : "، " + sub));
        return r;
    }

    /** زر دائري صغير بأيقونة */
    static ImageButton roundIcon(Context c, int icon, String desc) {
        ImageButton b = new ImageButton(c);
        b.setImageResource(icon);
        b.setColorFilter(c.getColor(R.color.gold_deep));
        b.setContentDescription(desc);
        b.setBackground(Ui.shape(c.getColor(R.color.card), 18, c.getColor(R.color.line), c));
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 38), dp(c, 38)));
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        return b;
    }

    /** أقسام متجاورة (كبسولة اختيار) */
    static LinearLayout segments(Context c, String[] labels, int active, java.util.function.IntConsumer onPick) {
        LinearLayout seg = new LinearLayout(c);
        seg.setPadding(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        seg.setBackground(Ui.shape(c.getColor(R.color.chip), 14, 0, c));
        for (int i = 0; i < labels.length; i++) {
            boolean on = i == active;
            TextView t = Ui.text(c, labels[i], 14, on ? c.getColor(R.color.ink) : c.getColor(R.color.muted), on ? 700 : 500);
            t.setGravity(Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(dp(c, 4), dp(c, 8), dp(c, 4), dp(c, 8));
            if (on) t.setBackground(Ui.shape(c.getColor(R.color.card), 11, 0, c));
            t.setSelected(on);
            t.setContentDescription(labels[i] + (on ? "، محدد" : ""));
            final int idx = i;
            t.setOnClickListener(v -> onPick.accept(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(dp(c, 4));
            seg.addView(t, lp);
        }
        return seg;
    }

    /** شريط تقدّم رفيع ذهبي */
    static View progress(Context c, float fraction, boolean onDark) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(Ui.shape(onDark ? 0x22FFFFFF : c.getColor(R.color.ivory_border), 4, 0, c));
        View fill = new View(c);
        fill.setBackground(Ui.shape(c.getColor(R.color.gold), 4, 0, c));
        f.addView(fill, new FrameLayout.LayoutParams(0, -1, Gravity.START));
        f.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(c, 8)));
        final float fr = Math.max(0f, Math.min(1f, fraction));
        f.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int w = Math.round((r - l) * fr);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) fill.getLayoutParams();
            if (lp.width != w) { lp.width = w; fill.post(() -> fill.setLayoutParams(lp)); }
        });
        return f;
    }

    /** تطبيع للبحث بالعربية: الهمزات والتاء المربوطة والألف المقصورة والتشكيل */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= 'ً' && ch <= 'ٟ' || ch == 'ٰ' || ch == 'ـ') continue;
            switch (ch) {
                case 'أ': case 'إ': case 'آ': case 'ٱ': ch = 'ا'; break;
                case 'ة': ch = 'ه'; break;
                case 'ى': ch = 'ي'; break;
                case 'ؤ': ch = 'و'; break;
                case 'ئ': ch = 'ي'; break;
                default: break;
            }
            b.append(Character.toLowerCase(ch));
        }
        return b.toString().trim();
    }
}
