package com.hawlalaalam.quran;

import android.content.Context;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** صفحة كل آية في مصحف المدينة (assets/quran/ayah-page.json، ٦٢٣٦ رقمًا)، ومعلومات السور */
final class AyahPages {
    private AyahPages() { }

    private static volatile int[] pages;

    /** السور المدنية في مصحف المدينة */
    private static final int[] MADANI = {2, 3, 4, 5, 8, 9, 13, 22, 24, 33, 47, 48, 49, 55, 57, 58, 59, 60, 61, 62, 63,
            64, 65, 66, 76, 98, 99, 110};

    static boolean madani(int s) {
        for (int m : MADANI) if (m == s) return true;
        return false;
    }

    /** «مكية · ٧ آيات» */
    static String surahLine(int s) {
        int n = QuranText.COUNTS[s - 1];
        String word = n <= 10 && n >= 3 ? L.t(" آيات") : L.t(" آية");
        return (madani(s) ? L.t("مدنية") : L.t("مكية")) + " · " + Ui.arabicNum(n) + word;
    }

    static int page(Context c, int surah, int ayah) {
        int[] p = load(c);
        int i = QuranText.valid(surah, ayah) ? QuranText.index(surah, ayah) : -1;
        if (p != null && i >= 0 && i < p.length) return p[i];
        return surah >= 1 && surah <= 114 ? Khatma.SURAH_START[surah - 1] : 1;
    }

    private static int[] load(Context c) {
        int[] p = pages;
        if (p != null) return p;
        synchronized (AyahPages.class) {
            if (pages != null) return pages;
            try (InputStream in = c.getApplicationContext().getAssets().open("quran/ayah-page.json")) {
                byte[] b = new byte[64 * 1024];
                int n, len = 0;
                byte[] all = new byte[0];
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
                String s = new String(out.toByteArray(), StandardCharsets.UTF_8).replace("[", "").replace("]", "");
                String[] parts = s.split(",");
                int[] r = new int[parts.length];
                for (int k = 0; k < parts.length; k++) r[k] = Integer.parseInt(parts[k].trim());
                pages = r;
                return r;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
