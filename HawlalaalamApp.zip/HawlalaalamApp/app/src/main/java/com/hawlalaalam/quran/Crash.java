package com.hawlalaalam.quran;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * التقاط الأعطال محليًا (دون أي خادم أو تتبّع): عند توقف التطبيق يُحفظ سبب العطل،
 * وفي التشغيل التالي يظهر في الإعدادات زر «أرسل تقرير العطل» يشاركه القارئ بنفسه إن شاء.
 */
final class Crash {
    private static boolean installed;

    private Crash() { }

    static void install(Context c) {
        if (installed) return;
        installed = true;
        final Context app = c.getApplicationContext();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String s = sw.toString();
                if (s.length() > 6000) s = s.substring(0, 6000);
                App.prefs(app).edit()
                        .putString("crash_text", s)
                        .putString("crash_meta", "الإصدار " + App.versionName(app) + " · أندرويد " + Build.VERSION.RELEASE
                                + " · " + Build.MANUFACTURER + " " + Build.MODEL + " · " + new java.util.Date())
                        .commit();                      // commit: التطبيق على وشك التوقف
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static boolean has(Context c) { return App.prefs(c).getString("crash_text", null) != null; }

    static void clear(Context c) { App.prefs(c).edit().remove("crash_text").remove("crash_meta").apply(); }

    /** مشاركة التقرير (بريد، واتساب...) ثم مسحه */
    static void share(Context c) {
        String body = "تقرير عطل — تطبيق حول العالم\n" + App.prefs(c).getString("crash_meta", "") + "\n\n"
                + App.prefs(c).getString("crash_text", "");
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "تقرير عطل — حول العالم " + App.versionName(c))
                .putExtra(Intent.EXTRA_TEXT, body);
        c.startActivity(Intent.createChooser(i, "أرسل تقرير العطل"));
        clear(c);
    }
}
