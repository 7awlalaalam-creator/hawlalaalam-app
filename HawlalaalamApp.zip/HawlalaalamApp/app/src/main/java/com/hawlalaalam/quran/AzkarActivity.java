package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * الأذكار دون إنترنت: الصباح والمساء (نصوص صفحة الموقع نفسها) والنوم وبعد الصلاة، من assets/azkar.json.
 * لمس البطاقة يعدّ، ويُحفظ التقدّم لليوم نفسه.
 */
public class AzkarActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    static final String EXTRA_SECTION = "section";

    static final class Item { String text, source, note; int count; boolean quran; }
    static final class Section { String id, title; final List<Item> items = new ArrayList<>(); }

    private static volatile List<Section> data;
    private List<Section> sections;
    private int active;
    private int[] counts;
    private LinearLayout col, list;
    private TextView progressText;
    private LinearLayout progressBox;
    private ScrollView scroll;
    private int ink, muted, gold;

    static Intent intent(Context c, String section) {
        return new Intent(c, AzkarActivity.class).putExtra(EXTRA_SECTION, section);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.keepAwake(this, false);                           // كالمصحف: مضاءة أثناء الأذكار، وتنطفئ بعد ١٠ دقائق دون لمس
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        ScrollView[] sv = new ScrollView[1];
        col = Kit.scrollPage(this, sv);
        scroll = sv[0];
        sections = load(this);
        if (sections.isEmpty()) {
            col.addView(Kit.header(this, "الأذكار", null, null));
            col.addView(Ui.text(this, "تعذّر فتح الأذكار", 14, muted, 400));
            return;
        }
        String want = state != null ? state.getString("sec") : getIntent().getStringExtra(EXTRA_SECTION);
        if (want == null) want = defaultSection();
        active = 0;
        for (int i = 0; i < sections.size(); i++) if (sections.get(i).id.equals(want)) active = i;
        build();
        // نصوص الآيات من ملف المصحف: تُقرأ في خيط خلفي أول مرة
        new Thread(() -> {
            for (Section s : sections) for (Item it : s.items) if (it.quran) resolveQuran(getApplicationContext(), it);
            runOnUiThread(() -> { if (!isFinishing()) renderCards(); });
        }).start();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (sections != null && !sections.isEmpty()) out.putString("sec", sections.get(active).id);
    }

    /** الصباح من الفجر حتى العصر، والمساء بعد العصر حتى منتصف الليل، والنوم بعده */
    private String defaultSection() {
        if (Adhan.hasLocation(this)) {
            long now = System.currentTimeMillis();
            long[] t = Adhan.times(this, Calendar.getInstance());
            if (now >= t[PrayerCalc.FAJR] && now < t[PrayerCalc.ASR]) return "morning";
            Calendar c = Calendar.getInstance();
            if (now >= t[PrayerCalc.ASR] && c.get(Calendar.HOUR_OF_DAY) < 23) return "evening";
            return c.get(Calendar.HOUR_OF_DAY) >= 23 || c.get(Calendar.HOUR_OF_DAY) < 3 ? "sleep" : "morning";
        }
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 4 && h < 15 ? "morning" : h >= 15 && h < 23 ? "evening" : "sleep";
    }

    static List<Section> load(Context c) {
        List<Section> d = data;
        if (d != null) return d;
        List<Section> out = new ArrayList<>();
        try (InputStream in = c.getAssets().open("azkar.json")) {
            java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            JSONArray secs = new JSONObject(new String(b.toByteArray(), StandardCharsets.UTF_8)).getJSONArray("sections");
            for (int i = 0; i < secs.length(); i++) {
                JSONObject s = secs.getJSONObject(i);
                Section sec = new Section();
                sec.id = s.optString("id");
                sec.title = s.optString("title");
                JSONArray items = s.getJSONArray("items");
                for (int k = 0; k < items.length(); k++) {
                    JSONObject o = items.getJSONObject(k);
                    Item it = new Item();
                    it.text = o.optString("text");
                    it.count = Math.max(1, o.optInt("count", 1));
                    it.source = o.optString("source");
                    it.note = o.optString("note");
                    it.quran = it.text.startsWith("Q:");
                    sec.items.add(it);
                }
                out.add(sec);
            }
        } catch (Exception ignored) { }
        data = out;
        return out;
    }

    private static void resolveQuran(Context c, Item it) {
        if (!it.quran || !it.text.startsWith("Q:")) return;
        try {
            String[] p = it.text.split(":");
            int s = Integer.parseInt(p[1]), from = Integer.parseInt(p[2]), to = Integer.parseInt(p[3]);
            StringBuilder sb = new StringBuilder();
            for (int a = from; a <= to; a++) {
                String v = QuranText.verse(c, s, a);
                if (v == null) return;
                if (a > from) sb.append(' ');
                sb.append(QuranText.withNumber(v, a));
            }
            it.text = sb.toString();
        } catch (Exception ignored) { }
    }

    private static String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    private SharedPreferences store() { return getSharedPreferences("azkar", MODE_PRIVATE); }

    private String key() { return "azkar_progress_" + sections.get(active).id + "_" + today(); }

    private void loadCounts() {
        Section s = sections.get(active);
        counts = new int[s.items.size()];
        String saved = store().getString(key(), "");
        String[] parts = saved.split(",");
        for (int i = 0; i < counts.length && i < parts.length; i++) {
            try { counts[i] = Integer.parseInt(parts[i]); } catch (Exception ignored) { }
        }
    }

    private void saveCounts() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < counts.length; i++) { if (i > 0) b.append(','); b.append(counts[i]); }
        SharedPreferences.Editor e = store().edit();
        // نحذف تقدّم الأيام السابقة حتى لا يكبر الملف
        for (String k : store().getAll().keySet()) if (!k.endsWith("_" + today())) e.remove(k);
        e.putString(key(), b.toString()).apply();
    }

    private void build() {
        col.removeAllViews();
        col.addView(Kit.header(this, "الأذكار", "اضغط على الذكر لتعدّه", null));
        String[] names = new String[sections.size()];
        for (int i = 0; i < names.length; i++) names[i] = shortTitle(sections.get(i));
        col.addView(Kit.segments(this, names, active, i -> { active = i; build(); scroll.scrollTo(0, 0); }), Kit.gap(this, 12));
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.VERTICAL);
        progressText = Ui.text(this, "", 13, muted, 500);
        pr.addView(progressText);
        progressBox = new LinearLayout(this);
        pr.addView(progressBox, Kit.gap(this, 6));
        col.addView(pr, Kit.gap(this, 12));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, Kit.gap(this, 10));
        TextView reset = Ui.text(this, "ابدأ من جديد", 14, gold, 700);
        reset.setGravity(Gravity.CENTER);
        reset.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        reset.setOnClickListener(v -> { counts = new int[counts.length]; saveCounts(); renderCards(); });
        col.addView(reset, new LinearLayout.LayoutParams(-1, -2));
        loadCounts();
        renderCards();
    }

    private static String shortTitle(Section s) {
        switch (s.id) {
            case "morning": return "الصباح";
            case "evening": return "المساء";
            case "sleep": return "النوم";
            case "prayer": return "بعد الصلاة";
            default: return s.title;
        }
    }

    private void renderCards() {
        if (list == null) return;
        Section s = sections.get(active);
        list.removeAllViews();
        int done = 0;
        for (int i = 0; i < s.items.size(); i++) if (counts[i] >= s.items.get(i).count) done++;
        progressText.setText(sections.get(active).title + " · أنجزت " + Ui.arabicNum(done) + " من " + Ui.arabicNum(s.items.size()));
        progressBox.removeAllViews();
        progressBox.addView(Kit.progress(this, s.items.isEmpty() ? 0 : done / (float) s.items.size(), false));
        for (int i = 0; i < s.items.size(); i++) {
            View card = card(s, i);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) lp.topMargin = Ui.dp(this, 10);
            list.addView(card, lp);
        }
        if (done == s.items.size() && !s.items.isEmpty()) {
            TextView fin = Ui.text(this, "أتممت " + s.title + "، تقبّل الله منك 🤍", 15, gold, 700);
            fin.setGravity(Gravity.CENTER);
            fin.setPadding(0, Ui.dp(this, 16), 0, 0);
            list.addView(fin, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private View card(Section s, int i) {
        Item it = s.items.get(i);
        boolean done = counts[i] >= it.count;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 12));
        card.setBackground(done ? Ui.shape(getColor(R.color.chip), 18, getColor(R.color.ivory_border), this)
                : Ui.shape(getColor(R.color.ivory), 18, getColor(R.color.ivory_border), this));
        card.setAlpha(done ? 0.6f : 1f);
        if (!it.note.isEmpty()) {
            TextView n = Ui.text(this, it.note, 12, gold, 700);
            n.setPadding(0, 0, 0, Ui.dp(this, 6));
            card.addView(n);
        }
        TextView t = new TextView(this);
        boolean quranText = it.quran && !it.text.startsWith("Q:");
        if (it.quran && !quranText) {
            t = Ui.text(this, "…", 18, muted, 400);
        } else if (quranText) {
            t.setText(it.text);
            t.setTypeface(QuranText.font(this));
            t.setTextSize(it.text.length() > 220 ? 19 : 22);
            t.setTextColor(ink);
            t.setLineSpacing(0, 1.35f);
            t.setGravity(Gravity.CENTER);
        } else {
            t.setText(it.text);
            t.setTypeface(Ui.quran(this));                 // Amiri Quran: الفاصلة العربية تبقى فاصلة
            t.setTextSize(20);
            t.setTextColor(ink);
            t.setLineSpacing(0, 1.45f);
        }
        card.addView(t, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, Ui.dp(this, 10), 0, 0);
        foot.addView(Ui.text(this, it.source, 12, muted, 400), new LinearLayout.LayoutParams(0, -2, 1f));
        String countText = done ? "تم ✓" : it.count == 1 ? "مرة واحدة"
                : Ui.arabicNum(counts[i]) + " من " + Ui.arabicNum(it.count);
        TextView cnt = Ui.text(this, countText, 14, done ? gold : ink, 700);
        cnt.setGravity(Gravity.CENTER);
        cnt.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 4));
        cnt.setBackground(Ui.shape(done ? getColor(R.color.card) : getColor(R.color.chip), 14, 0, this));
        foot.addView(Ui.minH(cnt, 34));
        card.addView(foot);
        card.setContentDescription(it.text + "، " + countText);
        card.setOnClickListener(v -> {
            if (counts[i] >= it.count) return;
            counts[i]++;
            boolean finished = counts[i] >= it.count;
            v.performHapticFeedback(finished && android.os.Build.VERSION.SDK_INT >= 30
                    ? android.view.HapticFeedbackConstants.CONFIRM : android.view.HapticFeedbackConstants.KEYBOARD_TAP);
            saveCounts();
            if (finished) {
                renderCards();
                // ننتقل للذكر التالي غير المكتمل
                for (int k = i + 1; k < counts.length; k++) {
                    if (counts[k] < s.items.get(k).count) {
                        final View target = list.getChildAt(k);
                        if (target != null) scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, target.getTop() + list.getTop() - Ui.dp(this, 80))));
                        break;
                    }
                }
            } else {
                int idx = list.indexOfChild(v);
                View fresh = card(s, i);
                if (idx >= 0) { list.removeViewAt(idx); list.addView(fresh, idx, v.getLayoutParams()); }
            }
        });
        return card;
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Ui.keepAwake(this, false);
    }
}
