package com.hawlalaalam.quran;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.widget.Toast;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * توجيه الروابط: كل رابط من الموقع يُفتح في شاشته الأصلية في التطبيق إن كان له نظير
 * (الاستماع، الأذكار، المواقيت، التفسير، ختمة العائلة، صفحات المصحف)،
 * وما سواه من صفحات الموقع يُفتح في متصفح الجوال لا داخل التطبيق.
 * التطبيق نفسه يلتقط روابط 7awlalaalam.com/quran، فنوجّه المتصفح باسم حزمته حتى لا يعود الرابط إلينا.
 */
final class Nav {
    private Nav() { }

    private static final Pattern AYAH = Pattern.compile("/ayah-(\\d{1,3})-(\\d{1,3})\\.html");
    private static final Pattern SURAH = Pattern.compile("/surah-(\\d{1,3})(?:-ar)?\\.html");
    private static final Pattern FAMILY_ID = Pattern.compile("[?&]id=([A-Za-z0-9]{6})");

    static boolean isSite(Uri u) {
        if (u == null || u.getHost() == null) return false;
        String h = u.getHost().toLowerCase(Locale.ROOT);
        String s = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        return (s.equals("https") || s.equals("http")) && (h.equals("7awlalaalam.com") || h.equals("www.7awlalaalam.com"));
    }

    /** صفحة المصحف دون إنترنت داخل التطبيق (/__hawl/) */
    static boolean isOfflineMushaf(Uri u) {
        return isSite(u) && u.getPath() != null && u.getPath().startsWith("/__hawl/");
    }

    /** نية الشاشة الأصلية المقابلة لرابط من الموقع، أو null إن لم يكن له نظير */
    static Intent nativeIntent(Context c, Uri u) {
        if (!isSite(u) || isOfflineMushaf(u)) return null;
        String url = u.toString();
        String path;
        try { path = java.net.URLDecoder.decode(u.getPath() == null ? "" : u.getPath(), "UTF-8"); }
        catch (Exception e) { path = u.getPath() == null ? "" : u.getPath(); }
        String p = path.toLowerCase(Locale.ROOT);
        if (p.contains("quran-reciters") || p.contains("/listen")) return new Intent(c, ListenActivity.class);
        if (p.contains("azkar-morning-evening") || p.endsWith("/azkar.html") || p.contains("azkar-ar")) {
            return new Intent(c, AzkarActivity.class);
        }
        if (p.contains("prayer-times")) return new Intent(c, PrayerTimesActivity.class);
        if (p.contains("family-khatma")) {
            Intent i = new Intent(c, FamilyActivity.class);
            Matcher m = FAMILY_ID.matcher(url);
            if (m.find()) i.putExtra(FamilyActivity.EXTRA_ID, m.group(1).toUpperCase(Locale.ROOT));
            return i;
        }
        Matcher a = AYAH.matcher(p);
        if (a.find()) {
            int s = Integer.parseInt(a.group(1)), ay = Integer.parseInt(a.group(2));
            if (QuranText.valid(s, ay)) return TafsirActivity.intent(c, s, ay);
        }
        // صفحات السور وفهرس المصحف وصفحات المصحف في الموقع ← المصحف دون إنترنت في التطبيق
        int page = Khatma.pageOf(url);
        Matcher sm = SURAH.matcher(p);
        if (page == 0 && sm.find()) {
            int s = Integer.parseInt(sm.group(1));
            if (s >= 1 && s <= 114) page = Khatma.SURAH_START[s - 1];
        }
        if (page == 0 && path.contains("/سورة-")) {
            String name = path.substring(path.indexOf("/سورة-") + 6).replace(".html", "").replace('-', ' ').trim();
            for (int s = 1; s <= 114; s++) if (QuranText.surahName(s).equals(name)) { page = Khatma.SURAH_START[s - 1]; break; }
        }
        if (page > 0) return mushafIntent(c, page);
        if (url.contains("action=quran")) return mushafIntent(c, 0);
        // الصفحة الرئيسية للموقع (روابط الإشعارات القديمة) ← «اليوم» في التطبيق
        if (p.equals("/quran") || p.equals("/quran/") || p.equals("/quran/index.php") || p.equals("/")) {
            return new Intent(c, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        }
        return null;
    }

    /** المصحف دون إنترنت على صفحة (٠ = من حيث توقف القارئ) */
    static Intent mushafIntent(Context c, int page) {
        String url = page > 0 ? Khatma.pageUrl(page) : App.mushaf(c);
        return new Intent(Intent.ACTION_VIEW, Uri.parse(url), c, MainActivity.class)
                .putExtra(HomeActivity.EXTRA_FROM_HOME, true);
    }

    /** المصحف على صفحة آية */
    static Intent mushafAt(Context c, int surah, int ayah) {
        return mushafIntent(c, AyahPages.page(c, surah, ayah));
    }

    /** نية لأي رابط: شاشة أصلية، أو المصحف، أو متصفح الجوال */
    static Intent intent(Context c, String url) {
        Uri u = Uri.parse(url == null ? App.HOME : url);
        Intent n = nativeIntent(c, u);
        if (n == null && isOfflineMushaf(u)) {
            n = new Intent(Intent.ACTION_VIEW, u, c, MainActivity.class).putExtra(HomeActivity.EXTRA_FROM_HOME, true);
        }
        if (n == null) n = browserIntent(c, u);
        return n.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    static void open(Context c, String url) {
        try { c.startActivity(intent(c, url)); }
        catch (ActivityNotFoundException e) { Toast.makeText(c, "لا يوجد تطبيق لفتح هذا الرابط", Toast.LENGTH_SHORT).show(); }
    }

    /** متصفح الجوال (لا التطبيق نفسه، رغم أنه يلتقط روابط الموقع) */
    static Intent browserIntent(Context c, Uri u) {
        Intent i = new Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE);
        if (isSite(u)) {
            String pkg = browserPackage(c);
            if (pkg != null) i.setPackage(pkg);
        }
        return i;
    }

    static void external(Context c, String url) {
        try { c.startActivity(browserIntent(c, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (ActivityNotFoundException e) { Toast.makeText(c, "لا يوجد متصفح لفتح الرابط", Toast.LENGTH_SHORT).show(); }
    }

    private static String browserPackage(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent probe = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/"))
                .addCategory(Intent.CATEGORY_BROWSABLE);
        ResolveInfo def = pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY);
        if (def != null && def.activityInfo != null && !"android".equals(def.activityInfo.packageName)
                && !c.getPackageName().equals(def.activityInfo.packageName)) {
            return def.activityInfo.packageName;
        }
        for (ResolveInfo r : pm.queryIntentActivities(probe, 0)) {
            if (r.activityInfo != null && !c.getPackageName().equals(r.activityInfo.packageName)) return r.activityInfo.packageName;
        }
        return null;
    }
}
