package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

/** «اجعلها صدقة جارية»: بطاقة مشاركة التطبيق باسم من تحب */
public class DedicateActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    private static final String[] TITLES = {"رحمه الله", "رحمها الله", "حفظه الله", "حفظها الله"};
    private static final String LINK = "7awlalaalam.com/quran";

    private EditText name;
    private int honor = 0;
    private ImageView preview;
    private LinearLayout chips;
    private Bitmap card;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(20), dp(14), dp(20), dp(28));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = Ui.text(this, "اجعلها صدقة جارية", 22, getColor(R.color.ink), 700);
        title.setPadding(dp(14), 0, dp(14), 0);
        bar.addView(title);
        col.addView(bar);

        TextView d = Ui.text(this, "شارك التطبيق باسم من تحب، حيًّا أو ميتًا، ليصل القرآن إلى غيرك صدقةً عنه.", 15, getColor(R.color.muted), 400);
        d.setPadding(0, dp(14), 0, dp(14));
        col.addView(d);

        name = new EditText(this);
        name.setHint("الاسم، مثال: والدي محمد");
        name.setTypeface(Ui.font(this, 500));
        name.setTextSize(17);
        name.setSingleLine(true);
        name.setPadding(dp(16), dp(14), dp(16), dp(14));
        name.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.field_border), this));
        col.addView(name, new LinearLayout.LayoutParams(-1, -2));

        chips = new LinearLayout(this);
        chips.setPadding(0, dp(12), 0, dp(14));
        col.addView(chips);
        buildChips();

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setContentDescription("معاينة البطاقة");
        col.addView(preview, new LinearLayout.LayoutParams(-1, -2));

        android.widget.Button share = Ui.button(this, "شارك البطاقة", true);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, dp(56));
        sl.topMargin = dp(18);
        share.setOnClickListener(v -> share());
        col.addView(share, sl);

        name.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { render(); }
        });

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(getColor(R.color.page));
        sc.addView(col);
        setContentView(sc);
        Ui.applyInsets(sc);
        render();
    }

    private void buildChips() {
        chips.removeAllViews();
        for (int i = 0; i < TITLES.length; i++) {
            TextView c = Ui.text(this, TITLES[i], 13, i == honor ? 0xFFFFFFFF : getColor(R.color.ink), 500);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(8), dp(9), dp(8), dp(9));
            c.setBackground(i == honor ? Ui.shape(getColor(R.color.primary), 18, 0, this) : Ui.shape(getColor(R.color.card), 18, getColor(R.color.field_border), this));
            final int idx = i;
            c.setOnClickListener(v -> { honor = idx; buildChips(); render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(dp(6));
            chips.addView(c, lp);
        }
    }

    private void render() {
        String n = name.getText().toString().trim();
        if (n.isEmpty()) n = "من تحب";
        boolean fem = honor == 1 || honor == 3;
        int W = 1080, H = 1350;
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF16424A, 0xFF071A1E, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4);
        p.setColor(0xFFC9A876);
        cv.drawRoundRect(new RectF(40, 40, W - 40, H - 40), 48, 48, p);
        p.setStyle(Paint.Style.FILL);

        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.app_logo);
        if (logo != null) cv.drawBitmap(Bitmap.createScaledBitmap(logo, 220, 220, true), (W - 220) / 2f, 120, p);

        float y = 400;
        y = text(cv, "صدقة جارية عن", 46, 0xFFC9A876, 500, y, false) + 20;
        y = text(cv, n, 92, 0xFFFFFFFF, 700, y, false) + 6;
        y = text(cv, TITLES[honor], 50, 0xFFE9DFC9, 500, y, false) + 60;
        p.setColor(0x55C9A876);
        cv.drawRect(W / 2f - 90, y, W / 2f + 90, y + 3, p);
        y += 50;
        y = text(cv, "حمّل تطبيق «حول العالم | القرآن الكريم»\nواقرأ وادعُ " + (fem ? "لها" : "له"),
                46, 0xFFFFFFFF, 500, y, false) + 70;
        text(cv, "مجاني · بلا تسجيل · بلا إعلانات", 36, 0xFFA9BABF, 400, y, false);
        text(cv, LINK, 44, 0xFFC9A876, 700, H - 170, true);
        card = b;
        preview.setImageBitmap(b);
    }

    private float text(Canvas cv, String s, int size, int color, int weight, float y, boolean ltr) {
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(size);
        tp.setColor(color);
        tp.setTypeface(Ui.font(this, weight));
        StaticLayout l = StaticLayout.Builder.obtain(s, 0, s.length(), tp, 940)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(8, 1f)
                .build();
        cv.save();
        cv.translate(70, y);
        l.draw(cv);
        cv.restore();
        return y + l.getHeight();
    }

    private void share() {
        try {
            File dir = new File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "sadaqa-jariya.png");
            try (FileOutputStream out = new FileOutputStream(f)) {
                card.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            boolean fem = honor == 1 || honor == 3;
            String n = name.getText().toString().trim();
            String msg = "صدقة جارية عن " + (n.isEmpty() ? "من أحب" : n) + " " + TITLES[honor]
                    + "\nحمّل تطبيق «حول العالم | القرآن الكريم» واقرأ وادعُ " + (fem ? "لها" : "له") + " 🤍\n"
                    + "https://" + LINK + "/";
            Intent send = new Intent(Intent.ACTION_SEND).setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_TEXT, msg)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newRawUri("", uri));
            startActivity(Intent.createChooser(send, "شارك البطاقة"));
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "تعذّرت المشاركة", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
