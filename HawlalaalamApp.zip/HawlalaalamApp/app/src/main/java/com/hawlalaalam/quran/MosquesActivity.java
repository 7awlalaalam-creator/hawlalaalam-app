package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

/**
 * «المساجد القريبة»: خريطة OpenFreeMap (مجانية بلا مفتاح) والمساجد من OpenStreetMap، داخل صفحة من ملفات التطبيق.
 * الموقع تقريبي ويُطلب مرة واحدة فقط (لا متابعة مستمرة) توفيرًا للبطارية؛ والاتجاهات تفتح تطبيق الخرائط في الجوال.
 */
public class MosquesActivity extends Activity {
    private static final int REQ_LOC = 71;
    private static final String HOST = "appassets.androidplatform.net";

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private WebView web;
    private boolean asked;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        int bg = 0xFF0F2A31;
        if (android.os.Build.VERSION.SDK_INT < 35) {
            getWindow().setStatusBarColor(bg);
            getWindow().setNavigationBarColor(bg);
        }
        if (android.os.Build.VERSION.SDK_INT >= 30 && getWindow().getInsetsController() != null) {
            getWindow().getInsetsController().setSystemBarsAppearance(0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
        web = new WebView(this);
        web.setBackgroundColor(bg);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/res/", new WebViewAssetLoader.ResourcesPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) { }
        });
        web.addJavascriptInterface(new Bridge(), "Mosq");
        // لغة الصفحة قبل تحميلها
        String en = L.en() ? "true" : "false";
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
            androidx.webkit.WebViewCompat.addDocumentStartJavaScript(web, "window.__en=" + en + ";",
                    java.util.Collections.singleton("https://" + HOST));
        }
        setContentView(web);
        web.loadUrl("https://" + HOST + "/assets/mosques/index.html" + (L.en() ? "?en=1" : ""));
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    private void sendStored() {
        if (Adhan.hasLocation(this)) {
            float lat = App.prefs(this).getFloat("lat", 0), lng = App.prefs(this).getFloat("lng", 0);
            js("window.setCenter&&window.setCenter(" + lat + "," + lng + ",false)");
        } else js("window.setCenter&&window.setCenter(null,null,false)");
    }

    private void locate() {
        boolean stored = Adhan.hasLocation(this);
        if (stored) sendStored();                         // نبدأ بموقع المدينة المحفوظ فورًا
        if (!Loc.hasPermission(this)) {
            if (!asked) {
                asked = true;
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            } else if (!stored) sendStored();
            return;
        }
        Loc.get(this, 10 * 60_000L, false, l -> {
            if (isFinishing() || isDestroyed()) return;
            if (l != null) js(String.format(Locale.US, "window.setCenter&&window.setCenter(%.6f,%.6f,true)", l.getLatitude(), l.getLongitude()));
            else if (!stored) sendStored();
        });
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) {
        super.onRequestPermissionsResult(req, p, r);
        if (req != REQ_LOC) return;
        boolean ok = r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED;
        if (ok) locate(); else if (!Adhan.hasLocation(this)) sendStored();
    }

    private void js(String s) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(s, null); });
    }

    private void open(Intent i) {
        try { startActivity(i); } catch (ActivityNotFoundException e) { android.widget.Toast.makeText(this, L.t("لا يوجد تطبيق خرائط على الجوال"), android.widget.Toast.LENGTH_SHORT).show(); }
    }

    final class Bridge {
        @JavascriptInterface public void locate() { runOnUiThread(MosquesActivity.this::locate); }

        @JavascriptInterface public void back() { runOnUiThread(MosquesActivity.this::finish); }

        @JavascriptInterface public void directions(double lat, double lng, String name, boolean walk) {
            String ll = String.format(Locale.US, "%.6f,%.6f", lat, lng);
            Intent nav = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + ll + (walk ? "&mode=w" : "")));
            nav.setPackage("com.google.android.apps.maps");
            if (nav.resolveActivity(getPackageManager()) != null) { runOnUiThread(() -> open(nav)); return; }
            Intent geo = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + ll + "?q=" + ll + "(" + Uri.encode(name) + ")"));
            runOnUiThread(() -> open(geo));
        }

        @JavascriptInterface public void share(String name, double lat, double lng) {
            String link = String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f", lat, lng);
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, name + "\n" + link);
            runOnUiThread(() -> open(Intent.createChooser(i, L.t("مشاركة"))));
        }

        @JavascriptInterface public void mapsSearch(double lat, double lng) {
            String q = L.en() ? "mosque" : "مسجد";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(Locale.US, "geo:%.6f,%.6f?q=", lat, lng) + Uri.encode(q)));
            runOnUiThread(() -> open(i));
        }
    }
}
