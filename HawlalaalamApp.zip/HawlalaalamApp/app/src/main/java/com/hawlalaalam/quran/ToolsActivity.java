package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/**
 * شاشة «الأدوات»: كل ما خرج من «اليوم» مرتّبًا في مجموعات —
 * سلسلة الأيام، أدوات القرآن، الصلاة والذكر، لقلبك، والصدقة الجارية.
 */
public class ToolsActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));
    }

    private LinearLayout col;
    private int ink, muted, gold;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.page));
        root.setLayoutDirection(L.dir());

        ScrollView scroll = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(14), dp(16), dp(24));
        scroll.addView(col);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(Ui.appNav(this, Ui.NAV_TOOLS, this::onNav));

        setContentView(root);
        Ui.applyInsets(root, false);
        Ui.applyInsets(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.isNight(this) != Ui.isNight(Ui.wrap(getApplicationContext()))) { recreate(); return; }
        render();                                   // السلسلة تتحدّث بعد القراءة
    }

    private void render() {
        col.removeAllViews();
        col.addView(header());
        View news = newsCard();
        if (news != null) col.addView(news, gap(12));
        col.addView(streakCard(), gap(14));

        col.addView(section(L.t("القرآن")), gap(20));
        col.addView(grid(new Object[][]{
                {L.t("الفهرس"), R.drawable.ic_mushaf_t, SurahIndexActivity.class},
                {L.t("ختمتي"), R.drawable.ic_khatma_t, KhatmaActivity.class},
                {L.t("الاستماع"), R.drawable.ic_listen_t, ListenActivity.class},
                {L.t("الترجمات"), R.drawable.ic_globe_t, Nav.browserIntent(this, android.net.Uri.parse(App.HOME + "languages.html"))},
                {L.t("الحفظ"), R.drawable.ic_l_sprout, App.mushaf(this) + "&hifz=1"},
                {L.t("بحث بالمعنى"), R.drawable.ic_l_spark, App.mushaf(this) + "&find=1"},
                {L.t("ختمة العائلة"), R.drawable.ic_l_user, FamilyActivity.class},
                {L.t("المقالات"), R.drawable.ic_article, ArticlesActivity.class},
                {L.t("القرآن للأطفال"), R.drawable.ic_kids, App.HOME + "quran-kids-ar.html"},
        }), gap(8));

        col.addView(section(L.t("الصلاة والذكر")), gap(20));
        col.addView(grid(new Object[][]{
                {L.t("المواقيت"), R.drawable.ic_prayer_t, PrayerTimesActivity.class},
                {L.t("القبلة"), R.drawable.ic_qibla, QiblaActivity.class},
                {L.t("مساجد قريبة"), R.drawable.ic_mosques, MosquesActivity.class},
                {L.t("الأذكار"), R.drawable.ic_azkar_t, AzkarActivity.class},
                {L.t("المسبحة"), R.drawable.ic_tasbeeh, TasbeehActivity.class},
                {L.t("أذكار الصلاة"), R.drawable.ic_azkar_t, PrayerAzkarActivity.class},
                {L.t("الأحاديث"), R.drawable.ic_hadith, HadithActivity.class},
                {L.t("وضع المسجد"), R.drawable.ic_silent, MosqueActivity.class},
                {L.t("فحص الأذان"), R.drawable.ic_adhan_check, AdhanCheckActivity.class},
                {L.t("الموقع"), R.drawable.ic_book, Nav.browserIntent(this, android.net.Uri.parse(App.HOME))},
        }), gap(8));

        col.addView(section(L.t("لقلبك والتطبيق")), gap(20));
        col.addView(grid(new Object[][]{
                {L.t("آية لحالك"), R.drawable.ic_l_heart, MoodActivity.class},
                {L.t("صدقة جارية"), R.drawable.ic_heart, DedicateActivity.class},
                {L.t("أثرك"), R.drawable.ic_impact, ImpactActivity.class},
                {L.t("حول العالم"), R.drawable.ic_world, WorldMapActivity.class},
                {L.t("التنبيهات"), R.drawable.ic_l_bell,
                        new Intent(this, SettingsActivity.class).putExtra(SettingsActivity.EXTRA_NOTIF_ONLY, true)},
                {L.t("النسخ والمزامنة"), R.drawable.ic_cloud_up, BackupActivity.class},
                {L.t("قيّم التطبيق"), R.drawable.ic_star, new Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse("market://details?id=" + getPackageName())).setPackage("com.android.vending")},
                {L.t("خصوصيتك"), R.drawable.ic_l_shield, PrivacyActivity.class},
                {L.t("الإعدادات"), R.drawable.ic_nav_settings, SettingsActivity.class},
        }), gap(8));

        col.addView(dedicateCard(), gap(20));
    }

    private View header() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.text(this, L.t("الأدوات"), 24, ink, 700);
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(bell(), new LinearLayout.LayoutParams(dp(48), dp(48)));
        ImageView st = Ui.icon(this, R.drawable.ic_nav_settings, ink, 22);
        st.setScaleType(ImageView.ScaleType.CENTER);
        st.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.line), this));
        st.setContentDescription(L.t("الإعدادات"));
        st.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        st.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        r.addView(st, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return r;
    }

    /** جرس «أخبار التطبيق» بعدد الأخبار الجديدة */
    private View bell() {
        android.widget.FrameLayout f = new android.widget.FrameLayout(this);
        ImageView b = Ui.icon(this, R.drawable.ic_l_bell, gold, 22);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.line), this));
        f.addView(b, new android.widget.FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER));
        int n = News.unread(this);
        if (n > 0) {
            TextView badge = Ui.text(this, Ui.arabicNum(Math.min(n, 9)), 11, 0xFFFFFFFF, 700);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(Ui.shape(0xFFB3412F, 10, getColor(R.color.page), this));
            badge.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            f.addView(badge, new android.widget.FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP | Gravity.START));
        }
        f.setContentDescription(L.t("أخبار التطبيق") + (n > 0 ? L.t("، ") + Ui.arabicNum(n) + L.t(" جديد") : ""));
        f.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        f.setOnClickListener(v -> startActivity(new Intent(this, NewsActivity.class)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
        lp.setMarginEnd(dp(6));
        f.setLayoutParams(lp);
        return f;
    }

    /** آخر خبر لم يُقرأ بعد (يختفي بعد فتح «أخبار التطبيق») */
    private View newsCard() {
        java.util.List<News.Item> items = News.items(this);
        long seen = App.prefs(this).getLong("news_read_at", 0);
        if (items.isEmpty() || items.get(0).at <= seen) return null;
        News.Item it = items.get(0);
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(new Ui.PatternDrawable(this, getColor(R.color.dark), 18));
        ImageView ic = Ui.icon(this, it.article > 0 ? R.drawable.ic_article : R.drawable.ic_l_bell, getColor(R.color.gold), 22);
        card.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(8), 0);
        t.addView(Ui.text(this, L.t("جديد في أخبار التطبيق"), 12, getColor(R.color.gold), 700));
        TextView title = Ui.text(this, (it.article > 0 ? L.t("مقال جديد: ") : "") + (it.article > 0 && !it.body.isEmpty() ? it.body : it.title), 15, 0xFFFFFFFF, 700);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.addView(title);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.ic_chevron);
        card.addView(chev, new LinearLayout.LayoutParams(dp(22), dp(22)));
        card.setContentDescription(L.t("جديد في أخبار التطبيق: ") + it.title);
        card.setOnClickListener(v -> startActivity(new Intent(this, NewsActivity.class)));
        return card;
    }

    private TextView section(String s) {
        TextView t = Ui.text(this, s, 14, muted, 700);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    /** شبكة بأربع خانات في كل صف؛ الصف الأخير الناقص يُكمَّل بفراغ حتى تبقى الخانات بنفس العرض */
    private View grid(Object[][] tools) {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        for (int start = 0; start < tools.length; start += 4) {
            LinearLayout row = new LinearLayout(this);
            for (int k = 0; k < 4; k++) {
                int i = start + k;
                View cell = i < tools.length ? tile(this, (String) tools[i][0], (Integer) tools[i][1], tools[i][2]) : new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                if (k > 0) lp.setMarginStart(dp(8));
                row.addView(cell, lp);
            }
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            if (start > 0) rl.topMargin = dp(8);
            g.addView(row, rl);
        }
        return g;
    }

    /** خانة أداة موحّدة (تُستخدم في «اليوم» و«الأدوات»): أيقونة ذهبية واسم في سطر واحد */
    static View tile(Activity a, String label, int icon, Object target) {
        LinearLayout tile = new LinearLayout(a);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(0, Ui.dp(a, 14), 0, Ui.dp(a, 12));
        tile.setBackground(Ui.shape(a.getColor(R.color.card), 16, a.getColor(R.color.line), a));
        tile.setContentDescription(label);
        ImageView ic = Ui.icon(a, icon, a.getColor(R.color.gold_deep), 26);
        tile.addView(ic);
        TextView l = Ui.text(a, label, 12, a.getColor(R.color.ink), 700);
        l.setPadding(Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4), 0);
        // في القائمة العمودية يأخذ النص عرض الخانة كاملًا، فبدون التوسيط يلتصق بطرفها
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        l.setSingleLine(true);
        l.setEllipsize(android.text.TextUtils.TruncateAt.END);
        l.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        tile.addView(l, new LinearLayout.LayoutParams(-1, -2));
        tile.setOnClickListener(v -> {
            if (target instanceof Intent) {
                try {
                    a.startActivity(new Intent((Intent) target));
                } catch (android.content.ActivityNotFoundException e) {
                    // بلا متجر Play (مثل هواوي): صفحة التطبيق في المتصفح
                    if ("com.android.vending".equals(((Intent) target).getPackage())) App.openPlayListing(a);
                }
            } else if (target instanceof String) {
                a.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse((String) target), a, MainActivity.class)
                        .putExtra(HomeActivity.EXTRA_FROM_HOME, true));
            } else {
                a.startActivity(new Intent(a, (Class<?>) target));
            }
        });
        return Ui.minH(tile, 84);
    }

    private View streakCard() {
        int n = Reading.streak(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        String title = n == 0 ? L.t("ابدأ سلسلتك اليوم مع القرآن")
                : n == 1 ? L.t("يوم واحد مع القرآن") : n == 2 ? L.t("يومان متتاليان مع القرآن")
                : Ui.arabicNum(n) + (n <= 10 ? L.t(" أيام متتالية مع القرآن") : L.t(" يومًا متتاليًا مع القرآن"));
        card.addView(Ui.text(this, title, 16, ink, 700));
        TextView s = Ui.text(this, Reading.readOn(this, Calendar.getInstance()) ? L.t("أحسنت، قرأت اليوم ✓") : L.t("اقرأ ولو آية اليوم لتكملها"), 12, muted, 400);
        s.setPadding(0, dp(4), 0, dp(10));
        card.addView(s);
        LinearLayout dots = new LinearLayout(this);
        String[] dn = {L.t("ح"), L.t("ن"), L.t("ث"), L.t("ر"), L.t("خ"), L.t("ج"), L.t("س")}; // الأحد..السبت
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -6);
        for (int i = 0; i < 7; i++) {
            boolean on = Reading.readOn(this, c);
            boolean today = i == 6;
            LinearLayout d = new LinearLayout(this);
            d.setOrientation(LinearLayout.VERTICAL);
            d.setGravity(Gravity.CENTER);
            TextView dot = new TextView(this);
            dot.setBackground(Ui.shape(on ? gold : getColor(R.color.chip), 14, today ? gold : 0, this));
            dot.setText(on ? "✓" : "");
            dot.setTextColor(0xFFFFFFFF);
            dot.setGravity(Gravity.CENTER);
            d.addView(dot, new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView lbl = Ui.text(this, dn[c.get(Calendar.DAY_OF_WEEK) - 1], 11, today ? gold : muted, today ? 700 : 400);
            lbl.setPadding(0, dp(4), 0, 0);
            lbl.setGravity(Gravity.CENTER_HORIZONTAL);
            lbl.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            d.addView(lbl, new LinearLayout.LayoutParams(-1, -2));
            dots.addView(d, new LinearLayout.LayoutParams(0, -2, 1f));
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        card.addView(dots);
        card.setContentDescription(title + L.t("، افتح «رحلتي»"));
        card.setOnClickListener(v -> startActivity(new Intent(this, JourneyActivity.class)));
        return card;
    }

    private View dedicateCard() {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(new Ui.PatternDrawable(this, getColor(R.color.dark), 18));
        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_heart);
        card.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(12), 0);
        t.addView(Ui.text(this, L.t("اجعلها صدقة جارية"), 16, 0xFFFFFFFF, 700));
        TextView s = Ui.text(this, L.t("شارك التطبيق باسم من تحب، حيًّا أو ميتًا"), 12, getColor(R.color.on_dark_muted), 400);
        s.setPadding(0, dp(3), 0, 0);
        t.addView(s);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.ic_chevron);
        card.addView(chev, new LinearLayout.LayoutParams(dp(22), dp(22)));
        card.setContentDescription(L.t("اجعلها صدقة جارية: شارك التطبيق باسم من تحب"));
        card.setOnClickListener(v -> startActivity(new Intent(this, DedicateActivity.class)));
        return card;
    }

    private void onNav(int idx) {
        if (idx == Ui.NAV_TODAY) {
            startActivity(new Intent(this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            finish();
        } else if (idx == Ui.NAV_MUSHAF) {
            startActivity(Nav.mushafIntent(this, 0));
            finish();
        } else if (idx == Ui.NAV_LISTEN) {
            startActivity(new Intent(this, ListenActivity.class));
            finish();
        }
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
