package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/**
 * إشعار التحديث من صفحة الإدارة في الموقع (مفتاح update في api/v1/app-services):
 * soft = نافذة «تحديث جديد متوفر» مرة في اليوم على الأكثر؛ force = شاشة لا تُغلق حتى يحدّث (لمن إصداره أقل من min).
 * نسخة GitHub لها تنبيهها الخاص (UpdateChecker)، فالتنبيه اللطيف هنا لنسخة المتجر فقط؛ والإجباري للجميع.
 */
final class UpdateGate {
    private static Dialog shown;

    private UpdateGate() { }

    /** يقارن «2.0.150» بـ«2.0.140» رقمًا رقمًا؛ سالب = الأول أقدم */
    static int cmp(String a, String b) {
        String[] x = a.split("\\."), y = b.split("\\.");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = i < x.length ? num(x[i]) : 0, q = i < y.length ? num(y[i]) : 0;
            if (p != q) return p < q ? -1 : 1;
        }
        return 0;
    }

    private static int num(String s) {
        try { return Integer.parseInt(s.replaceAll("[^0-9]", "")); } catch (Exception e) { return 0; }
    }

    private static String current(Activity a) {
        try { return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
    }

    static void check(Activity a) {
        if (a.isFinishing() || (shown != null && shown.isShowing())) return;
        JSONObject u = SiteServices.update(a);
        if (u == null) return;
        String mode = u.optString("mode", "none");
        if ("none".equals(mode)) return;
        JSONObject p = u.optJSONObject("android");
        if (p == null) return;
        String cur = current(a), latest = p.optString("latest", ""), min = p.optString("min", "");
        if (cur.isEmpty()) return;
        String msg = u.optString("message", "");
        if ("force".equals(mode) && !min.isEmpty() && cmp(cur, min) < 0) {
            showForce(a, cur, min, msg);
            return;
        }
        if (latest.isEmpty() || cmp(cur, latest) >= 0 || !App.fromPlay(a)) return;
        long last = App.prefs(a).getLong("upd_soft_at", 0);
        if (System.currentTimeMillis() - last < 20 * 3_600_000L) return;          // مرة في اليوم على الأكثر
        App.prefs(a).edit().putLong("upd_soft_at", System.currentTimeMillis()).apply();
        showSoft(a, cur, latest, msg);
    }

    private static void update(Activity a) {
        if (App.fromPlay(a)) { App.openPlayListing(a); return; }
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.APK_URL))); } catch (Exception ignored) { }
    }

    private static String ar(String v) { return L.en() ? v : Adhan.arabic(v).replace('.', '٫'); }

    private static void showSoft(Activity a, String cur, String latest, String msg) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = Ui.dp(a, 20);
        box.setPadding(pad, pad, pad, Ui.dp(a, 8));
        ImageView logo = new ImageView(a);
        logo.setImageResource(a.getApplicationInfo().icon);
        box.addView(logo, new LinearLayout.LayoutParams(Ui.dp(a, 64), Ui.dp(a, 64)));
        TextView t = Ui.text(a, L.t("تحديث جديد متوفر"), 19, a.getColor(R.color.ink), 700);
        t.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 2));
        box.addView(t);
        box.addView(Ui.text(a, L.t("الإصدار ") + ar(latest) + L.t(" جاهز · أنت على ") + ar(cur), 13, a.getColor(R.color.muted), 400));
        if (!msg.isEmpty()) {
            TextView m = Ui.text(a, msg, 13, a.getColor(R.color.ink), 400);
            m.setLineSpacing(0, 1.3f);
            m.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
            m.setBackground(Ui.shape(a.getColor(R.color.chip), 14, 0, a));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = Ui.dp(a, 12);
            box.addView(m, lp);
        }
        AlertDialog d = new AlertDialog.Builder(a, Ui.dialogTheme(a))
                .setView(box)
                .setPositiveButton(L.t("حدّث الآن"), (x, w) -> update(a))
                .setNegativeButton(L.t("لاحقًا"), null)
                .create();
        shown = d;
        d.show();
    }

    private static void showForce(Activity a, String cur, String min, String msg) {
        Dialog d = new Dialog(a, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int pad = Ui.dp(a, 30);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(new Ui.PatternDrawable(a, a.getColor(R.color.dark), 0));
        box.setLayoutDirection(L.dir());
        ImageView logo = new ImageView(a);
        logo.setImageResource(a.getApplicationInfo().icon);
        box.addView(logo, new LinearLayout.LayoutParams(Ui.dp(a, 96), Ui.dp(a, 96)));
        TextView t = Ui.text(a, L.t("يلزم تحديث التطبيق"), 22, 0xFFFFFFFF, 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(a, 18), 0, Ui.dp(a, 8));
        box.addView(t);
        TextView m = Ui.text(a, (msg.isEmpty() ? L.t("أصلحنا خطأ مهمًّا في هذا الإصدار، ولن يعمل التطبيق بشكل صحيح حتى تحدّثه.") : msg)
                + L.t("\nالتحديث مجاني ويستغرق أقل من دقيقة."), 14, a.getColor(R.color.on_dark_muted), 400);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(0, 1.35f);
        box.addView(m);
        Button b = Ui.button(a, L.t("حدّث الآن"), true);
        b.setBackground(Ui.shape(a.getColor(R.color.gold), 16, 0, a));
        b.setTextColor(a.getColor(R.color.dark));
        b.setOnClickListener(v -> update(a));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, Ui.dp(a, 54));
        bl.topMargin = Ui.dp(a, 24);
        box.addView(b, bl);
        TextView ver = Ui.text(a, L.t("إصدارك ") + ar(cur) + L.t(" · أقل إصدار مطلوب ") + ar(min), 12, a.getColor(R.color.on_dark_muted), 400);
        ver.setGravity(Gravity.CENTER);
        ver.setPadding(0, Ui.dp(a, 14), 0, 0);
        box.addView(ver);
        d.setContentView(box);
        d.setCancelable(false);
        shown = d;
        d.show();
    }

}
