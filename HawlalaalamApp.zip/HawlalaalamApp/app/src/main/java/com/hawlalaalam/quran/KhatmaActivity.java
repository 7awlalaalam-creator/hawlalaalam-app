package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** الختمة الذكية: إعداد الخطة، ومتابعة التقدّم، والتذكير */
public class KhatmaActivity extends Activity {

    private static final String[] DAY_NAMES = {L.t("أحد"), L.t("اثنين"), L.t("ثلاثاء"), L.t("أربعاء"), L.t("خميس"), L.t("جمعة"), L.t("سبت")};
    /** خيار التذكير: صلاة (PrayerCalc) أو وقت ثابت أو بلا تذكير */
    private static final int REMIND_FIXED = -1, REMIND_NONE = -2;

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }

    private LinearLayout col;
    private int ink, muted, gold, goldL;

    // حالة شاشة الإعداد
    private boolean editing;
    private boolean setupLoaded;
    private final Khatma.Plan plan = new Khatma.Plan();
    private boolean customDays, customPpd;
    private int remind = REMIND_FIXED, remindH = 21, remindM = 0;
    private boolean followUp = true;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(L.dir());
        col.setPadding(dp(18), dp(14), dp(18), dp(32));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.addView(col);
        setContentView(scroll);
        Ui.applyInsets(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private boolean running() { return Khatma.active(this) && !Khatma.done(this); }

    private void render() {
        col.removeAllViews();
        col.addView(header());
        if (Khatma.active(this) && Khatma.consumeJustDone(this)) celebrate();
        if (!running() || editing) {
            if (!setupLoaded) loadSetup();
            col.addView(setupCard(), gap(14));
        } else {
            col.addView(progressCard(), gap(14));
            col.addView(todayCard(), gap(14));
            if (Khatma.consumeExtendedNote(this)) {
                col.addView(note(L.t("انتهت مدة الختمة قبل إتمامها، فمدّدنا الموعد بنفس وردك اليومي بدل أن نُثقل عليك. موعدك الجديد: ")
                        + Khatma.endDateText(this)), gap(14));
            } else if (Khatma.missedDays(this)) {
                col.addView(note(Khatma.fixedPace(this)
                        ? L.t("فاتك يوم؟ لا بأس، وردك كما هو، وتحرّك موعد الختم قليلًا.")
                        : L.t("فاتك يوم؟ لا بأس، وزّعنا الصفحات الباقية على الأيام القادمة بهدوء، وموعد ختمتك كما هو.")), gap(14));
            }
            col.addView(section(L.t("هذا الأسبوع")), gap(20));
            col.addView(week(), gap(8));
            col.addView(section(L.t("خطتك")), gap(20));
            col.addView(planCard(), gap(8));
            TextView stop = Ui.text(this, L.t("إنهاء هذه الختمة"), 13, muted, 500);
            stop.setGravity(Gravity.CENTER);
            stop.setPadding(0, dp(18), 0, dp(4));
            stop.setOnClickListener(v -> confirm(L.t("إنهاء الختمة؟"), L.t("سيُحذف تقدّمك في هذه الختمة."), () -> {
                Khatma.stop(this); setupLoaded = false; render();
            }));
            col.addView(stop);
        }
        View hist = historyCard();
        if (hist != null) {
            col.addView(section(L.t("ختماتك السابقة")), gap(20));
            col.addView(hist, gap(8));
        }
        TextView how = Ui.text(this, L.t("تُحتسب الصفحة مقروءة عندما تبقى عليها في المصحف بضع ثوانٍ، فلا يُحسب التصفح السريع. ")
                + L.t("ويصلك تذكير الورد من التطبيق نفسه ولو كان مغلقًا، ولا يصلك إن أتممت وردك."), 13, muted, 400);
        how.setPadding(dp(4), dp(18), dp(4), 0);
        how.setLineSpacing(0, 1.2f);
        col.addView(how);
    }

    private View header() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription(L.t("رجوع"));
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> {
            if (editing) { editing = false; setupLoaded = false; render(); } else finish();
        });
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = Ui.text(this, editing ? L.t("تعديل الخطة") : L.t("ختمتي"), 24, ink, 700);
        t.setPadding(dp(14), 0, dp(14), 0);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        return head;
    }

    // ------------------------------------------------------------------ المتابعة

    private View progressCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        LinearLayout row = new LinearLayout(this);
        row.addView(Ui.text(this, L.t("تقدّمك"), 16, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(Ui.text(this, num(Khatma.read(this)) + L.t(" من ٦٠٤ صفحة"), 13, muted, 400), new LinearLayout.LayoutParams(-2, -2));
        card.addView(row);
        card.addView(bar(Khatma.percent(this)), barLp());
        LinearLayout r2 = new LinearLayout(this);
        r2.addView(Ui.text(this, num(Khatma.percent(this)) + L.t("٪ مكتمل"), 13, muted, 400), new LinearLayout.LayoutParams(0, -2, 1f));
        String end = Khatma.endDateText(this);
        if (!end.isEmpty()) {
            TextView et = Ui.text(this, L.t("الختم المتوقع: ") + end, 13, muted, 400);
            et.setGravity(Gravity.END);
            r2.addView(et, new LinearLayout.LayoutParams(0, -2, 1.6f));
        }
        card.addView(r2);

        int next = Khatma.nextPage(this);
        TextView pos = Ui.text(this, L.t("وصلت إلى: ") + Khatma.where(next) + L.t(" · صفحة ") + num(next), 14, ink, 500);
        pos.setPadding(0, dp(10), 0, 0);
        card.addView(pos);

        int ahead = Khatma.aheadBy(this);
        String status;
        if (ahead > 0) status = L.t("متقدّم على خطتك بـ ") + num(ahead) + L.t(" صفحة، بارك الله فيك");
        else if (ahead < 0) status = L.t("متأخر ") + num(-ahead) + L.t(" صفحة عن الخطة")
                + (Khatma.fixedPace(this) ? L.t("، وتحرّك موعد الختم قليلًا") : L.t("، وزّعناها على أيامك القادمة"));
        else status = L.t("على خطتك تمامًا");
        TextView st = Ui.text(this, status, 13, ahead >= 0 ? gold : muted, 500);
        st.setPadding(0, dp(4), 0, 0);
        card.addView(st);
        return card;
    }

    private View todayCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(18));
        card.setBackground(Ui.shape(getColor(R.color.dark), 20, 0, this));
        int next = Khatma.nextPage(this);

        if (!Khatma.readingToday(this)) {
            card.addView(Ui.text(this, L.t("يوم راحة 🌿"), 13, goldL, 700));
            TextView t = Ui.text(this, L.t("لا ورد اليوم حسب خطتك"), 22, 0xFFFFFFFF, 700);
            t.setPadding(0, dp(8), 0, dp(4));
            card.addView(t);
            card.addView(Ui.text(this, L.t("وإن قرأت احتُسب لك وخفّ وردك القادم."), 14, getColor(R.color.on_dark_muted), 400));
            card.addView(goldButton(L.t("تابع القراءة من صفحة ") + num(next), next), btnLp());
            return card;
        }

        int[] r = Khatma.todayRange(this);
        int left = Khatma.todayRemaining(this);
        card.addView(Ui.text(this, left == 0 ? L.t("أتممت ورد اليوم ✓") : L.t("ورد اليوم"), 13, goldL, 700));
        TextView range = Ui.text(this, L.t("من صفحة ") + num(r[0]) + L.t(" إلى ") + num(r[1]), 22, 0xFFFFFFFF, 700);
        range.setPadding(0, dp(8), 0, dp(2));
        card.addView(range);
        String fromName = Khatma.surahName(r[0]), toName = Khatma.surahName(r[1]);
        card.addView(Ui.text(this, fromName.equals(toName) ? L.t("سورة ") + fromName : L.t("من سورة ") + fromName + L.t(" إلى سورة ") + toName,
                14, getColor(R.color.on_dark_soft), 500));
        int target = Khatma.dailyTarget(this);
        TextView cnt = Ui.text(this, num(target) + L.t(" صفحة · ") + (left == 0 ? L.t("بارك الله فيك") : L.t("بقي ") + num(left)),
                14, getColor(R.color.on_dark_muted), 400);
        cnt.setPadding(0, dp(4), 0, 0);
        card.addView(cnt);
        int open = left == 0 ? next : Math.max(r[0], next);
        card.addView(goldButton(left == 0 ? L.t("تابع القراءة من صفحة ") + num(open)
                : L.t("افتح المصحف على الصفحة ") + num(open), open), btnLp());
        return card;
    }

    private TextView goldButton(String label, int page) {
        TextView btn = Ui.text(this, label, 15, getColor(R.color.dark), 700);
        btn.setPadding(dp(14), dp(8), dp(14), dp(8));
        Ui.minH(btn, 50);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(Ui.shape(goldL, 25, 0, this));
        btn.setOnClickListener(v -> startActivity(App.openInApp(this, Khatma.pageUrl(page))));
        return btn;
    }

    private LinearLayout.LayoutParams btnLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        return lp;
    }

    private View note(String s) {
        TextView t = Ui.text(this, s, 14, ink, 400);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.Drawable sp = getDrawable(R.drawable.ic_l_sprout).mutate();
        sp.setTint(gold);
        t.setCompoundDrawablesRelativeWithIntrinsicBounds(sp, null, null, null);
        t.setCompoundDrawablePadding(dp(10));
        t.setLineSpacing(0, 1.2f);
        t.setBackground(Ui.shape(getColor(R.color.ivory), 16, getColor(R.color.ivory_border), this));
        return t;
    }

    /** آخر ٧ أيام: ✓ أتم الورد، • قرأ بعضه، — يوم راحة */
    private View week() {
        LinearLayout row = Ui.card(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(12), dp(8), dp(12));
        long t = Khatma.today();
        for (long d = t - 6; d <= t; d++) {
            boolean isToday = d == t;
            boolean off = !Khatma.isReadingDay(this, d);
            int st = Khatma.dayState(this, d);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            String mark = st == 2 ? "✓" : st == 1 ? "•" : off ? "—" : "";
            int fg = st == 2 || isToday ? 0xFFFFFFFF : off ? muted : gold;
            int bg = st == 2 ? gold : isToday ? getColor(R.color.primary) : off ? getColor(R.color.page) : getColor(R.color.chip);
            TextView dot = Ui.text(this, mark, 13, fg, 700);
            dot.setGravity(Gravity.CENTER);
            dot.setBackground(Ui.shape(bg, 17, off && !isToday ? getColor(R.color.line) : 0, this));
            cell.addView(dot, new LinearLayout.LayoutParams(dp(34), dp(34)));
            TextView n = Ui.text(this, DAY_NAMES[Khatma.dow(d) - 1], 11, muted, 400);
            n.setPadding(0, dp(4), 0, 0);
            cell.addView(n);
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return row;
    }

    private View planCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(18), dp(14), dp(18), dp(16));
        int pace = Khatma.pace(this);
        card.addView(infoRow(L.t("الورد"), L.t("نحو ") + num(pace) + L.t(" صفحة يوميًا") + juzHint(pace)));
        card.addView(infoRow(L.t("أيام القراءة"), daysText(Khatma.offMask(this))));
        card.addView(infoRow(L.t("إن فاتني يوم"), Khatma.fixedPace(this) ? L.t("يتمدّد الموعد بنفس الورد") : L.t("يُوزَّع الباقي على الأيام")));
        String rem = Reminders.enabled(this, Reminders.WIRD)
                ? Reminders.wirdLabel(this) + (Reminders.followUpOn(this) ? L.t(" + تذكير ثانٍ") : "") : L.t("بلا تذكير");
        card.addView(infoRow(L.t("التذكير"), rem));
        android.widget.Button edit = Ui.button(this, L.t("تعديل الخطة"), false);
        edit.setOnClickListener(v -> { editing = true; setupLoaded = false; render(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        card.addView(Ui.minH(edit, 46), lp);
        return card;
    }

    private View infoRow(String k, String v) {
        LinearLayout r = new LinearLayout(this);
        r.setPadding(0, dp(6), 0, dp(6));
        r.setBaselineAligned(false);
        // القيمة لا تستحوذ على السطر كله: لكل منهما نصيب، والقيمة الطويلة تلتف داخل نصيبها
        r.addView(Ui.text(this, k, 14, muted, 400), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView val = Ui.text(this, v, 14, ink, 500);
        val.setGravity(Gravity.END);
        r.addView(val, new LinearLayout.LayoutParams(0, -2, 1.8f));
        return r;
    }

    private View historyCard() {
        List<long[]> h = Khatma.history(this);
        if (h.isEmpty()) return null;
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(18), dp(10), dp(18), dp(10));
        for (int i = 0; i < Math.min(5, h.size()); i++) {
            long[] e = h.get(i);
            card.addView(infoRow(L.t("ختمة ") + Khatma.dateText(e[1]), L.t("خلال ") + num(Math.max(1, e[1] - e[0] + 1)) + L.t(" يومًا")));
        }
        return card;
    }

    // ------------------------------------------------------------------ الإعداد

    /** تعبئة الإعداد: من الخطة الحالية عند التعديل، أو بقيم افتراضية */
    private void loadSetup() {
        setupLoaded = true;
        customDays = false;
        customPpd = false;
        if (editing && running()) {
            plan.mode = Khatma.mode(this);
            plan.ppd = Khatma.pace(this);
            plan.days = (int) Math.max(1, Khatma.endDay(this) - Khatma.today() + 1);
            plan.offMask = Khatma.offMask(this);
            plan.extend = Khatma.fixedPace(this) && Khatma.MODE_DAYS.equals(plan.mode);
            plan.label = Khatma.label(this);
            customDays = true;
            customPpd = java.util.Arrays.binarySearch(new int[]{1, 2, 3, 5, 10, 20, 40}, plan.ppd) < 0;
        } else {
            plan.mode = Khatma.MODE_DAYS;
            plan.days = 30;
            plan.ppd = 20;
            plan.offMask = 0;
            plan.extend = false;
            plan.label = L.t("شهر");
            plan.startPage = 1;
        }
        followUp = Reminders.followUpOn(this);
        remindH = Reminders.hour(this, Reminders.WIRD);
        remindM = Reminders.minute(this, Reminders.WIRD);
        if (!Reminders.enabled(this, Reminders.WIRD) && editing) remind = REMIND_NONE;
        else if (Reminders.byPrayer(this, Reminders.WIRD)) remind = Reminders.wirdPrayer(this);
        else remind = Adhan.hasLocation(this) && !editing ? PrayerCalc.ISHA : REMIND_FIXED;
    }

    private View setupCard() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        if (!editing) {
            LinearLayout intro = new LinearLayout(this);
            intro.setOrientation(LinearLayout.VERTICAL);
            intro.setPadding(dp(18), dp(18), dp(18), dp(18));
            intro.setBackground(Ui.shape(getColor(R.color.dark), 20, 0, this));
            int done = Khatma.completed(this);
            intro.addView(Ui.text(this, done > 0 ? L.t("ختمت القرآن ") + num(done) + L.t(" مرة، تقبّل الله منك") : L.t("ابدأ ختمتك"), 13, goldL, 700));
            TextView t = Ui.text(this, L.t("خطة على مقاسك"), 22, 0xFFFFFFFF, 700);
            t.setPadding(0, dp(8), 0, dp(4));
            intro.addView(t);
            intro.addView(Ui.text(this, L.t("اختر المدة أو الورد اليومي، وأيام قراءتك ووقت تذكيرك، ونحسب لك الباقي."),
                    14, getColor(R.color.on_dark_muted), 400));
            wrap.addView(intro);
        }

        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(10), dp(16), dp(16));

        // ١) طريقة الختمة
        card.addView(label(L.t("طريقة الختمة")));
        List<View> modes = new ArrayList<>();
        modes.add(choice(L.t("حسب المدة"), Khatma.MODE_DAYS.equals(plan.mode), () -> plan.mode = Khatma.MODE_DAYS));
        modes.add(choice(L.t("حسب الورد اليومي"), Khatma.MODE_PAGES.equals(plan.mode), () -> plan.mode = Khatma.MODE_PAGES));
        card.addView(grid(modes, 2));

        // ٢) المدة أو الورد
        if (Khatma.MODE_DAYS.equals(plan.mode)) {
            card.addView(label(editing ? L.t("أختم خلال (من اليوم)") : L.t("أختم خلال")));
            List<View> items = new ArrayList<>();
            if (Ramadan.active()) items.add(dayChoice(L.t("حتى آخر رمضان"), Ramadan.daysLeftInRamadan()));
            int[] ds = {7, 10, 15, 30, 60, 90, 180, 365};
            String[] ns = {L.t("أسبوع"), L.t("١٠ أيام"), L.t("١٥ يومًا"), L.t("شهر"), L.t("شهران"), L.t("٣ أشهر"), L.t("٦ أشهر"), L.t("سنة")};
            for (int i = 0; i < ds.length; i++) items.add(dayChoice(ns[i], ds[i]));
            items.add(choice(customDays ? num(plan.days) + L.t(" يومًا") : L.t("مدة أخرى…"), customDays, null, () ->
                    askNumber(L.t("كم يومًا؟"), L.t("من ١ إلى ٧٣٠ يومًا"), 1, 730, v -> {
                        plan.days = v; plan.label = num(v) + L.t(" يومًا"); customDays = true; render();
                    })));
            card.addView(grid(items, 3));
        } else {
            card.addView(label(L.t("وردي اليومي")));
            List<View> items = new ArrayList<>();
            int[] ps = {1, 2, 3, 5, 10, 20, 40};
            String[] ns = {L.t("صفحة"), L.t("صفحتان"), L.t("٣ صفحات"), L.t("ربع جزء"), L.t("نصف جزء"), L.t("جزء"), L.t("جزءان")};
            for (int i = 0; i < ps.length; i++) items.add(ppdChoice(ns[i], ps[i]));
            items.add(choice(customPpd ? num(plan.ppd) + L.t(" صفحة") : L.t("عدد آخر…"), customPpd, null, () ->
                    askNumber(L.t("كم صفحة يوميًا؟"), L.t("من ١ إلى ١٢٠ صفحة"), 1, 120, v -> {
                        plan.ppd = v; plan.label = num(v) + L.t(" صفحة يوميًا"); customPpd = true; render();
                    })));
            card.addView(grid(items, 3));
        }

        // ٣) نقطة البداية (للختمة الجديدة)
        if (!editing) {
            card.addView(label(L.t("أبدأ من")));
            List<View> starts = new ArrayList<>();
            starts.add(choice(L.t("الفاتحة"), plan.startPage == 1, () -> plan.startPage = 1));
            int last = Khatma.lastMushafPage(this);
            if (last > 1) starts.add(choice(L.t("حيث توقفت · صفحة ") + num(last), plan.startPage == last, () -> plan.startPage = last));
            boolean other = plan.startPage != 1 && plan.startPage != last;
            starts.add(choice(other ? L.t("صفحة ") + num(plan.startPage) : L.t("صفحة أخرى…"), other, null, () ->
                    askNumber(L.t("من أي صفحة تبدأ؟"), L.t("من ١ إلى ٦٠٤"), 1, 604, v -> { plan.startPage = v; render(); })));
            card.addView(grid(starts, starts.size() == 3 ? 3 : 2));
            if (plan.startPage > 1) {
                TextView hint = Ui.text(this, L.t("تبدأ من ") + Khatma.where(plan.startPage) + L.t("، وبعد آخر المصحف نكمل من أوله حتى تتم الختمة."), 12, muted, 400);
                hint.setPadding(dp(2), dp(6), dp(2), 0);
                card.addView(hint);
            }
        }

        // ٤) أيام القراءة
        card.addView(label(L.t("أيام القراءة (اضغط لجعل اليوم راحة)")));
        List<View> days = new ArrayList<>();
        int[] order = {Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY,
                Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY};
        for (int d : order) {
            boolean on = (plan.offMask & (1 << d)) == 0;
            days.add(choice(DAY_NAMES[d - 1], on, () -> {
                int m = plan.offMask ^ (1 << d);
                if (m != 0b11111110) plan.offMask = m;     // يبقى يوم قراءة واحد على الأقل
            }));
        }
        card.addView(grid(days, 4));

        // ٥) سياسة فوات يوم (لوضع المدة)
        if (Khatma.MODE_DAYS.equals(plan.mode)) {
            card.addView(label(L.t("إن فاتني يوم")));
            List<View> pol = new ArrayList<>();
            pol.add(choice(L.t("أزيد وردي لأختم في موعدي"), !plan.extend, () -> plan.extend = false));
            pol.add(choice(L.t("أمدّد الموعد بنفس الورد"), plan.extend, () -> plan.extend = true));
            card.addView(grid(pol, 2));
        }

        // ٦) التذكير
        card.addView(label(L.t("ذكّرني بالورد")));
        List<View> rem = new ArrayList<>();
        if (Adhan.hasLocation(this)) {
            rem.add(choice(L.t("بعد الفجر"), remind == PrayerCalc.FAJR, () -> remind = PrayerCalc.FAJR));
            rem.add(choice(L.t("بعد العصر"), remind == PrayerCalc.ASR, () -> remind = PrayerCalc.ASR));
            rem.add(choice(L.t("بعد العشاء"), remind == PrayerCalc.ISHA, () -> remind = PrayerCalc.ISHA));
        }
        rem.add(choice(remind == REMIND_FIXED ? Adhan.arabic(App.formatTime(remindH, remindM)) : L.t("وقت محدد…"),
                remind == REMIND_FIXED, null, () ->
                new TimePickerDialog(this, (tp, h, m) -> { remindH = h; remindM = m; remind = REMIND_FIXED; render(); },
                        remindH, remindM, false).show()));
        rem.add(choice(L.t("بلا تذكير"), remind == REMIND_NONE, () -> remind = REMIND_NONE));
        card.addView(grid(rem, 3));
        if (remind != REMIND_NONE) {
            Switch sw = Ui.toggle(this);
            sw.setChecked(followUp);
            sw.setOnCheckedChangeListener((b, on) -> followUp = on);
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            rl.topMargin = dp(8);
            card.addView(Ui.row(this, L.t("تذكير ثانٍ لطيف"), L.t("بعد ٣ ساعات إن لم تُتمّ وردك، ولا يصل بعد ١١ مساءً"), sw), rl);
        }
        if (!Adhan.hasLocation(this)) {
            TextView hint = Ui.text(this, L.t("فعّل مواقيت الصلاة من الإعدادات ليصبح التذكير بعد الصلاة متاحًا."), 12, muted, 400);
            hint.setPadding(dp(2), dp(6), dp(2), 0);
            card.addView(hint);
        }

        // الملخّص
        int remaining = editing ? Khatma.PAGES - Khatma.read(this) : Khatma.PAGES;
        int pace = plan.pace(remaining);
        long end = plan.end(remaining);
        TextView sum = Ui.text(this, L.t("وردك نحو ") + num(pace) + L.t(" صفحة يوميًا") + juzHint(pace)
                + L.t("\nتختم بإذن الله يوم ") + Khatma.dateText(end), 15, ink, 700);
        sum.setLineSpacing(0, 1.3f);
        sum.setPadding(dp(14), dp(12), dp(14), dp(12));
        sum.setBackground(Ui.shape(getColor(R.color.ivory), 16, getColor(R.color.ivory_border), this));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.topMargin = dp(16);
        card.addView(sum, sl);

        android.widget.Button go = Ui.button(this, editing ? L.t("احفظ التعديل") : L.t("ابدأ الختمة"), true);
        go.setOnClickListener(v -> commit());
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
        gl.topMargin = dp(14);
        card.addView(Ui.minH(go, 52), gl);
        if (editing) {
            TextView cancel = Ui.text(this, L.t("إلغاء"), 14, muted, 500);
            cancel.setGravity(Gravity.CENTER);
            cancel.setPadding(0, dp(14), 0, dp(2));
            cancel.setOnClickListener(v -> { editing = false; setupLoaded = false; render(); });
            card.addView(cancel);
        }

        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        if (!editing) cl.topMargin = dp(12);
        wrap.addView(card, cl);
        return wrap;
    }

    private void commit() {
        Runnable go = () -> {
            if (editing && running()) Khatma.replan(this, plan);
            else Khatma.start(this, plan);
            applyReminder();
            editing = false;
            setupLoaded = false;
            KhatmaWidget.updateAll(this);
            render();
        };
        if (!editing && running() && Khatma.read(this) > 0) {
            confirm(L.t("بدء ختمة جديدة؟"), L.t("ستبدأ ختمة جديدة ويُحذف تقدّم الختمة الحالية."), go);
        } else go.run();
    }

    private void applyReminder() {
        if (remind == REMIND_NONE) {
            Reminders.set(this, Reminders.WIRD, false, remindH, remindM);
            Reminders.setFollowUp(this, false);
            return;
        }
        if (remind == REMIND_FIXED) {
            App.prefs(this).edit().putInt("wird_prayer", -1).apply();
            Reminders.set(this, Reminders.WIRD, true, remindH, remindM);
        } else {
            Reminders.setWirdPrayer(this, remind);
        }
        Reminders.setFollowUp(this, followUp);
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.allowed(this)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        }
    }

    private View dayChoice(String name, int days) {
        boolean sel = !customDays && plan.days == days;
        return choice(name, sel, () -> { plan.days = days; plan.label = name; customDays = false; });
    }

    private View ppdChoice(String name, int ppd) {
        boolean sel = !customPpd && plan.ppd == ppd;
        return choice(name, sel, () -> { plan.ppd = ppd; plan.label = name + L.t(" يوميًا"); customPpd = false; });
    }

    // ------------------------------------------------------------------ أدوات الواجهة

    private TextView choice(String s, boolean selected, Runnable onSelect) {
        return choice(s, selected, onSelect, null);
    }

    /** زر اختيار: onSelect يغيّر الحالة ثم تُعاد الرسم، أو onTap لفتح حوار */
    private TextView choice(String s, boolean selected, Runnable onSelect, Runnable onTap) {
        TextView chip = Ui.text(this, s, 13, selected ? 0xFFFFFFFF : ink, selected ? 700 : 500);
        chip.setGravity(Gravity.CENTER);
        chip.setMaxLines(3);
        chip.setEllipsize(android.text.TextUtils.TruncateAt.END);
        chip.setPadding(dp(6), dp(6), dp(6), dp(6));
        chip.setMinHeight(dp(44));
        chip.setBackground(Ui.shape(selected ? getColor(R.color.primary) : getColor(R.color.card), 20,
                selected ? 0 : getColor(R.color.field_border), this));
        chip.setContentDescription(s + (selected ? L.t("، مختار") : ""));
        chip.setOnClickListener(v -> {
            if (onTap != null) onTap.run();
            else if (onSelect != null) { onSelect.run(); render(); }
        });
        return chip;
    }

    private View grid(List<View> items, int cols) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setBaselineAligned(false);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                if (i > 0) rl.topMargin = dp(8);
                wrap.addView(row, rl);
            }
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -1, 1f);
            if (i % cols > 0) cl.setMarginStart(dp(8));
            row.addView(items.get(i), cl);
        }
        int rem = items.size() % cols;
        if (rem != 0 && row != null) for (int k = rem; k < cols; k++) {
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -1, 1f);
            cl.setMarginStart(dp(8));
            row.addView(new View(this), cl);
        }
        return wrap;
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 14, gold, 700);
        t.setPadding(dp(2), dp(16), dp(2), dp(8));
        return t;
    }

    private interface IntDone { void done(int v); }

    private void askNumber(String title, String hint, int min, int max, IntDone done) {
        EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_NUMBER);
        in.setHint(hint);
        in.setGravity(Gravity.CENTER);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(in, new LinearLayout.LayoutParams(-1, -2));
        AlertDialog d = new AlertDialog.Builder(this, dialogTheme())
                .setTitle(title).setView(box)
                .setPositiveButton(L.t("تم"), (x, w) -> {
                    try {
                        int v = Integer.parseInt(in.getText().toString().trim());
                        if (v >= min && v <= max) done.done(v);
                    } catch (NumberFormatException ignored) { }
                })
                .setNegativeButton(L.t("إلغاء"), null).create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(L.dir());
    }

    private static String juzHint(int pace) {
        switch (pace) {
            case 5: return L.t(" (ربع جزء)");
            case 10: return L.t(" (نصف جزء)");
            case 20: return L.t(" (جزء)");
            case 40: return L.t(" (جزءان)");
            default: return "";
        }
    }

    private static String daysText(int mask) {
        if (mask == 0) return L.t("كل يوم");
        StringBuilder sb = new StringBuilder(L.t("عدا "));
        boolean first = true;
        for (int d = 1; d <= 7; d++) {
            if ((mask & (1 << d)) == 0) continue;
            if (!first) sb.append(L.t(" و"));
            sb.append(DAY_NAMES[d - 1]);
            first = false;
        }
        return sb.toString();
    }

    private int dialogTheme() { return Ui.dialogTheme(this); }

    private void celebrate() {
        AlertDialog d = new AlertDialog.Builder(this, dialogTheme())
                .setTitle(L.t("ختمت القرآن الكريم، تقبّل الله منك"))
                .setMessage(L.t("اللهم ارحمني بالقرآن واجعله لي إمامًا ونورًا وهدًى ورحمة."))
                .setPositiveButton(L.t("آمين"), null)
                .create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(L.dir());
    }

    private void confirm(String title, String msg, Runnable yes) {
        AlertDialog d = new AlertDialog.Builder(this, dialogTheme())
                .setTitle(title).setMessage(msg)
                .setPositiveButton(L.t("نعم"), (x, w) -> yes.run())
                .setNegativeButton(L.t("إلغاء"), null).create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(L.dir());
    }

    private ProgressBar bar(int pct) {
        ProgressBar b = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        b.setMax(100);
        b.setProgress(pct);
        b.setProgressTintList(android.content.res.ColorStateList.valueOf(gold));
        b.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.chip)));
        b.setContentDescription(L.t("التقدّم ") + pct + L.t("٪"));
        return b;
    }

    private LinearLayout.LayoutParams barLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(14));
        lp.topMargin = dp(10);
        lp.bottomMargin = dp(8);
        return lp;
    }

    private TextView section(String s) {
        TextView t = Ui.text(this, s, 14, gold, 700);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private static String num(long n) { return Adhan.arabic(String.valueOf(n)); }

    private int dp(int v) { return Ui.dp(this, v); }
}
