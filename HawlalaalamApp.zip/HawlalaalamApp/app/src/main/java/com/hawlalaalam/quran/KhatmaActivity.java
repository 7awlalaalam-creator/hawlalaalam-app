package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/** الختمة الذكية */
public class KhatmaActivity extends Activity {
    private LinearLayout col;
    private int ink, muted, gold, goldL;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(18), dp(14), dp(18), dp(32));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.addView(col);
        setContentView(scroll);
        Ui.applyInsets(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        col.removeAllViews();
        col.addView(header());
        if (Khatma.active(this) && Khatma.consumeJustDone(this)) celebrate();
        if (!Khatma.active(this) || Khatma.done(this)) {
            col.addView(startCard(), gap(14));
        } else {
            col.addView(progressCard(), gap(14));
            col.addView(todayCard(), gap(14));
            if (Khatma.missedDays(this)) col.addView(gentleNote(), gap(14));
            col.addView(section("هذا الأسبوع"), gap(20));
            col.addView(week(), gap(8));
            col.addView(section("تغيير مدة الختمة"), gap(20));
            col.addView(plans(), gap(8));
            TextView stop = Ui.text(this, "إنهاء هذه الختمة", 13, muted, 500);
            stop.setGravity(Gravity.CENTER);
            stop.setPadding(0, dp(18), 0, dp(4));
            stop.setOnClickListener(v -> confirm("إنهاء الختمة؟", "سيُحذف تقدّمك في هذه الختمة.", () -> { Khatma.stop(this); render(); }));
            col.addView(stop);
        }
        TextView how = Ui.text(this, "يعرف التطبيق الصفحات التي قرأتها تلقائيًا عند فتحها في المصحف، ويذكّرك بورد اليوم في وقت «الورد اليومي» من الإعدادات.", 13, muted, 400);
        how.setPadding(dp(4), dp(18), dp(4), 0);
        col.addView(how);
    }

    private View header() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(0xFFFFFFFF, 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = Ui.text(this, "ختمتي", 24, ink, 700);
        t.setPadding(dp(14), 0, dp(14), 0);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        return head;
    }

    private View progressCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        LinearLayout row = new LinearLayout(this);
        row.addView(Ui.text(this, "تقدّمك", 16, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(Ui.text(this, "صفحة " + Adhan.arabic(String.valueOf(Khatma.read(this))) + " من ٦٠٤", 13, muted, 400));
        card.addView(row);
        card.addView(bar(Khatma.percent(this)), barLp());
        LinearLayout r2 = new LinearLayout(this);
        r2.addView(Ui.text(this, Adhan.arabic(String.valueOf(Khatma.percent(this))) + "٪ مكتمل", 13, muted, 400), new LinearLayout.LayoutParams(0, -2, 1f));
        String end = Khatma.endDateText(this);
        if (!end.isEmpty()) r2.addView(Ui.text(this, "الختم المتوقع: " + end, 13, muted, 400));
        card.addView(r2);
        return card;
    }

    private View todayCard() {
        int[] r = Khatma.todayRange(this);
        int left = Khatma.todayRemaining(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(18));
        card.setBackground(Ui.shape(getColor(R.color.dark), 20, 0, this));
        card.addView(Ui.text(this, left == 0 ? "أتممت ورد اليوم ✓" : "ورد اليوم", 13, goldL, 700));
        TextView range = Ui.text(this, "من صفحة " + Adhan.arabic(String.valueOf(r[0])) + " إلى " + Adhan.arabic(String.valueOf(r[1])), 22, 0xFFFFFFFF, 700);
        range.setPadding(0, dp(8), 0, dp(4));
        card.addView(range);
        int target = Khatma.dailyTarget(this);
        card.addView(Ui.text(this, Adhan.arabic(String.valueOf(target)) + " صفحة · "
                + (left == 0 ? "بارك الله فيك" : "بقي " + Adhan.arabic(String.valueOf(left))), 14, getColor(R.color.on_dark_muted), 400));
        int open = left == 0 ? Khatma.nextPage(this) : Math.max(r[0], Khatma.nextPage(this));
        TextView btn = Ui.text(this, left == 0 ? "تابع القراءة من صفحة " + Adhan.arabic(String.valueOf(open))
                : "افتح المصحف على الصفحة " + Adhan.arabic(String.valueOf(open)), 15, getColor(R.color.dark), 700);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(Ui.shape(goldL, 25, 0, this));
        btn.setOnClickListener(v -> startActivity(App.openInApp(this, Khatma.pageUrl(open))));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(14);
        card.addView(btn, lp);
        return card;
    }

    private View gentleNote() {
        TextView t = Ui.text(this, "🌱 فاتك يوم؟ لا بأس، وزّعنا الصفحات الباقية على الأيام القادمة بهدوء، وموعد ختمتك كما هو.", 14, ink, 400);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(Ui.shape(getColor(R.color.ivory), 16, getColor(R.color.ivory_border), this));
        return t;
    }

    private View week() {
        LinearLayout row = Ui.card(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(8), dp(12), dp(8), dp(12));
        String[] names = {"أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"};
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -6);
        for (int i = 0; i < 7; i++) {
            boolean isToday = i == 6;
            boolean read = Reading.readOn(this, c);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView dot = Ui.text(this, read ? "✓" : "", 13, read || isToday ? 0xFFFFFFFF : gold, 700);
            dot.setGravity(Gravity.CENTER);
            dot.setBackground(Ui.shape(read ? gold : isToday ? ink : getColor(R.color.chip), 17, 0, this));
            cell.addView(dot, new LinearLayout.LayoutParams(dp(34), dp(34)));
            TextView n = Ui.text(this, names[c.get(Calendar.DAY_OF_WEEK) - 1], 11, muted, 400);
            n.setPadding(0, dp(4), 0, 0);
            cell.addView(n);
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return row;
    }

    private View startCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(Ui.shape(getColor(R.color.dark), 20, 0, this));
        int done = Khatma.completed(this);
        card.addView(Ui.text(this, done > 0 ? "ختمت القرآن " + Adhan.arabic(String.valueOf(done)) + " مرة، تقبّل الله منك" : "ابدأ ختمتك", 13, goldL, 700));
        TextView t = Ui.text(this, "متى تحب أن تختم؟", 22, 0xFFFFFFFF, 700);
        t.setPadding(0, dp(8), 0, dp(4));
        card.addView(t);
        card.addView(Ui.text(this, "نحسب لك ورد كل يوم، ونذكّرك به، ونفتح المصحف على الصفحة نفسها.", 14, getColor(R.color.on_dark_muted), 400));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        card.addView(plans(), lp);
        return card;
    }

    private View plans() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        java.util.List<Object[]> items = new java.util.ArrayList<>();
        if (Ramadan.active()) items.add(new Object[]{"حتى آخر رمضان", Ramadan.daysLeftInRamadan()});
        items.add(new Object[]{"شهر", 30});
        items.add(new Object[]{"شهرين", 60});
        items.add(new Object[]{"٣ أشهر", 90});
        items.add(new Object[]{"أسبوع", 7});
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                if (i > 0) rl.topMargin = dp(8);
                wrap.addView(row, rl);
            }
            String name = (String) items.get(i)[0];
            int days = (Integer) items.get(i)[1];
            TextView chip = Ui.text(this, name, 14, ink, 500);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(Ui.shape(0xFFFFFFFF, 20, 0xFFD5DADF, this));
            chip.setOnClickListener(v -> {
                Runnable go = () -> { Khatma.start(this, days, name); render(); };
                if (Khatma.active(this) && !Khatma.done(this) && Khatma.read(this) > 0) {
                    confirm("بدء ختمة جديدة؟", "ستبدأ ختمة جديدة مدتها " + name + "، ويُحذف تقدّم الختمة الحالية.", go);
                } else go.run();
            });
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(42), 1f);
            if (i % 3 > 0) cl.setMarginStart(dp(8));
            row.addView(chip, cl);
        }
        int rem = items.size() % 3;
        if (rem != 0) for (int k = rem; k < 3; k++) {
            View sp = new View(this);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(42), 1f);
            cl.setMarginStart(dp(8));
            row.addView(sp, cl);
        }
        return wrap;
    }

    private void celebrate() {
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert)
                .setTitle("🎉 ختمت القرآن الكريم")
                .setMessage("تقبّل الله منك. اللهم ارحمني بالقرآن واجعله لي إمامًا ونورًا وهدًى ورحمة.")
                .setPositiveButton("آمين", null)
                .create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    private void confirm(String title, String msg, Runnable yes) {
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert)
                .setTitle(title).setMessage(msg)
                .setPositiveButton("نعم", (x, w) -> yes.run())
                .setNegativeButton("إلغاء", null).create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    private ProgressBar bar(int pct) {
        ProgressBar b = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        b.setMax(100);
        b.setProgress(pct);
        b.setProgressTintList(android.content.res.ColorStateList.valueOf(gold));
        b.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.chip)));
        b.setContentDescription("التقدّم " + pct + "٪");
        return b;
    }

    private LinearLayout.LayoutParams barLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(14));
        lp.topMargin = dp(10);
        lp.bottomMargin = dp(8);
        return lp;
    }

    private TextView section(String s) {
        TextView t = Ui.text(this, s, 14, gold, 700);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
