package com.hawlalaalam.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * مشغّل التلاوات الأصلي: بث من mp3quran.net أو من الملف المحمّل، يستمر في الخلفية مع التحكم من الإشعار
 * وشاشة القفل والسماعات، وقائمة تشغيل متتالية، وسرعة التلاوة، ومؤقت النوم، وتكرار السورة، واستكمال الموضع.
 * الحالة ثابتة (static) لأن هناك مشغّلًا واحدًا في التطبيق؛ الشاشات تستمع للتغيّرات عبر Listener.
 */
public class PlayerService extends Service {

    static final class Track {
        String url, title, reciter;
        int reciterId, moshafId, surah;
        boolean live;                    // إذاعة: لا مدة ولا تقديم

        static Track surah(Reciters.Reciter r, Reciters.Moshaf m, int s) {
            Track t = new Track();
            t.url = m.url(s);
            t.title = "سورة " + QuranText.surahName(s);
            t.reciter = r.name;
            t.reciterId = r.id;
            t.moshafId = m.id;
            t.surah = s;
            return t;
        }
    }

    interface Listener { void changed(); }

    private static final String CHANNEL = "media";
    private static final int NOTE_ID = 41;               // ليس 4: ذلك رقم إشعار الأذان
    static final String ACT_TOGGLE = "toggle", ACT_NEXT = "next", ACT_PREV = "prev", ACT_STOP = "stop", ACT_START = "start";

    static final float[] SPEEDS = {0.75f, 1f, 1.25f, 1.5f};

    private static final List<Track> queue = new ArrayList<>();
    private static int index = -1;
    private static long startAt;                  // موضع البدء (استكمال)
    private static volatile boolean playing, preparing;
    private static float speed = 1f;
    private static boolean repeatOne;
    private static long sleepAt;                  // وقت انتهاء مؤقت النوم، ٠ = لا يوجد
    private static boolean sleepEndOfTrack;
    private static String error;
    private static final CopyOnWriteArraySet<Listener> listeners = new CopyOnWriteArraySet<>();
    private static PlayerService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaPlayer mp;
    private MediaSession session;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private boolean noisyRegistered;
    private boolean foreground, everForeground;
    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { pause(); }      // نُزعت السماعة
    };

    // ------------------------------------------------------------------ واجهة الشاشات

    static void addListener(Listener l) { listeners.add(l); }
    static void removeListener(Listener l) { listeners.remove(l); }

    private static void notifyChanged() {
        new Handler(Looper.getMainLooper()).post(() -> { for (Listener l : listeners) l.changed(); });
    }

    static Track current() { return index >= 0 && index < queue.size() ? queue.get(index) : null; }
    static boolean isPlaying() { return playing; }
    static boolean isPreparing() { return preparing; }
    static boolean hasNext() { return index + 1 < queue.size(); }
    static boolean hasPrev() { return index > 0; }
    static float speed() { return speed; }
    static boolean repeatOne() { return repeatOne; }
    static String error() { return error; }
    static long sleepAt() { return sleepAt; }
    static boolean sleepEndOfTrack() { return sleepEndOfTrack; }

    static long position() {
        PlayerService s = instance;
        try { return s != null && s.mp != null && !preparing ? s.mp.getCurrentPosition() : startAt; } catch (Exception e) { return 0; }
    }

    static long duration() {
        PlayerService s = instance;
        Track t = current();
        if (t == null || t.live) return 0;
        try { return s != null && s.mp != null && !preparing ? Math.max(0, s.mp.getDuration()) : 0; } catch (Exception e) { return 0; }
    }

    /** تشغيل قائمة من عنصر معيّن، مع موضع بدء اختياري */
    static void play(Context c, List<Track> tracks, int from, long position) {
        if (tracks == null || tracks.isEmpty()) return;
        queue.clear();
        queue.addAll(tracks);
        index = Math.max(0, Math.min(from, tracks.size() - 1));
        startAt = Math.max(0, position);
        error = null;
        // صفحة المصحف قد تكون تتلو: نوقفها حتى لا يتداخل صوتان
        java.util.function.Consumer<String> web = MediaService.controller;
        if (web != null) web.accept("pause");
        Context app = c.getApplicationContext();
        Intent i = new Intent(app, PlayerService.class).setAction(ACT_START);
        if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i); else app.startService(i);
        notifyChanged();
    }

    static void command(Context c, String act) {
        if (instance == null) {
            if (ACT_TOGGLE.equals(act) && current() != null) play(c, new ArrayList<>(queue), index, posFor(current()));
            return;
        }
        instance.handle(act);
    }

    static void seek(long ms) {
        PlayerService s = instance;
        if (s == null || s.mp == null || preparing) { startAt = ms; return; }
        try { s.mp.seekTo((int) Math.max(0, ms)); } catch (Exception ignored) { }
        s.saveLast();
        s.updateSession();
        notifyChanged();
    }

    static void skip(long deltaMs) {
        long d = duration();
        long p = position() + deltaMs;
        seek(Math.max(0, d > 0 ? Math.min(d - 500, p) : p));
    }

    static void setSpeed(Context c, float f) {
        speed = f;
        App.prefs(c).edit().putFloat("listen_speed", f).apply();
        PlayerService s = instance;
        if (s != null) s.applySpeed();
        notifyChanged();
    }

    static void setRepeat(boolean on) { repeatOne = on; notifyChanged(); }

    /** مؤقت النوم بالدقائق؛ ٠ يلغيه؛ -١ نهاية السورة */
    static void setSleep(int minutes) {
        sleepEndOfTrack = minutes < 0;
        sleepAt = minutes > 0 ? System.currentTimeMillis() + minutes * 60_000L : 0;
        PlayerService s = instance;
        if (s != null) s.armSleep();
        notifyChanged();
    }

    /** إيقاف مؤقت من خارج المشغّل (صفحة المصحف بدأت تتلو) */
    static void pauseIfPlaying() {
        PlayerService s = instance;
        if (s != null && playing) s.pause();
    }

    /** آخر موضع معروف للمقطع نفسه فقط (للاستكمال بعد توقف الخدمة)؛ وإلا من البداية */
    private static volatile String memUrl;
    private static volatile long memMs;
    static long posFor(Track t) { return t != null && t.url != null && t.url.equals(memUrl) ? memMs : 0; }

    static long lastPos(Context c) {
        try { return new JSONObject(App.prefs(c).getString("listen_last", "{}")).optLong("pos", 0); }
        catch (Exception e) { return 0; }
    }

    // ------------------------------------------------------------------ الخدمة

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        speed = App.prefs(this).getFloat("listen_speed", 1f);
        audio = getSystemService(AudioManager.class);
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CHANNEL, "التحكم بالتلاوة", NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "hawl-player");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { handle(ACT_NEXT); }
            @Override public void onSkipToPrevious() { handle(ACT_PREV); }
            @Override public void onStop() { handle(ACT_STOP); }
            @Override public void onSeekTo(long pos) { seek(pos); }
            @Override public void onFastForward() { skip(15_000); }
            @Override public void onRewind() { skip(-15_000); }
        });
        session.setSessionActivity(PendingIntent.getActivity(this, 451,
                new Intent(this, PlayerActivity.class), PendingIntent.FLAG_IMMUTABLE));
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null && intent.getAction() != null ? intent.getAction() : ACT_START;
        if (ACT_START.equals(act)) startCurrent();      // يُظهر الإشعار فورًا (خدمة أمامية) ثم يبدأ التحميل
        else { if (current() == null) { showNotification(); stopAll(); return START_NOT_STICKY; } handle(act); }
        return START_NOT_STICKY;
    }

    void handle(String act) {
        switch (act) {
            case ACT_TOGGLE: if (playing) pause(); else resume(); break;
            case ACT_NEXT: if (hasNext()) { saveLast(); index++; startAt = 0; startCurrent(); } break;
            case ACT_PREV:
                if (position() > 5000 || !hasPrev()) seek(0);
                else { index--; startAt = 0; startCurrent(); }
                break;
            case ACT_STOP: stopAll(); break;
            default: break;
        }
    }

    private void startCurrent() {
        Track t = current();
        if (t == null) { showNotification(); stopAll(); return; }
        release();
        preparing = true;
        playing = false;
        error = null;
        mp = new MediaPlayer();
        mp.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
        mp.setWakeMode(getApplicationContext(), android.os.PowerManager.PARTIAL_WAKE_LOCK);
        try {
            File local = t.live ? null : Downloads.ready(this, t.url);
            if (local != null) mp.setDataSource(local.getAbsolutePath());
            else mp.setDataSource(t.url);
        } catch (Exception e) {
            fail("تعذّر فتح التلاوة");
            return;
        }
        final MediaPlayer me = mp;
        mp.setOnPreparedListener(p -> {
            if (p != mp) return;
            preparing = false;
            if (startAt > 0 && !t.live) { try { p.seekTo((int) startAt); } catch (Exception ignored) { } }
            startAt = 0;
            applySpeed();
            resume();
        });
        mp.setOnCompletionListener(p -> {
            if (p != mp) return;
            if (sleepEndOfTrack) { sleepEndOfTrack = false; pause(); seek(0); return; }
            if (repeatOne) { seek(0); resume(); return; }
            if (hasNext()) { index++; startAt = 0; startCurrent(); }
            else { playing = false; saveLast(); updateSession(); showNotification(); notifyChanged(); }
        });
        mp.setOnErrorListener((p, what, extra) -> {
            if (p != me) return true;
            fail(Downloads.ready(this, t.url) == null ? "تعذّر تشغيل التلاوة، تحقق من الاتصال بالإنترنت" : "تعذّر تشغيل الملف");
            return true;
        });
        mp.prepareAsync();
        updateSession();
        showNotification();
        notifyChanged();
    }

    private void fail(String msg) {
        preparing = false;
        playing = false;
        error = msg;
        release();
        updateSession();
        showNotification();
        notifyChanged();
    }

    private void resume() {
        if (mp == null) { if (current() != null) startCurrent(); return; }
        if (preparing) return;
        if (!requestFocus()) return;
        try { mp.start(); } catch (Exception e) { return; }
        playing = true;
        applySpeed();
        registerNoisy(true);
        armSleep();
        updateSession();
        showNotification();
        notifyChanged();
        tick();
    }

    private void pause() {
        try { if (mp != null && mp.isPlaying()) mp.pause(); } catch (Exception ignored) { }
        playing = false;
        registerNoisy(false);
        saveLast();
        updateSession();
        showNotification();
        notifyChanged();
    }

    private void applySpeed() {
        if (mp == null || preparing || Build.VERSION.SDK_INT < 23) return;
        Track t = current();
        if (t != null && t.live) return;
        try {
            boolean was = mp.isPlaying();
            PlaybackParams pp = mp.getPlaybackParams();
            mp.setPlaybackParams(pp.setSpeed(speed));
            if (!was) mp.pause();               // setPlaybackParams يبدأ التشغيل إن كان متوقفًا
        } catch (Exception ignored) { }
    }

    private final Runnable sleepCheck = () -> {
        if (sleepAt > 0 && System.currentTimeMillis() >= sleepAt) { sleepAt = 0; pause(); }
        else if (sleepAt > 0) armSleep();
    };

    private void armSleep() {
        main.removeCallbacks(sleepCheck);
        if (sleepAt > 0) main.postDelayed(sleepCheck, Math.min(30_000, Math.max(500, sleepAt - System.currentTimeMillis())));
    }

    /** حفظ الموضع كل ١٠ ث أثناء التشغيل */
    private final Runnable ticker = this::tick;
    private void tick() {
        main.removeCallbacks(ticker);
        if (!playing) return;
        saveLast();
        main.postDelayed(ticker, 10_000);
    }

    private void saveLast() {
        Track t = current();
        if (t != null && !t.live) { memUrl = t.url; memMs = position(); }
        if (t == null || t.live || t.reciterId == 0) return;
        try {
            JSONObject o = new JSONObject().put("reciter", t.reciterId).put("moshaf", t.moshafId).put("surah", t.surah)
                    .put("pos", position()).put("dur", duration()).put("name", t.reciter).put("at", System.currentTimeMillis());
            App.prefs(this).edit().putString("listen_last", o.toString()).apply();
        } catch (Exception ignored) { }
    }

    private boolean requestFocus() {
        if (audio == null) return true;
        if (Build.VERSION.SDK_INT >= 26) {
            if (focus == null) {
                focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setOnAudioFocusChangeListener(this::onFocus, main)
                        .build();
            }
            return audio.requestAudioFocus(focus) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return true;
    }

    private boolean pausedByFocus;
    private void onFocus(int change) {
        if (change == AudioManager.AUDIOFOCUS_LOSS) { pausedByFocus = false; pause(); }
        else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            if (playing) { pausedByFocus = true; pause(); }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && pausedByFocus) { pausedByFocus = false; resume(); }
    }

    private void registerNoisy(boolean on) {
        if (on && !noisyRegistered) {
            IntentFilter f = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(noisy, f);
            noisyRegistered = true;
        } else if (!on && noisyRegistered) {
            try { unregisterReceiver(noisy); } catch (Exception ignored) { }
            noisyRegistered = false;
        }
    }

    private void updateSession() {
        Track t = current();
        if (t == null || session == null) return;
        long dur = duration();
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.reciter == null ? "القرآن حول العالم" : t.reciter)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "القرآن حول العالم")
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
                .build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        if (!t.live) actions |= PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_FAST_FORWARD | PlaybackState.ACTION_REWIND;
        int st = preparing ? PlaybackState.STATE_BUFFERING : playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
                .setState(st, t.live ? PlaybackState.PLAYBACK_POSITION_UNKNOWN : position(), playing ? speed : 0f).build());
    }

    private PendingIntent action(String act, int req) {
        return PendingIntent.getService(this, req, new Intent(this, PlayerService.class).setAction(act),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void showNotification() {
        Track t = current();
        String title = t == null ? "تلاوة القرآن الكريم" : t.title;
        String sub = t == null ? "القرآن حول العالم" : (preparing ? "جارٍ التحميل…" : error != null ? error : t.reciter);
        Notification.Action prev = new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_prev),
                "السابق", action(ACT_PREV, 452)).build();
        Notification.Action toggle = new Notification.Action.Builder(
                Icon.createWithResource(this, playing ? R.drawable.ic_pause : R.drawable.ic_play),
                playing ? "إيقاف مؤقت" : "تشغيل", action(ACT_TOGGLE, 453)).build();
        Notification.Action next = new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_next),
                "التالي", action(ACT_NEXT, 454)).build();
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(getColor(R.color.gold_deep))
                .setContentTitle(title)
                .setContentText(sub)
                .setContentIntent(PendingIntent.getActivity(this, 455, new Intent(this, PlayerActivity.class),
                        PendingIntent.FLAG_IMMUTABLE))
                .setDeleteIntent(action(ACT_STOP, 456))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(playing || preparing)
                .addAction(prev).addAction(toggle).addAction(next)
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .build();
        try {
            if (playing || preparing || !everForeground) {
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                else startForeground(NOTE_ID, n);
                foreground = true;
                everForeground = true;
            }
            if (!playing && !preparing) {
                // متوقف مؤقتًا: يبقى الإشعار للاستكمال لكن الخدمة ليست أمامية (يمكن للنظام إيقافها)
                stopForeground(STOP_FOREGROUND_DETACH);
                foreground = false;
                getSystemService(NotificationManager.class).notify(NOTE_ID, n);
            }
        } catch (Exception e) {
            try { getSystemService(NotificationManager.class).notify(NOTE_ID, n); } catch (Exception ignored) { }
        }
    }

    private void release() {
        if (mp != null) {
            try { mp.reset(); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void stopAll() {
        saveLast();
        // إيقاف صريح من المستخدم: نفرغ القائمة فيختفي المشغّل المصغّر («تابع الاستماع» يبقى من listen_last)
        queue.clear();
        index = 0;
        memUrl = null;
        playing = false;
        preparing = false;
        release();
        registerNoisy(false);
        main.removeCallbacksAndMessages(null);
        if (audio != null && focus != null && Build.VERSION.SDK_INT >= 26) audio.abandonAudioFocusRequest(focus);
        sleepAt = 0;
        stopForeground(true);
        getSystemService(NotificationManager.class).cancel(NOTE_ID);
        stopSelf();
        notifyChanged();
    }

    @Override
    public void onDestroy() {
        instance = null;
        release();
        registerNoisy(false);
        main.removeCallbacksAndMessages(null);
        if (session != null) { session.setActive(false); session.release(); }
        playing = false;
        preparing = false;
        notifyChanged();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
