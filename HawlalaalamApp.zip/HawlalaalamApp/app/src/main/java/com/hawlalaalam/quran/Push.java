package com.hawlalaalam.quran;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;

/**
 * الإشعارات الفورية عبر Firebase Cloud Messaging.
 * يشترك كل جهاز في موضوع واحد (TOPIC)، وصفحة الإدارة في الموقع ترسل إليه.
 * لا يُرسل التطبيق أي بيانات عن المستخدم؛ Firebase يحتفظ بمعرّف تثبيت لإيصال الإشعار فقط.
 */
final class Push {
    static final String TOPIC = "all";

    private Push() { }

    static boolean configured(Context c) {
        return !c.getString(R.string.fcm_app_id).trim().isEmpty()
                && !c.getString(R.string.fcm_api_key).trim().isEmpty()
                && !c.getString(R.string.fcm_project_id).trim().isEmpty();
    }

    static void init(Context c) {
        try {
            if (!configured(c)) return;                 // لم يُضبط Firebase بعد: الطريقة العادية تكفي
            if (FirebaseApp.getApps(c).isEmpty()) {
                FirebaseOptions o = new FirebaseOptions.Builder()
                        .setProjectId(c.getString(R.string.fcm_project_id).trim())
                        .setGcmSenderId(c.getString(R.string.fcm_sender_id).trim())
                        .setApplicationId(c.getString(R.string.fcm_app_id).trim())
                        .setApiKey(c.getString(R.string.fcm_api_key).trim())
                        .build();
                FirebaseApp.initializeApp(c, o);
            }
            FirebaseMessaging.getInstance().subscribeToTopic(TOPIC);
        } catch (Throwable ignored) { }                 // لا يوقف التطبيق أبدًا
    }
}
