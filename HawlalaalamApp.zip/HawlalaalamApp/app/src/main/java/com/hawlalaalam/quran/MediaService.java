package com.hawlalaalam.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.function.Consumer;

/** التحكم بالتلاوة من الإشعار وشاشة القفل، ويُبقي الصوت يعمل في الخلفية */
public class MediaService extends Service {
    static final String ACT_UPDATE = "update", ACT_PLAY = "play", ACT_PAUSE = "pause", ACT_STOP = "stop";
    static final String EXTRA_TITLE = "title", EXTRA_PLAYING = "playing";
    private static final String CHANNEL = "media";

    /** يضبطه MainActivity لتمرير الأوامر إلى صفحة الويب */
    static volatile Consumer<String> controller;
    static volatile MediaService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private String title = "";
    private boolean playing;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CHANNEL, "التحكم بالتلاوة", NotificationManager.IMPORTANCE_LOW));
        session = new MediaSession(this, "hawlalaalam");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { send("play"); }
            @Override public void onPause() { send("pause"); }
            @Override public void onStop() { stopAll(); }
        });
        session.setSessionActivity(PendingIntent.getActivity(this, 401,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null && intent.getAction() != null ? intent.getAction() : ACT_UPDATE;
        switch (a) {
            case ACT_PLAY: send("play"); break;
            case ACT_PAUSE: send("pause"); break;
            case ACT_STOP: stopAll(); return START_NOT_STICKY;
            default:
                if (intent != null) onState(intent.getStringExtra(EXTRA_TITLE), intent.getBooleanExtra(EXTRA_PLAYING, true));
                else stopAll();
        }
        return START_NOT_STICKY;
    }

    /** تحديث الحالة من صفحة الويب */
    void onState(String t, boolean isPlaying) {
        if (t != null && !t.isEmpty()) title = t;
        playing = isPlaying;
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title.isEmpty() ? "تلاوة القرآن الكريم" : title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "حول العالم | القرآن الكريم")
                .build());
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? 1f : 0f)
                .build());
        showNotification();
    }

    private PendingIntent action(String act, int req) {
        return PendingIntent.getService(this, req, new Intent(this, MediaService.class).setAction(act),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void showNotification() {
        Notification.Action toggle = playing
                ? new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_pause), "إيقاف مؤقت", action(ACT_PAUSE, 402)).build()
                : new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_play), "تشغيل", action(ACT_PLAY, 403)).build();
        Notification.Action stop = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stop), "إنهاء", action(ACT_STOP, 404)).build();

        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(getColor(R.color.gold_deep))
                .setContentTitle(title.isEmpty() ? "تلاوة القرآن الكريم" : title)
                .setContentText("حول العالم | القرآن الكريم")
                .setContentIntent(PendingIntent.getActivity(this, 405,
                        new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE))
                .setDeleteIntent(action(ACT_STOP, 406))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(playing)
                .addAction(toggle)
                .addAction(stop)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(3, n);
            }
        } catch (Exception e) {
            getSystemService(NotificationManager.class).notify(3, n);
        }
    }

    private void send(String cmd) {
        Consumer<String> c = controller;
        if (c != null) main.post(() -> c.accept(cmd));
        else if (!"pause".equals(cmd)) stopAll();   // الصفحة لم تعد مفتوحة
    }

    @SuppressWarnings("deprecation")
    void stopAll() {
        send("pause");
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        instance = null;
        session.setActive(false);
        session.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
