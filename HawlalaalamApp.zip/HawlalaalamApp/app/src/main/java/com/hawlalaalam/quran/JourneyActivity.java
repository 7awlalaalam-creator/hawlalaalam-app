package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/**
 * «رحلتي»: سلسلة الأيام وأطولها، أيام القراءة في آخر ٣٠ يومًا، الختمات، والحفظ.
 * كل البيانات من الجهاز نفسه (نفس JourneyView في آيفون).
 */
public class JourneyActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));
    }

    private LinearLayout col;
    private int ink, muted, gold, goldL;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(14), dp(16), dp(28));
        scroll.addView(col);
        setContentView(scroll);
        Ui.applyInsets(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        col.removeAllViews();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = Ui.text(this, "رحلتي", 22, ink, 700);
        title.setPadding(dp(14), 0, dp(8), 0);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(head);

        // السلسلة
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(16), dp(18), dp(16));
        hero.setBackground(Ui.shape(getColor(R.color.dark), 22, 0, this));
        hero.addView(Ui.text(this, "سلسلتك الحالية", 13, goldL, 700));
        TextView big = Ui.text(this, streakText(Reading.streak(this)), 26, 0xFFFFFFFF, 700);
        big.setPadding(0, dp(4), 0, dp(4));
        hero.addView(big);
        hero.addView(Ui.text(this, "أطول سلسلة: " + streakText(bestStreak()), 13, getColor(R.color.on_dark_muted), 400));
        col.addView(hero, gap(14));

        // الأرقام
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -29);
        int readCount = 0;
        Calendar k = (Calendar) c.clone();
        for (int i = 0; i < 30; i++) { if (Reading.readOn(this, k)) readCount++; k.add(Calendar.DAY_OF_MONTH, 1); }
        int done = Khatma.completed(this);
        int hz = App.prefs(this).getInt("hifz_total", 0), held = App.prefs(this).getInt("hifz_held", 0),
                pct = App.prefs(this).getInt("hifz_pct", 0);
        LinearLayout stats = new LinearLayout(this);
        stats.addView(stat(Ui.arabicNum(readCount), "يومًا قرأت\nمن آخر ٣٠"), weight(0));
        stats.addView(stat(Ui.arabicNum(done), done == 1 ? "ختمة\nأتممتها" : "ختمات\nأتممتها"), weight(8));
        stats.addView(stat(Ui.arabicNum(hz), "آية\nفي حفظك"), weight(8));
        col.addView(stats, gap(10));
        col.addView(PrayerLog.journey(this), gap(14));

        // آخر ٣٠ يومًا
        LinearLayout cal = card();
        cal.addView(Ui.text(this, "آخر ٣٠ يومًا", 15, ink, 700));
        GridLayout g = new GridLayout(this);
        g.setColumnCount(7);
        g.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Calendar d = (Calendar) c.clone();
        for (int i = 0; i < 30; i++) {
            boolean on = Reading.readOn(this, d);
            TextView cell = Ui.text(this, Ui.arabicNum(d.get(Calendar.DAY_OF_MONTH)), 12, on ? getColor(R.color.dark) : muted, on ? 700 : 400);
            cell.setGravity(Gravity.CENTER);
            cell.setBackground(Ui.shape(on ? goldL : getColor(R.color.chip), 9, 0, this));
            cell.setContentDescription("يوم " + Ui.arabicNum(d.get(Calendar.DAY_OF_MONTH)) + (on ? "، قرأت" : "، لم تقرأ"));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(34);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            g.addView(cell, lp);
            d.add(Calendar.DAY_OF_MONTH, 1);
        }
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
        gl.topMargin = dp(10);
        cal.addView(g, gl);
        col.addView(cal, gap(14));

        // الحفظ
        if (hz > 0) {
            LinearLayout h = card();
            h.addView(Ui.text(this, "الحفظ", 15, ink, 700));
            TextView t = Ui.text(this, Ui.arabicNum(held) + " آية ثابتة من " + Ui.arabicNum(hz) + " · الإتقان " + Ui.arabicNum(pct) + "٪", 14, muted, 400);
            t.setPadding(0, dp(6), 0, dp(10));
            h.addView(t);
            android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(Math.max(1, hz));
            bar.setProgress(held);
            bar.setProgressTintList(android.content.res.ColorStateList.valueOf(goldL));
            h.addView(bar, new LinearLayout.LayoutParams(-1, dp(10)));
            TextView go = Ui.text(this, "راجع حفظك", 15, 0xFFFFFFFF, 700);
            go.setGravity(Gravity.CENTER);
            go.setBackground(Ui.shape(getColor(R.color.primary), 22, 0, this));
            go.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse(App.mushaf(this) + "&hifz=1"), this, MainActivity.class)
                    .putExtra(HomeActivity.EXTRA_FROM_HOME, true)));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(46));
            bl.topMargin = dp(12);
            h.addView(go, bl);
            col.addView(h, gap(14));
        }

        TextView foot = Ui.text(this, "كل هذا محفوظ على جهازك فقط.", 12, muted, 400);
        foot.setGravity(Gravity.CENTER_HORIZONTAL);
        foot.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        col.addView(foot, gap(16));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        return l;
    }

    private View stat(String n, String label) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(4), dp(14), dp(4), dp(14));
        l.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        TextView a = Ui.text(this, n, 24, ink, 700);
        a.setGravity(Gravity.CENTER);
        l.addView(a);
        TextView b = Ui.text(this, label, 12, muted, 400);
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        l.addView(b);
        return l;
    }

    private LinearLayout.LayoutParams weight(int start) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMarginStart(dp(start));
        return lp;
    }

    private String streakText(int n) {
        int r = n % 100;
        if (n == 0) return "لم تبدأ بعد";
        if (n == 1) return "يوم واحد";
        if (n == 2) return "يومان متتاليان";
        if (r >= 3 && r <= 10) return Ui.arabicNum(n) + " أيام متتالية";
        if (r >= 11) return Ui.arabicNum(n) + " يومًا متتاليًا";
        return Ui.arabicNum(n) + " يوم متتالٍ";
    }

    /** أطول سلسلة في السجل (حتى ٤٠٠ يوم) */
    private int bestStreak() {
        Calendar d = Calendar.getInstance();
        d.add(Calendar.DAY_OF_MONTH, -400);
        int best = 0, run = 0;
        for (int i = 0; i <= 400; i++) {
            if (Reading.readOn(this, d)) { run++; best = Math.max(best, run); } else run = 0;
            d.add(Calendar.DAY_OF_MONTH, 1);
        }
        return best;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
