package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** «النسخ والمزامنة»: النسخ التلقائي إلى Google Drive، وتصدير/استعادة ملف نسخة احتياطية (يُنقل بين أندرويد وآيفون) */
public class BackupActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private static final int REQ_EXPORT = 71, REQ_IMPORT = 72;
    private LinearLayout col;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, new ScrollView[1]);
        render();
    }

    private void render() {
        col.removeAllViews();
        int ink = getColor(R.color.ink), muted = getColor(R.color.muted);
        col.addView(Kit.header(this, L.t("النسخ والمزامنة"), L.t("بياناتك لك وحدك، لا حساب ولا خادم لنا"), null));

        LinearLayout c1 = Ui.card(this);
        TextView ic = Kit.badge(this, "▲", false);
        ic.setTextColor(0xFF2E8B4A);
        ic.setBackground(Ui.shape(0x1A2E8B4A, 23, 0, this));
        c1.addView(Kit.listRow(this, ic, L.t("نسخة احتياطية في Google Drive"),
                L.t("تلقائية من أندرويد إن كان «النسخ الاحتياطي» مفعّلًا في جوالك، وتعود بياناتك عند تغيير الجوال"), null));
        TextView how = Ui.text(this, L.t("للتأكد: الإعدادات ← Google ← النسخ الاحتياطي ← «نسخ احتياطي الآن»."), 13, muted, 400);
        how.setPadding(0, 0, 0, Ui.dp(this, 10));
        c1.addView(how);
        View sys = Ui.pill(this, R.drawable.ic_nav_settings, L.t("افتح إعدادات النسخ الاحتياطي"), false);
        sys.setOnClickListener(v -> openBackupSettings());
        c1.addView(Ui.minH(sys, 44), new LinearLayout.LayoutParams(-1, -2));
        TextView sp = new TextView(this);
        sp.setHeight(Ui.dp(this, 10));
        c1.addView(sp);
        col.addView(c1, Kit.gap(this, 12));

        LinearLayout c2 = Ui.card(this);
        c2.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        c2.addView(Ui.text(this, L.t("ما يُحفظ"), 15, ink, 700));
        TextView list = Ui.text(this, L.t("✓ الختمة والورد اليومي\n✓ العلامات وآخر موضع قراءة\n✓ الحفظ ومواعيد المراجعة والملاحظات\n")
                + L.t("✓ السلسلة وأيام القراءة\n✓ الإعدادات والتذكيرات والقرّاء المفضّلون وختمات العائلة"), 14, muted, 400);
        list.setLineSpacing(Ui.dp(this, 6), 1f);
        list.setPadding(0, Ui.dp(this, 8), 0, 0);
        c2.addView(list);
        TextView not = Ui.text(this, L.t("لا تُحفظ التلاوات المحمّلة (تُحمَّل من جديد عند الحاجة)."), 12, muted, 400);
        not.setPadding(0, Ui.dp(this, 8), 0, 0);
        c2.addView(not);
        col.addView(c2, Kit.gap(this, 12));

        View exp = Ui.pill(this, R.drawable.ic_cloud_up, L.t("تصدير نسخة احتياطية"), true);
        exp.setOnClickListener(v -> exportFile());
        col.addView(Ui.minH(exp, 48), Kit.gap(this, 14));
        View share = Ui.pill(this, R.drawable.ic_share, L.t("إرسال النسخة (واتساب، بريد، Drive…)"), false);
        share.setOnClickListener(v -> shareFile());
        col.addView(Ui.minH(share, 48), Kit.gap(this, 8));
        View imp = Ui.pill(this, R.drawable.ic_refresh, L.t("استعادة من ملف"), false);
        imp.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            try { startActivityForResult(i, REQ_IMPORT); } catch (Exception e) { toast(L.t("لا يوجد تطبيق ملفات لاختيار الملف")); }
        });
        col.addView(Ui.minH(imp, 48), Kit.gap(this, 8));

        long last = App.prefs(this).getLong("backup_last_export", 0);
        TextView lt = Ui.text(this, last > 0 ? L.t("آخر تصدير: ")
                + Adhan.arabic(new java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.US).format(new java.util.Date(last))) : "",
                12, muted, 400);
        lt.setGravity(Gravity.CENTER);
        lt.setPadding(0, Ui.dp(this, 12), 0, 0);
        col.addView(lt, new LinearLayout.LayoutParams(-1, -2));
        TextView cross = Ui.text(this, L.t("الملف نفسه يُستعاد في تطبيق آيفون أيضًا (علامات المصحف والحفظ والملاحظات)."), 12, muted, 400);
        cross.setGravity(Gravity.CENTER);
        cross.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(cross, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openBackupSettings() {
        String[] actions = {"android.settings.BACKUP_AND_RESET_SETTINGS", "android.settings.PRIVACY_SETTINGS",
                android.provider.Settings.ACTION_SETTINGS};
        for (String a : actions) {
            try { startActivity(new Intent(a)); return; } catch (Exception ignored) { }
        }
    }

    private void exportFile() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, Backup.fileName());
        try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { shareFile(); }
    }

    private void shareFile() {
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, Backup.fileName());
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
                out.write(Backup.exportJson(this).getBytes(StandardCharsets.UTF_8));
            }
            Uri uri = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent send = new Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_SUBJECT, L.t("نسخة احتياطية · القرآن حول العالم"))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newRawUri("", uri));
            startActivity(Intent.createChooser(send, L.t("احفظ النسخة الاحتياطية")));
            App.prefs(this).edit().putLong("backup_last_export", System.currentTimeMillis()).apply();
        } catch (Exception e) {
            toast(L.t("تعذّر إنشاء النسخة"));
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IllegalStateException();
                out.write(Backup.exportJson(this).getBytes(StandardCharsets.UTF_8));
                App.prefs(this).edit().putLong("backup_last_export", System.currentTimeMillis()).apply();
                toast(L.t("حُفظت النسخة الاحتياطية ✓"));
                render();
            } catch (Exception e) {
                toast(L.t("تعذّر حفظ الملف"));
            }
        } else if (req == REQ_IMPORT) {
            String json;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IllegalStateException();
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0 && b.size() < 5_000_000) b.write(buf, 0, n);
                json = b.toString("UTF-8");
            } catch (Exception e) {
                toast(L.t("تعذّر فتح الملف"));
                return;
            }
            Backup.Summary s;
            try { s = Backup.inspect(json); } catch (Exception e) { toast(L.t("هذا ليس ملف نسخة احتياطية من التطبيق")); return; }
            String when = s.at > 0 ? Adhan.arabic(new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.US).format(new java.util.Date(s.at))) : "";
            new AlertDialog.Builder(this, Ui.dialogTheme(this))
                    .setTitle(L.t("استعادة النسخة الاحتياطية؟"))
                    .setMessage(L.t("نسخة ") + ("ios".equals(s.platform) ? L.t("من آيفون") : L.t("من أندرويد")) + (when.isEmpty() ? "" : L.t(" بتاريخ ") + when)
                            + L.t(".\nستحل محل بيانات التطبيق الحالية على هذا الجوال."))
                    .setPositiveButton(L.t("استعادة"), (d, w) -> {
                        try {
                            Backup.restore(this, json);
                            toast(L.t("استُعيدت بياناتك ✓"));
                            startActivity(new Intent(this, HomeActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                            finish();
                        } catch (Exception e) {
                            toast(L.t("تعذّرت الاستعادة"));
                        }
                    })
                    .setNegativeButton(L.t("إلغاء"), null).show();
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
