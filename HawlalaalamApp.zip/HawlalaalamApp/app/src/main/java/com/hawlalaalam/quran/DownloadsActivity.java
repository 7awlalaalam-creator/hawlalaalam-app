package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** التلاوات المحمّلة للاستماع بدون إنترنت */
public class DownloadsActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    private LinearLayout col;
    private int ink, muted, gold, goldL;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean loading, again, resumed;
    private String lastSig;
    /** يقرأ حالة التحميلات في الخلفية (استعلام لكل ملف)، ثم يرسم مرة واحدة إن تغيّر شيء */
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!resumed || io.isShutdown()) return;
            if (loading) { again = true; return; }
            loading = true;
            final android.content.Context app = getApplicationContext();
            io.execute(() -> {
                List<Downloads.Item> all = Downloads.all(app);
                h.post(() -> {
                    loading = false;
                    if (!resumed || isDestroyed()) return;
                    if (again) { again = false; h.post(tick); return; }   // تغيّر شيء أثناء القراءة: نعيدها
                    StringBuilder sig = new StringBuilder();
                    boolean running = false;
                    for (Downloads.Item it : all) {
                        sig.append(it.url).append(it.status).append(':').append(it.percent).append(';');
                        if (it.status == Downloads.RUNNING) running = true;
                    }
                    if (!sig.toString().equals(lastSig)) { lastSig = sig.toString(); render(all); }
                    h.removeCallbacks(tick);
                    if (running) h.postDelayed(tick, 1500);
                });
            });
        }
    };

    private void refresh() { lastSig = null; h.removeCallbacks(tick); h.post(tick); }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(18), dp(14), dp(18), dp(32));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.addView(col);
        setContentView(scroll);
        Ui.applyInsets(scroll);
    }

    @Override protected void onResume() { super.onResume(); resumed = true; again = false; h.post(tick); }
    @Override protected void onPause() { super.onPause(); resumed = false; h.removeCallbacks(tick); }
    @Override protected void onDestroy() { super.onDestroy(); h.removeCallbacksAndMessages(null); io.shutdown(); }

    private void render(List<Downloads.Item> all) {
        col.removeAllViews();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = Ui.text(this, "التلاوات المحمّلة", 24, ink, 700);
        t.setPadding(dp(14), 0, dp(14), 0);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(head);

        int done = 0;
        for (Downloads.Item it : all) if (it.status == Downloads.DONE) done++;

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(16), dp(18), dp(16));
        hero.setBackground(Ui.shape(getColor(R.color.dark), 20, 0, this));
        hero.addView(Ui.iconTitle(this, R.drawable.ic_l_plane, "استمع في أي مكان", 17, 0xFFFFFFFF, 700, goldL));
        TextView sub = Ui.text(this, done == 0 ? "لا توجد تلاوات محمّلة بعد"
                : Adhan.arabic(String.valueOf(done)) + " تلاوة محمّلة · " + Downloads.mb(Downloads.totalBytes(all)), 14, getColor(R.color.on_dark_muted), 400);
        sub.setPadding(0, dp(6), 0, 0);
        hero.addView(sub);
        col.addView(hero, gap(14));

        if (all.isEmpty()) {
            TextView how = Ui.text(this, "افتح صفحة أي قارئ، واختر السورة، ثم اضغط «⬇ تحميل للاستماع بدون إنترنت» تحت المشغّل.", 15, ink, 400);
            how.setPadding(dp(16), dp(16), dp(16), dp(16));
            how.setBackground(Ui.shape(getColor(R.color.ivory), 16, getColor(R.color.ivory_border), this));
            col.addView(how, gap(16));
            TextView go = Ui.text(this, "تصفّح القرّاء", 15, 0xFFFFFFFF, 700);
            go.setGravity(Gravity.CENTER);
            go.setBackground(Ui.shape(getColor(R.color.primary), 25, 0, this));
            go.setOnClickListener(v -> startActivity(App.openInApp(this, App.HOME + "quran-reciters-ar.html")));
            col.addView(Ui.minH(go, 50), new LinearLayout.LayoutParams(-1, -2) {{ topMargin = dp(12); }});
            return;
        }

        LinearLayout list = Ui.card(this);
        list.setPadding(dp(14), dp(4), dp(14), dp(4));
        for (int i = 0; i < all.size(); i++) {
            if (i > 0) list.addView(Ui.divider(this));
            list.addView(row(all.get(i)));
        }
        col.addView(list, gap(16));
        TextView note = Ui.text(this, "يستمر الاستماع مع قفل الشاشة، وتتحكم به من الإشعار. والتلاوات المحمّلة تُشغَّل من جهازك حتى مع الإنترنت، توفيرًا لباقتك.", 13, muted, 400);
        note.setPadding(dp(4), dp(14), dp(4), 0);
        col.addView(note);
    }

    private View row(Downloads.Item it) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        android.widget.ImageView ic = Ui.icon(this, R.drawable.ic_l_headphones, gold, 22);
        ic.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        ic.setBackground(Ui.shape(getColor(R.color.chip), 12, 0, this));
        r.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(12), 0);
        texts.addView(Ui.text(this, it.title, 16, ink, 700));
        String meta = it.reciter + (it.size > 0 ? " · " + Downloads.mb(it.size) : "");
        TextView m = Ui.text(this, meta, 12, muted, 400);
        m.setPadding(0, dp(4), 0, 0);
        texts.addView(m);
        if (it.status == Downloads.RUNNING) {
            ProgressBar b = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            b.setMax(100);
            b.setProgress(it.percent);
            b.setProgressTintList(android.content.res.ColorStateList.valueOf(gold));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(8));
            bl.topMargin = dp(6);
            texts.addView(b, bl);
        }
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));

        if (it.status == Downloads.DONE) {
            TextView play = Ui.text(this, "▶ تشغيل", 13, 0xFFFFFFFF, 700);
            play.setGravity(Gravity.CENTER);
            play.setBackground(Ui.shape(getColor(R.color.primary), 18, 0, this));
            play.setPadding(dp(14), dp(4), dp(14), dp(4));
            play.setOnClickListener(v -> startActivity(App.openInApp(this, Downloads.playerUrl(it.url))));
            r.addView(Ui.minH(play, 36), new LinearLayout.LayoutParams(-2, -2));
        } else if (it.status == Downloads.RUNNING) {
            r.addView(Ui.text(this, Adhan.arabic(String.valueOf(it.percent)) + "٪", 13, gold, 700));
        } else {
            TextView retry = Ui.text(this, "إعادة", 13, gold, 700);
            retry.setOnClickListener(v -> { Downloads.delete(this, it.url); Downloads.start(this, it.url, it.title, it.reciter); refresh(); });
            r.addView(retry);
        }
        android.widget.ImageView del = Ui.icon(this, R.drawable.ic_l_close, muted, 18);
        del.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        del.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        del.setContentDescription("حذف " + it.title);
        del.setOnClickListener(v -> {
            AlertDialog d = new AlertDialog.Builder(this, Ui.dialogTheme(this))
                    .setTitle("حذف التلاوة؟")
                    .setMessage(it.title + " · " + it.reciter)
                    .setPositiveButton("حذف", (x, w) -> { Downloads.delete(this, it.url); refresh(); })
                    .setNegativeButton("إلغاء", null).create();
            d.show();
            if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        });
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(40), dp(40));
        dl.setMarginStart(dp(6));
        r.addView(del, dl);
        return r;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
