package com.hawlalaalam.quran;

import android.content.Context;

import java.util.Calendar;

/**
 * البطاقة الذكية في ويدجت المواقيت: سطر يتغيّر حسب الوقت واليوم والمناسبة.
 * الأولوية: رمضان ← ساعة الإجابة ← الجمعة ← أوقات اليوم (الشروق، الضحى، المساء، الثلث الأخير، الوتر).
 */
final class Smart {
    static final class Tip {
        final String text, url;
        /** متى تتغيّر البطاقة (لجدولة تحديث الويدجت) */
        final long until;
        Tip(String text, String url, long until) { this.text = text; this.url = url; this.until = until; }
    }

    private Smart() { }

    private static final long MIN = 60_000L;
    private static final String AZKAR = App.HOME + "azkar-morning-evening-ar.html";

    static Tip tip(Context c) {
        long now = System.currentTimeMillis();
        Calendar today = Calendar.getInstance();
        long[] t = Adhan.times(c, today);
        Calendar yesterday = (Calendar) today.clone();
        yesterday.add(Calendar.DAY_OF_MONTH, -1);
        Calendar tomorrow = (Calendar) today.clone();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);

        long fajr = t[PrayerCalc.FAJR], sunrise = t[PrayerCalc.SUNRISE], dhuhr = t[PrayerCalc.DHUHR];
        long asr = t[PrayerCalc.ASR], maghrib = t[PrayerCalc.MAGHRIB], isha = t[PrayerCalc.ISHA];
        long duha = sunrise + 15 * MIN;
        long midnight = startOfDay(tomorrow);

        // الليل الحالي: من مغرب أمس إلى فجر اليوم، أو من مغرب اليوم إلى فجر الغد
        long nightStart, nightEnd;
        if (now < fajr) { nightStart = Adhan.times(c, yesterday)[PrayerCalc.MAGHRIB]; nightEnd = fajr; }
        else { nightStart = maghrib; nightEnd = Adhan.times(c, tomorrow)[PrayerCalc.FAJR]; }
        long lastThird = nightEnd - (nightEnd - nightStart) / 3;

        int dow = today.get(Calendar.DAY_OF_WEEK);
        boolean friday = dow == Calendar.FRIDAY;

        // 1) رمضان: الإفطار والسحور
        if (Ramadan.active()) {
            if (now >= fajr && now < maghrib) {
                return new Tip("🌙 الإفطار " + Adhan.clock(maghrib) + " · «لِلصَّائِمِ فَرْحَتَانِ»",
                        Ramadan.tadabburUrl(), maghrib);
            }
            if (now >= lastThird && now < fajr) {
                return new Tip("🍽 وقت السحور · الإمساك قبل الفجر " + Adhan.clock(fajr) + " · «تسحّروا فإن في السحور بركة»",
                        App.HOME, fajr);
            }
        }

        // 2) يوم الجمعة
        if (friday && now >= asr && now < maghrib) {
            long lastHour = maghrib - 60 * MIN;
            String txt = now >= lastHour
                    ? "🤲 آخر ساعة من الجمعة الآن · ساعة إجابة، أكثِر من الدعاء"
                    : "🤲 ساعة الإجابة آخر ساعة بعد العصر · من " + Adhan.clock(lastHour);
            return new Tip(txt, App.HOME, now >= lastHour ? maghrib : lastHour);
        }
        if (friday && now >= fajr && now < asr) {
            return new Tip("📖 يوم الجمعة: سورة الكهف · وأكثِروا من الصلاة على النبي ﷺ",
                    App.HOME + "surah-18.html", asr);
        }

        // 3) أوقات اليوم
        if (now >= fajr && now < sunrise) {
            return new Tip("🌅 الشروق " + Adhan.clock(sunrise) + " · اجلس تذكر الله حتى تطلع الشمس", AZKAR, sunrise);
        }
        if (now >= sunrise && now < duha) {
            return new Tip("⏳ وقت نهي حتى ترتفع الشمس · يبدأ الضحى " + Adhan.clock(duha), AZKAR, duha);
        }
        if (now >= duha && now < dhuhr - 10 * MIN) {
            return new Tip("☀️ وقت الضحى الآن · ركعتان تجزئان عن صدقة ٣٦٠ مفصلًا", App.HOME, dhuhr - 10 * MIN);
        }
        if (now >= asr && now < maghrib) {
            return new Tip("🌇 أذكار المساء · المغرب " + Adhan.clock(maghrib), AZKAR, maghrib);
        }
        if (now >= maghrib && now < isha) {
            String[] fast = Fadl.fastTomorrow();
            if (fast != null) return new Tip("🌙 غدًا " + fast[0] + " · تذكّر النية والسحور", App.HOME, isha);
            return new Tip("📖 بين المغرب والعشاء · وقت طيّب لوردك اليومي", App.mushaf(c), isha);
        }
        if (now >= lastThird && now < fajr) {
            return new Tip("🌌 الثلث الأخير من الليل · «ينزل ربنا إلى السماء الدنيا… من يدعوني فأستجيب له»",
                    App.HOME, fajr);
        }
        if (now >= isha || now < fajr) {
            String[] fast = now >= isha ? Fadl.fastTomorrow() : Fadl.fastDay(today);
            long until = Math.min(lastThird, now >= isha ? midnight : lastThird);
            if (fast != null) {
                return new Tip("🌙 " + (now >= isha ? "غدًا " : "اليوم ") + fast[0] + " · تذكّر النية والسحور",
                        App.HOME, until);
            }
            return new Tip("🌙 الوتر قبل النوم · «اجعلوا آخر صلاتكم بالليل وترًا»", App.HOME, until);
        }

        // 4) بقية النهار: الورد
        long until = asr;
        if (Khatma.active(c) && !Khatma.done(c)) {
            int left = Khatma.todayRemaining(c);
            if (left > 0) {
                int page = Khatma.nextPage(c);
                return new Tip("📖 بقي " + Adhan.arabic(String.valueOf(left)) + " صفحات من وردك · اضغط للمتابعة",
                        Khatma.pageUrl(page), until);
            }
            if (!Khatma.readingToday(c)) return new Tip("🌿 يوم راحة من وردك · اقرأ إن شئت", App.mushaf(c), until);
            return new Tip("✅ أتممت ورد اليوم · بارك الله فيك", App.mushaf(c), until);
        }
        String[] fast = Fadl.fastDay(today);
        if (fast != null && now < maghrib) {
            return new Tip("🌙 اليوم " + fast[0] + " · الإفطار " + Adhan.clock(maghrib), App.HOME, maghrib);
        }
        return new Tip("📖 «أحب الأعمال إلى الله أدومها وإن قلّ» · افتح وردك", App.mushaf(c), until);
    }

    static long startOfDay(Calendar day) {
        Calendar x = (Calendar) day.clone();
        x.set(Calendar.HOUR_OF_DAY, 0);
        x.set(Calendar.MINUTE, 0);
        x.set(Calendar.SECOND, 5);
        x.set(Calendar.MILLISECOND, 0);
        return x.getTimeInMillis();
    }
}
