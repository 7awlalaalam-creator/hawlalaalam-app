package com.hawlalaalam.quran;

import android.content.Context;
import android.util.JsonReader;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * الأحاديث الصحيحة دون إنترنت: صحيح البخاري (ترقيم فتح الباري) وصحيح مسلم (ترقيم محمد فؤاد عبد الباقي).
 * الملفات في assets/hadith مضغوطة DEFLATE خام؛ تُقرأ مرة واحدة في خيط خلفي.
 */
final class Hadith {
    static final String BUKHARI = "bukhari", MUSLIM = "muslim";
    private static final String FAV = "hadith_fav";

    private Hadith() { }

    static final class Book {
        int id, count;
        String name;
    }

    static final class Collection {
        String key, title;
        List<Book> books = new ArrayList<>();
        int[] num, book;
        String[] isnad, matn, narrator;
        private String[] norm;                  // للبحث، يُبنى عند أول بحث

        int size() { return num.length; }

        int indexOf(int n) {
            int lo = 0, hi = num.length - 1;
            while (lo <= hi) {
                int mid = (lo + hi) >>> 1;
                if (num[mid] == n) return mid;
                if (num[mid] < n) lo = mid + 1; else hi = mid - 1;
            }
            return -1;
        }

        String bookName(int id) {
            for (Book b : books) if (b.id == id) return b.name;
            return "";
        }

        /** فهرس البحث (يُبنى في خيط التحميل حتى لا يتأخر أول بحث) */
        synchronized void prepareSearch() {
            if (norm != null) return;
            String[] n = new String[num.length];
            for (int i = 0; i < num.length; i++) n[i] = Kit.norm(matn[i] + " " + narrator[i]);
            norm = n;
        }

        /** نتائج البحث (أرقام مواضع)، حتى max نتيجة */
        synchronized List<Integer> search(String q, int max) {
            List<Integer> out = new ArrayList<>();
            String n = Kit.norm(q).trim();
            if (n.isEmpty()) return out;
            prepareSearch();
            String[] words = n.split("\\s+");
            for (int i = 0; i < num.length && out.size() < max; i++) {
                boolean all = true;
                for (String w : words) if (!norm[i].contains(w)) { all = false; break; }
                if (all) out.add(i);
            }
            return out;
        }
    }

    private static volatile Collection bukhari, muslim;
    private static volatile int[][] daily;

    static String title(String key) { return MUSLIM.equals(key) ? L.t("صحيح مسلم") : L.t("صحيح البخاري"); }

    /** من الذاكرة إن حُمّل، وإلا null (للعرض الفوري) */
    static Collection peek(String key) { return MUSLIM.equals(key) ? muslim : bukhari; }

    /** يُستدعى من خيط خلفي */
    static Collection load(Context c, String key) {
        Collection got = peek(key);
        if (got != null) return got;
        synchronized (Hadith.class) {
            got = peek(key);
            if (got != null) return got;
            try {
                got = read(c, key);
            } catch (Exception e) {
                return null;
            }
            got.prepareSearch();                     // فهرس البحث هنا، لا عند أول بحث
            if (MUSLIM.equals(key)) muslim = got; else bukhari = got;
            return got;
        }
    }

    private static Collection read(Context c, String key) throws Exception {
        Collection col = new Collection();
        col.key = key;
        List<int[]> nb = new ArrayList<>();
        List<String[]> txt = new ArrayList<>();
        Inflater inf = new Inflater(true);
        try (JsonReader r = new JsonReader(new InputStreamReader(new InflaterInputStream(
                c.getAssets().open("hadith/hadith-" + key + ".deflate"), inf, 65536), StandardCharsets.UTF_8))) {
            r.beginObject();
            while (r.hasNext()) {
                String name = r.nextName();
                if ("title".equals(name)) col.title = r.nextString();
                else if ("books".equals(name)) {
                    r.beginArray();
                    while (r.hasNext()) {
                        r.beginArray();
                        Book b = new Book();
                        b.id = r.nextInt();
                        b.name = r.nextString();
                        b.count = r.nextInt();
                        while (r.hasNext()) r.skipValue();
                        r.endArray();
                        col.books.add(b);
                    }
                    r.endArray();
                } else if ("h".equals(name)) {
                    r.beginArray();
                    while (r.hasNext()) {
                        r.beginArray();
                        int n = r.nextInt(), b = r.nextInt();
                        String is = r.nextString(), mt = r.nextString(), na = r.nextString();
                        while (r.hasNext()) r.skipValue();
                        r.endArray();
                        nb.add(new int[]{n, b});
                        txt.add(new String[]{is, mt, na});
                    }
                    r.endArray();
                } else r.skipValue();
            }
            r.endObject();
        } finally {
            inf.end();
        }
        int n = nb.size();
        col.num = new int[n]; col.book = new int[n];
        col.isnad = new String[n]; col.matn = new String[n]; col.narrator = new String[n];
        for (int i = 0; i < n; i++) {
            col.num[i] = nb.get(i)[0]; col.book[i] = nb.get(i)[1];
            col.isnad[i] = txt.get(i)[0]; col.matn[i] = txt.get(i)[1]; col.narrator[i] = txt.get(i)[2];
        }
        if (col.title == null) col.title = title(key);
        return col;
    }

    /** «حديث اليوم»: نفس الحديث طوال اليوم لكل المستخدمين — {0 للبخاري أو 1 لمسلم، رقم الحديث} */
    static int[] today(Context c) {
        int[][] d = daily;
        if (d == null) {
            try (java.io.InputStream in = c.getAssets().open("hadith/hadith-daily.json")) {
                java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int k;
                while ((k = in.read(buf)) > 0) b.write(buf, 0, k);
                org.json.JSONArray a = new org.json.JSONObject(new String(b.toByteArray(), StandardCharsets.UTF_8)).getJSONArray("daily");
                d = new int[a.length()][];
                for (int i = 0; i < a.length(); i++) {
                    org.json.JSONArray x = a.getJSONArray(i);
                    d[i] = new int[]{MUSLIM.equals(x.getString(0)) ? 1 : 0, x.getInt(1)};
                }
                daily = d;
            } catch (Exception e) {
                return new int[]{0, 1};
            }
        }
        if (d.length == 0) return new int[]{0, 1};
        Calendar cal = Calendar.getInstance();
        int day = cal.get(Calendar.YEAR) * 366 + cal.get(Calendar.DAY_OF_YEAR);
        return d[day % d.length];
    }

    static String keyOf(int which) { return which == 1 ? MUSLIM : BUKHARI; }

    // --- المفضلة
    static Set<String> favorites(Context c) {
        return new HashSet<>(App.prefs(c).getStringSet(FAV, new HashSet<>()));
    }

    static boolean isFav(Context c, String key, int n) { return favorites(c).contains(key + ":" + n); }

    static void toggleFav(Context c, String key, int n) {
        Set<String> s = favorites(c);
        String id = key + ":" + n;
        if (!s.remove(id)) s.add(id);
        App.prefs(c).edit().putStringSet(FAV, s).apply();
    }

    /** نص الحديث للمشاركة والنسخ */
    static String shareText(Collection col, int i, boolean withIsnad) {
        StringBuilder b = new StringBuilder();
        if (withIsnad && !col.isnad[i].isEmpty()) b.append(col.isnad[i]).append("\n\n");
        b.append(col.matn[i]);
        b.append("\n\n").append(col.title).append(L.t("، رقم ")).append(Ui.arabicNum(col.num[i]));
        String bk = col.bookName(col.book[i]);
        if (!bk.isEmpty()) b.append(" — ").append(bk);
        b.append(L.t("\nمن تطبيق «القرآن حول العالم»: https://7awlalaalam.com/app"));
        return b.toString();
    }
}
