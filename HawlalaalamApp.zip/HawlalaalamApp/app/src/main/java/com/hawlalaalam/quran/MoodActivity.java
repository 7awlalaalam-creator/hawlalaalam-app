package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

/** «آية لحالك»: تختار شعورك فتأتيك آية تواسيك، وتشاركها كصورة */
public class MoodActivity extends Activity {
    private int loadSeq;

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    static final String EXTRA_MOOD = "mood";

    /** {الرمز، الشعور، عنوان البطاقة، مراجع الآيات} */
    static final String[][] MOODS = {
            {"", "قلق", "حين يقلقك أمر", "13:28,65:3,9:51,2:286,3:173,20:46"},
            {"", "حزين", "حين يثقل الحزن قلبك", "9:40,93:3,12:86,94:6,2:155,3:139"},
            {"", "ضيق", "حين يضيق صدرك", "94:1,65:2,15:97,21:88,2:214,94:5"},
            {"", "خائف", "حين يغلبك الخوف", "20:46,3:175,9:51,41:30,28:31,10:62"},
            {"", "مذنب", "حين تثقلك ذنوبك", "39:53,4:110,3:135,25:70,11:114,66:8"},
            {"", "متعب", "حين يتعبك الطريق", "94:5,2:286,65:7,29:69,2:45,2:153"},
            {"", "وحيد", "حين تشعر بالوحدة", "2:186,50:16,58:7,57:4,20:46,2:152"},
            {"", "غاضب", "حين يشتد غضبك", "3:134,41:34,7:199,42:37,42:43,3:159"},
            {"", "ممتن", "حين يغمرك الامتنان", "14:7,10:58,2:152,16:18,93:11,55:13"},
    };

    /** أيقونة لكل شعور بنفس ترتيب MOODS */
    static final int[] ICONS = {R.drawable.ic_l_cloud, R.drawable.ic_l_drop, R.drawable.ic_l_wind, R.drawable.ic_l_shield,
            R.drawable.ic_l_return, R.drawable.ic_l_battery, R.drawable.ic_l_user, R.drawable.ic_l_flame, R.drawable.ic_l_spark};

    private LinearLayout col, result;
    private int mood = -1;
    private String lastRef = "";
    private String curText = "", curName = "", curRef = "";
    private int curS, curA;
    private int ink, muted, gold, goldL;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(18), dp(14), dp(18), dp(32));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.addView(col);
        setContentView(scroll);
        Ui.applyInsets(scroll);
        build();
        int m = getIntent().getIntExtra(EXTRA_MOOD, -1);
        if (m >= 0 && m < MOODS.length) pick(m);
    }

    private void build() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = Ui.text(this, "آية لحالك", 24, ink, 700);
        t.setPadding(dp(14), 0, dp(14), 0);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(head);

        TextView q = Ui.text(this, "كيف تشعر الآن؟", 20, ink, 700);
        q.setPadding(dp(4), dp(20), dp(4), dp(4));
        col.addView(q);
        TextView sub = Ui.text(this, "اختر شعورك، وتأتيك آية من كتاب الله تواسيك", 14, muted, 400);
        sub.setPadding(dp(4), 0, dp(4), dp(12));
        col.addView(sub);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < MOODS.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                if (i > 0) rl.topMargin = dp(8);
                grid.addView(row, rl);
            }
            final int idx = i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(0, dp(12), 0, dp(10));
            cell.setTag("mood" + i);
            cell.setBackground(Ui.shape(getColor(R.color.card), 16, getColor(R.color.line), this));
            cell.setContentDescription(MOODS[i][1]);
            cell.addView(Ui.icon(this, ICONS[i], gold, 28));
            TextView l = Ui.text(this, MOODS[i][1], 14, ink, 700);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, dp(8), 0, 0);
            cell.addView(l);
            cell.setOnClickListener(v -> pick(idx));
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i % 3 > 0) cl.setMarginStart(dp(8));
            row.addView(cell, cl);
        }
        col.addView(grid);

        result = new LinearLayout(this);
        result.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(18);
        col.addView(result, rlp);
    }

    private void pick(int m) {
        mood = m;
        for (int i = 0; i < MOODS.length; i++) {
            View cell = col.findViewWithTag("mood" + i);
            if (cell != null) cell.setBackground(i == m
                    ? Ui.shape(getColor(R.color.ivory), 16, gold, this)
                    : Ui.shape(getColor(R.color.card), 16, getColor(R.color.line), this));
        }
        load();
    }

    private void load() {
        String[] refs = MOODS[mood][3].split(",");
        String ref;
        Random r = new Random();
        do { ref = refs[r.nextInt(refs.length)]; } while (refs.length > 1 && ref.equals(lastRef));
        lastRef = ref;
        result.removeAllViews();
        TextView wait = Ui.text(this, "…", 22, muted, 400);
        wait.setGravity(Gravity.CENTER);
        wait.setPadding(0, dp(30), 0, dp(30));
        result.addView(wait);
        final String fRef = ref;
        final int token = ++loadSeq;                      // الضغط السريع: نعرض نتيجة آخر طلب فقط
        new Thread(() -> {
            String[] v = fetch(fRef);
            runOnUiThread(() -> { if (token == loadSeq && !isDestroyed()) show(fRef, v); });
        }).start();
    }

    /** {النص، اسم السورة} من المصحف المدمج (بدون إنترنت) */
    private String[] fetch(String ref) {
        try {
            String[] p = ref.split(":");
            int su = Integer.parseInt(p[0]), ay = Integer.parseInt(p[1]);
            String text = QuranText.verse(this, su, ay);
            return text == null ? null : new String[]{text, QuranText.surahName(su)};
        } catch (Exception e) {
            return null;
        }
    }

    private void show(String ref, String[] v) {
        result.removeAllViews();
        if (v == null) {
            TextView err = Ui.text(this, "تعذّر عرض الآية، حاول مرة أخرى.", 15, muted, 400);
            err.setGravity(Gravity.CENTER);
            err.setPadding(0, dp(20), 0, dp(20));
            result.addView(err);
            return;
        }
        String[] p = ref.split(":");
        curS = Integer.parseInt(p[0]);
        curA = Integer.parseInt(p[1]);
        curText = v[0];
        curName = v[1];
        curRef = ref;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(16));
        card.setBackground(Ui.shape(getColor(R.color.ivory), 22, getColor(R.color.ivory_border), this));
        TextView mt = Ui.text(this, MOODS[mood][2], 14, gold, 700);
        mt.setGravity(Gravity.CENTER);
        card.addView(mt);
        TextView ayah = new TextView(this);
        ayah.setText(QuranText.withNumber(curText, curA));
        ayah.setTypeface(QuranText.font(this));
        ayah.setTextSize(25);
        ayah.setTextColor(ink);
        ayah.setLineSpacing(0, 1.35f);
        ayah.setGravity(Gravity.CENTER);
        ayah.setPadding(0, dp(12), 0, dp(10));
        ayah.setTextIsSelectable(true);
        card.addView(ayah);
        TextView src = Ui.text(this, "سورة " + curName + " · الآية " + Adhan.arabic(String.valueOf(curA)), 13, muted, 400);
        src.setGravity(Gravity.CENTER);
        card.addView(src);
        result.addView(card);

        LinearLayout actions = new LinearLayout(this);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = dp(12);
        View share = Ui.pill(this, R.drawable.ic_image, "شارك كصورة", true);
        share.setOnClickListener(x -> shareImage());
        actions.addView(Ui.minH(share, 46), new LinearLayout.LayoutParams(0, -1, 1f));
        View another = Ui.pill(this, R.drawable.ic_refresh, "آية أخرى", false);
        another.setOnClickListener(x -> load());
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -1, 1f);
        l2.setMarginStart(dp(8));
        actions.addView(Ui.minH(another, 46), l2);
        result.addView(actions, alp);

        TextView tafsir = Ui.text(this, "اقرأ التفسير ←", 14, gold, 700);
        tafsir.setGravity(Gravity.CENTER);
        tafsir.setPadding(0, dp(14), 0, 0);
        tafsir.setOnClickListener(x -> startActivity(App.openInApp(this, App.HOME + "ayah-" + curS + "-" + curA + ".html")));
        result.addView(tafsir);
    }

    private Bitmap card() {
        int W = 1080, H = 1350;
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF16424A, 0xFF071A1E, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4);
        p.setColor(0xFFC9A876);
        cv.drawRoundRect(new RectF(40, 40, W - 40, H - 40), 48, 48, p);
        p.setStyle(Paint.Style.FILL);
        Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.app_logo_png);
        if (logo != null) cv.drawBitmap(Bitmap.createScaledBitmap(logo, 150, 150, true), (W - 150) / 2f, 100, p);
        float y = 290;
        y = draw(cv, MOODS[mood][2], 44, 0xFFC9A876, Ui.font(this, 700), y) + 50;
        int size = curText.length() > 160 ? 46 : curText.length() > 90 ? 56 : 64;
        StaticLayout ay = layout(QuranText.withNumber(curText, curA), size, 0xFFFFFFFF, QuranText.font(this), 1.45f);
        float avail = H - 330 - y;
        float ty = y + Math.max(0, (avail - ay.getHeight()) / 2f);
        cv.save(); cv.translate(70, ty); ay.draw(cv); cv.restore();
        draw(cv, "سورة " + curName + " · الآية " + Adhan.arabic(String.valueOf(curA)), 36, 0xFFE9DFC9, Ui.font(this, 500), ty + ay.getHeight() + 30);
        p.setColor(0x55C9A876);
        cv.drawRect(W / 2f - 90, H - 250, W / 2f + 90, H - 247, p);
        draw(cv, "آية لحالك · تطبيق «حول العالم | القرآن الكريم»", 34, 0xFFFFFFFF, Ui.font(this, 500), H - 220);
        draw(cv, "7awlalaalam.com/quran", 40, 0xFFC9A876, Ui.font(this, 700), H - 150);
        return b;
    }

    private StaticLayout layout(String s, int size, int color, android.graphics.Typeface tf, float spacing) {
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextSize(size);
        tp.setColor(color);
        tp.setTypeface(tf);
        return StaticLayout.Builder.obtain(s, 0, s.length(), tp, 940)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0, spacing).build();
    }

    private float draw(Canvas cv, String s, int size, int color, android.graphics.Typeface tf, float y) {
        StaticLayout l = layout(s, size, color, tf, 1.1f);
        cv.save(); cv.translate(70, y); l.draw(cv); cv.restore();
        return y + l.getHeight();
    }

    private void shareImage() {
        if (curText.isEmpty()) return;
        try {
            File dir = new File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "ayah-lihalak.png");
            try (FileOutputStream out = new FileOutputStream(f)) {
                card().compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            String msg = MOODS[mood][2] + " 🤍\n﴿ " + curText + " ﴾ [" + curName + ": " + curA + "]\n\n"
                    + "اختر شعورك واقرأ آية تواسيك في تطبيق «حول العالم | القرآن الكريم»:\n"
                    + "https://7awlalaalam.com/quran/?utm_source=app_share&utm_medium=mood";
            Intent send = new Intent(Intent.ACTION_SEND).setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_TEXT, msg)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newRawUri("", uri));
            startActivity(Intent.createChooser(send, "شارك الآية"));
        } catch (Exception e) {
            Toast.makeText(this, "تعذّرت المشاركة", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
