package com.hawlalaalam.quran;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** «القرآن حول العالم»: خريطة نقاط تضيء حيث يُقرأ القرآن اليوم (من المشاركين فقط، على مستوى الدولة) */
public class WorldMapActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private static final int BG = 0xFF0B1F24, CARD = 0xFF102A30, LINE = 0xFF1F3A41, LAND = 0xFF1F4048;
    private static final int GOLD = 0xFFC9A876, LIGHT = 0xFFE9D9B8, MUTED = 0xFFA9BABF;

    private LinearLayout col;
    private JSONObject data;
    private boolean failed;
    private MapView map;
    /** الفترة: now | today | 7 | 30 (الأخيرة افتراضية)، من pulse.php: زيارات الموقع + صفحات التطبيق لكل دولة */
    private String range = "30";
    private static final String[] RANGES = {"now", "today", "7", "30"};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
        ((View) col.getParent()).setBackgroundColor(BG);
        if (android.os.Build.VERSION.SDK_INT < 35) {   // أندرويد 15+: الأشرطة شفافة والخلفية تظهر خلفها
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        }
        // أيقونات شريط الحالة فاتحة على الخلفية الداكنة
        if (android.os.Build.VERSION.SDK_INT >= 30 && getWindow().getInsetsController() != null) {
            getWindow().getInsetsController().setSystemBarsAppearance(0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(0);
        }
        range = App.prefs(this).getString("st_world_r", "30");
        String cached = App.prefs(this).getString("st_world_cache_" + range, null);
        if (cached != null) try { data = new JSONObject(cached); } catch (Exception ignored) { }
        render();
        load();
    }

    @Override
    protected void onDestroy() {
        if (map != null) map.stop();
        super.onDestroy();
    }

    private void load() {
        Context app = getApplicationContext();
        new Thread(() -> {
            JSONObject j = null;
            final String r0 = range;
            try { Stats.sync(app); } catch (Exception ignored) { }
            try {
                j = pulse(r0);
                App.prefs(app).edit().putString("st_world_cache_" + r0, j.toString()).apply();
            } catch (Exception e) {
                // احتياط: خريطة المشاركين اليوم من stats-api
                try { if (!"now".equals(r0)) { j = Stats.world(); j.put("fallback", true); } } catch (Exception ignored) { }
            }
            final JSONObject r = j;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || !r0.equals(range)) return;
                failed = r == null;
                if (r != null) data = r;
                render();
            });
        }).start();
    }

    /** يحوّل pulse.php إلى { total, countries, now, top:[{cc,pages}] } مرتّبة تنازليًا */
    static JSONObject pulse(String r) throws Exception {
        JSONObject p = new JSONObject(App.get(App.HOME + "api/v1/pulse.php?r=" + r, 256 * 1024));
        JSONArray cs = p.optJSONArray("countries");
        java.util.ArrayList<JSONObject> l = new java.util.ArrayList<>();
        int total = 0;
        if (cs != null) for (int i = 0; i < cs.length(); i++) {
            JSONObject o = cs.optJSONObject(i);
            if (o == null || o.optString("cc").length() != 2) continue;
            int v = o.optInt("site") + o.optInt("app");
            if (v <= 0) continue;
            total += v;
            l.add(new JSONObject().put("cc", o.optString("cc").toUpperCase(java.util.Locale.ROOT)).put("pages", v));
        }
        java.util.Collections.sort(l, (a, b) -> b.optInt("pages") - a.optInt("pages"));
        JSONArray top = new JSONArray();
        for (JSONObject o : l) top.put(o);
        return new JSONObject().put("total", total).put("countries", l.size()).put("now", p.optInt("now")).put("top", top).put("range", r);
    }

    /** علم الدولة من رمزها (حرفان) */
    static String flag(String cc) {
        if (cc == null || cc.length() != 2) return "";
        cc = cc.toUpperCase(java.util.Locale.ROOT);
        return new String(Character.toChars(0x1F1E6 + cc.charAt(0) - 'A')) + new String(Character.toChars(0x1F1E6 + cc.charAt(1) - 'A'));
    }

    private String rangeLabel(String r) {
        switch (r) {
            case "now": return L.t("الآن");
            case "today": return L.t("اليوم");
            case "7": return L.t("٧ أيام");
            default: return L.t("٣٠ يومًا");
        }
    }

    private View rangeBar() {
        LinearLayout seg = new LinearLayout(this);
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(Ui.shape(CARD, 14, LINE, this));
        for (int i = 0; i < RANGES.length; i++) {
            String r = RANGES[i];
            boolean on = r.equals(range);
            TextView t = Ui.text(this, rangeLabel(r), 13, on ? 0xFF0E2C31 : MUTED, on ? 700 : 500);
            t.setGravity(Gravity.CENTER);
            t.setMaxLines(1);
            t.setPadding(dp(4), dp(8), dp(4), dp(8));
            if (on) t.setBackground(Ui.shape(GOLD, 11, 0, this));
            t.setSelected(on);
            t.setContentDescription(rangeLabel(r) + (on ? L.t("، محدد") : ""));
            t.setOnClickListener(v -> {
                if (r.equals(range)) return;
                range = r;
                App.prefs(this).edit().putString("st_world_r", r).apply();
                data = null; failed = false;
                String c = App.prefs(this).getString("st_world_cache_" + r, null);
                if (c != null) try { data = new JSONObject(c); } catch (Exception ignored) { }
                render();
                load();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(dp(4));
            seg.addView(t, lp);
        }
        return seg;
    }

    private void render() {
        if (map != null) map.stop();
        col.removeAllViews();

        // ترويسة داكنة
        LinearLayout head = Kit.header(this, L.t("القرآن حول العالم"), null, null);
        TextView title = findTitle(head);
        if (title != null) title.setTextColor(0xFFFFFFFF);
        View back = head.getChildAt(0);
        back.setBackground(Ui.shape(CARD, 22, LINE, this));
        ((android.widget.ImageButton) back).setColorFilter(0xFFFFFFFF);
        TextView live = Ui.text(this, rangeLabel(range), 11, 0xFF0E2C31, 700);
        live.setBackground(Ui.shape(GOLD, 8, 0, this));
        live.setPadding(dp(8), dp(2), dp(8), dp(2));
        head.addView(live);
        col.addView(head);

        col.addView(rangeBar(), Kit.gap(this, 10));
        boolean fb = data != null && data.optBoolean("fallback");
        boolean isNow = "now".equals(range);
        int total = data == null ? 0 : (isNow && !fb ? data.optInt("now") : data.optInt("total"));
        int countries = data == null ? 0 : data.optInt("countries");
        String cap = fb ? L.t("صفحات قرأها المشاركون اليوم")
                : isNow ? L.t("يقرؤون القرآن الآن (آخر ٥ دقائق)")
                : "today".equals(range) ? L.t("قراءات اليوم في الموقع والتطبيق")
                : "7".equals(range) ? L.t("قراءات آخر ٧ أيام في الموقع والتطبيق")
                : L.t("قراءات آخر ٣٠ يومًا في الموقع والتطبيق");
        TextView l1 = center(Ui.text(this, cap, 13, MUTED, 400));
        col.addView(l1, Kit.gap(this, 10));
        TextView big = center(Ui.text(this, data == null ? (failed ? "—" : "…") : ImpactActivity.num(total), 44, LIGHT, 700));
        col.addView(big);
        TextView l2 = center(Ui.text(this, countries > 0 ? L.t("في ") + Ui.arabicNum(countries) + (countries <= 10 ? L.t(" دول") : L.t(" دولة"))
                : failed ? L.t("تعذّر الاتصال الآن") : L.t("تضيء الخريطة كلما قرأ المشاركون"), 12, MUTED, 400));
        col.addView(l2);
        int nowN = data == null ? 0 : data.optInt("now");
        if (!isNow && nowN > 0) {
            TextView nl = center(Ui.text(this, "● " + L.t("يقرأ الآن ") + Ui.arabicNum(nowN), 12, GOLD, 700));
            col.addView(nl, Kit.gap(this, 4));
        }

        map = new MapView(this, data == null ? null : data.optJSONArray("top"));
        map.setBackground(Ui.shape(CARD, 18, LINE, this));
        map.setContentDescription(L.t("خريطة نقاط تضيء حيث يُقرأ القرآن"));
        LinearLayout.LayoutParams ml = Kit.gap(this, 14);
        ml.height = dp(190);
        col.addView(map, ml);

        // أعلى الدول
        JSONArray top = data == null ? null : data.optJSONArray("top");
        if (top != null && top.length() > 0) {
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(14), dp(4), dp(14), dp(4));
            list.setBackground(Ui.shape(CARD, 18, LINE, this));
            int n = Math.min(10, top.length());
            for (int i = 0; i < n; i++) {
                JSONObject o = top.optJSONObject(i);
                if (o == null) continue;
                if (i > 0) {
                    View d = new View(this);
                    d.setBackgroundColor(LINE);
                    list.addView(d, new LinearLayout.LayoutParams(-1, 1));
                }
                LinearLayout r = new LinearLayout(this);
                r.setPadding(0, dp(11), 0, dp(11));
                r.addView(Ui.text(this, Ui.arabicNum(i + 1) + "  " + flag(o.optString("cc")) + "  " + Stats.countryName(o.optString("cc")), 14, 0xFFFFFFFF, 700), new LinearLayout.LayoutParams(0, -2, 1f));
                r.addView(Ui.text(this, Ui.arabicNum(o.optInt("pages")) + (fb ? L.t(" صفحة") : L.t(" قراءة")), 14, LIGHT, 700));
                list.addView(r);
            }
            col.addView(list, Kit.gap(this, 14));
        }

        // الموافقة
        LinearLayout opt = new LinearLayout(this);
        opt.setGravity(Gravity.CENTER_VERTICAL);
        opt.setPadding(dp(14), dp(12), dp(14), dp(12));
        opt.setBackground(Ui.shape(0x0FFFFFFF, 16, 0, this));
        LinearLayout ot = new LinearLayout(this);
        ot.setOrientation(LinearLayout.VERTICAL);
        ot.addView(Ui.text(this, L.t("أضِف قراءتي للخريطة"), 14, 0xFFFFFFFF, 700));
        String cc = Stats.country(this);
        TextView os = Ui.text(this, L.t("يُرسل عدد الصفحات واسم الدولة") + (cc.isEmpty() ? "" : " (" + Stats.countryName(cc) + ")")
                + L.t(" فقط، بلا موقع دقيق ولا أي معرّف"), 11, MUTED, 400);
        os.setLineSpacing(dp(3), 1f);
        os.setPadding(0, dp(2), dp(8), 0);
        ot.addView(os);
        opt.addView(ot, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = Ui.toggle(this);
        // مسار المفتاح الافتراضي داكن فلا يظهر على خلفية الخريطة
        sw.setTrackTintList(new android.content.res.ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0x99C9A876, 0xFF3A555C}));
        sw.setChecked(Stats.mapOn(this));
        sw.setContentDescription(L.t("أضف قراءتي للخريطة"));
        sw.setOnCheckedChangeListener((b, on) -> {
            Stats.setMapOn(this, on);
            if (on) load();
        });
        opt.addView(sw);
        col.addView(opt, Kit.gap(this, 12));
        if (Stats.mapOn(this)) {
            TextView mine = Ui.text(this, Stats.today(this) == 0 ? L.t("لم تقرأ اليوم بعد: اقرأ ولو صفحة لتضيء بها دولتك") : L.t("قرأت اليوم ") + Ui.arabicNum(Stats.today(this)) + L.t(" صفحة"), 12, GOLD, 700);
            mine.setPadding(dp(4), 0, dp(4), 0);
            col.addView(mine, Kit.gap(this, 8));
        }
    }

    private static TextView findTitle(LinearLayout head) {
        for (int i = 0; i < head.getChildCount(); i++) {
            View v = head.getChildAt(i);
            if (v instanceof LinearLayout && ((LinearLayout) v).getChildCount() > 0 && ((LinearLayout) v).getChildAt(0) instanceof TextView)
                return (TextView) ((LinearLayout) v).getChildAt(0);
        }
        return null;
    }

    private TextView center(TextView t) { t.setGravity(Gravity.CENTER); return t; }

    private int dp(int v) { return Ui.dp(this, v); }

    /** خريطة نقطية (إسقاط متساوي المسافات) من assets/world-map.json، ونقاط مضيئة على مراكز الدول */
    static final class MapView extends View {
        private int w, h;
        private boolean[][] land;
        private JSONObject centers;
        private final float[][] dots;       // x, y (بوحدات الشبكة), حجم نسبي
        private final Paint landP = new Paint(Paint.ANTI_ALIAS_FLAG), dotP = new Paint(Paint.ANTI_ALIAS_FLAG),
                glowP = new Paint(Paint.ANTI_ALIAS_FLAG), ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private ValueAnimator anim;
        private float phase;

        MapView(Context c, JSONArray top) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);   // لظل التوهج
            readMap(c);
            landP.setColor(LAND);
            dotP.setColor(0xFFF3D9A4);
            glowP.setColor(LIGHT);
            glowP.setShadowLayer(Ui.dp(c, 8), 0, 0, GOLD);
            ringP.setStyle(Paint.Style.STROKE);
            ringP.setStrokeWidth(Ui.dp(c, 1));
            int n = top == null ? 0 : Math.min(40, top.length());
            int max = 1;
            for (int i = 0; i < n; i++) { JSONObject o = top.optJSONObject(i); if (o != null) max = Math.max(max, o.optInt("pages")); }
            java.util.ArrayList<float[]> l = new java.util.ArrayList<>();
            for (int i = 0; i < n; i++) {
                JSONObject o = top.optJSONObject(i);
                JSONArray p = o == null || centers == null ? null : centers.optJSONArray(o.optString("cc"));
                if (p == null) continue;
                float s = (float) Math.sqrt(o.optInt("pages") / (double) max);
                l.add(new float[]{(float) p.optDouble(0), (float) p.optDouble(1), Math.max(0.35f, s)});
            }
            dots = l.toArray(new float[0][]);
            if (dots.length > 0) {
                anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(2000);
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.setInterpolator(new LinearInterpolator());
                anim.addUpdateListener(a -> { phase = (float) a.getAnimatedValue(); invalidate(); });
                anim.start();
            }
        }

        void stop() { if (anim != null) anim.cancel(); }

        @Override
        protected void onDetachedFromWindow() { stop(); super.onDetachedFromWindow(); }

        private void readMap(Context c) {
            try (InputStream in = c.getAssets().open("world-map.json")) {
                java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int k;
                while ((k = in.read(b)) > 0) o.write(b, 0, k);
                JSONObject j = new JSONObject(o.toString(StandardCharsets.UTF_8.name()));
                w = j.getInt("w"); h = j.getInt("h");
                JSONArray rows = j.getJSONArray("rows");
                land = new boolean[h][w];
                for (int y = 0; y < h; y++) {
                    String r = rows.getString(y);
                    for (int x = 0; x < w; x++) {
                        int nib = Character.digit(r.charAt(x / 4), 16);
                        land[y][x] = (nib & (8 >> (x % 4))) != 0;
                    }
                }
                centers = j.getJSONObject("c");
            } catch (Exception e) {
                land = null;
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            if (land == null) return;
            float pad = Ui.dp(getContext(), 10);
            float cw = (getWidth() - 2 * pad) / w, ch = (getHeight() - 2 * pad) / h;
            float cell = Math.min(cw, ch);
            float ox = (getWidth() - cell * w) / 2f, oy = (getHeight() - cell * h) / 2f;
            float r = cell * 0.32f;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    if (land[y][x]) cv.drawCircle(ox + (x + .5f) * cell, oy + (y + .5f) * cell, r, landP);
            for (int i = 0; i < dots.length; i++) {
                float[] d = dots[i];
                float x = ox + d[0] * cell, y = oy + d[1] * cell;
                float size = cell * (0.7f + 1.1f * d[2]);
                if (i < 3) {
                    float ph = (phase + i * 0.33f) % 1f;
                    ringP.setColor(0xF3D9A4 | ((int) (200 * (1 - ph)) << 24));
                    cv.drawCircle(x, y, size * (1 + 2f * ph), ringP);
                }
                cv.drawCircle(x, y, size, glowP);
                cv.drawCircle(x, y, size * 0.55f, dotP);
            }
        }
    }
}
