package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * «الأحاديث الصحيحة»: حديث اليوم، وصحيح البخاري وصحيح مسلم مرتّبَين بالكتب، والبحث، والمفضلة.
 * الشاشة نفسها تعرض قائمة كتاب واحد حين تُفتح بـ book.
 */
public class HadithActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    static Intent book(Context c, String key, int book) {
        return new Intent(c, HadithActivity.class).putExtra("key", key).putExtra("book", book);
    }

    private static final int PAGE = 40;
    private LinearLayout col;
    private String key = Hadith.BUKHARI;
    private int book = -1;                 // -1: الشاشة الرئيسية
    private int tab;                       // ٠ البخاري، ١ مسلم، ٢ المفضلة
    private int shown = PAGE;
    private String query = "";
    private Typeface amiri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        key = getIntent().getStringExtra("key") == null ? Hadith.BUKHARI : getIntent().getStringExtra("key");
        book = getIntent().getIntExtra("book", -1);
        tab = Hadith.MUSLIM.equals(key) ? 1 : 0;
        if (state != null) { tab = state.getInt("tab", tab); query = state.getString("q", ""); }
        try { amiri = getResources().getFont(R.font.amiri_quran); } catch (Exception e) { amiri = Ui.font(this, 400); }
        col = Kit.scrollPage(this, null);
        render();
        Context app = getApplicationContext();
        new Thread(() -> {
            Hadith.load(app, Hadith.BUKHARI);
            Hadith.load(app, Hadith.MUSLIM);
            runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) render(); });
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tab == 2) render();              // المفضلة قد تتغير من شاشة الحديث
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", tab);
        out.putString("q", query);
    }

    private void render() {
        col.removeAllViews();
        if (book >= 0) { renderBook(); return; }
        col.addView(Kit.header(this, L.t("الأحاديث الصحيحة"), L.t("صحيح البخاري وصحيح مسلم"), null));
        col.addView(daily(), Kit.gap(this, 6));
        col.addView(Kit.segments(this, new String[]{L.t("صحيح البخاري"), L.t("صحيح مسلم"), L.t("المفضلة")}, tab, i -> {
            tab = i; shown = PAGE; render();
        }), Kit.gap(this, 14));
        if (tab < 2) col.addView(searchBox(), Kit.gap(this, 10));

        Hadith.Collection c = Hadith.peek(tab == 1 ? Hadith.MUSLIM : Hadith.BUKHARI);
        if (tab == 2) { renderFavorites(); return; }
        if (c == null) { col.addView(loadingText(), Kit.gap(this, 30)); return; }

        if (!query.isEmpty()) {
            List<Integer> res = c.search(query, 300);
            col.addView(Ui.text(this, res.isEmpty() ? L.t("لا نتائج لـ«") + query + "»"
                    : Ui.arabicNum(res.size()) + (res.size() >= 300 ? "+" : "") + L.t(" نتيجة"), 13, getColor(R.color.muted), 500), Kit.gap(this, 12));
            addItems(c, res);
            return;
        }
        col.addView(Kit.section(this, L.t("الكتب")), Kit.gap(this, 18));
        LinearLayout card = Ui.card(this);
        boolean firstRow = true;
        for (Hadith.Book b : c.books) {
            if (!firstRow) card.addView(Ui.divider(this));
            firstRow = false;
            TextView chev = Ui.text(this, Ui.arabicNum(b.count), 12, getColor(R.color.muted), 500);
            LinearLayout r = Kit.listRow(this, null, b.name, null, chev);
            r.setContentDescription(b.name + L.t("، ") + Ui.arabicNum(b.count) + L.t(" حديث"));
            final int id = b.id;
            r.setOnClickListener(v -> startActivity(book(this, c.key, id)));
            card.addView(r);
        }
        col.addView(card, Kit.gap(this, 6));
        TextView src = Ui.text(this, L.t("البخاري بترقيم فتح الباري، ومسلم بترقيم محمد فؤاد عبد الباقي · يعمل دون إنترنت"), 11, getColor(R.color.muted), 400);
        src.setGravity(Gravity.CENTER);
        src.setPadding(0, dp(12), 0, 0);
        col.addView(src, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderBook() {
        Hadith.Collection c = Hadith.peek(key);
        String title = c == null ? Hadith.title(key) : c.bookName(book);
        col.addView(Kit.header(this, title.isEmpty() ? Hadith.title(key) : title, Hadith.title(key), null));
        if (c == null) { col.addView(loadingText(), Kit.gap(this, 30)); return; }
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < c.size(); i++) if (c.book[i] == book) idx.add(i);
        addItems(c, idx);
    }

    private void renderFavorites() {
        List<String> favs = new ArrayList<>(Hadith.favorites(this));
        java.util.Collections.sort(favs);
        if (favs.isEmpty()) {
            TextView t = Ui.text(this, L.t("لم تحفظ أحاديث بعد.\nاضغط «حفظ» في أي حديث ليظهر هنا."), 15, getColor(R.color.muted), 400);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(40), 0, 0);
            col.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (String f : favs) {
            String[] p = f.split(":");
            if (p.length != 2) continue;
            Hadith.Collection c = Hadith.peek(p[0]);
            if (c == null) { col.addView(loadingText(), Kit.gap(this, 30)); return; }
            int i;
            try { i = c.indexOf(Integer.parseInt(p[1])); } catch (Exception e) { continue; }
            if (i >= 0) col.addView(item(c, i), Kit.gap(this, 8));
        }
    }

    private void addItems(Hadith.Collection c, List<Integer> idx) {
        int end = Math.min(idx.size(), shown);
        for (int k = 0; k < end; k++) col.addView(item(c, idx.get(k)), Kit.gap(this, 8));
        if (idx.size() > end) {
            View more = Ui.pill(this, R.drawable.ic_chevron, L.t("عرض المزيد (") + Ui.arabicNum(idx.size() - end) + ")", false);
            more.setOnClickListener(v -> { shown += PAGE * 2; render(); });
            col.addView(Ui.minH(more, 46), Kit.gap(this, 12));
        }
    }

    private View item(Hadith.Collection c, int i) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        r.setBackground(Ui.shape(getColor(R.color.card), 16, getColor(R.color.line), this));
        TextView m = Ui.text(this, c.matn[i], 18, getColor(R.color.ink), 400);
        m.setTypeface(amiri);
        m.setMaxLines(4);
        m.setEllipsize(TextUtils.TruncateAt.END);
        m.setLineSpacing(dp(4), 1f);
        r.addView(m);
        String who = c.narrator[i].isEmpty() ? "" : L.t("عن ") + c.narrator[i] + " · ";
        TextView meta = Ui.text(this, who + (Hadith.MUSLIM.equals(c.key) ? L.t("مسلم ") : L.t("البخاري ")) + Ui.arabicNum(c.num[i]),
                12, getColor(R.color.gold_deep), 700);
        meta.setPadding(0, dp(6), 0, 0);
        r.addView(meta);
        r.setContentDescription(c.matn[i] + L.t("، ") + who + Hadith.title(c.key) + " " + Ui.arabicNum(c.num[i]));
        r.setOnClickListener(v -> startActivity(HadithDetailActivity.intent(this, c.key, c.num[i])));
        return r;
    }

    private View daily() {
        int[] d = Hadith.today(this);
        String k = Hadith.keyOf(d[0]);
        Hadith.Collection c = Hadith.peek(k);
        LinearLayout h = Kit.hero(this);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView lbl = Ui.text(this, L.t("حديث اليوم"), 12, getColor(R.color.gold), 700);
        h.addView(lbl);
        int i = c == null ? -1 : c.indexOf(d[1]);
        TextView m = Ui.text(this, i < 0 ? "…" : c.matn[i], 20, 0xFFFFFFFF, 400);
        m.setTypeface(amiri);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(dp(6), 1f);
        m.setPadding(0, dp(8), 0, dp(8));
        h.addView(m, new LinearLayout.LayoutParams(-1, -2));
        if (i >= 0) {
            String who = c.narrator[i].isEmpty() ? "" : L.t("عن ") + c.narrator[i] + " · ";
            TextView s = Ui.text(this, who + Hadith.title(k) + " " + Ui.arabicNum(c.num[i]), 12, getColor(R.color.on_dark_muted), 400);
            s.setGravity(Gravity.CENTER);
            h.addView(s, new LinearLayout.LayoutParams(-1, -2));
            h.setOnClickListener(v -> startActivity(HadithDetailActivity.intent(this, k, d[1])));
        }
        return h;
    }

    private View searchBox() {
        EditText e = new EditText(this);
        e.setHint(L.t("ابحث في ") + (tab == 1 ? L.t("صحيح مسلم") : L.t("صحيح البخاري")) + "…");
        e.setText(query);
        e.setSingleLine(true);
        e.setTypeface(Ui.font(this, 400));
        e.setTextSize(15);
        e.setTextColor(getColor(R.color.ink));
        e.setHintTextColor(getColor(R.color.muted));
        e.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        e.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.field_border), this));
        e.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                query = v.getText().toString().trim();
                shown = PAGE;
                InputMethodManager im = getSystemService(InputMethodManager.class);
                if (im != null) im.hideSoftInputFromWindow(v.getWindowToken(), 0);
                render();
                return true;
            }
            return false;
        });
        return Ui.minH(e, 48);
    }

    private TextView loadingText() {
        TextView t = Ui.text(this, L.t("جارٍ فتح الأحاديث…"), 15, getColor(R.color.muted), 400);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
