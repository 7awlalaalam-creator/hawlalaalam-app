package com.hawlalaalam.quran;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** يخدم التلاوات المحمّلة من الجهاز بدل الإنترنت، ومشغّلها المحلي */
final class OfflineAudio {
    private OfflineAudio() { }

    static WebResourceResponse intercept(Context c, WebResourceRequest req) {
        Uri u = req.getUrl();
        String url = u.toString();
        String path = u.getPath() == null ? "" : u.getPath();
        if (path.endsWith("/quran/__offline/play")) return player(c, u.getQueryParameter("u"));
        if (!Downloads.isAudio(url)) return null;
        File f = Downloads.ready(c, url);
        if (f == null) return null;
        try {
            return serve(f, req.getRequestHeaders() == null ? null : req.getRequestHeaders().get("Range"));
        } catch (Exception e) {
            return null;
        }
    }

    /** يدعم طلبات Range حتى يعمل التقديم والتأخير في المشغّل */
    private static WebResourceResponse serve(File f, String range) throws Exception {
        long len = f.length();
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Access-Control-Allow-Origin", "*");
        InputStream in = new FileInputStream(f);
        if (range != null && range.startsWith("bytes=")) {
            String[] p = range.substring(6).split("-");
            boolean hasStart = p.length > 0 && !p[0].trim().isEmpty();
            boolean hasEnd = p.length > 1 && !p[1].trim().isEmpty();
            long start, end;
            if (!hasStart && hasEnd) {            // bytes=-N: آخر N بايت
                long n = Long.parseLong(p[1].trim());
                start = Math.max(0, len - n);
                end = len - 1;
            } else {
                start = hasStart ? Long.parseLong(p[0].trim()) : 0;
                end = hasEnd ? Long.parseLong(p[1].trim()) : len - 1;
            }
            if (start >= len || start > end) {      // نطاق غير صالح
                in.close();
                Map<String, String> bad = new HashMap<>();
                bad.put("Content-Range", "bytes */" + len);
                return new WebResourceResponse("audio/mpeg", null, 416, "Range Not Satisfiable", bad,
                        new ByteArrayInputStream(new byte[0]));
            }
            end = Math.min(end, len - 1);
            long skipped = 0;
            while (skipped < start) {
                long s = in.skip(start - skipped);
                if (s <= 0) break;
                skipped += s;
            }
            final long remaining = end - start + 1;
            InputStream bounded = new InputStream() {
                long left = remaining;
                @Override public int read() throws java.io.IOException {
                    if (left <= 0) return -1;
                    int b = in.read();
                    if (b >= 0) left--;
                    return b;
                }
                @Override public int read(byte[] b, int off, int n) throws java.io.IOException {
                    if (left <= 0) return -1;
                    int r = in.read(b, off, (int) Math.min(n, left));
                    if (r > 0) left -= r;
                    return r;
                }
                @Override public void close() throws java.io.IOException { in.close(); }
            };
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
            h.put("Content-Length", String.valueOf(remaining));
            return new WebResourceResponse("audio/mpeg", null, 206, "Partial Content", h, bounded);
        }
        h.put("Content-Length", String.valueOf(len));
        return new WebResourceResponse("audio/mpeg", null, 200, "OK", h, in);
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /** صفحة تشغيل بهوية الموقع؛ صوتها يُخدم من الجهاز */
    private static WebResourceResponse player(Context c, String audio) {
        Downloads.Item it = audio == null ? null : Downloads.get(c, audio);
        String title = it == null ? "تلاوة" : it.title;
        String reciter = it == null ? "" : it.reciter;
        boolean ok = audio != null && Downloads.ready(c, audio) != null;
        String html = "<!doctype html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">"
                + "<title>" + esc(title) + " · " + esc(reciter) + "</title><style>"
                + "body{margin:0;min-height:100vh;background:#F6F8F9;color:#16353D;font-family:Tajawal,'Segoe UI',Tahoma,sans-serif;"
                + "display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box}"
                + ".c{width:100%;max-width:440px;background:#123640;color:#fff;border-radius:24px;padding:28px 22px;text-align:center}"
                + ".b{display:inline-block;background:rgba(255,255,255,.1);color:#C9A876;border-radius:12px;padding:4px 12px;font-size:13px;font-weight:700}"
                + "h1{margin:16px 0 6px;font-size:28px}p{margin:0;color:#A9BABF;font-size:15px}"
                + "audio{width:100%;margin-top:22px}.n{margin-top:16px;font-size:13px;color:#EFE4CF}</style></head><body><div class=\"c\">"
                + "<span class=\"b\">✈️ متاحة بدون إنترنت</span><h1>" + esc(title) + "</h1><p>" + esc(reciter) + "</p>"
                + (ok ? "<audio controls autoplay preload=\"auto\" title=\"" + esc(title) + "\" src=\"" + esc(audio) + "\"></audio>"
                      + "<div class=\"n\">يستمر الاستماع مع قفل الشاشة، وتتحكم به من الإشعار</div>"
                      : "<div class=\"n\">هذه التلاوة لم تعد محمّلة على جهازك</div>")
                + "</div></body></html>";
        return new WebResourceResponse("text/html", "utf-8", new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8)));
    }
}
