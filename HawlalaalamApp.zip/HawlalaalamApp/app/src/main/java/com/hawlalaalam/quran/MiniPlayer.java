package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/** شريط المشغّل المصغّر فوق شريط التبويب: يظهر ما دامت هناك تلاوة في المشغّل الأصلي */
final class MiniPlayer {
    private MiniPlayer() { }

    static View bar(Activity a) {
        LinearLayout wrap = new LinearLayout(a);
        wrap.setPadding(Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 6));
        wrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout b = new LinearLayout(a);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
        b.setBackground(Ui.shape(a.getColor(R.color.dark), 18, 0, a));
        ImageButton play = new ImageButton(a);
        play.setBackground(Ui.shape(a.getColor(R.color.gold), 20, 0, a));
        play.setColorFilter(a.getColor(R.color.dark));
        play.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        b.addView(play, new LinearLayout.LayoutParams(Ui.dp(a, 40), Ui.dp(a, 40)));
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(a, 10), 0, Ui.dp(a, 8), 0);
        TextView title = Ui.text(a, "", 15, 0xFFFFFFFF, 700);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView sub = Ui.text(a, "", 12, a.getColor(R.color.on_dark_muted), 400);
        sub.setMaxLines(1);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.addView(title);
        t.addView(sub);
        b.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageButton next = new ImageButton(a);
        next.setImageResource(R.drawable.ic_next);
        next.setColorFilter(0xFFFFFFFF);
        next.setBackground(null);
        next.setContentDescription("التالي");
        b.addView(next, new LinearLayout.LayoutParams(Ui.dp(a, 40), Ui.dp(a, 40)));
        wrap.addView(b, new LinearLayout.LayoutParams(-1, -2));

        play.setOnClickListener(v -> PlayerService.command(a, PlayerService.ACT_TOGGLE));
        next.setOnClickListener(v -> PlayerService.command(a, PlayerService.ACT_NEXT));
        b.setOnClickListener(v -> a.startActivity(new Intent(a, PlayerActivity.class)));

        Runnable render = () -> {
            PlayerService.Track tr = PlayerService.current();
            wrap.setVisibility(tr == null ? View.GONE : View.VISIBLE);
            if (tr == null) return;
            boolean on = PlayerService.isPlaying();
            play.setImageResource(on ? R.drawable.ic_pause : R.drawable.ic_play);
            play.setContentDescription(on ? "إيقاف مؤقت" : "تشغيل");
            title.setText(tr.title);
            String err = PlayerService.error();
            sub.setText(err != null ? err : PlayerService.isPreparing() ? "جارٍ التحميل…" : tr.reciter);
            next.setVisibility(PlayerService.hasNext() ? View.VISIBLE : View.GONE);
            b.setContentDescription("المشغّل: " + tr.title + "، " + tr.reciter);
        };
        PlayerService.Listener l = render::run;
        wrap.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { PlayerService.addListener(l); render.run(); }
            @Override public void onViewDetachedFromWindow(View v) { PlayerService.removeListener(l); }
        });
        render.run();
        return wrap;
    }
}
