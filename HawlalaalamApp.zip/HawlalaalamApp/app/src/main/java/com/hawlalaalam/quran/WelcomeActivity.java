package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** الترحيب عند أول تشغيل: اختيار التذكيرات */
public class WelcomeActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    private static final int REQ_NOTIF = 51, REQ_LOC = 52;
    private Switch verse, adhan, wird;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(24), dp(40), dp(24), dp(32));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setClipToOutline(true);
        logo.setBackground(Ui.shape(0xFF0E2C31, 28, 0, this));
        logo.setElevation(dp(10));
        col.addView(logo, new LinearLayout.LayoutParams(dp(112), dp(112)));
        TextView t = Ui.text(this, "أهلًا بك في حول العالم", 26, getColor(R.color.ink), 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(22), 0, dp(8));
        col.addView(t);
        TextView d = Ui.text(this, "رفيقك اليومي مع كتاب الله: تقرأ، وتستمع، وتتدبّر، ولا يفوتك وِردك.", 15, getColor(R.color.muted), 400);
        d.setGravity(Gravity.CENTER);
        col.addView(d);

        TextView s = Ui.text(this, "اختر ما يناسبك", 14, getColor(R.color.gold_deep), 700);
        s.setPadding(0, dp(28), 0, dp(10));
        col.addView(s, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout card = Ui.card(this);
        verse = Ui.toggle(this); verse.setChecked(true);
        adhan = Ui.toggle(this); adhan.setChecked(true);
        wird = Ui.toggle(this); wird.setChecked(true);
        card.addView(Ui.row(this, "آية اليوم كل صباح", "مع تفسيرها، الساعة ٧:٠٠ ص", verse));
        card.addView(Ui.divider(this));
        card.addView(Ui.row(this, "تنبيه الأذان في مدينتي", "يحتاج إذن الموقع · طريقة أم القرى", adhan));
        card.addView(Ui.divider(this));
        card.addView(Ui.row(this, "تذكير بالورد مساءً", "الساعة ٩:٠٠ م", wird));
        col.addView(card, new LinearLayout.LayoutParams(-1, -2));

        android.widget.Button go = Ui.button(this, "ابدأ رحلتك مع القرآن", true);
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, dp(56));
        gl.topMargin = dp(28);
        go.setOnClickListener(v -> start());
        col.addView(go, gl);
        TextView later = Ui.text(this, "يمكنك تغيير ذلك لاحقًا من الإعدادات", 12, getColor(R.color.muted), 400);
        later.setPadding(0, dp(12), 0, 0);
        col.addView(later);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(getColor(R.color.page));
        sc.addView(col);
        setContentView(sc);
        Ui.applyInsets(sc);
    }

    private void start() {
        App.prefs(this).edit().putBoolean("welcomed", true).putBoolean("reminders_asked", true).apply();
        boolean wantsNotif = verse.isChecked() || adhan.isChecked() || wird.isChecked();
        if (wantsNotif && !Notifier.allowed(this) && Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            afterNotif();
        }
    }

    private void afterNotif() {
        boolean ok = Notifier.allowed(this);
        Reminders.set(this, Reminders.VERSE, ok && verse.isChecked(), Reminders.hour(this, Reminders.VERSE), Reminders.minute(this, Reminders.VERSE));
        Reminders.set(this, Reminders.WIRD, ok && wird.isChecked(), Reminders.hour(this, Reminders.WIRD), Reminders.minute(this, Reminders.WIRD));
        if (ok && adhan.isChecked()) {
            if (Loc.hasPermission(this)) locate();
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
        } else {
            finish();
        }
    }

    private void locate() {
        android.content.Context app = getApplicationContext();
        Loc.get(this, l -> {
            if (l != null) {
                Adhan.saveLocation(app, l.getLatitude(), l.getLongitude());
                Adhan.setEnabled(app, true);
                PrayerWidget.updateAll(app);
                new Thread(() -> Adhan.saveCity(app, Loc.cityName(app, l.getLatitude(), l.getLongitude()))).start();
            }
        });
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_NOTIF) afterNotif();
        else if (code == REQ_LOC) {
            if (Loc.hasPermission(this)) locate();
            else finish();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        App.prefs(this).edit().putBoolean("welcomed", true).apply();
        super.onBackPressed();
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
