package com.hawlalaalam.quran;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** التلاوات المحمّلة للاستماع بدون إنترنت (ملفات mp3quran.net المباشرة) */
final class Downloads {
    static final int DONE = 0, RUNNING = 1, FAILED = 2, NONE = 3;

    static final class Item {
        String url, title, reciter, file;
        long id, size;
        int status, percent;
    }

    private Downloads() { }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("downloads", Context.MODE_PRIVATE); }

    static boolean isAudio(String url) {
        return url != null && url.startsWith("http") && url.toLowerCase().contains("mp3quran.net") && url.toLowerCase().endsWith(".mp3");
    }

    static File dir(Context c) {
        File d = c.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (d == null) d = new File(c.getFilesDir(), "audio");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static String fileName(String url) {
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "x" : u.getHost().split("\\.")[0];
        String path = u.getPath() == null ? "" : u.getPath().replaceAll("[^A-Za-z0-9]+", "_");
        return host + path.replaceAll("_mp3$", "") + ".mp3";
    }

    static File file(Context c, String url) { return new File(dir(c), fileName(url)); }

    /** بدء التحميل عبر مدير التنزيلات في النظام (يستمر حتى لو أُغلق التطبيق) */
    static void start(Context c, String url, String title, String reciter) {
        if (!isAudio(url)) return;
        if (status(c, url) == DONE || status(c, url) == RUNNING) return;
        File f = file(c, url);
        if (f.exists()) f.delete();
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url))
                .setTitle(title.isEmpty() ? "تلاوة" : title)
                .setDescription(reciter.isEmpty() ? "حول العالم · للاستماع بدون إنترنت" : reciter)
                .setMimeType("audio/mpeg")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(f));
        long id = c.getSystemService(DownloadManager.class).enqueue(r);
        try {
            JSONObject o = new JSONObject().put("title", title).put("reciter", reciter).put("id", id)
                    .put("file", f.getName()).put("time", System.currentTimeMillis());
            p(c).edit().putString(url, o.toString()).apply();
        } catch (Exception ignored) { }
    }

    static Item get(Context c, String url) {
        String json = p(c).getString(url, null);
        if (json == null) return null;
        try {
            JSONObject o = new JSONObject(json);
            Item it = new Item();
            it.url = url;
            it.title = o.optString("title");
            it.reciter = o.optString("reciter");
            it.file = o.optString("file");
            it.id = o.optLong("id", -1);
            fill(c, it);
            return it;
        } catch (Exception e) {
            return null;
        }
    }

    private static void fill(Context c, Item it) {
        File f = new File(dir(c), it.file);
        it.status = NONE;
        if (it.id > 0) {
            try (Cursor cur = c.getSystemService(DownloadManager.class).query(new DownloadManager.Query().setFilterById(it.id))) {
                if (cur != null && cur.moveToFirst()) {
                    int st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    long done = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    it.size = total > 0 ? total : done;
                    it.percent = total > 0 ? (int) (done * 100 / total) : 0;
                    if (st == DownloadManager.STATUS_SUCCESSFUL) it.status = DONE;
                    else if (st == DownloadManager.STATUS_FAILED) it.status = FAILED;
                    else it.status = RUNNING;
                }
            } catch (Exception ignored) { }
        }
        if (it.status == NONE && f.exists() && f.length() > 0) { it.status = DONE; it.size = f.length(); }
        if (it.status == DONE) { it.size = f.length(); it.percent = 100; }
    }

    static int status(Context c, String url) {
        Item it = get(c, url);
        return it == null ? NONE : it.status;
    }

    /** الملف المحلي إن كان مكتمل التحميل */
    static File ready(Context c, String url) {
        if (!isAudio(url) || p(c).getString(url, null) == null) return null;
        Item it = get(c, url);
        if (it == null || it.status != DONE) return null;
        File f = new File(dir(c), it.file);
        return f.exists() ? f : null;
    }

    static List<Item> all(Context c) {
        List<Item> out = new ArrayList<>();
        for (Map.Entry<String, ?> e : p(c).getAll().entrySet()) {
            Item it = get(c, e.getKey());
            if (it != null) out.add(it);
        }
        out.sort((a, b) -> a.title.compareTo(b.title));
        return out;
    }

    static void delete(Context c, String url) {
        Item it = get(c, url);
        if (it != null) {
            try { if (it.id > 0) c.getSystemService(DownloadManager.class).remove(it.id); } catch (Exception ignored) { }
            new File(dir(c), it.file).delete();
        }
        p(c).edit().remove(url).apply();
    }

    static long totalBytes(Context c) {
        long t = 0;
        for (Item it : all(c)) if (it.status == DONE) t += it.size;
        return t;
    }

    static String mb(long bytes) {
        return Adhan.arabic(String.valueOf(Math.max(1, Math.round(bytes / 1048576.0)))) + " م.ب";
    }

    /** رابط مشغّل التلاوة المحمّلة داخل التطبيق */
    static String playerUrl(String url) {
        return App.HOME + "__offline/play?u=" + Uri.encode(url);
    }
}
