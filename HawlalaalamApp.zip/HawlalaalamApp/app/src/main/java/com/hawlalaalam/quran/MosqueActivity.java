package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** «وضع المسجد»: صمت تلقائي عند الإقامة ثم يعود الصوت */
public class MosqueActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private LinearLayout col;
    private boolean askedAccess;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // عاد من إعدادات «عدم الإزعاج» بعد السماح: نفعّل الوضع الذي طلبه
        if (askedAccess) {
            askedAccess = false;
            if (Mosque.allowed(this)) Mosque.setEnabled(this, true);
        }
        render();
    }

    private void render() {
        col.removeAllViews();
        col.addView(Kit.header(this, "وضع المسجد", null, null));

        // البطاقة الرئيسية
        LinearLayout hero = Kit.hero(this);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(Ui.icon(this, R.drawable.ic_silent, getColor(R.color.gold), 28), new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.setPadding(dp(12), 0, dp(8), 0);
        tt.addView(Ui.text(this, "جوالك صامت في الصلاة", 17, 0xFFFFFFFF, 700));
        TextView sub = Ui.text(this, "يصمت عند الإقامة، ويعود لوضعه بعد الصلاة تلقائيًا", 12, getColor(R.color.on_dark_muted), 400);
        sub.setPadding(0, dp(2), 0, 0);
        tt.addView(sub);
        top.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = Ui.toggle(this);
        sw.setChecked(Mosque.enabled(this) && Mosque.allowed(this));
        sw.setContentDescription("تفعيل وضع المسجد");
        sw.setOnCheckedChangeListener((b, on) -> {
            if (on && !Adhan.hasLocation(this)) {
                b.setChecked(false);
                Toast.makeText(this, "حدّد مدينتك أولًا من «المواقيت»", Toast.LENGTH_LONG).show();
                return;
            }
            if (on && !Mosque.allowed(this)) { b.setChecked(false); askAccess(); return; }
            Mosque.setEnabled(this, on);
            render();
        });
        top.addView(sw);
        hero.addView(top);
        if (Mosque.enabled(this) && Mosque.allowed(this)) {
            long[] n = Mosque.next(this);
            if (n != null) {
                TextView nx = Ui.text(this, "الصمت القادم " + Adhan.clock(n[0]) + " لمدة " + Ui.arabicNum(n[1]) + " دقيقة",
                        13, getColor(R.color.gold), 700);
                nx.setPadding(0, dp(12), 0, 0);
                hero.addView(nx);
            }
        }
        long until = App.prefs(this).getLong("mosque_until", 0);
        if (until > System.currentTimeMillis()) {
            TextView now = Ui.text(this, "صامت الآن حتى " + Adhan.clock(until), 13, 0xFFFFFFFF, 700);
            now.setPadding(0, dp(10), 0, 0);
            hero.addView(now);
            TextView stop = Ui.text(this, "أعد الصوت الآن", 13, getColor(R.color.gold), 700);
            stop.setPadding(0, dp(8), 0, dp(4));
            stop.setOnClickListener(v -> { Mosque.restore(this); render(); });
            hero.addView(Ui.minH(stop, 44));
        }
        col.addView(hero, Kit.gap(this, 4));

        // المدة
        col.addView(Kit.section(this, "مدة الصمت بعد الإقامة"), Kit.gap(this, 20));
        final int[] mins = {15, 20, 30};
        int cur = 1;
        for (int i = 0; i < mins.length; i++) if (mins[i] == Mosque.minutes(this)) cur = i;
        col.addView(Kit.segments(this, new String[]{"١٥ دقيقة", "٢٠ دقيقة", "٣٠ دقيقة"}, cur, i -> {
            Mosque.setMinutes(this, mins[i]);
            Mosque.schedule(this);
            render();
        }), Kit.gap(this, 8));

        // جدول الإقامة
        col.addView(Kit.section(this, "الإقامة بعد الأذان (تقويم أم القرى)"), Kit.gap(this, 20));
        LinearLayout tbl = Ui.card(this);
        String[][] rows = {
                {"الفجر", "بعد ٢٥ دقيقة"},
                {"الظهر · العصر · العشاء", "بعد ٢٠ دقيقة"},
                {"المغرب", "بعد ١٠ دقائق"},
                {"الجمعة", "من الأذان الأول · ٤٥ دقيقة"},
        };
        for (int i = 0; i < rows.length; i++) {
            if (i > 0) tbl.addView(Ui.divider(this));
            LinearLayout r = new LinearLayout(this);
            r.setPadding(0, dp(12), 0, dp(12));
            r.addView(Ui.text(this, rows[i][0], 15, getColor(R.color.ink), 700), new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(Ui.text(this, rows[i][1], 14, getColor(R.color.gold_deep), 700));
            tbl.addView(r);
        }
        col.addView(tbl, Kit.gap(this, 8));

        TextView note = Ui.text(this, "لا يغيّر التطبيق إلا وضع الرنين، ولا يلمسه إن كان جوالك صامتًا أصلًا أو غيّرته بنفسك أثناء الصلاة. "
                + "يحتاج صلاحية «عدم الإزعاج» من إعدادات الجوال.", 12, getColor(R.color.muted), 400);
        note.setLineSpacing(dp(4), 1f);
        note.setPadding(dp(4), 0, dp(4), 0);
        col.addView(note, Kit.gap(this, 14));
    }

    private void askAccess() {
        AlertDialog d = new AlertDialog.Builder(this, Ui.dialogTheme(this))
                .setTitle("صلاحية «عدم الإزعاج»")
                .setMessage("ليصمت الجوال عند الإقامة ويعود صوته بعد الصلاة، اسمح لـ«حول العالم» من الصفحة التالية، ثم ارجع للتطبيق.")
                .setPositiveButton("السماح", (x, w) -> {
                    askedAccess = true;
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                    } catch (Exception e) {
                        askedAccess = false;
                        Toast.makeText(this, "افتح إعدادات الجوال ← الإشعارات ← «عدم الإزعاج» واسمح للتطبيق", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("لاحقًا", null)
                .create();
        d.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
