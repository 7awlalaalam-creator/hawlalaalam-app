package com.hawlalaalam.quran;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * واجهة الموقع الرسمية https://7awlalaalam.com/quran/api/v1/ — يُستدعى من صفحة المصحف عبر الجسر (cmd: net)
 * لا يُرسل إلا إلى هذا العنوان، ولا يُرسل شيئًا عن المستخدم غير نص السؤال حين يسأل عن آية.
 */
final class Api {
    static final String BASE = "https://7awlalaalam.com/quran/api/v1/";

    private Api() { }

    /** يعيد [رمز الحالة، النص]؛ ٠ يعني عدم الاتصال */
    static String[] request(String path, String method, String body) {
        if (path == null || path.contains("..") || path.contains("://") || !path.matches("[A-Za-z0-9_\\-./?=&%:+]*")) return new String[]{"0", ""};
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(BASE + path).openConnection();
            con.setConnectTimeout(12000);
            con.setReadTimeout("POST".equals(method) ? 60000 : 20000);
            con.setRequestProperty("User-Agent", "HawlalaalamApp/2 (Android)");
            con.setRequestProperty("Accept", "application/json");
            if ("POST".equals(method)) {
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] b = (body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = con.getOutputStream()) { os.write(b); }
            }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            String txt = "";
            if (in != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 4_000_000) break; }
                in.close();
                txt = bo.toString("UTF-8");
            }
            return new String[]{String.valueOf(code), txt};
        } catch (Exception e) {
            return new String[]{"0", ""};
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
