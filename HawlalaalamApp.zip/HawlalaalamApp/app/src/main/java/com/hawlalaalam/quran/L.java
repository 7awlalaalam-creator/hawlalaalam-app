package com.hawlalaalam.quran;

import android.content.Context;
import android.view.View;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * لغة التطبيق: العربية (الأصل) أو الإنجليزية.
 * النصوص مكتوبة بالعربية في الكود وتمر عبر L.t: في الإنجليزية تُستبدل من assets/i18n/en.json، وما لا ترجمة له يبقى عربيًا.
 * التفضيل app_lang: «ar» أو «en». أول تشغيل لمستخدم جديد يتبع لغة الجوال؛ المستخدم الحالي يبقى على العربية.
 */
final class L {
    static final String AR = "ar", EN = "en";
    private static volatile boolean en;
    private static volatile Map<String, String> map;

    private L() { }

    /** من Application.onCreate (قبل أي شاشة أو مستقبِل) */
    static void init(Context c) {
        String lang = App.prefs(c).getString("app_lang", null);
        if (lang == null) {
            boolean existing = App.prefs(c).getBoolean("welcomed", false);
            String sys = Locale.getDefault().getLanguage();
            lang = existing || "ar".equals(sys) ? AR : EN;
            App.prefs(c).edit().putString("app_lang", lang).apply();
        }
        apply(c, lang);
    }

    static void apply(Context c, String lang) {
        en = EN.equals(lang);
        if (en && map == null) map = load(c);
    }

    static String lang(Context c) { return App.prefs(c).getString("app_lang", AR); }

    /** يحفظ اللغة؛ المستدعي يعيد تشغيل الشاشات */
    static void set(Context c, String lang) {
        App.prefs(c).edit().putString("app_lang", lang).commit();   // قبل إعادة تشغيل العملية
        apply(c.getApplicationContext(), lang);
    }

    static boolean en() { return en; }

    static String t(String s) {
        if (!en || s == null) return s;
        Map<String, String> m = map;
        if (m == null) return s;
        String v = m.get(s);
        return v == null ? s : v;
    }

    /** اتجاه الواجهة حسب اللغة */
    static int dir() { return en ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL; }

    static Locale locale() { return en ? Locale.ENGLISH : new Locale("ar"); }

    private static Map<String, String> load(Context c) {
        Map<String, String> m = new HashMap<>();
        try (InputStream in = c.getAssets().open("i18n/en.json"); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            JSONObject j = new JSONObject(o.toString("UTF-8"));
            for (Iterator<String> it = j.keys(); it.hasNext(); ) {
                String k = it.next();
                m.put(k, j.optString(k, k));
            }
        } catch (Exception ignored) { }
        return m;
    }
}
