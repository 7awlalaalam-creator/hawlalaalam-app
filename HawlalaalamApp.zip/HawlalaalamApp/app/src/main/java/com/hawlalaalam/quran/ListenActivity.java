package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** «الاستماع»: القرّاء (بحث ومفضّلون) والإذاعات والتلاوات المحمّلة، وبطاقة «تابع الاستماع» */
public class ListenActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private static final String[] TABS = {"القرّاء", "الإذاعات", "المحمّلة"};
    private int tab;
    private String query = "";
    private LinearLayout col, listBox;
    private EditText search;
    private boolean loading;
    private int ink, muted, gold;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        tab = state != null ? state.getInt("tab", 0) : getIntent().getIntExtra("tab", 0);
        col = Kit.tabPage(this, Ui.NAV_LISTEN, this::onNav, new ScrollView[1]);
        buildStatic();
        renderList();
        refresh(false);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", tab);
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderList();          // المفضّلون والمحمّلة قد تغيّرت
    }

    private void buildStatic() {
        col.removeAllViews();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.text(this, "الاستماع", 24, ink, 700);
        t.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageButton reload = Kit.roundIcon(this, R.drawable.ic_refresh, "تحديث القائمة");
        reload.setOnClickListener(v -> refresh(true));
        head.addView(reload);
        col.addView(head);

        col.addView(Kit.segments(this, TABS, tab, i -> { tab = i; buildStatic(); renderList(); }), Kit.gap(this, 12));

        if (tab == 0) {
            search = new EditText(this);
            search.setHint("ابحث عن قارئ…");
            search.setTextSize(15);
            search.setTypeface(Ui.font(this, 400));
            search.setTextColor(ink);
            search.setHintTextColor(muted);
            search.setSingleLine(true);
            search.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
            search.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.line), this));
            search.setText(query);
            search.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0);
            search.setCompoundDrawablePadding(Ui.dp(this, 8));
            search.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void afterTextChanged(Editable e) { query = e.toString(); renderList(); }
            });
            col.addView(search, Kit.gap(this, 12));
            View cont = continueCard();
            if (cont != null) col.addView(cont, Kit.gap(this, 12));
        }
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(listBox, Kit.gap(this, 12));
    }

    /** «تابع الاستماع»: آخر سورة وموضعها */
    private View continueCard() {
        try {
            JSONObject o = new JSONObject(App.prefs(this).getString("listen_last", "{}"));
            int rid = o.optInt("reciter"), s = o.optInt("surah");
            if (rid == 0 || s < 1 || s > 114) return null;
            Reciters.Reciter r = Reciters.byId(this, rid);
            if (r == null) return null;
            Reciters.Moshaf m = r.moshaf(o.optInt("moshaf"));
            if (m == null || !m.has(s)) return null;
            long pos = o.optLong("pos"), dur = o.optLong("dur");
            LinearLayout h = Kit.hero(this);
            h.addView(Ui.text(this, "تابع الاستماع", 13, getColor(R.color.gold), 700));
            TextView title = Ui.text(this, "سورة " + QuranText.surahName(s) + " · " + r.name, 18, 0xFFFFFFFF, 700);
            title.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
            h.addView(title);
            h.addView(Kit.progress(this, dur > 0 ? pos / (float) dur : 0f, true));
            h.setContentDescription("تابع الاستماع: سورة " + QuranText.surahName(s) + "، " + r.name);
            h.setOnClickListener(v -> {
                List<PlayerService.Track> q = new ArrayList<>();
                int from = 0;
                for (int x : m.surahs) { if (x == s) from = q.size(); q.add(PlayerService.Track.surah(r, m, x)); }
                PlayerService.play(this, q, from, pos);
                startActivity(new Intent(this, PlayerActivity.class));
            });
            return h;
        } catch (Exception e) {
            return null;
        }
    }

    private void refresh(boolean force) {
        if (loading) return;
        loading = true;
        if (force) android.widget.Toast.makeText(this, "جارٍ التحديث…", android.widget.Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Context app = getApplicationContext();
            Reciters.load(app, force);
            if (tab == 1 || force) Reciters.loadRadios(app);
            runOnUiThread(() -> {
                loading = false;
                if (isFinishing() || isDestroyed()) return;
                if (tab == 0 && Reciters.cached(this) != null && (search == null || !search.hasFocus())) buildStatic();
                renderList();
            });
        }).start();
    }

    private void renderList() {
        if (listBox == null) return;
        listBox.removeAllViews();
        if (tab == 0) renderReciters();
        else if (tab == 1) renderRadios();
        else renderDownloads();
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 14, muted, 400);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24));
        return t;
    }

    private void renderReciters() {
        List<Reciters.Reciter> all = Reciters.cached(this);
        if (all == null) {
            listBox.addView(note(loading ? "جارٍ تحميل قائمة القرّاء…" : "تحتاج اتصالًا بالإنترنت لأول مرة لعرض القرّاء"));
            if (!loading) refresh(false);
            return;
        }
        Set<Integer> favs = Reciters.favorites(this);
        String q = Kit.norm(query);
        List<Reciters.Reciter> fav = new ArrayList<>(), rest = new ArrayList<>();
        for (Reciters.Reciter r : all) {
            if (!q.isEmpty() && !Kit.norm(r.name).contains(q)) continue;
            (favs.contains(r.id) ? fav : rest).add(r);
        }
        if (fav.isEmpty() && rest.isEmpty()) { listBox.addView(note("لا يوجد قارئ بهذا الاسم")); return; }
        if (!fav.isEmpty()) {
            listBox.addView(Kit.section(this, "المفضّلون"));
            listBox.addView(card(fav, true), Kit.gap(this, 6));
        }
        if (!rest.isEmpty()) {
            TextView s = Kit.section(this, q.isEmpty() ? "كل القرّاء · " + Ui.arabicNum(rest.size()) : "النتائج");
            listBox.addView(s, Kit.gap(this, fav.isEmpty() ? 0 : 16));
            // قائمة طويلة (أكثر من ٢٠٠ قارئ): نعرض أول ٦٠ ثم «عرض الكل» حتى تبقى الشاشة سريعة
            int limit = q.isEmpty() && !showAll ? 60 : rest.size();
            listBox.addView(card(rest.subList(0, Math.min(limit, rest.size())), false), Kit.gap(this, 6));
            if (limit < rest.size()) {
                TextView more = Ui.text(this, "عرض كل القرّاء (" + Ui.arabicNum(rest.size()) + ")", 15, gold, 700);
                more.setGravity(Gravity.CENTER);
                more.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
                more.setOnClickListener(v -> { showAll = true; renderList(); });
                listBox.addView(more, new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    private boolean showAll;

    private View card(List<Reciters.Reciter> list, boolean favs) {
        LinearLayout c = Ui.card(this);
        for (int i = 0; i < list.size(); i++) {
            Reciters.Reciter r = list.get(i);
            String letter = r.name.isEmpty() ? "" : r.name.substring(0, 1);
            ImageButton heart = Kit.roundIcon(this, favs ? R.drawable.ic_heart_fill : R.drawable.ic_heart,
                    favs ? "إزالة من المفضّلين" : "إضافة إلى المفضّلين");
            if (favs) heart.clearColorFilter();
            heart.setOnClickListener(v -> { Reciters.toggleFavorite(this, r.id); renderList(); });
            int total = 0;
            for (Reciters.Moshaf m : r.moshaf) total = Math.max(total, m.surahs.length);
            String sub = r.tags() + " · " + Ui.arabicNum(total) + " سورة";
            LinearLayout row = Kit.listRow(this, Kit.badge(this, letter, true), r.name, sub, heart);
            row.setOnClickListener(v -> startActivity(new Intent(this, ReciterActivity.class).putExtra("id", r.id)));
            if (i > 0) c.addView(Ui.divider(this));
            c.addView(row);
        }
        return c;
    }

    private void renderRadios() {
        List<Reciters.Radio> list = Reciters.cachedRadios(this);
        if (list == null) {
            listBox.addView(note(loading ? "جارٍ تحميل الإذاعات…" : "تحتاج اتصالًا بالإنترنت لعرض الإذاعات"));
            if (!loading) refresh(false);
            return;
        }
        LinearLayout c = Ui.card(this);
        for (int i = 0; i < list.size(); i++) {
            Reciters.Radio r = list.get(i);
            ImageButton play = Kit.roundIcon(this, R.drawable.ic_play, "استمع");
            View.OnClickListener go = v -> {
                PlayerService.Track t = new PlayerService.Track();
                t.url = r.url;
                t.title = r.name;
                t.reciter = "إذاعة مباشرة";
                t.live = true;
                List<PlayerService.Track> q = new ArrayList<>();
                q.add(t);
                PlayerService.play(this, q, 0, 0);
            };
            play.setOnClickListener(go);
            LinearLayout row = Kit.listRow(this, Kit.badge(this, "📻", false), r.name, "بث مباشر", play);
            row.setOnClickListener(go);
            if (i > 0) c.addView(Ui.divider(this));
            c.addView(row);
        }
        listBox.addView(c);
    }

    private void renderDownloads() {
        List<Downloads.Item> items = Downloads.all(this);
        List<Downloads.Item> ready = new ArrayList<>();
        for (Downloads.Item it : items) if (Downloads.ready(this, it.url) != null) ready.add(it);
        if (ready.isEmpty()) {
            listBox.addView(note("لا توجد تلاوات محمّلة بعد.\nاضغط زر التحميل بجانب أي سورة لتستمع لها دون إنترنت."));
        } else {
            TextView s = Kit.section(this, "متاحة دون إنترنت · " + Ui.arabicNum(ready.size()));
            listBox.addView(s);
            LinearLayout c = Ui.card(this);
            for (int i = 0; i < ready.size(); i++) {
                Downloads.Item it = ready.get(i);
                ImageButton play = Kit.roundIcon(this, R.drawable.ic_play, "استمع");
                final int idx = i;
                View.OnClickListener go = v -> {
                    List<PlayerService.Track> q = new ArrayList<>();
                    for (Downloads.Item d : ready) {
                        PlayerService.Track t = new PlayerService.Track();
                        t.url = d.url;
                        t.title = d.title;
                        t.reciter = d.reciter;
                        t.surah = surahFromUrl(d.url);
                        q.add(t);
                    }
                    PlayerService.play(this, q, idx, 0);
                    startActivity(new Intent(this, PlayerActivity.class));
                };
                play.setOnClickListener(go);
                LinearLayout row = Kit.listRow(this, Kit.badge(this, "✓", false), it.title, it.reciter, play);
                row.setOnClickListener(go);
                if (i > 0) c.addView(Ui.divider(this));
                c.addView(row);
            }
            listBox.addView(c, Kit.gap(this, 6));
        }
        TextView manage = Ui.text(this, "إدارة التحميلات والمساحة", 15, gold, 700);
        manage.setGravity(Gravity.CENTER);
        manage.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 6));
        manage.setOnClickListener(v -> startActivity(new Intent(this, DownloadsActivity.class)));
        listBox.addView(manage, new LinearLayout.LayoutParams(-1, -2));
    }

    static int surahFromUrl(String url) {
        try {
            String f = url.substring(url.lastIndexOf('/') + 1).replace(".mp3", "");
            int n = Integer.parseInt(f);
            return n >= 1 && n <= 114 ? n : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private void onNav(int idx) {
        if (idx == Ui.NAV_TODAY) {
            startActivity(new Intent(this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            finish();
        } else if (idx == Ui.NAV_MUSHAF) {
            startActivity(Nav.mushafIntent(this, 0));
            finish();
        } else if (idx == Ui.NAV_TOOLS) {
            startActivity(new Intent(this, ToolsActivity.class));
            finish();
        }
    }
}
