package com.hawlalaalam.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/** قراءة مقال داخل التطبيق: نص المقال بتنسيق التطبيق، وتكبير الخط وتصغيره، ومشاركة رابطه في الموقع */
public class ArticleActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    static Intent intent(Context c, int id, String url) {
        return new Intent(c, ArticleActivity.class).putExtra("id", id).putExtra("url", url == null ? "" : url);
    }

    private static final String SIZE = "article_font";
    private int id;
    private String url;
    private Articles.Item item;
    private WebView web;
    private TextView status;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        id = getIntent().getIntExtra("id", 0);
        url = getIntent().getStringExtra("url");
        if (url == null || url.isEmpty()) url = App.HOME + "article.php?id=" + id;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(getColor(R.color.ivory));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(8), dp(14), dp(8));
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = Ui.text(this, "المقالات", 15, getColor(R.color.muted), 700);
        t.setPadding(dp(12), 0, 0, 0);
        bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(sizeButton("أ-", "تصغير الخط", -2));
        bar.addView(sizeButton("أ+", "تكبير الخط", 2));
        root.addView(bar);
        View line = new View(this);
        line.setBackgroundColor(getColor(R.color.ivory_border));
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        status = Ui.text(this, "جارٍ فتح المقال…", 15, getColor(R.color.muted), 400);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(24), dp(60), dp(24), 0);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        web = new WebView(this);
        web.setBackgroundColor(getColor(R.color.ivory));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(false);                 // نص فقط: لا سكربتات
        s.setDomStorageEnabled(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u == null) return true;
                String s = u.toString();
                int other = News.articleId(s);
                if (other > 0 && other != id) startActivity(intent(ArticleActivity.this, other, s));
                else if (s.startsWith("http")) startActivity(App.openInApp(ArticleActivity.this, s));
                return true;
            }
        });
        web.setVisibility(View.GONE);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout foot = new LinearLayout(this);
        foot.setPadding(dp(16), dp(10), dp(16), dp(12));
        foot.setBackgroundColor(getColor(R.color.ivory));
        View share = Ui.pill(this, R.drawable.ic_share, "مشاركة المقال", true);
        share.setOnClickListener(v -> share());
        foot.addView(Ui.minH(share, 48), new LinearLayout.LayoutParams(0, -2, 1f));
        View site = Ui.pill(this, R.drawable.ic_globe_t, "في الموقع", false);
        site.setOnClickListener(v -> startActivity(Nav.browserIntent(this, Uri.parse(url))));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.setMarginStart(dp(8));
        foot.addView(Ui.minH(site, 48), sp);
        root.addView(foot);

        setContentView(root);
        Ui.applyInsets(root, false);

        Context app = getApplicationContext();
        new Thread(() -> {
            Articles.Item a = Articles.get(app, id, true);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                item = a;
                show();
            });
        }).start();
    }

    private TextView sizeButton(String label, String desc, int delta) {
        TextView b = Ui.text(this, label, delta > 0 ? 19 : 15, getColor(R.color.ink), 700);
        b.setGravity(Gravity.CENTER);
        b.setContentDescription(desc);
        b.setOnClickListener(v -> {
            int cur = App.prefs(this).getInt(SIZE, 18);
            int next = Math.max(14, Math.min(28, cur + delta));
            App.prefs(this).edit().putInt(SIZE, next).apply();
            show();
        });
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private void show() {
        if (item == null || item.html == null) {
            status.setText("تعذّر فتح المقال. تحتاج اتصالًا بالإنترنت لأول مرة، أو افتحه في الموقع.");
            status.setVisibility(View.VISIBLE);
            web.setVisibility(View.GONE);
            return;
        }
        status.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        web.loadDataWithBaseURL("file:///android_res/", page(item), "text/html", "utf-8", null);
    }

    private String page(Articles.Item a) {
        int size = App.prefs(this).getInt(SIZE, 18);
        String meta = (a.category.isEmpty() ? "" : a.category + " · ")
                + (a.minutes == 1 ? "دقيقة قراءة" : a.minutes == 2 ? "دقيقتا قراءة"
                : Ui.arabicNum(a.minutes) + (a.minutes <= 10 ? " دقائق" : " دقيقة") + " قراءة");
        return "<!doctype html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>"
                + "@font-face{font-family:T;src:url('font/tajawal_regular.ttf')}"
                + "@font-face{font-family:T;font-weight:700;src:url('font/tajawal_bold.ttf')}"
                + "@font-face{font-family:Q;src:url('font/amiri_quran.ttf')}"
                + "html{-webkit-text-size-adjust:100%}"
                + "body{margin:0;padding:18px 20px 28px;background:" + hex(R.color.ivory) + ";color:" + hex(R.color.ink)
                + ";font-family:T,sans-serif;font-size:" + size + "px;line-height:1.95;word-wrap:break-word}"
                + ".m{display:inline-block;font-size:12px;font-weight:700;color:" + hex(R.color.gold_deep) + ";background:" + hex(R.color.chip)
                + ";border-radius:10px;padding:2px 10px;line-height:1.8}"
                + "h1{font-family:Q,serif;font-size:" + (size + 11) + "px;line-height:1.5;margin:12px 0 10px}"
                + "h2,h3{font-size:" + (size + 2) + "px;line-height:1.6;margin:22px 0 6px;color:" + hex(R.color.ink) + "}"
                + "p{margin:0 0 14px}a{color:" + hex(R.color.gold_deep) + "}"
                + "blockquote{margin:14px 0;padding:14px 16px;border-radius:14px;background:" + hex(R.color.dark)
                + ";color:#FFFFFF;font-family:Q,serif;font-size:" + (size + 3) + "px;text-align:center;line-height:2}"
                + "ul,ol{padding-inline-start:22px}li{margin:4px 0}"
                + "</style></head><body><span class=\"m\">" + TextUtils.htmlEncode(meta) + "</span>"
                + "<h1>" + TextUtils.htmlEncode(a.title) + "</h1>" + a.html + "</body></html>";
    }

    private String hex(int res) { return String.format("#%06X", 0xFFFFFF & getColor(res)); }

    private void share() {
        String title = item != null ? item.title : "";
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, (title.isEmpty() ? "" : "«" + title + "»\n") + Uri.decode(url)
                        + "\n\nمن تطبيق «القرآن حول العالم»: https://7awlalaalam.com/app");
        startActivity(Intent.createChooser(i, "شارك المقال"));
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
