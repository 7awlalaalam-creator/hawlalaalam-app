package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** آية اليوم: نفس الآية المعروضة في الصفحة الرئيسية للموقع، ونصها بالرسم العثماني */
final class VerseRepo {

    static final class Verse {
        int surah, ayah;
        String text, surahName;

        String ref() { return surahName + " · الآية " + ayah; }
        String tafsirUrl() { return App.HOME + "ayah-" + surah + "-" + ayah + ".html"; }
        String cardUrl() {
            return App.HOME + "verse-story-card.html?surah=" + surah + "&from=" + ayah + "&to=" + ayah;
        }
    }

    private static final Pattern AYAH_LINK = Pattern.compile("ayah-(\\d{1,3})-(\\d{1,3})\\.html");

    private VerseRepo() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("verse", Context.MODE_PRIVATE);
    }

    static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** آخر آية محفوظة (قد تكون من يوم سابق) أو null */
    static Verse cached(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.contains("text")) return null;
        Verse v = new Verse();
        v.surah = p.getInt("s", 1);
        v.ayah = p.getInt("a", 1);
        v.text = p.getString("text", "");
        v.surahName = p.getString("name", "");
        return v;
    }

    static boolean isFresh(Context c) {
        return today().equals(prefs(c).getString("date", ""));
    }

    /** يجلب آية اليوم (من خيط خلفي). يرجع المحفوظة إن فشل الاتصال. */
    static Verse fetchToday(Context c) {
        if (isFresh(c)) return cached(c);
        try {
            int s = 0, a = 0;
            try {
                String html = App.get(App.HOME, 600_000);
                int start = Math.max(0, html.indexOf("آية اليوم"));
                Matcher m = AYAH_LINK.matcher(html);
                if (m.find(start) || m.find(0)) {
                    s = Integer.parseInt(m.group(1));
                    a = Integer.parseInt(m.group(2));
                }
            } catch (Exception ignored) { }

            String ref = (s >= 1 && s <= 114 && a >= 1) ? (s + ":" + a)
                    : String.valueOf((int) ((System.currentTimeMillis() / 86_400_000L) % 6236) + 1);
            JSONObject d = new JSONObject(App.get(
                    "https://api.alquran.cloud/v1/ayah/" + ref + "/quran-uthmani", 200_000))
                    .getJSONObject("data");

            Verse v = new Verse();
            v.surah = d.getJSONObject("surah").getInt("number");
            v.ayah = d.getInt("numberInSurah");
            v.surahName = d.getJSONObject("surah").optString("name", "");
            String text = d.getString("text").trim();
            // الآية الأولى في المصدر تبدأ بالبسملة (عدا الفاتحة)، فنحذف كلماتها الأربع
            if (v.ayah == 1 && v.surah != 1 && v.surah != 9) {
                String[] w = text.split("\\s+");
                if (w.length > 4 && w[0].charAt(0) == 'ب' && w[1].contains("ل")) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 4; i < w.length; i++) sb.append(i > 4 ? " " : "").append(w[i]);
                    text = sb.toString();
                }
            }
            v.text = text;

            prefs(c).edit().putString("date", today()).putInt("s", v.surah).putInt("a", v.ayah)
                    .putString("text", v.text).putString("name", v.surahName).apply();
            return v;
        } catch (Exception e) {
            return cached(c);
        }
    }
}
