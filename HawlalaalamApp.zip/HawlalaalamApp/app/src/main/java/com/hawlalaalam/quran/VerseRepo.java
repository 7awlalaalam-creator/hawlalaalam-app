package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** آية اليوم: نفس الآية المعروضة في الصفحة الرئيسية للموقع، ونصها بالرسم العثماني */
final class VerseRepo {

    static final class Verse {
        int surah, ayah;
        String text, surahName;

        String ref() { return surahName + " · الآية " + arabicDigits(ayah); }
        String tafsirUrl() { return App.HOME + "ayah-" + surah + "-" + ayah + ".html"; }
        String cardUrl() {
            return App.HOME + "verse-story-card.html?surah=" + surah + "&from=" + ayah + "&to=" + ayah;
        }
    }

    private static final Pattern AYAH_LINK = Pattern.compile("ayah-(\\d{1,3})-(\\d{1,3})\\.html");

    private VerseRepo() { }

    /** 62 ← ٦٢ */
    static String arabicDigits(int n) {
        String d = String.valueOf(n);
        StringBuilder sb = new StringBuilder();
        for (char ch : d.toCharArray()) sb.append((char) ('٠' + (ch - '0')));
        return sb.toString();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("verse", Context.MODE_PRIVATE);
    }

    static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** إصدار صيغة الحفظ: 2 = نص مجمع الملك فهد المدمج */
    private static final int FMT = 2;

    /** آخر آية محفوظة (قد تكون من يوم سابق) أو null */
    static Verse cached(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.contains("text") || p.getInt("fmt", 0) != FMT) return null;
        Verse v = new Verse();
        v.surah = p.getInt("s", 1);
        v.ayah = p.getInt("a", 1);
        v.text = p.getString("text", "");
        v.surahName = QuranText.surahTitle(v.surah);
        return v;
    }

    static boolean isFresh(Context c) {
        SharedPreferences p = prefs(c);
        return today().equals(p.getString("date", "")) && p.getInt("fmt", 0) == FMT;
    }

    /** يجلب آية اليوم (من خيط خلفي). النص من المصحف المدمج، والمرجع من الصفحة الرئيسية للموقع. */
    static Verse fetchToday(Context c) {
        if (isFresh(c)) return cached(c);
        SharedPreferences p = prefs(c);
        int s = 0, a = 0;
        boolean fromSite = false;
        // بعد محاولة فاشلة لا نعيد تنزيل الصفحة الرئيسية قبل ساعة (توفير البيانات والبطارية)
        long now = System.currentTimeMillis();
        boolean tryNet = now - p.getLong("try_at", 0) > 3_600_000L;
        if (tryNet) try {
            String html = App.get(App.HOME, 600_000);
            int start = Math.max(0, html.indexOf("آية اليوم"));
            Matcher m = AYAH_LINK.matcher(html);
            if (m.find(start) || m.find(0)) {
                s = Integer.parseInt(m.group(1));
                a = Integer.parseInt(m.group(2));
                fromSite = QuranText.valid(s, a);
            }
        } catch (Exception ignored) { }
        if (!fromSite && tryNet) p.edit().putLong("try_at", now).apply();
        if (!fromSite) {
            // بدون اتصال: نُبقي آية اليوم المحفوظة إن كانت لليوم نفسه، وإلا آية بحسب التاريخ
            int[] r = QuranText.fromIndex((int) (System.currentTimeMillis() / 86_400_000L));
            s = r[0];
            a = r[1];
        }
        String text = QuranText.verse(c, s, a);
        if (text == null || text.isEmpty()) return cached(c);
        Verse v = new Verse();
        v.surah = s;
        v.ayah = a;
        v.text = text;
        v.surahName = QuranText.surahTitle(s);
        // آية مختارة بلا اتصال لا تُثبَّت لليوم: نعيد المحاولة مع الموقع لاحقًا
        p.edit().putString("date", fromSite ? today() : "").putInt("fmt", FMT).putInt("s", s).putInt("a", a)
                .putString("text", text).apply();
        return v;
    }
}
