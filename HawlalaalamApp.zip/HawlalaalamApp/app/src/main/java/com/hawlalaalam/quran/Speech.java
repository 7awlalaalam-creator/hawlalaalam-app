package com.hawlalaalam.quran;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * التسميع: التعرّف على التلاوة بالعربية من خدمة الجوال (Google)، ويُرسل النص المسموع إلى صفحة المصحف
 * (window.__hawlSpeech) التي تقارنه بكلمات الآيات. المتعرّف يتوقف بعد كل سكتة، فنعيد تشغيله ما دام المستخدم يقرأ.
 * يعمل على خيط الواجهة فقط. لا يُحفظ الصوت.
 */
final class Speech {
    private final Context ctx;
    private final WebView web;
    private SpeechRecognizer rec;
    private boolean active;
    private int emptyRuns;                       // دورات متتالية بلا أي كلام: نتوقف بعد عدد منها

    Speech(Context ctx, WebView web) {
        this.ctx = ctx;
        this.web = web;
    }

    boolean isActive() { return active; }

    void start(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            state("error", L.t("التعرّف على الكلام غير متاح في جوالك (يحتاج تطبيق Google)"));
            return;
        }
        active = true;
        emptyRuns = 0;
        listen(lang == null || lang.isEmpty() ? "ar-SA" : lang);
        state("listening", "");
    }

    void stop() {
        active = false;
        destroy();
        state("stopped", "");
    }

    void stopIfActive() { if (active) stop(); }

    private void destroy() {
        if (rec != null) {
            try { rec.cancel(); } catch (Exception ignored) { }
            try { rec.destroy(); } catch (Exception ignored) { }
            rec = null;
        }
    }

    private void listen(final String lang) {
        destroy();
        if (!active) return;
        try {
            rec = SpeechRecognizer.createSpeechRecognizer(ctx);
        } catch (Exception e) {
            active = false;
            state("error", L.t("تعذّر بدء الاستماع"));
            return;
        }
        rec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float v) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int t, Bundle p) { }

            @Override public void onPartialResults(Bundle b) {
                String t = best(b);
                if (!t.isEmpty()) send(t, false);
            }

            @Override public void onResults(Bundle b) {
                String t = best(b);
                if (!t.isEmpty()) { send(t, true); emptyRuns = 0; } else emptyRuns++;
                again(lang);
            }

            @Override public void onError(int error) {
                if (!active) return;
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    active = false; destroy();
                    state("error", L.t("اسمح للتطبيق باستخدام الميكروفون"));
                } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                    emptyRuns++;
                    again(lang);
                } else {
                    active = false; destroy();
                    state("error", error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                            ? L.t("التعرّف على الكلام يحتاج اتصالًا بالإنترنت في جوالك") : L.t("تعذّر الاستماع، حاول مرة أخرى"));
                }
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L);
        try {
            rec.startListening(i);
        } catch (Exception e) {
            active = false;
            state("error", L.t("تعذّر بدء الاستماع"));
        }
    }

    /** دورة جديدة ما دام المستخدم يقرأ؛ وبعد دقيقة تقريبًا من الصمت نتوقف حتى لا يبقى الميكروفون يعمل */
    private void again(String lang) {
        if (!active) return;
        if (emptyRuns >= 8) { stop(); return; }
        web.postDelayed(() -> listen(lang), 150);
    }

    private static String best(Bundle b) {
        if (b == null) return "";
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return r == null || r.isEmpty() || r.get(0) == null ? "" : r.get(0).trim();
    }

    private void send(String text, boolean fin) {
        try { js(new JSONObject().put("type", "text").put("text", text).put("final", fin)); } catch (Exception ignored) { }
    }

    void state(String s, String msg) {
        try { js(new JSONObject().put("type", "state").put("state", s).put("msg", msg)); } catch (Exception ignored) { }
    }

    private void js(JSONObject o) {
        web.post(() -> web.evaluateJavascript("window.__hawlSpeech && window.__hawlSpeech(" + o + ")", null));
    }
}
