package com.hawlalaalam.quran;

import java.util.List;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** تفسير الآية دون إنترنت (التفسير الميسر المدمج): الآية بخط المجمع، والتفسير، والمشاركة، والتنقّل */
public class TafsirActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private static volatile JSONArray tafsir;
    private static volatile String source = L.t("التفسير الميسر — مجمع الملك فهد لطباعة المصحف الشريف");

    private int surah, ayah;
    private LinearLayout col;
    private ScrollView scroll;

    static Intent intent(Context c, int s, int a) {
        return new Intent(c, TafsirActivity.class).putExtra("s", s).putExtra("a", a);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        surah = getIntent().getIntExtra("s", 1);
        ayah = getIntent().getIntExtra("a", 1);
        if (state != null) { surah = state.getInt("s", surah); ayah = state.getInt("a", ayah); }
        if (!QuranText.valid(surah, ayah)) { surah = 1; ayah = 1; }
        ScrollView[] sv = new ScrollView[1];
        col = Kit.scrollPage(this, sv);
        scroll = sv[0];
        render();
        if (tafsir == null || QuranText.peek(surah, ayah) == null) {
            new Thread(() -> {
                load(getApplicationContext());
                QuranText.verse(getApplicationContext(), surah, ayah);
                runOnUiThread(() -> { if (!isFinishing()) render(); });
            }).start();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("s", surah);
        out.putInt("a", ayah);
    }

    static void load(Context c) {
        if (tafsir != null) return;
        synchronized (TafsirActivity.class) {
            if (tafsir != null) return;
            try (InputStream in = c.getAssets().open("quran/tafsir-muyassar.json")) {
                java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream(3_000_000);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                JSONObject o = new JSONObject(new String(b.toByteArray(), StandardCharsets.UTF_8));
                source = o.optString("src", source);
                tafsir = o.getJSONArray("s");
            } catch (Exception ignored) { }
        }
    }

    static String text(int s, int a) {
        JSONArray t = tafsir;
        if (t == null) return null;
        JSONArray sur = t.optJSONArray(s - 1);
        return sur == null ? "" : sur.optString(a - 1, "");
    }

    private void listenSurah(int s) {
        Toast.makeText(this, L.t("جارٍ تجهيز التلاوة…"), Toast.LENGTH_SHORT).show();
        Context app = getApplicationContext();
        new Thread(() -> {
            List<Reciters.Reciter> all = Reciters.load(app, false);
            Reciters.Reciter pick = null;
            Reciters.Moshaf m = null;
            if (all != null) {
                int want = 0, wantM = 0;
                try {
                    JSONObject l = new JSONObject(App.prefs(app).getString("listen_last", "{}"));
                    want = l.optInt("reciter"); wantM = l.optInt("moshaf");
                } catch (Exception ignored) { }
                java.util.Set<Integer> favs = Reciters.favorites(app);
                for (int pass = 0; pass < 3 && pick == null; pass++) {
                    for (Reciters.Reciter r : all) {
                        boolean ok = pass == 0 ? r.id == want : pass == 1 ? favs.contains(r.id) : r.name.contains("المعيقلي");   // الافتراضي: ماهر المعيقلي (مثل الموقع)
                        if (!ok) continue;
                        Reciters.Moshaf mm = r.moshaf(pass == 0 ? wantM : 0);
                        if (mm != null && mm.has(s)) { pick = r; m = mm; break; }
                    }
                }
                if (pick == null) for (Reciters.Reciter r : all) {
                    Reciters.Moshaf mm = r.moshaf(0);
                    if (mm != null && mm.has(s)) { pick = r; m = mm; break; }
                }
            }
            final Reciters.Reciter fr = pick;
            final Reciters.Moshaf fm = m;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (fr == null) { Toast.makeText(this, L.t("تحتاج اتصالًا بالإنترنت لأول مرة لتحميل قائمة القرّاء"), Toast.LENGTH_LONG).show(); return; }
                List<PlayerService.Track> q = new java.util.ArrayList<>();
                int from = 0;
                for (int x : fm.surahs) { if (x == s) from = q.size(); q.add(PlayerService.Track.surah(fr, fm, x)); }
                PlayerService.play(this, q, from, 0);
                startActivity(new Intent(this, PlayerActivity.class));
            });
        }).start();
    }

    private void go(int s, int a) {
        surah = s;
        ayah = a;
        render();
        scroll.scrollTo(0, 0);
    }

    private void render() {
        col.removeAllViews();
        String name = QuranText.surahName(surah);
        col.addView(Kit.header(this, L.t("التفسير"), L.t("سورة ") + name + L.t(" · الآية ") + Ui.arabicNum(ayah), null));

        LinearLayout ay = new LinearLayout(this);
        ay.setOrientation(LinearLayout.VERTICAL);
        ay.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 16));
        ay.setBackground(Ui.shape(getColor(R.color.ivory), 18, getColor(R.color.ivory_border), this));
        ay.addView(Ui.text(this, L.t("سورة ") + name + L.t(" · الآية ") + Ui.arabicNum(ayah), 12, getColor(R.color.gold_deep), 700));
        String v = QuranText.peek(surah, ayah);              // النص يُحمَّل في خيط خلفي (onCreate)
        TextView q = new TextView(this);
        q.setText(v == null ? "…" : QuranText.withNumber(v, ayah));
        q.setTypeface(QuranText.font(this));
        q.setTextSize(v != null && v.length() > 300 ? 20 : 24);
        q.setTextColor(getColor(R.color.ink));
        q.setLineSpacing(0, 1.4f);
        q.setGravity(Gravity.CENTER);
        q.setPadding(0, Ui.dp(this, 10), 0, 0);
        q.setTextIsSelectable(true);
        ay.addView(q, new LinearLayout.LayoutParams(-1, -2));
        col.addView(ay, Kit.gap(this, 12));

        LinearLayout tc = Ui.card(this);
        tc.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        tc.addView(Ui.text(this, L.t("التفسير الميسر"), 15, getColor(R.color.ink), 700));
        String t = text(surah, ayah);
        TextView body = Ui.text(this, t == null ? L.t("جارٍ فتح التفسير…") : t.isEmpty() ? L.t("لا يوجد تفسير لهذه الآية") : t.trim(),
                17, getColor(R.color.ink), 400);
        body.setLineSpacing(Ui.dp(this, 8), 1f);
        body.setPadding(0, Ui.dp(this, 8), 0, 0);
        body.setTextIsSelectable(true);
        tc.addView(body);
        TextView src = Ui.text(this, source, 11, getColor(R.color.muted), 400);
        src.setPadding(0, Ui.dp(this, 10), 0, 0);
        tc.addView(src);
        col.addView(tc, Kit.gap(this, 12));

        LinearLayout btns = new LinearLayout(this);
        View open = Ui.pill(this, R.drawable.ic_mushaf_t, L.t("في المصحف"), true);
        open.setOnClickListener(x -> startActivity(Nav.mushafAt(this, surah, ayah)));
        View img = Ui.pill(this, R.drawable.ic_image, L.t("صورة"), false);
        img.setOnClickListener(x -> shareImage(v));
        View copy = Ui.pill(this, R.drawable.ic_text, L.t("نسخ"), false);
        copy.setOnClickListener(x -> {
            String all = (v == null ? "" : "﴿" + v + "﴾ [" + name + ": " + Ui.arabicNum(ayah) + "]")
                    + (t == null || t.isEmpty() ? "" : L.t("\n\nالتفسير الميسر: ") + t.trim());
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(L.t("الآية والتفسير"), all));
            Toast.makeText(this, L.t("نُسخت الآية وتفسيرها"), Toast.LENGTH_SHORT).show();
        });
        btns.addView(Ui.minH(open, 46), new LinearLayout.LayoutParams(0, -2, 1.3f));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, -2, 1f);
        p2.setMarginStart(Ui.dp(this, 8));
        btns.addView(Ui.minH(img, 46), p2);
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, -2, 1f);
        p3.setMarginStart(Ui.dp(this, 8));
        btns.addView(Ui.minH(copy, 46), p3);
        col.addView(btns, Kit.gap(this, 12));

        // استمع: السورة بصوت آخر قارئ استمعت إليه (أو المفضّل)، كما في آيفون — mp3quran لا يوفر ملف آية مفردة
        View listen = Ui.pill(this, R.drawable.ic_l_headphones, L.t("استمع إلى سورة ") + name, false);
        listen.setOnClickListener(x -> listenSurah(surah));
        col.addView(Ui.minH(listen, 46), Kit.gap(this, 8));

        // التنقّل: الآية السابقة يمينًا والتالية يسارًا (اتجاه القراءة)
        LinearLayout nav = new LinearLayout(this);
        int gold = getColor(R.color.gold_deep);
        int ps = surah, pa = ayah - 1;
        if (pa < 1) { ps = surah - 1; pa = ps >= 1 ? QuranText.COUNTS[ps - 1] : 0; }
        int ns = surah, na = ayah + 1;
        if (na > QuranText.COUNTS[surah - 1]) { ns = surah + 1; na = 1; }
        TextView prev = Ui.text(this, ps >= 1 ? "› " + label(ps, pa) : "", 14, gold, 700);
        TextView next = Ui.text(this, ns <= 114 ? label(ns, na) + " ‹" : "", 14, gold, 700);
        next.setGravity(Gravity.END);
        final int fps = ps, fpa = pa, fns = ns, fna = na;
        if (ps >= 1) prev.setOnClickListener(x -> go(fps, fpa));
        if (ns <= 114) next.setOnClickListener(x -> go(fns, fna));
        prev.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        next.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        nav.addView(prev, new LinearLayout.LayoutParams(0, -2, 1f));
        nav.addView(next, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(nav, Kit.gap(this, 10));
        TextView off = Ui.text(this, L.t("يعمل دون إنترنت"), 12, getColor(R.color.muted), 400);
        off.setGravity(Gravity.CENTER);
        col.addView(off, new LinearLayout.LayoutParams(-1, -2));
    }

    private String label(int s, int a) {
        return s == surah ? L.t("الآية ") + Ui.arabicNum(a) : QuranText.surahName(s) + " " + Ui.arabicNum(a);
    }

    private void shareImage(String text) {
        if (text == null) return;
        VerseRepo.Verse vv = new VerseRepo.Verse();
        vv.surah = surah;
        vv.ayah = ayah;
        vv.text = text;
        vv.surahName = L.t("سورة ") + QuranText.surahName(surah);
        android.graphics.Bitmap img = Notifier.verseShareImage(this, vv);
        if (img == null) { Toast.makeText(this, L.t("تعذّر إنشاء الصورة"), Toast.LENGTH_SHORT).show(); return; }
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, "ayah-" + surah + "-" + ayah + ".png");
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
                img.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
            }
            img.recycle();
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent send = new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(ClipData.newRawUri("", uri));
            startActivity(Intent.createChooser(send, L.t("شارك الآية")));
        } catch (Exception e) {
            Toast.makeText(this, L.t("تعذّرت المشاركة"), Toast.LENGTH_SHORT).show();
        }
    }
}
