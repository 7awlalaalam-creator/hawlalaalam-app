package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/** المسبحة الإلكترونية */
public class TasbeehActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    private static final String[] DHIKR = {
            "سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ", "لَا إِلَهَ إِلَّا اللَّهُ",
            "أَسْتَغْفِرُ اللَّهَ", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
            "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ"};
    private static final int[] TARGETS = {33, 99, 100, 0};

    private SharedPreferences prefs;
    private int dhikr, target, count;
    private long total;
    private TextView countView, dhikrView, totalView, targetView;
    private LinearLayout chips;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("tasbeeh", MODE_PRIVATE);
        dhikr = prefs.getInt("dhikr", 0);
        target = prefs.getInt("target", 33);
        count = prefs.getInt("count", 0);
        total = prefs.getLong("total", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(getColor(R.color.page));
        root.setPadding(dp(20), dp(14), dp(20), dp(20));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = Ui.text(this, "المسبحة", 22, getColor(R.color.ink), 700);
        title.setPadding(dp(14), 0, dp(14), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView reset = Ui.text(this, "تصفير", 14, getColor(R.color.gold_deep), 700);
        reset.setPadding(dp(12), dp(10), dp(12), dp(10));
        reset.setOnClickListener(v -> { count = 0; save(); refresh(); });
        bar.addView(reset);
        root.addView(bar);

        // اختيار الذكر
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chips = new LinearLayout(this);
        chips.setPadding(0, dp(14), 0, dp(6));
        hs.addView(chips);
        root.addView(hs);

        dhikrView = new TextView(this);
        dhikrView.setTypeface(Ui.quran(this));
        dhikrView.setTextSize(30);
        dhikrView.setTextColor(getColor(R.color.ink));
        dhikrView.setGravity(Gravity.CENTER);
        dhikrView.setPadding(0, dp(18), 0, dp(6));
        root.addView(dhikrView, new LinearLayout.LayoutParams(-1, -2));

        // زر العدّ الكبير
        FrameLayout tapArea = new FrameLayout(this);
        TextView circle = new TextView(this);
        circle.setBackground(Ui.shape(getColor(R.color.dark), 1000, getColor(R.color.gold), this));
        circle.setContentDescription("اضغط للتسبيح");
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(dp(240), dp(240), Gravity.CENTER);
        tapArea.addView(circle, cl);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER);
        countView = Ui.text(this, "", 64, 0xFFFFFFFF, 700);
        countView.setGravity(Gravity.CENTER);
        inner.addView(countView);
        targetView = Ui.text(this, "", 14, getColor(R.color.gold), 500);
        targetView.setGravity(Gravity.CENTER);
        inner.addView(targetView);
        tapArea.addView(inner, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        tapArea.setOnClickListener(v -> tap(v));
        // الدائرة تتسع لما يتبقى من الشاشة: كاملة على الجوال، وأصغر في الوضع الأفقي أو مع تكبير الخط
        tapArea.addOnLayoutChangeListener((v, l, t, r, btm, ol, ot, or, ob) -> {
            int side = Math.max(dp(96), Math.min(dp(240), Math.min(r - l, btm - t) - dp(8)));
            ViewGroup.LayoutParams p = circle.getLayoutParams();
            if (p.width != side) {
                v.post(() -> {
                    circle.setLayoutParams(new FrameLayout.LayoutParams(side, side, Gravity.CENTER));
                    countView.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, side * 0.25f);
                    targetView.setVisibility(side < dp(140) ? View.GONE : View.VISIBLE);
                });
            }
        });
        root.addView(tapArea, new LinearLayout.LayoutParams(-1, 0, 1f));

        // الهدف
        LinearLayout targets = new LinearLayout(this);
        targets.setGravity(Gravity.CENTER);
        for (int t : TARGETS) {
            TextView b = Ui.text(this, t == 0 ? "بلا حد" : Ui.arabicNum(t), 14, getColor(R.color.ink), 700);
            b.setGravity(Gravity.CENTER);
            b.setTag(t);
            b.setOnClickListener(v -> { target = (Integer) v.getTag(); count = 0; save(); refresh(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
            lp.setMarginStart(dp(6));
            targets.addView(Ui.minH(b, 42), lp);
        }
        root.addView(targets);
        totalView = Ui.text(this, "", 13, getColor(R.color.muted), 400);
        totalView.setGravity(Gravity.CENTER);
        totalView.setPadding(0, dp(12), 0, 0);
        root.addView(totalView, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        Ui.applyInsets(root);
        buildChips();
        refresh();
        targetViews = targets;
        refresh();
    }

    private LinearLayout targetViews;

    private void buildChips() {
        chips.removeAllViews();
        for (int i = 0; i < DHIKR.length; i++) {
            TextView c = Ui.text(this, DHIKR[i], 14, i == dhikr ? 0xFFFFFFFF : getColor(R.color.ink), 500);
            c.setPadding(dp(14), dp(8), dp(14), dp(8));
            c.setBackground(i == dhikr ? Ui.shape(getColor(R.color.primary), 18, 0, this)
                    : Ui.shape(getColor(R.color.card), 18, getColor(R.color.field_border), this));
            final int idx = i;
            c.setOnClickListener(v -> { dhikr = idx; count = 0; save(); buildChips(); refresh(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMarginEnd(dp(8));
            chips.addView(c, lp);
        }
    }

    private void tap(View v) {
        count++;
        total++;
        Vibrator vib = getSystemService(Vibrator.class);
        if (target > 0 && count == target) {
            if (vib != null) vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 90, 80, 90}, -1));
        } else {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
        if (target > 0 && count > target) count = 1;
        save();
        refresh();
    }

    private void refresh() {
        dhikrView.setText(DHIKR[dhikr]);
        countView.setText(Ui.arabicNum(count));
        targetView.setText(target > 0 ? "من " + Ui.arabicNum(target) : "عدّ مفتوح");
        totalView.setText("مجموع تسبيحاتك: " + Ui.arabicNum(total));
        if (targetViews != null) {
            for (int i = 0; i < targetViews.getChildCount(); i++) {
                TextView b = (TextView) targetViews.getChildAt(i);
                boolean sel = (Integer) b.getTag() == target;
                b.setTextColor(sel ? 0xFFFFFFFF : getColor(R.color.ink));
                b.setBackground(sel ? Ui.shape(getColor(R.color.gold_deep), 21, 0, this)
                        : Ui.shape(getColor(R.color.card), 21, getColor(R.color.field_border), this));
            }
        }
    }

    private void save() {
        prefs.edit().putInt("dhikr", dhikr).putInt("target", target).putInt("count", count).putLong("total", total).apply();
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
