package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** الحديث كاملًا: السند (يُظهَر ويُخفى)، والمتن بخط أكبر، والراوي والمصدر ورقم الحديث، والمشاركة والحفظ */
public class HadithDetailActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    static Intent intent(Context c, String key, int num) {
        return new Intent(c, HadithDetailActivity.class).putExtra("key", key).putExtra("n", num);
    }

    private static final String SHOW_ISNAD = "hadith_isnad";
    private LinearLayout col;
    private String key;
    private int num;
    private Typeface amiri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        key = getIntent().getStringExtra("key");
        if (key == null) key = Hadith.BUKHARI;
        num = getIntent().getIntExtra("n", 1);
        try { amiri = getResources().getFont(R.font.amiri_quran); } catch (Exception e) { amiri = Ui.font(this, 400); }
        col = Kit.scrollPage(this, null);
        render();
        if (Hadith.peek(key) == null) {
            Context app = getApplicationContext();
            new Thread(() -> {
                Hadith.load(app, key);
                runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) render(); });
            }).start();
        }
    }

    private void render() {
        col.removeAllViews();
        Hadith.Collection c = Hadith.peek(key);
        int i = c == null ? -1 : c.indexOf(num);
        String bookName = i < 0 ? "" : c.bookName(c.book[i]);
        col.addView(Kit.header(this, Hadith.title(key) + " · " + Ui.arabicNum(num), bookName, null));
        if (i < 0) {
            TextView t = Ui.text(this, c == null ? "جارٍ فتح الحديث…" : "لم يُعثر على الحديث", 15, getColor(R.color.muted), 400);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(40), 0, 0);
            col.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        boolean hasIsnad = !c.isnad[i].isEmpty();
        boolean showIsnad = App.prefs(this).getBoolean(SHOW_ISNAD, true);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setBackground(Ui.shape(getColor(R.color.ivory), 18, getColor(R.color.ivory_border), this));

        if (hasIsnad) {
            TextView tog = Ui.text(this, showIsnad ? "إخفاء السند" : "إظهار السند", 13, getColor(R.color.gold_deep), 700);
            tog.setPadding(dp(14), dp(8), dp(14), dp(8));
            tog.setBackground(Ui.shape(getColor(R.color.chip), 18, getColor(R.color.ivory_border), this));
            tog.setContentDescription(showIsnad ? "إخفاء السند" : "إظهار السند");
            tog.setOnClickListener(v -> {
                App.prefs(this).edit().putBoolean(SHOW_ISNAD, !showIsnad).apply();
                render();
            });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
            tl.gravity = Gravity.START;
            card.addView(Ui.minH(tog, 40), tl);
            if (showIsnad) {
                card.addView(label("السند"), Kit.gap(this, 12));
                TextView is = Ui.text(this, c.isnad[i], 16, getColor(R.color.muted), 400);
                is.setTypeface(amiri);
                is.setLineSpacing(dp(6), 1f);
                is.setTextIsSelectable(true);
                card.addView(is, Kit.gap(this, 4));
            }
            card.addView(label("المتن"), Kit.gap(this, 14));
        } else {
            card.addView(label("نص الحديث"));
        }
        TextView m = Ui.text(this, c.matn[i], hasIsnad ? 23 : 20, getColor(R.color.ink), 400);
        m.setTypeface(amiri);
        m.setLineSpacing(dp(8), 1f);
        m.setTextIsSelectable(true);
        card.addView(m, Kit.gap(this, 4));
        col.addView(card, Kit.gap(this, 8));

        LinearLayout facts = new LinearLayout(this);
        if (!c.narrator[i].isEmpty()) facts.addView(fact("الراوي", c.narrator[i]), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(0, -2, 1f);
        if (facts.getChildCount() > 0) fl.setMarginStart(dp(8));
        facts.addView(fact("المصدر", Hadith.title(key) + "، ح " + Ui.arabicNum(num)), fl);
        col.addView(facts, Kit.gap(this, 10));

        LinearLayout btns = new LinearLayout(this);
        View share = Ui.pill(this, R.drawable.ic_share, "مشاركة", true);
        share.setOnClickListener(v -> {
            Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Hadith.shareText(c, i, showIsnad));
            startActivity(Intent.createChooser(s, "شارك الحديث"));
        });
        btns.addView(Ui.minH(share, 46), new LinearLayout.LayoutParams(0, -2, 1.3f));
        View copy = Ui.pill(this, R.drawable.ic_text, "نسخ", false);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("حديث", Hadith.shareText(c, i, showIsnad)));
            Toast.makeText(this, "نُسخ الحديث", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, -2, 1f);
        p2.setMarginStart(dp(8));
        btns.addView(Ui.minH(copy, 46), p2);
        boolean fav = Hadith.isFav(this, key, num);
        View save = Ui.pill(this, fav ? R.drawable.ic_heart_fill : R.drawable.ic_heart, fav ? "محفوظ" : "حفظ", false);
        save.setOnClickListener(v -> { Hadith.toggleFav(this, key, num); render(); });
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, -2, 1f);
        p3.setMarginStart(dp(8));
        btns.addView(Ui.minH(save, 46), p3);
        col.addView(btns, Kit.gap(this, 12));

        // التنقّل بين أحاديث الكتاب نفسه: السابق يمينًا والتالي يسارًا
        LinearLayout nav = new LinearLayout(this);
        int gold = getColor(R.color.gold_deep);
        TextView prev = Ui.text(this, i > 0 ? "› الحديث " + Ui.arabicNum(c.num[i - 1]) : "", 14, gold, 700);
        TextView next = Ui.text(this, i < c.size() - 1 ? "الحديث " + Ui.arabicNum(c.num[i + 1]) + " ‹" : "", 14, gold, 700);
        next.setGravity(Gravity.END);
        if (i > 0) prev.setOnClickListener(v -> { num = c.num[i - 1]; render(); });
        if (i < c.size() - 1) next.setOnClickListener(v -> { num = c.num[i + 1]; render(); });
        prev.setPadding(0, dp(12), 0, dp(12));
        next.setPadding(0, dp(12), 0, dp(12));
        nav.addView(prev, new LinearLayout.LayoutParams(0, -2, 1f));
        nav.addView(next, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(nav, Kit.gap(this, 6));
    }

    private TextView label(String s) {
        return Ui.text(this, s, 12, getColor(R.color.gold_deep), 700);
    }

    private View fact(String k, String v) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(12), dp(10), dp(12), dp(10));
        f.setBackground(Ui.shape(getColor(R.color.card), 12, getColor(R.color.line), this));
        f.addView(Ui.text(this, k, 11, getColor(R.color.muted), 400));
        f.addView(Ui.text(this, v, 14, getColor(R.color.ink), 700));
        return f;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
