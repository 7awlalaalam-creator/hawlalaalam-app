package com.hawlalaalam.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * إقلاع الجهاز، تحديث التطبيق، تغيير الوقت أو المنطقة الزمنية: نعيد جدولة المنبّهات وتحديث الويدجت فقط.
 * مستقل عن ReminderReceiver عمدًا: لا يبدأ أي خدمة (لا تشغيل تلاوة ولا خدمة في المقدمة)،
 * وهو ما يشترطه Android 15 على مستقبِلات BOOT_COMPLETED.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Context c = context.getApplicationContext();
        try { Adhan.forgetPending(c); Adhan.scheduleNext(c); } catch (Exception ignored) { }
        try { Reminders.scheduleAll(c); } catch (Exception ignored) { }
        try {
            PrayerWidget.updateAll(c);
            VerseWidget.updateAll(c);
            RamadanWidget.updateAll(c);
            KhatmaWidget.updateAll(c);
        } catch (Exception ignored) { }
    }
}
