package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

/**
 * «فحص الأذان»: يتأكد أن الأذان سيصل في وقته (الإشعارات، فئة الأذان، الموقع، المنبّه الدقيق، البطارية، وصول الأذان الماضي).
 * يُعاد تلقائيًا كل أسبوع، ولا يُرسل إشعارًا إلا إن وُجد ما يحتاج إصلاحًا.
 */
final class AdhanCheck {
    static final String ACTION_WEEKLY = Reminders.ACTION_PREFIX + "adhan_check";
    static final String ACTION_TEST = Reminders.ACTION_PREFIX + "adhan_test";
    private static final long WEEK = 7 * 86_400_000L;

    /** بند في قائمة الفحص */
    static final class Item {
        final boolean ok; final String title; final String sub; final String fix; final Intent intent;
        Item(boolean ok, String title, String sub, String fix, Intent intent) {
            this.ok = ok; this.title = title; this.sub = sub; this.fix = fix; this.intent = intent;
        }
    }

    private AdhanCheck() { }

    static List<Item> run(Context c) {
        String pkg = c.getPackageName();
        Intent appSettings = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        List<Item> l = new ArrayList<>();
        String block = Notifier.adhanBlock(c);
        boolean notifOk = !"off".equals(block);
        l.add(new Item(notifOk, notifOk ? L.t("الإشعارات مسموحة") : L.t("إشعارات التطبيق متوقفة"),
                notifOk ? null : L.t("يحين الوقت ولا يظهر إشعار الأذان"), L.t("أصلحه"),
                new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg)));
        if (notifOk) {
            boolean ch = !"channel".equals(block);
            l.add(new Item(ch, ch ? L.t("فئة «الأذان» مفعّلة · ") + Adhan.soundName(Adhan.sound(c)) : L.t("فئة «الأذان» متوقفة"),
                    ch ? null : L.t("من إعدادات إشعارات الجوال"), L.t("أصلحه"),
                    new Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg)
                            .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, Notifier.adhanChannel(c, Adhan.sound(c)))));
        }
        boolean on = Adhan.enabled(c);
        l.add(new Item(on, on ? L.t("تنبيه الأذان مفعّل") : L.t("تنبيه الأذان مطفأ"), on ? null : L.t("من «التنبيهات» في التطبيق"), L.t("فعّله"),
                new Intent(c, SettingsActivity.class).putExtra(SettingsActivity.EXTRA_NOTIF_ONLY, true)));
        boolean loc = Adhan.hasLocation(c);
        String city = Adhan.city(c);
        l.add(new Item(loc, loc ? L.t("الموقع محدّد") + (city.isEmpty() ? "" : ": " + city) : L.t("لم تُحدَّد مدينتك"),
                loc ? null : L.t("المواقيت تُحسب حسب مدينتك"), L.t("حدّده"), new Intent(c, PrayerTimesActivity.class)));
        if (Build.VERSION.SDK_INT >= 31) {
            boolean ex = Adhan.canExact(c);
            l.add(new Item(ex, ex ? L.t("صلاحية «المنبهات والتذكيرات» مفعّلة") : L.t("صلاحية «المنبهات والتذكيرات» غير مفعّلة"),
                    ex ? null : L.t("قد يتأخر الأذان عدة دقائق"), L.t("أصلحه"),
                    new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + pkg))));
        }
        boolean bat = Adhan.batteryFree(c);
        l.add(new Item(bat, bat ? L.t("توفير البطارية لا يقيّد التطبيق") : L.t("توفير البطارية يقيّد التطبيق"),
                bat ? null : L.t("من الصفحة التالية: البطارية ← «غير مقيّد»"), L.t("أصلحه"), appSettings));
        long missed = Adhan.lastMissed(c);
        int late = Adhan.lastLate(c);
        if (missed > 0) {
            l.add(new Item(false, L.t("لم يصل الأذان الماضي"), L.t("أخرج التطبيق من «التطبيقات النائمة» في إعدادات البطارية"), L.t("أصلحه"), appSettings));
        } else if (late >= 3) {
            l.add(new Item(false, L.t("الأذان الماضي تأخر ") + Adhan.arabic(String.valueOf(late)) + L.t(" دقائق"),
                    L.t("اجعل البطارية «غير مقيّد» للتطبيق"), L.t("أصلحه"), appSettings));
        } else if (p(c).getLong("adhan_late_at", 0) > 0) {
            l.add(new Item(true, L.t("الأذان الماضي وصل في وقته"), null, null, null));
        }
        return l;
    }

    static int problems(List<Item> l) {
        int n = 0;
        for (Item i : l) if (!i.ok) n++;
        return n;
    }

    private static android.content.SharedPreferences p(Context c) { return App.prefs(c); }

    static long lastRun(Context c) { return p(c).getLong("adhan_check_at", 0); }

    static void markRun(Context c) { p(c).edit().putLong("adhan_check_at", System.currentTimeMillis()).apply(); }

    private static PendingIntent pi(Context c, String action, int req) {
        return PendingIntent.getBroadcast(c, req, new Intent(c, ReminderReceiver.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** يجدول الفحص الأسبوعي (غير دقيق عمدًا: لا يحتاج إيقاظًا في دقيقة بعينها) */
    static void schedule(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent w = pi(c, ACTION_WEEKLY, 240);
        if (!Adhan.enabled(c)) { am.cancel(w); return; }
        long last = lastRun(c);
        if (last == 0) { markRun(c); last = System.currentTimeMillis(); }
        long next = Math.max(System.currentTimeMillis() + 60_000L, last + WEEK);
        am.set(AlarmManager.RTC_WAKEUP, next, w);
    }

    /** الفحص الأسبوعي في الخلفية: إشعار واحد فقط إن وُجد ما يؤخّر الأذان */
    static void weekly(Context c) {
        markRun(c);
        schedule(c);
        if (!Adhan.enabled(c)) return;
        List<Item> l = run(c);
        int n = problems(l);
        if (n == 0) return;
        Item first = null;
        for (Item i : l) if (!i.ok) { first = i; break; }
        notifyIssue(c, n, first == null ? "" : first.title);
    }

    private static void notifyIssue(Context c, int n, String what) {
        if (!Notifier.allowed(c)) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.areNotificationsEnabled()) return;
        nm.createNotificationChannel(new NotificationChannel("adhan_check", L.t("فحص الأذان"), NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(c, 241, new Intent(c, AdhanCheckActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification x = new Notification.Builder(c, "adhan_check")
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(c.getColor(R.color.gold_deep))
                .setContentTitle(n == 1 ? L.t("شيء واحد قد يؤخّر الأذان") : Adhan.arabic(String.valueOf(n)) + L.t(" أشياء قد تؤخّر الأذان"))
                .setContentText(what + L.t(" · اضغط لإصلاحه"))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        nm.notify(17, x);
    }

    /** «جرّب الأذان الآن»: إشعار تجريبي بعد ١٠ ثوانٍ بالصوت المختار */
    static void test(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        long at = System.currentTimeMillis() + 10_000L;
        PendingIntent t = pi(c, ACTION_TEST, 242);
        if (Adhan.canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, t);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, t);
    }
}
