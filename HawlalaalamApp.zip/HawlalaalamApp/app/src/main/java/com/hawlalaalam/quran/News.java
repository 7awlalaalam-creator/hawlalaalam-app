package com.hawlalaalam.quran;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * «أخبار التطبيق»: كل إشعار يصل من صاحب التطبيق (فوري أو مجدول أو مقال جديد) يُحفظ هنا على الجهاز
 * ويبقى ٢٤ ساعة من لحظة وصوله، ثم يُحذف تلقائيًا. لا يُرسل أي شيء عن المستخدم.
 */
final class News {
    static final long KEEP_MS = 24L * 3_600_000L;
    private static final String KEY = "news_box";
    private static final String READ = "news_read_at";
    private static final Pattern ARTICLE = Pattern.compile("(?:article\\.php\\?id=|مقالة-)(\\d+)");

    private News() { }

    static final class Item {
        String id, title, body, url;
        int article;            // رقم المقالة إن كان الخبر «مقال جديد»، وإلا ٠
        long at;                // وقت الوصول (ملّي ثانية)

        long leftMs() { return Math.max(0, at + KEEP_MS - System.currentTimeMillis()); }
    }

    /** رقم المقالة من رابطها في الموقع (article.php?id=50 أو /مقالة-50-…html) */
    static int articleId(String url) {
        if (url == null || url.isEmpty()) return 0;
        try {
            Matcher m = ARTICLE.matcher(Uri.decode(url));
            return m.find() ? Integer.parseInt(m.group(1)) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    static synchronized void add(Context c, String id, String title, String body, String url, int article) {
        if (id == null || id.isEmpty()) return;
        JSONArray old = raw(c);
        for (int i = 0; i < old.length(); i++) {
            JSONObject x = old.optJSONObject(i);
            if (x != null && id.equals(x.optString("id"))) return;     // وصل من قبل: لا نجدّد مدته
        }
        JSONArray out = new JSONArray();
        long now = System.currentTimeMillis();
        try {
            JSONObject o = new JSONObject();
            o.put("id", id).put("t", title == null ? "" : title).put("b", body == null ? "" : body)
                    .put("u", url == null ? "" : url).put("a", article > 0 ? article : articleId(url)).put("at", now);
            out.put(o);
            for (int i = 0; i < old.length() && out.length() < 40; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x == null || id.equals(x.optString("id"))) continue;
                if (now - x.optLong("at") >= KEEP_MS) continue;
                out.put(x);
            }
        } catch (Exception ignored) { }
        App.prefs(c).edit().putString(KEY, out.toString()).apply();
    }

    /** الأخبار السارية فقط، الأحدث أولًا */
    static synchronized java.util.List<Item> items(Context c) {
        java.util.List<Item> list = new java.util.ArrayList<>();
        JSONArray a = raw(c);
        long now = System.currentTimeMillis();
        boolean pruned = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            if (now - x.optLong("at") >= KEEP_MS) { pruned = true; continue; }
            Item it = new Item();
            it.id = x.optString("id");
            it.title = x.optString("t");
            it.body = x.optString("b");
            it.url = x.optString("u");
            it.article = x.optInt("a");
            it.at = x.optLong("at");
            list.add(it);
        }
        if (pruned) {
            JSONArray keep = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.optJSONObject(i);
                if (x != null && now - x.optLong("at") < KEEP_MS) keep.put(x);
            }
            App.prefs(c).edit().putString(KEY, keep.toString()).apply();
        }
        return list;
    }

    static int unread(Context c) {
        long seen = App.prefs(c).getLong(READ, 0);
        int n = 0;
        for (Item it : items(c)) if (it.at > seen) n++;
        return n;
    }

    static void markRead(Context c) {
        App.prefs(c).edit().putLong(READ, System.currentTimeMillis()).apply();
    }

    /** «قبل ٣ ساعات» */
    static String ago(long at) {
        long m = Math.max(0, (System.currentTimeMillis() - at) / 60_000L);
        if (m < 1) return L.t("الآن");
        if (L.en()) return m < 60 ? enCount(m, "minute") + " ago" : enCount(m / 60, "hour") + " ago";
        if (m < 60) return L.t("قبل ") + count(m, L.t("دقيقة"), L.t("دقيقتين"), L.t("دقائق"));
        long h = m / 60;
        return L.t("قبل ") + count(h, L.t("ساعة"), L.t("ساعتين"), L.t("ساعات"));
    }

    /** «يختفي بعد ٢١ ساعة» */
    static String left(Item it) {
        long m = it.leftMs() / 60_000L;
        if (L.en()) return "Disappears in " + (m < 60 ? enCount(Math.max(1, m), "minute") : enCount(m / 60, "hour"));
        if (m < 60) return L.t("يختفي بعد ") + count(Math.max(1, m), L.t("دقيقة"), L.t("دقيقتين"), L.t("دقائق"));
        return L.t("يختفي بعد ") + count(m / 60, L.t("ساعة"), L.t("ساعتين"), L.t("ساعات"));
    }

    static String enCount(long n, String word) { return n + " " + word + (n == 1 ? "" : "s"); }

    private static String count(long n, String one, String two, String few) {
        if (n == 1) return one;
        if (n == 2) return two;
        return Ui.arabicNum(n) + " " + (n <= 10 ? few : one);
    }

    private static JSONArray raw(Context c) {
        try {
            return new JSONArray(App.prefs(c).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }
}
