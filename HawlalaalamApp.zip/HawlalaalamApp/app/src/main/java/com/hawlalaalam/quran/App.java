package com.hawlalaalam.quran;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** أدوات مشتركة */
final class App {
    static final String HOME = "https://7awlalaalam.com/quran/";
    /** فهرس السور في الموقع */
    static final String MUSHAF = HOME + "index.php?action=quran";

    /** «المصحف» في التطبيق: صفحات مصحف المدينة (بالإطار وأرقام الصفحات) من حيث توقف القارئ */
    static String mushaf(android.content.Context c) {
        int page = 1;
        try { page = Khatma.lastMushafPage(c); } catch (Throwable ignored) { }
        return Khatma.pageUrl(page >= 1 && page <= Khatma.PAGES ? page : 1);
    }
    static final String CONTACT = HOME + "contact.html";
    static final String PRIVACY = HOME + "privacy-app-section.html";
    static final String APK_URL =
            "https://github.com/7awlalaalam-creator/hawlalaalam-app/releases/latest/download/hawlalaalam-quran.apk";
    static final String PLAY_URL =
            "https://play.google.com/store/apps/details?id=com.hawlalaalam.quran";
    static final String LATEST_API =
            "https://api.github.com/repos/7awlalaalam-creator/hawlalaalam-app/releases/latest";

    private App() { }

    /**
     * هل ثُبّت التطبيق من Google Play؟
     * سياسة Play تمنع تحديث التطبيق من خارج المتجر، فنعطّل فحص GitHub في نسخة المتجر.
     */
    @SuppressWarnings("deprecation")
    static boolean fromPlay(Context c) {
        try {
            String installer;
            if (Build.VERSION.SDK_INT >= 30) {
                installer = c.getPackageManager().getInstallSourceInfo(c.getPackageName()).getInstallingPackageName();
            } else {
                installer = c.getPackageManager().getInstallerPackageName(c.getPackageName());
            }
            return "com.android.vending".equals(installer);
        } catch (Exception e) {
            return false;
        }
    }

    /** فتح صفحة التطبيق في متجر Play */
    static void openPlayListing(Context c) {
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + c.getPackageName()))
                    .setPackage("com.android.vending").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) { }
        }
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    @SuppressWarnings("deprecation")
    static long versionCode(Context c) {
        try {
            android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    static String versionName(Context c) {
        try {
            String v = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            return v == null ? "" : v;
        } catch (Exception e) {
            return "";
        }
    }

    /** طلب GET بسيط (يُستدعى من خيط خلفي فقط) */
    static String get(String url, int maxBytes) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(15000);
        con.setRequestProperty("User-Agent", "HawlalaalamApp/1 (Android)");
        con.setRequestProperty("Accept", "application/json, text/html;q=0.9, */*;q=0.8");
        try {
            if (con.getResponseCode() >= 400) throw new IllegalStateException("HTTP " + con.getResponseCode());
            try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n, total = 0;
                while ((n = in.read(buf)) > 0 && total < maxBytes) {
                    out.write(buf, 0, n);
                    total += n;
                }
                return out.toString("UTF-8");
            }
        } finally {
            con.disconnect();
        }
    }

    /** نية لفتح رابط من الموقع داخل التطبيق */
    static Intent openInApp(Context c, String url) {
        // الشاشة الأصلية المقابلة (الاستماع، الأذكار، المواقيت، التفسير، ختمة العائلة، المصحف) أو متصفح الجوال
        return Nav.intent(c, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    /** 7:05 م */
    static String formatTime(int h, int m) {
        String suffix = L.en() ? (h < 12 ? "AM" : "PM") : (h < 12 ? "ص" : "م");
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return String.format(java.util.Locale.US, "%d:%02d %s", h12, m, suffix);
    }

    static String shareText(Context c) {
        return L.t("📖 تطبيق «القرآن حول العالم» لأندرويد\n")
                + L.t("قراءة واستماع وتفسير وأكثر من ٣٠ أداة إسلامية، مجانًا وبلا تسجيل.\n\n")
                + (fromPlay(c) ? PLAY_URL : APK_URL);
    }
}
