package com.hawlalaalam.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction() == null ? "" : intent.getAction();
        Context c = context.getApplicationContext();

        if (action.equals(Reminders.ACTION_PREFIX + Reminders.VERSE)) {
            PendingResult pr = goAsync();
            new Thread(() -> {
                try {
                    VerseRepo.Verse v = VerseRepo.fetchToday(c);
                    Notifier.verse(c, v);
                    VerseWidget.updateAll(c);
                } catch (Exception ignored) {
                } finally {
                    Reminders.schedule(c, Reminders.VERSE);
                    pr.finish();
                }
            }).start();
        } else if (action.equals(Reminders.ACTION_PREFIX + Reminders.WIRD)) {
            Notifier.wird(c);
            Reminders.schedule(c, Reminders.WIRD);
        } else {
            // إقلاع الجهاز، تحديث التطبيق، تغيير الوقت أو المنطقة الزمنية
            Reminders.scheduleAll(c);
        }
    }
}
