package com.hawlalaalam.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction() == null ? "" : intent.getAction();
        Context c = context.getApplicationContext();

        if (action.equals(Reminders.ACTION_PREFIX + Reminders.VERSE)) {
            PendingResult pr = goAsync();
            new Thread(() -> {
                try {
                    VerseRepo.Verse v = VerseRepo.fetchToday(c);
                    Notifier.verse(c, v);
                    VerseWidget.updateAll(c);
                } catch (Exception ignored) {
                } finally {
                    Reminders.schedule(c, Reminders.VERSE);
                    pr.finish();
                }
            }).start();
        } else if (action.equals(Reminders.ACTION_PREFIX + Reminders.WIRD)) {
            Notifier.wird(c);
            Reminders.schedule(c, Reminders.WIRD);
        } else if (action.equals(Reminders.ACTION_PREFIX + Reminders.AZKAR_AM)
                || action.equals(Reminders.ACTION_PREFIX + Reminders.AZKAR_PM)
                || action.equals(Reminders.ACTION_PREFIX + Reminders.KAHF)) {
            String kind = action.substring(Reminders.ACTION_PREFIX.length());
            Notifier.reminder(c, kind);
            Reminders.schedule(c, kind);
        } else if (action.equals(Adhan.ACTION)) {
            int idx = intent.getIntExtra(Adhan.EXTRA_INDEX, PrayerCalc.DHUHR);
            if (Adhan.enabled(c)) Notifier.adhan(c, idx);
            if (idx == PrayerCalc.MAGHRIB && Ramadan.active() && App.prefs(c).getBoolean("iftar_on", true)) Notifier.iftar(c);
            PrayerWidget.updateAll(c);
            RamadanWidget.updateAll(c);
            KhatmaWidget.updateAll(c);
            Adhan.scheduleNext(c);
        } else {
            Adhan.scheduleNext(c);
            PrayerWidget.updateAll(c);
            VerseWidget.updateAll(c);
            RamadanWidget.updateAll(c);
            KhatmaWidget.updateAll(c);
            // إقلاع الجهاز، تحديث التطبيق، تغيير الوقت أو المنطقة الزمنية
            Reminders.scheduleAll(c);
        }
    }
}
