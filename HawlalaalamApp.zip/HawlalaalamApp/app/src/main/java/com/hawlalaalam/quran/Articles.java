package com.hawlalaalam.quran;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * مقالات الموقع داخل التطبيق: القائمة والنص من articles-api.php، وتُحفظ آخر المقالات على الجهاز
 * فتُقرأ دون إنترنت. يُستدعى الجلب من خيط خلفي فقط.
 */
final class Articles {
    static final String API = App.HOME + "articles-api.php";
    static final int KEEP_OFFLINE = 20;

    private Articles() { }

    static final class Item {
        int id, minutes;
        String title, category, image, excerpt, date, url, html;

        static Item from(JSONObject o) {
            Item a = new Item();
            a.id = o.optInt("id");
            a.title = o.optString("title");
            a.category = o.optString("category");
            a.image = o.optString("image");
            a.excerpt = o.optString("excerpt");
            a.date = o.optString("date");
            a.url = o.optString("url");
            a.minutes = Math.max(1, o.optInt("minutes", 1));
            a.html = o.isNull("html") ? null : o.optString("html", null);
            return a;
        }
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "articles");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** القائمة المحفوظة (null إن لم تُجلب من قبل) */
    static JSONObject cachedList(Context c) {
        String s = read(new File(dir(c), "list.json"));
        try { return s == null ? null : new JSONObject(s); } catch (Exception e) { return null; }
    }

    /** يجلب القائمة ويحفظها، ويجلب نص آخر المقالات لتُقرأ دون إنترنت؛ يعيد null عند الفشل */
    static JSONObject refresh(Context c) {
        try {
            String s = App.get(API + "?limit=60&t=" + (System.currentTimeMillis() / 300_000L), 2_000_000);
            JSONObject o = new JSONObject(s);
            if (o.optJSONArray("articles") == null) return null;
            write(new File(dir(c), "list.json"), s);
            JSONArray arr = o.getJSONArray("articles");
            int[] ids = new int[Math.min(arr.length(), KEEP_OFFLINE)];
            for (int i = 0; i < ids.length; i++) ids[i] = arr.optJSONObject(i) == null ? 0 : arr.optJSONObject(i).optInt("id");
            new Thread(() -> prefetch(c.getApplicationContext(), ids)).start();   // القائمة تظهر فورًا، والنصوص تُحفظ بعدها
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    /** يحفظ نص آخر المقالات للقراءة دون إنترنت، ويحذف ما خرج منها */
    private static void prefetch(Context c, int[] ids) {
        java.util.Set<String> keep = new java.util.HashSet<>();
        keep.add("list.json");
        for (int id : ids) {
            if (id <= 0) continue;
            keep.add(id + ".json");
            if (!new File(dir(c), id + ".json").exists()) fetch(c, id);
        }
        File[] all = dir(c).listFiles();
        if (all != null) for (File f : all) if (!keep.contains(f.getName()) && !f.getName().endsWith(".tmp")) f.delete();
    }

    /** مقالة بنصها: من الجهاز أولًا، ثم من الموقع */
    static Item get(Context c, int id, boolean network) {
        File f = new File(dir(c), id + ".json");
        String s = read(f);
        if (s == null && network) s = fetch(c, id);
        try { return s == null ? null : Item.from(new JSONObject(s)); } catch (Exception e) { return null; }
    }

    private static String fetch(Context c, int id) {
        try {
            String s = App.get(API + "?id=" + id, 3_000_000);
            JSONObject o = new JSONObject(s);
            if (o.optInt("id") != id) return null;
            write(new File(dir(c), id + ".json"), s);
            return s;
        } catch (Exception e) {
            return null;
        }
    }

    /** «٢٢ أكتوبر» من 2026-10-22 */
    static String day(String iso) {
        String[] m = {"يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"};
        try {
            String[] p = iso.split("-");
            return Ui.arabicNum(Integer.parseInt(p[2])) + " " + m[Integer.parseInt(p[1]) - 1];
        } catch (Exception e) {
            return "";
        }
    }

    private static String read(File f) {
        if (!f.exists()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            return new String(b, 0, off, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private static void write(File f, String s) {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(s.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return;
        }
        if (!tmp.renameTo(f)) tmp.delete();
    }
}
