package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;
import android.telephony.TelephonyManager;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Calendar;
import java.util.Locale;

/**
 * إحصاءات مجهولة لـ«أثرك» و«القرآن حول العالم».
 * على الجهاز: عدد الصفحات المختلفة المقروءة اليوم. وإلى الموقع (فقط عند الموافقة أو إدخال رمز دعوة):
 * عدد صفحات جديدة منذ آخر إرسال + رمز الدولة (للخريطة) + رمز الداعي (للأثر). بلا موقع ولا معرّف للجهاز.
 */
final class Stats {
    static final String API = App.HOME + "stats-api.php";
    private static final String ALPHA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";   // بلا حروف تلتبس (O/0، I/1، L)
    private static final long SYNC_EVERY = 3 * 3_600_000L;

    private Stats() { }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    private static int dayKey() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH);
    }

    // ---------- العدّ على الجهاز

    /** صفحة فُتحت في المصحف ومكث عليها القارئ (تُستدعى من Khatma.onUrl قبل فحص الختمة) */
    static void onPage(Context c, int page) {
        if (page < 1 || page > 604) return;
        int day = dayKey();
        String bits = p(c).getString("st_bits", "");
        if (p(c).getInt("st_day", 0) != day || bits.length() != 604) {
            char[] z = new char[604];
            java.util.Arrays.fill(z, '0');
            bits = new String(z);
            p(c).edit().putInt("st_day", day).putInt("st_today", 0).apply();
        }
        if (bits.charAt(page - 1) == '1') return;
        char[] b = bits.toCharArray();
        b[page - 1] = '1';
        p(c).edit().putString("st_bits", new String(b))
                .putInt("st_today", p(c).getInt("st_today", 0) + 1)
                .putInt("st_pending", Math.min(5000, p(c).getInt("st_pending", 0) + 1))
                .apply();
    }

    /** صفحات اليوم على هذا الجهاز */
    static int today(Context c) { return p(c).getInt("st_day", 0) == dayKey() ? p(c).getInt("st_today", 0) : 0; }

    /** اكتملت ختمة: تُحسب لمن دعاك */
    static void onKhatma(Context c) {
        if (!ref(c).isEmpty()) p(c).edit().putInt("st_khatma_pending", p(c).getInt("st_khatma_pending", 0) + 1).apply();
    }

    // ---------- الموافقة والرموز

    /** «أضِف قراءتي للخريطة» (مطفأ افتراضيًا) */
    static boolean mapOn(Context c) { return p(c).getBoolean("st_map", false); }

    static void setMapOn(Context c, boolean on) { p(c).edit().putBoolean("st_map", on).apply(); }

    /** رمزك الذي تشاركه (يُنشأ عشوائيًا عند أول طلب) */
    static String code(Context c) {
        String s = p(c).getString("st_code", null);
        if (s != null) return s;
        SecureRandom r = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 6; i++) b.append(ALPHA.charAt(r.nextInt(ALPHA.length())));
        s = b.toString();
        p(c).edit().putString("st_code", s).apply();
        return s;
    }

    static String link(Context c) { return "https://7awlalaalam.com/app?r=" + code(c); }

    static String shareText(Context c) {
        return "تطبيق «القرآن حول العالم»: مصحف وتلاوات ومواقيت وأذان وأذكار، بلا إعلانات ولا حساب.\n"
                + "حمّله من هنا: " + link(c) + "\n\n"
                + "وعند فتحه اكتب رمز الدعوة " + code(c) + " في «أثرك» ليُكتب لي أثر قراءتك، «من دلّ على خير فله مثل أجر فاعله».";
    }

    /** رمز من دعاك (فارغ إن لم يُدخَل) */
    static String ref(Context c) { return p(c).getString("st_ref", ""); }

    static String clean(String s) {
        if (s == null) return "";
        s = s.trim().toUpperCase(Locale.ROOT);
        int i = s.lastIndexOf("R=");
        if (i >= 0) s = s.substring(i + 2);
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) if (ALPHA.indexOf(ch) >= 0) b.append(ch);
        return b.length() == 6 ? b.toString() : "";
    }

    /** يحفظ رمز الداعي؛ يُرجع رسالة خطأ أو null */
    static String setRef(Context c, String raw) {
        String s = clean(raw);
        if (s.isEmpty()) return "الرمز من ٦ حروف وأرقام، مثل K7Q2MA";
        if (s.equals(code(c))) return "هذا رمزك أنت، اكتب رمز من دعاك";
        if (!ref(c).isEmpty()) return "سجّلت رمزًا من قبل";
        p(c).edit().putString("st_ref", s).putBoolean("st_ref_joined", false).apply();
        return null;
    }

    // ---------- الدولة

    /** رمز الدولة من شريحة الجوال أو الشبكة، ثم إعدادات اللغة. لا يُستخدم الموقع. */
    static String country(Context c) {
        try {
            TelephonyManager tm = c.getSystemService(TelephonyManager.class);
            if (tm != null) {
                String s = tm.getSimCountryIso();
                if (s == null || s.length() != 2) s = tm.getNetworkCountryIso();
                if (s != null && s.length() == 2) return s.toUpperCase(Locale.ROOT);
            }
        } catch (Exception ignored) { }
        String s = Locale.getDefault().getCountry();
        return s != null && s.length() == 2 ? s.toUpperCase(Locale.ROOT) : "";
    }

    static String countryName(String cc) {
        if (cc == null || cc.length() != 2) return "";
        String n = new Locale("", cc).getDisplayCountry(new Locale("ar"));
        return n == null || n.isEmpty() || n.equals(cc) ? cc : n;
    }

    // ---------- المزامنة

    /** تُستدعى عند فتح التطبيق (من خيط خلفي) — لا ترسل شيئًا إن لم يوافق المستخدم ولم يُدخل رمز دعوة */
    static void syncAsync(Context c) {
        Context app = c.getApplicationContext();
        if (!mapOn(app) && ref(app).isEmpty()) return;
        long last = p(app).getLong("st_sync_at", 0);
        if (System.currentTimeMillis() - last < SYNC_EVERY && p(app).getBoolean("st_ref_joined", true)) return;
        new Thread(() -> sync(app)).start();
    }

    static synchronized void sync(Context c) {
        try {
            String ref = ref(c);
            boolean map = mapOn(c);
            if (!map && ref.isEmpty()) return;
            if (!ref.isEmpty() && !p(c).getBoolean("st_ref_joined", true)) {
                JSONObject j = new JSONObject().put("action", "join").put("ref", ref);
                if (post(j) != null) p(c).edit().putBoolean("st_ref_joined", true).apply();
            }
            int pending = p(c).getInt("st_pending", 0);
            int khatmas = p(c).getInt("st_khatma_pending", 0);
            if (pending > 0 || khatmas > 0) {
                JSONObject j = new JSONObject().put("action", "add").put("pages", Math.min(pending, 604));
                if (map) j.put("cc", country(c));
                if (!ref.isEmpty()) j.put("ref", ref).put("khatmas", Math.min(khatmas, 3));
                if (post(j) != null) {
                    p(c).edit().putInt("st_pending", Math.max(0, p(c).getInt("st_pending", 0) - Math.min(pending, 604)))
                            .putInt("st_khatma_pending", Math.max(0, p(c).getInt("st_khatma_pending", 0) - Math.min(khatmas, 3)))
                            .apply();
                }
            }
            p(c).edit().putLong("st_sync_at", System.currentTimeMillis()).apply();
        } catch (Exception ignored) { }
    }

    /** خريطة اليوم (من خيط خلفي) */
    static JSONObject world() throws Exception {
        return new JSONObject(App.get(API + "?action=world", 64 * 1024));
    }

    /** أثر رمزك (من خيط خلفي) */
    static JSONObject impact(Context c) throws Exception {
        return new JSONObject(App.get(API + "?action=ref&code=" + code(c), 16 * 1024));
    }

    private static String post(JSONObject body) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(API).openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(15000);
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("User-Agent", "HawlalaalamApp/1 (Android)");
            byte[] b = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = con.getOutputStream()) { o.write(b); }
            if (con.getResponseCode() >= 400) return null;
            try (java.io.InputStream in = con.getInputStream()) {
                byte[] buf = new byte[2048];
                int n = in.read(buf);
                return n > 0 ? new String(buf, 0, n, StandardCharsets.UTF_8) : "";
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
