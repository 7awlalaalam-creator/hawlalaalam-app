package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** بوصلة القبلة: من حساسات الجوال، وتعمل بدون إنترنت */
public class QiblaActivity extends Activity implements SensorEventListener {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    private static final double KAABA_LAT = 21.422487, KAABA_LNG = 39.826206;
    private static final int REQ_LOC = 51;

    private SensorManager sm;
    private Sensor rotation;
    private CompassView compass;
    private TextView status, details, place;
    private float qibla = -1;          // اتجاه القبلة من الشمال الحقيقي
    private float declination = 0;
    private float heading = 0;         // اتجاه الجوال (مُنعّم)
    private boolean aligned = false;
    private int ink, muted, gold;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(18), dp(14), dp(18), dp(30));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setContentDescription("رجوع");
        back.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = Ui.text(this, "اتجاه القبلة", 24, ink, 700);
        title.setPadding(dp(14), 0, dp(14), 0);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        place = Ui.text(this, "", 14, muted, 400);
        place.setGravity(Gravity.CENTER);
        place.setPadding(0, dp(18), 0, dp(6));
        col.addView(place, new LinearLayout.LayoutParams(-1, -2));

        compass = new CompassView(this);
        int size = Math.min(getResources().getDisplayMetrics().widthPixels - dp(40), dp(360));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(size, size);
        clp.topMargin = dp(10);
        col.addView(compass, clp);

        status = Ui.text(this, "", 20, ink, 700);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(22), 0, dp(6));
        col.addView(status, new LinearLayout.LayoutParams(-1, -2));

        details = Ui.text(this, "", 14, muted, 400);
        details.setGravity(Gravity.CENTER);
        col.addView(details, new LinearLayout.LayoutParams(-1, -2));

        TextView tip = Ui.text(this, "ضع الجوال مسطحًا بعيدًا عن المعادن والمغناطيس. إذا كانت القراءة غير مستقرة، حرّك الجوال في الهواء على شكل الرقم 8 لمعايرة البوصلة.", 13, muted, 400);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(dp(8), dp(22), dp(8), 0);
        col.addView(tip, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.page));
        scroll.addView(col);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        sm = getSystemService(SensorManager.class);
        rotation = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rotation == null) {
            status.setText("جوالك لا يحتوي على بوصلة");
            details.setText("اتجاه القبلة يظهر بالدرجات من الشمال");
        }
        setupLocation();
    }

    private void setupLocation() {
        if (Adhan.hasLocation(this)) {
            applyLocation(App.prefs(this).getFloat("lat", 0), App.prefs(this).getFloat("lng", 0));
        } else {
            place.setText("جارٍ تحديد موقعك…");
        }
        if (!Loc.hasPermission(this)) {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        Loc.get(this, l -> {
            if (l == null) {
                if (!Adhan.hasLocation(this)) place.setText("تعذّر تحديد الموقع، فعّل خدمة الموقع (GPS)");
                return;
            }
            Adhan.saveLocation(this, l.getLatitude(), l.getLongitude());
            applyLocation(l.getLatitude(), l.getLongitude());
            new Thread(() -> {
                String c = Loc.cityName(getApplicationContext(), l.getLatitude(), l.getLongitude());
                Adhan.saveCity(getApplicationContext(), c);
                runOnUiThread(() -> applyLocation(l.getLatitude(), l.getLongitude()));
            }).start();
        });
    }

    private void applyLocation(double lat, double lng) {
        qibla = (float) bearing(lat, lng, KAABA_LAT, KAABA_LNG);
        declination = new GeomagneticField((float) lat, (float) lng, 0, System.currentTimeMillis()).getDeclination();
        double km = distanceKm(lat, lng, KAABA_LAT, KAABA_LNG);
        String city = Adhan.city(this);
        // فاصل «—» بدل «·» لأن النقطة تُقرأ صفرًا عربيًا (٠) بجوار الأرقام
        place.setText((city.isEmpty() ? "موقعك الحالي" : city) + " — تبعد " + Adhan.arabic(String.valueOf(Math.round(km))) + " كم عن مكة المكرمة");
        details.setText("اتجاه القبلة " + Adhan.arabic(String.valueOf(Math.round(qibla))) + "° من الشمال");
        compass.setQibla(qibla);
        updateStatus();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_LOC) {
            if (Loc.hasPermission(this)) setupLocation();
            else place.setText("نحتاج إذن الموقع لتحديد اتجاه القبلة");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (rotation != null) sm.registerListener(this, rotation, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sm != null) sm.unregisterListener(this);
    }

    private final float[] matrix = new float[9];
    private final float[] orientation = new float[3];

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(matrix, e.values);
        SensorManager.getOrientation(matrix, orientation);
        float az = (float) Math.toDegrees(orientation[0]) + declination;   // الشمال الحقيقي
        az = (az + 360) % 360;
        float diff = ((az - heading + 540) % 360) - 180;                   // تنعيم دائري
        heading = (heading + diff * 0.15f + 360) % 360;
        compass.setHeading(heading);
        updateStatus();
    }

    @Override
    public void onAccuracyChanged(Sensor s, int accuracy) {
        compass.setLowAccuracy(accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW);
    }

    private void updateStatus() {
        if (qibla < 0 || rotation == null) return;
        float off = ((qibla - heading + 540) % 360) - 180;
        boolean now = Math.abs(off) <= 4;
        if (now && !aligned) compass.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
        aligned = now;
        compass.setAligned(now);
        if (now) {
            status.setText("✓ أنت باتجاه القبلة");
            status.setTextColor(gold);
        } else {
            status.setText(off > 0 ? "استدر نحو اليمين ↻" : "استدر نحو اليسار ↺");
            status.setTextColor(ink);
        }
    }

    static double bearing(double lat1, double lng1, double lat2, double lng2) {
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2), dl = Math.toRadians(lng2 - lng1);
        double y = Math.sin(dl) * Math.cos(p2);
        double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        return (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
    }

    static double distanceKm(double lat1, double lng1, double lat2, double lng2) {
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private int dp(int v) { return Ui.dp(this, v); }

    /** قرص البوصلة بهوية الموقع */
    static class CompassView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float heading, qibla = -1;
        private boolean aligned, lowAccuracy;
        private final int ink, gold, goldLight, ivory, line, muted;

        CompassView(Context c) {
            super(c);
            ink = c.getColor(R.color.ink);
            gold = c.getColor(R.color.gold_deep);
            goldLight = c.getColor(R.color.gold);
            ivory = c.getColor(R.color.ivory);
            line = c.getColor(R.color.ivory_border);
            muted = c.getColor(R.color.muted);
            p.setTypeface(Ui.font(c, 700));
            setContentDescription("بوصلة القبلة");
        }

        void setHeading(float h) { heading = h; invalidate(); }
        void setQibla(float q) { qibla = q; invalidate(); }
        void setAligned(boolean a) { if (a != aligned) { aligned = a; invalidate(); } }
        void setLowAccuracy(boolean l) { lowAccuracy = l; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) - dpx(10);

            // الحلقة الخارجية
            p.setStyle(Paint.Style.FILL);
            p.setColor(aligned ? goldLight : 0xFF123640);
            c.drawCircle(cx, cy, r, p);
            p.setColor(ivory);
            c.drawCircle(cx, cy, r - dpx(10), p);

            // القرص الدوّار (ينعكس مع اتجاه الجوال)
            c.save();
            c.rotate(-heading, cx, cy);
            for (int d = 0; d < 360; d += 5) {
                boolean major = d % 30 == 0;
                p.setColor(major ? ink : line);
                p.setStrokeWidth(dpx(major ? 2.5f : 1.5f));
                float r1 = r - dpx(16), r2 = r1 - dpx(major ? 14 : 7);
                double a = Math.toRadians(d);
                c.drawLine(cx + (float) (r1 * Math.sin(a)), cy - (float) (r1 * Math.cos(a)),
                        cx + (float) (r2 * Math.sin(a)), cy - (float) (r2 * Math.cos(a)), p);
            }
            String[] dirs = {"ش", "ق", "ج", "غ"};
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dpx(20));
            for (int i = 0; i < 4; i++) {
                double a = Math.toRadians(i * 90);
                float tr = r - dpx(48);
                p.setColor(i == 0 ? 0xFFB3412F : ink);
                c.drawText(dirs[i], cx + (float) (tr * Math.sin(a)), cy - (float) (tr * Math.cos(a)) + dpx(7), p);
            }
            // مؤشر القبلة على القرص
            if (qibla >= 0) {
                double a = Math.toRadians(qibla);
                float kr = r - dpx(88);
                float kx = cx + (float) (kr * Math.sin(a)), ky = cy - (float) (kr * Math.cos(a));
                p.setColor(goldLight);
                p.setStrokeWidth(dpx(3));
                c.drawLine(cx, cy, kx, ky, p);
                drawKaaba(c, kx, ky, dpx(26), (float) qibla);
            }
            c.restore();

            // سهم ثابت أعلى القرص = اتجاه الجوال
            Path tri = new Path();
            tri.moveTo(cx, cy - r - dpx(2));
            tri.lineTo(cx - dpx(12), cy - r + dpx(18));
            tri.lineTo(cx + dpx(12), cy - r + dpx(18));
            tri.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(aligned ? 0xFFFFFFFF : gold);
            c.drawPath(tri, p);

            // المركز
            p.setColor(ink);
            c.drawCircle(cx, cy, dpx(7), p);

            if (lowAccuracy) {
                p.setColor(muted);
                p.setTextSize(dpx(12));
                c.drawText("البوصلة تحتاج معايرة", cx, cy + r * 0.45f, p);
            }
        }

        private void drawKaaba(Canvas c, float x, float y, float s, float rot) {
            c.save();
            c.rotate(rot, x, y);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF111111);
            c.drawRoundRect(new RectF(x - s / 2, y - s / 2, x + s / 2, y + s / 2), dpx(3), dpx(3), p);
            p.setColor(goldLight);
            c.drawRect(x - s / 2, y - s / 2 + s * 0.22f, x + s / 2, y - s / 2 + s * 0.34f, p);
            c.restore();
        }

        private float dpx(float v) { return v * getResources().getDisplayMetrics().density; }
    }
}
