package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * القرّاء والإذاعات من mp3quran.net (المصدر نفسه الذي يستخدمه الموقع)، مع نسخة محفوظة على الجهاز
 * تُحدَّث كل ٣ أيام، والمفضّلون وآخر استماع.
 */
final class Reciters {
    private Reciters() { }

    static final String API = "https://mp3quran.net/api/v3/reciters?language=ar";
    static final String RADIOS = "https://mp3quran.net/api/v3/radios?language=ar";
    private static final long FRESH = 3L * 24 * 3600_000L;

    static final class Moshaf {
        int id;
        String name, server;
        int total;
        int[] surahs;

        boolean has(int s) {
            for (int x : surahs) if (x == s) return true;
            return false;
        }

        /** رابط السورة: server + 001.mp3 */
        String url(int s) {
            String base = server.endsWith("/") ? server : server + "/";
            return base + String.format(Locale.US, "%03d", s) + ".mp3";
        }
    }

    static final class Reciter {
        int id;
        String name, letter;
        final List<Moshaf> moshaf = new ArrayList<>();

        Moshaf moshaf(int id) {
            for (Moshaf m : moshaf) if (m.id == id) return m;
            return moshaf.isEmpty() ? null : moshaf.get(0);
        }

        /** أسماء الروايات مختصرة للعرض */
        String tags() {
            LinkedHashSet<String> t = new LinkedHashSet<>();
            for (Moshaf m : moshaf) t.add(shortName(m.name));
            StringBuilder b = new StringBuilder();
            for (String s : t) { if (b.length() > 0) b.append(" · "); b.append(s); if (b.length() > 40) break; }
            return b.toString();
        }
    }

    static final class Radio {
        String name, url;
    }

    /** «رواية حفص عن عاصم - مرتل» ← «حفص · مرتل» */
    static String shortName(String n) {
        if (n == null) return "";
        String s = n.replace("رواية", "").replace("عن عاصم", "").replace(" - ", " · ").replace("-", " · ").trim();
        while (s.contains("  ")) s = s.replace("  ", " ");
        return s;
    }

    private static volatile List<Reciter> cache;
    private static volatile List<Radio> radios;

    private static File file(Context c, String name) { return new File(c.getFilesDir(), name); }

    private static String readFile(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            return new String(b, 0, off, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private static void writeFile(File f, String s) {
        try (FileOutputStream out = new FileOutputStream(f)) { out.write(s.getBytes(StandardCharsets.UTF_8)); }
        catch (Exception ignored) { }
    }

    /** القائمة المحفوظة فورًا (أو null)، دون اتصال */
    static List<Reciter> cached(Context c) {
        if (cache != null) return cache;
        String s = readFile(file(c, "reciters.json"));
        if (s == null) return null;
        try { cache = parse(s); } catch (Exception e) { return null; }
        return cache;
    }

    static boolean stale(Context c) {
        File f = file(c, "reciters.json");
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > FRESH;
    }

    /** يحدّث من الإنترنت (خيط خلفي). يعيد القائمة أو المحفوظة إن تعذّر */
    static List<Reciter> load(Context c, boolean force) {
        List<Reciter> have = cached(c);
        if (have != null && !force && !stale(c)) return have;
        try {
            String s = App.get(API, 6_000_000);
            List<Reciter> list = parse(s);
            if (!list.isEmpty()) {
                writeFile(file(c, "reciters.json"), s);
                cache = list;
                return list;
            }
        } catch (Exception ignored) { }
        return have;
    }

    static List<Radio> cachedRadios(Context c) {
        if (radios != null) return radios;
        String s = readFile(file(c, "radios.json"));
        if (s == null) return null;
        try { radios = parseRadios(s); } catch (Exception e) { return null; }
        return radios;
    }

    static List<Radio> loadRadios(Context c) {
        List<Radio> have = cachedRadios(c);
        File f = file(c, "radios.json");
        if (have != null && System.currentTimeMillis() - f.lastModified() < FRESH) return have;
        try {
            String s = App.get(RADIOS, 2_000_000);
            List<Radio> list = parseRadios(s);
            if (!list.isEmpty()) { writeFile(f, s); radios = list; return list; }
        } catch (Exception ignored) { }
        return have;
    }

    private static List<Reciter> parse(String s) throws Exception {
        JSONArray arr = new JSONObject(s).getJSONArray("reciters");
        List<Reciter> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Reciter r = new Reciter();
            r.id = o.optInt("id");
            r.name = o.optString("name").trim();
            r.letter = o.optString("letter");
            JSONArray ms = o.optJSONArray("moshaf");
            if (ms == null) continue;
            for (int k = 0; k < ms.length(); k++) {
                JSONObject m = ms.getJSONObject(k);
                Moshaf x = new Moshaf();
                x.id = m.optInt("id");
                x.name = m.optString("name");
                x.server = m.optString("server");
                x.total = m.optInt("surah_total");
                String[] parts = m.optString("surah_list").split(",");
                List<Integer> nums = new ArrayList<>();
                for (String p : parts) {
                    try { int n = Integer.parseInt(p.trim()); if (n >= 1 && n <= 114) nums.add(n); } catch (Exception ignored) { }
                }
                java.util.Collections.sort(nums);
                x.surahs = new int[nums.size()];
                for (int j = 0; j < nums.size(); j++) x.surahs[j] = nums.get(j);
                if (x.server.startsWith("http") && x.surahs.length > 0) r.moshaf.add(x);
            }
            if (!r.moshaf.isEmpty() && !r.name.isEmpty()) out.add(r);
        }
        java.text.Collator col = java.text.Collator.getInstance(new Locale("ar"));
        out.sort((a, b) -> col.compare(a.name, b.name));
        return out;
    }

    private static List<Radio> parseRadios(String s) throws Exception {
        JSONArray arr = new JSONObject(s).getJSONArray("radios");
        List<Radio> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Radio r = new Radio();
            r.name = o.optString("name").trim();
            r.url = o.optString("url");
            if (r.url.startsWith("http") && !r.name.isEmpty()) out.add(r);
        }
        return out;
    }

    static Reciter byId(Context c, int id) {
        List<Reciter> l = cached(c);
        if (l != null) for (Reciter r : l) if (r.id == id) return r;
        return null;
    }

    // ------------------------------------------------------------------ المفضّلون

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static Set<Integer> favorites(Context c) {
        Set<Integer> out = new LinkedHashSet<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("listen_favs", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getInt(i));
        } catch (Exception ignored) { }
        return out;
    }

    static boolean isFavorite(Context c, int id) { return favorites(c).contains(id); }

    static void toggleFavorite(Context c, int id) {
        Set<Integer> f = favorites(c);
        if (!f.remove(id)) f.add(id);
        JSONArray a = new JSONArray();
        for (int x : f) a.put(x);
        p(c).edit().putString("listen_favs", a.toString()).apply();
    }

    /** حرف الدائرة: أول حرف من الاسم، وإن كان ألفًا (يُرى كعلامة) فأول حرف من آخر كلمة */
    static String initial(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return "";
        String[] w = n.split("\\s+");
        String c = w[0].substring(0, 1);
        if ("اأإآ".contains(c) && w.length > 1 && !w[w.length - 1].isEmpty()) c = w[w.length - 1].substring(0, 1);
        if ("أإآ".contains(c)) c = "ا";
        return c;
    }
}
