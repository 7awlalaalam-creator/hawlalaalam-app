package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * الختمة الذكية: تتبّع صفحات المصحف المقروءة تلقائيًا (عند فتح mushaf-page-N)،
 * وتوزيع الباقي على الأيام المتبقية بهدوء إن فات يوم.
 */
final class Khatma {
    static final int PAGES = 604;
    private static final Pattern PAGE = Pattern.compile("mushaf-page-(\\d{1,3})\\.html");

    private Khatma() { }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("khatma", Context.MODE_PRIVATE); }

    static long today() {
        Calendar cal = Calendar.getInstance();
        return (cal.getTimeInMillis() + cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET)) / 86_400_000L;
    }

    static boolean active(Context c) { return p(c).getBoolean("active", false); }

    private static String bits(Context c) {
        String b = p(c).getString("pages", null);
        if (b == null || b.length() != PAGES) {
            StringBuilder sb = new StringBuilder(PAGES);
            for (int i = 0; i < PAGES; i++) sb.append('0');
            b = sb.toString();
        }
        return b;
    }

    /** بدء ختمة جديدة تنتهي بعد عدد أيام */
    static void start(Context c, int days, String label) {
        long t = today();
        StringBuilder sb = new StringBuilder(PAGES);
        for (int i = 0; i < PAGES; i++) sb.append('0');
        p(c).edit().putBoolean("active", true).putString("pages", sb.toString())
                .putLong("start", t).putLong("end", t + Math.max(1, days) - 1).putString("label", label)
                .putLong("day", t).putInt("today_count", 0).putInt("today_from", 1).putLong("last_read", t - 1)
                .apply();
        if (!Reminders.enabled(c, Reminders.WIRD)) {
            Reminders.set(c, Reminders.WIRD, true, Reminders.hour(c, Reminders.WIRD), Reminders.minute(c, Reminders.WIRD));
        }
    }

    static void stop(Context c) { p(c).edit().putBoolean("active", false).apply(); }

    static String label(Context c) { return p(c).getString("label", ""); }
    static int completed(Context c) { return p(c).getInt("completed", 0); }

    /** يُستدعى عند فتح أي صفحة في التطبيق */
    static void onUrl(Context c, String url) {
        if (url == null || !active(c)) return;
        Matcher m = PAGE.matcher(url);
        if (!m.find()) return;
        int page = Integer.parseInt(m.group(1));
        if (page < 1 || page > PAGES) return;
        ensureDay(c);
        char[] b = bits(c).toCharArray();
        if (b[page - 1] == '1') return;
        b[page - 1] = '1';
        SharedPreferences.Editor e = p(c).edit().putString("pages", new String(b))
                .putInt("today_count", p(c).getInt("today_count", 0) + 1)
                .putLong("last_read", today());
        if (readCount(new String(b)) >= PAGES) {
            e.putInt("completed", p(c).getInt("completed", 0) + 1).putBoolean("just_done", true);
        }
        e.apply();
        Reading.markToday(c);
    }

    /** بداية يوم جديد: نثبّت نقطة انطلاق ورد اليوم */
    static void ensureDay(Context c) {
        long t = today();
        if (p(c).getLong("day", -1) == t) return;
        p(c).edit().putLong("day", t).putInt("today_count", 0).putInt("today_from", nextPage(c)).apply();
    }

    private static int readCount(String b) {
        int n = 0;
        for (int i = 0; i < b.length(); i++) if (b.charAt(i) == '1') n++;
        return n;
    }

    static int read(Context c) { return readCount(bits(c)); }

    static int percent(Context c) { return Math.round(read(c) * 100f / PAGES); }

    static boolean done(Context c) { return read(c) >= PAGES; }

    /** أول صفحة لم تُقرأ */
    static int nextPage(Context c) {
        int i = bits(c).indexOf('0');
        return i < 0 ? PAGES : i + 1;
    }

    static int daysLeft(Context c) {
        return (int) Math.max(1, p(c).getLong("end", today()) - today() + 1);
    }

    /** عدد صفحات ورد اليوم (يُعاد توزيعه تلقائيًا إن فات يوم) */
    static int dailyTarget(Context c) {
        ensureDay(c);
        int remainingAtDayStart = PAGES - read(c) + p(c).getInt("today_count", 0);
        return Math.max(1, (int) Math.ceil(remainingAtDayStart / (double) daysLeft(c)));
    }

    static int todayCount(Context c) { ensureDay(c); return p(c).getInt("today_count", 0); }

    /** [من، إلى] صفحات ورد اليوم */
    static int[] todayRange(Context c) {
        ensureDay(c);
        int from = Math.max(1, p(c).getInt("today_from", nextPage(c)));
        int to = Math.min(PAGES, from + dailyTarget(c) - 1);
        return new int[]{from, to};
    }

    /** بقي من ورد اليوم */
    static int todayRemaining(Context c) { return Math.max(0, dailyTarget(c) - todayCount(c)); }

    /** فات يوم أو أكثر دون قراءة؟ (لرسالة التطمين) */
    static boolean missedDays(Context c) {
        long t = today();
        return active(c) && p(c).getLong("start", t) < t - 1 && p(c).getLong("last_read", t) < t - 1;
    }

    /** تاريخ الختم المتوقع كنص هجري قصير */
    static String endDateText(Context c) {
        long end = p(c).getLong("end", today());
        long millis = end * 86_400_000L - java.util.TimeZone.getDefault().getOffset(end * 86_400_000L) + 12 * 3_600_000L;
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            return new android.icu.text.SimpleDateFormat("d MMMM", loc).format(new java.util.Date(millis));
        } catch (Throwable e) {
            return "";
        }
    }

    static String pageUrl(int page) { return App.HOME + "mushaf-page-" + page + ".html"; }

    static boolean consumeJustDone(Context c) {
        boolean d = p(c).getBoolean("just_done", false);
        if (d) p(c).edit().putBoolean("just_done", false).apply();
        return d;
    }
}
