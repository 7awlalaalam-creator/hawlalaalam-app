package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * الختمة الذكية (الإصدار ٢)
 * - خطة حسب المدة أو حسب الورد اليومي، وتبدأ من الفاتحة أو من حيث توقف القارئ.
 * - أيام راحة اختيارية، وسياسة واضحة عند فوات يوم: توزيع الباقي أو تمديد الموعد.
 * - الورد ينتهي عند نهاية الجزء إن كانت قريبة، ويُعرض باسم السورة والجزء.
 * - تُحتسب الصفحة مقروءة بعد بقاء القارئ عليها مدة كافية (لا بمجرد التصفح).
 * - سجل يومي وسجل للختمات السابقة.
 * المفاتيح القديمة محفوظة كما هي، فالختمات الجارية تستمر بعد التحديث.
 */
final class Khatma {
    static final int PAGES = 604;
    /** مدة البقاء على الصفحة لتُحتسب مقروءة */
    static final long DWELL_MS = 12_000L;

    static final String MODE_DAYS = "days", MODE_PAGES = "pages";

    /** صفحة المصحف في الموقع: mushaf-pages-ar.html?page=4 (والصيغة القديمة mushaf-page-4.html) */
    private static final Pattern PAGE = Pattern.compile("mushaf-page-(\\d{1,3})\\.html|mushaf-pages[^?#]*\\?(?:[^#]*&)?page=(\\d{1,3})");

    /** بداية كل جزء في مصحف المدينة */
    static final int[] JUZ_START = {1, 22, 42, 62, 82, 102, 121, 142, 162, 182, 201, 222, 242, 262, 282,
            302, 322, 342, 362, 382, 402, 422, 442, 462, 482, 502, 522, 542, 562, 582};

    /** صفحة بداية كل سورة في مصحف المدينة */
    static final int[] SURAH_START = {1, 2, 50, 77, 106, 128, 151, 177, 187, 208, 221, 235, 249, 255, 262, 267,
            282, 293, 305, 312, 322, 332, 342, 350, 359, 367, 377, 385, 396, 404, 411, 415, 418, 428, 434, 440,
            446, 453, 458, 467, 477, 483, 489, 496, 499, 502, 507, 511, 515, 518, 520, 523, 526, 528, 531, 534,
            537, 542, 545, 549, 551, 553, 554, 556, 558, 560, 562, 564, 566, 568, 570, 572, 574, 575, 577, 578,
            580, 582, 583, 585, 586, 587, 587, 589, 590, 591, 591, 592, 593, 594, 595, 595, 596, 596, 597, 597,
            598, 598, 599, 599, 600, 600, 601, 601, 601, 602, 602, 602, 603, 603, 603, 604, 604, 604};

    private Khatma() { }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("khatma", Context.MODE_PRIVATE); }

    // ------------------------------------------------------------------ الأيام

    static long today() {
        Calendar cal = Calendar.getInstance();
        return (cal.getTimeInMillis() + cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET)) / 86_400_000L;
    }

    /** يوم الأسبوع بترقيم Calendar (الأحد = ١) — اليوم صفر (١٩٧٠/١/١) كان خميسًا */
    static int dow(long day) { return (int) (((day + 4) % 7 + 7) % 7) + 1; }

    /** أيام الراحة: قناع بتّات حسب Calendar.DAY_OF_WEEK */
    static int offMask(Context c) { return p(c).getInt("off_days", 0); }

    static boolean isReadingDay(Context c, long day) { return (offMask(c) & (1 << dow(day))) == 0; }

    static boolean readingToday(Context c) { return isReadingDay(c, today()); }

    /** عدد أيام القراءة بين يومين (شاملة الطرفين) */
    static int readingDays(int mask, long from, long to) {
        int n = 0;
        for (long d = from; d <= to; d++) if ((mask & (1 << dow(d))) == 0) n++;
        return n;
    }

    /** اليوم الذي تكتمل فيه كمية من الأيام القرائية بدءًا من يوم معيّن */
    static long dayAfterReadingDays(int mask, long from, int count) {
        if (mask == 0b11111110) mask = 0;                 // حماية: لا يجوز أن تكون كل الأيام راحة
        long d = from;
        int n = 0;
        while (true) {
            if ((mask & (1 << dow(d))) == 0 && ++n >= Math.max(1, count)) return d;
            d++;
        }
    }

    // ------------------------------------------------------------------ الحالة

    static boolean active(Context c) { return p(c).getBoolean("active", false); }
    static String label(Context c) { return p(c).getString("label", ""); }
    static int completed(Context c) { return p(c).getInt("completed", 0); }
    static String mode(Context c) { return p(c).getString("mode", MODE_DAYS); }
    /** true: الورد اليومي ثابت ويتمدّد الموعد عند فوات يوم */
    static boolean fixedPace(Context c) { return MODE_PAGES.equals(mode(c)) || p(c).getBoolean("extend", false); }
    static long startDay(Context c) { return p(c).getLong("start", today()); }
    static long endDay(Context c) { ensureDay(c); return p(c).getLong("end", today()); }
    static int startPage(Context c) { return Math.max(1, Math.min(PAGES, p(c).getInt("start_page", 1))); }

    /** الورد اليومي المخطط له (للختمات القديمة يُحسب من مدتها) */
    static int pace(Context c) {
        int v = p(c).getInt("ppd", 0);
        if (v > 0) return v;
        long s = p(c).getLong("start", today()), e = p(c).getLong("end", today());
        return Math.max(1, (int) Math.ceil(PAGES / (double) Math.max(1, e - s + 1)));
    }

    private static String bits(Context c) {
        String b = p(c).getString("pages", null);
        if (b == null || b.length() != PAGES) b = zeros();
        return b;
    }

    private static String zeros() {
        StringBuilder sb = new StringBuilder(PAGES);
        for (int i = 0; i < PAGES; i++) sb.append('0');
        return sb.toString();
    }

    /** إعدادات خطة جديدة أو معدّلة */
    static final class Plan {
        String mode = MODE_DAYS;
        int days = 30;          // لوضع المدة
        int ppd = 20;           // لوضع الورد اليومي
        int startPage = 1;
        int offMask = 0;
        boolean extend = false; // لوضع المدة: عند فوات يوم نمدّد الموعد بدل زيادة الورد
        String label = "";

        /** عدد صفحات الورد اليومي لهذه الخطة */
        int pace(int remaining) {
            if (MODE_PAGES.equals(mode)) return Math.max(1, ppd);
            long t = today();
            int rd = readingDays(offMask, t, t + Math.max(1, days) - 1);
            return Math.max(1, (int) Math.ceil(remaining / (double) Math.max(1, rd)));
        }

        /** يوم الختم المتوقع */
        long end(int remaining) {
            long t = today();
            if (MODE_DAYS.equals(mode)) return t + Math.max(1, days) - 1;
            return dayAfterReadingDays(offMask, t, (int) Math.ceil(remaining / (double) Math.max(1, ppd)));
        }
    }

    /** بدء ختمة جديدة */
    static void start(Context c, Plan plan) {
        long t = today();
        int pace = plan.pace(PAGES);
        p(c).edit().putBoolean("active", true).putString("pages", zeros())
                .putString("mode", plan.mode).putInt("ppd", pace).putBoolean("extend", plan.extend)
                .putInt("start_page", Math.max(1, Math.min(PAGES, plan.startPage)))
                .putInt("off_days", plan.offMask == 0b11111110 ? 0 : plan.offMask)
                .putLong("start", t).putLong("end", plan.end(PAGES)).putString("label", plan.label)
                .putLong("base_day", t).putInt("base_read", 0)
                .putLong("day", t).putInt("today_count", 0).putLong("last_read", t - 1)
                .putBoolean("extended_note", false)
                .apply();
        p(c).edit().putInt("today_from", nextPage(c)).apply();
        if (!Reminders.enabled(c, Reminders.WIRD)) {
            Reminders.set(c, Reminders.WIRD, true, Reminders.hour(c, Reminders.WIRD), Reminders.minute(c, Reminders.WIRD));
        }
    }

    /** تعديل الخطة مع الإبقاء على التقدّم */
    static void replan(Context c, Plan plan) {
        int remaining = PAGES - read(c);
        int pace = plan.pace(remaining);
        // ما قُرئ قبل التعديل (ومنه قراءة اليوم) يتبع الخطة القديمة
        p(c).edit().putLong("base_day", today()).putInt("base_read", read(c)).putString("mode", plan.mode).putInt("ppd", pace).putBoolean("extend", plan.extend)
                .putInt("off_days", plan.offMask == 0b11111110 ? 0 : plan.offMask)
                .putLong("end", plan.end(remaining)).putString("label", plan.label)
                .putLong("day", today()).putInt("today_count", 0).putInt("today_from", nextPage(c))
                .putBoolean("extended_note", false)
                .apply();
    }

    static void stop(Context c) { p(c).edit().putBoolean("active", false).apply(); }

    // ------------------------------------------------------------------ التتبّع

    /** رقم صفحة المصحف من الرابط، أو ٠ */
    static int pageOf(String url) {
        if (url == null) return 0;
        Matcher m = PAGE.matcher(url);
        if (!m.find()) return 0;
        int page = Integer.parseInt(m.group(1) != null ? m.group(1) : m.group(2));
        return page >= 1 && page <= PAGES ? page : 0;
    }

    /** يُستدعى بعد بقاء القارئ على صفحة المصحف مدة DWELL_MS */
    static void onUrl(Context c, String url) {
        if (!active(c)) return;
        int page = pageOf(url);
        if (page == 0) return;
        ensureDay(c);
        char[] b = bits(c).toCharArray();
        if (b[page - 1] == '1') return;
        b[page - 1] = '1';
        int todayCount = p(c).getInt("today_count", 0) + 1;
        SharedPreferences.Editor e = p(c).edit().putString("pages", new String(b))
                .putInt("today_count", todayCount)
                .putLong("last_read", today());
        if (readCount(new String(b)) >= PAGES) {
            e.putInt("completed", p(c).getInt("completed", 0) + 1).putBoolean("just_done", true);
            e.putString("history", appendHistory(p(c).getString("history", ""),
                    p(c).getLong("start", today()) + "-" + today()));
        }
        e.apply();
        logToday(c, todayCount);
        Reading.markToday(c);
        KhatmaWidget.updateAll(c);
    }

    /** بداية يوم جديد: نثبّت نقطة انطلاق ورد اليوم، ونعالج التأخر دون ورد مُرهق */
    static void ensureDay(Context c) {
        long t = today();
        if (p(c).getLong("day", -1) == t) return;
        SharedPreferences.Editor e = p(c).edit().putLong("day", t).putInt("today_count", 0)
                .putInt("today_from", nextPage(c));
        int remaining = PAGES - read(c);
        long end = p(c).getLong("end", t);
        if (remaining > 0 && active(c)) {
            if (fixedPace(c)) {
                // الورد ثابت: الموعد يتحرك مع القراءة الفعلية
                e.putLong("end", dayAfterReadingDays(offMask(c), t, (int) Math.ceil(remaining / (double) pace(c))));
            } else if (end < t || readingDays(offMask(c), t, end) == 0) {
                // انتهت المدة ولم تكتمل الختمة: نمدّد بنفس الورد بدل أن يصبح ورد اليوم كل ما بقي
                e.putLong("end", dayAfterReadingDays(offMask(c), t, (int) Math.ceil(remaining / (double) pace(c))))
                 .putBoolean("extended_note", true);
            }
        }
        e.apply();
    }

    private static int readCount(String b) {
        int n = 0;
        for (int i = 0; i < b.length(); i++) if (b.charAt(i) == '1') n++;
        return n;
    }

    static int read(Context c) { return readCount(bits(c)); }

    static int percent(Context c) { return Math.round(read(c) * 100f / PAGES); }

    static boolean done(Context c) { return read(c) >= PAGES; }

    /** أول صفحة لم تُقرأ ابتداءً من صفحة البداية (ثم من أول المصحف) */
    static int nextPage(Context c) {
        String b = bits(c);
        int i = b.indexOf('0', startPage(c) - 1);
        if (i < 0) i = b.indexOf('0');
        return i < 0 ? PAGES : i + 1;
    }

    /** أيام القراءة المتبقية حتى الموعد (يوم واحد على الأقل) */
    static int daysLeft(Context c) {
        long t = today();
        return Math.max(1, readingDays(offMask(c), t, Math.max(t, p(c).getLong("end", t))));
    }

    /** عدد صفحات الورد قبل التقريب لنهاية الجزء */
    private static int rawTarget(Context c) {
        ensureDay(c);
        if (!readingToday(c)) return 0;
        int remainingAtDayStart = PAGES - read(c) + p(c).getInt("today_count", 0);
        if (remainingAtDayStart <= 0) return 0;
        if (fixedPace(c)) return Math.min(remainingAtDayStart, pace(c));
        return Math.max(1, (int) Math.ceil(remainingAtDayStart / (double) daysLeft(c)));
    }

    /** [من، إلى] صفحات ورد اليوم، ينتهي عند نهاية الجزء إن كانت على بُعد صفحتين */
    static int[] todayRange(Context c) {
        ensureDay(c);
        int from = Math.max(1, p(c).getInt("today_from", nextPage(c)));
        int target = rawTarget(c);
        if (target == 0) return new int[]{from, from - 1};
        int to = Math.min(PAGES, from + target - 1);
        for (int js : JUZ_START) {
            int juzEnd = js - 1;
            if (juzEnd >= from && Math.abs(juzEnd - to) <= 2 && juzEnd != to) { to = juzEnd; break; }
        }
        return new int[]{from, to};
    }

    /** عدد صفحات ورد اليوم (٠ في يوم الراحة) */
    static int dailyTarget(Context c) {
        int[] r = todayRange(c);
        return Math.max(0, r[1] - r[0] + 1);
    }

    static int todayCount(Context c) { ensureDay(c); return p(c).getInt("today_count", 0); }

    /** بقي من ورد اليوم */
    static int todayRemaining(Context c) { return Math.max(0, dailyTarget(c) - todayCount(c)); }

    /** فات يوم قراءة أو أكثر دون قراءة؟ */
    static boolean missedDays(Context c) {
        long t = today();
        if (!active(c)) return false;
        long last = Math.max(p(c).getLong("last_read", t), p(c).getLong("start", t) - 1);
        return readingDays(offMask(c), last + 1, t - 1) > 0;
    }

    /** مُدّد الموعد تلقائيًا لأن المدة انتهت؟ (يُعرض مرة) */
    static boolean consumeExtendedNote(Context c) {
        boolean d = p(c).getBoolean("extended_note", false);
        if (d) p(c).edit().putBoolean("extended_note", false).apply();
        return d;
    }

    /** الفرق عن الخطة الأصلية بالصفحات: موجب = متقدّم، سالب = متأخر */
    static int aheadBy(Context c) {
        long t = today();
        // يُقاس من آخر تعديل للخطة بالوتيرة الجديدة، لا من بداية الختمة
        long base = p(c).getLong("base_day", p(c).getLong("start", t));
        int baseRead = p(c).getInt("base_read", 0);
        int planned = Math.min(PAGES - baseRead, pace(c) * readingDays(offMask(c), base, t - 1));
        int readBeforeToday = read(c) - todayCount(c);
        return (readBeforeToday - baseRead) - planned;
    }

    // ------------------------------------------------------------------ الأسماء والتواريخ

    static int juzOf(int page) {
        int j = 1;
        for (int i = 0; i < JUZ_START.length; i++) if (JUZ_START[i] <= page) j = i + 1;
        return j;
    }

    /** السورة التي تبدأ بها الصفحة أو تستمر فيها (١..١١٤) */
    static int surahOf(int page) {
        int s = 1;
        for (int i = 0; i < SURAH_START.length; i++) {
            if (SURAH_START[i] < page) s = i + 1;
            else if (SURAH_START[i] == page) { s = i + 1; break; }
        }
        return s;
    }

    static String surahName(int page) {
        int s = surahOf(page);
        try { return QuranText.NAMES[s - 1]; } catch (Throwable e) { return ""; }
    }

    /** «سورة آل عمران · الجزء ٤» */
    static String where(int page) {
        String n = surahName(page);
        return (n.isEmpty() ? "" : "سورة " + n + " · ") + "الجزء " + Adhan.arabic(String.valueOf(juzOf(page)));
    }

    /** نص موحّد لورد اليوم: للبطاقة والويدجت والإشعار */
    static String todayLine(Context c) {
        if (!readingToday(c)) return "يوم راحة من الورد · اقرأ إن شئت";
        if (todayRemaining(c) == 0) return "أتممت ورد اليوم ✓";
        int[] r = todayRange(c);
        return "ورد اليوم: صفحة " + Adhan.arabic(String.valueOf(r[0])) + " إلى " + Adhan.arabic(String.valueOf(r[1]))
                + " · " + surahName(r[0]);
    }

    static String dateText(long day) {
        long millis = day * 86_400_000L - java.util.TimeZone.getDefault().getOffset(day * 86_400_000L) + 12 * 3_600_000L;
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            return new android.icu.text.SimpleDateFormat("d MMMM", loc).format(new java.util.Date(millis));
        } catch (Throwable e) {
            return "";
        }
    }

    /** تاريخ الختم المتوقع كنص هجري قصير */
    static String endDateText(Context c) {
        ensureDay(c);
        return dateText(p(c).getLong("end", today()));
    }

    /** صفحة المصحف في التطبيق: من ملفات التطبيق نفسه، فتعمل دون إنترنت */
    static String pageUrl(int page) { return OFFLINE + page; }
    static final String OFFLINE = "https://7awlalaalam.com/__hawl/mushaf-pages-offline.html?page=";

    static boolean consumeJustDone(Context c) {
        boolean d = p(c).getBoolean("just_done", false);
        if (d) p(c).edit().putBoolean("just_done", false).apply();
        return d;
    }

    // ------------------------------------------------------------------ السجلات

    /** سجل الأيام: «يوم:عدد:ورد» لآخر ٦٠ يومًا */
    private static void logToday(Context c, int count) {
        long t = today();
        int goal = dailyTarget(c);
        String log = p(c).getString("log", "");
        StringBuilder out = new StringBuilder();
        String[] parts = log.isEmpty() ? new String[0] : log.split(",");
        int startAt = Math.max(0, parts.length - 59);
        for (int i = startAt; i < parts.length; i++) {
            if (parts[i].startsWith(t + ":")) continue;
            if (out.length() > 0) out.append(',');
            out.append(parts[i]);
        }
        if (out.length() > 0) out.append(',');
        out.append(t).append(':').append(count).append(':').append(goal);
        p(c).edit().putString("log", out.toString()).apply();
    }

    /** حالة يوم في السجل: ٠ لم يقرأ، ١ قرأ بعض الورد، ٢ أتم الورد */
    static int dayState(Context c, long day) {
        String log = p(c).getString("log", "");
        for (String part : log.split(",")) {
            String[] f = part.split(":");
            if (f.length == 3 && f[0].equals(String.valueOf(day))) {
                try {
                    int n = Integer.parseInt(f[1]), g = Integer.parseInt(f[2]);
                    return n >= Math.max(1, g) ? 2 : n > 0 ? 1 : 0;
                } catch (NumberFormatException e) { return 0; }
            }
        }
        return 0;
    }

    private static String appendHistory(String h, String entry) {
        String all = h == null || h.isEmpty() ? entry : h + "," + entry;
        String[] parts = all.split(",");
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, parts.length - 10); i < parts.length; i++) {
            if (sb.length() > 0) sb.append(',');
            sb.append(parts[i]);
        }
        return sb.toString();
    }

    /** الختمات السابقة: كل عنصر [يوم البدء، يوم الختم]، الأحدث أولًا */
    static java.util.List<long[]> history(Context c) {
        java.util.List<long[]> out = new java.util.ArrayList<>();
        String h = p(c).getString("history", "");
        if (h.isEmpty()) return out;
        String[] parts = h.split(",");
        for (int i = parts.length - 1; i >= 0; i--) {
            String[] f = parts[i].split("-");
            try { out.add(new long[]{Long.parseLong(f[0]), Long.parseLong(f[1])}); } catch (Exception ignored) { }
        }
        return out;
    }

    /** صفحة المصحف التي توقّف عندها القارئ خارج الختمة (لخيار «من حيث توقفت») */
    static int lastMushafPage(Context c) {
        if (active(c) && !done(c) && read(c) > 0) return nextPage(c);
        return pageOf(Reading.lastUrl(c));
    }
}
