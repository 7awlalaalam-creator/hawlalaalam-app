package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** «أخبار التطبيق»: ما أرسله صاحب التطبيق خلال آخر ٢٤ ساعة، ثم يُحذف تلقائيًا */
public class NewsActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private LinearLayout col;
    private long seenBefore;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
        seenBefore = App.prefs(this).getLong("news_read_at", 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
        News.markRead(this);
    }

    private void render() {
        col.removeAllViews();
        col.addView(Kit.header(this, L.t("أخبار التطبيق"), null, null));

        LinearLayout note = Ui.iconTitle(this, R.drawable.ic_clock, L.t("تبقى الأخبار هنا ٢٤ ساعة، ثم تُحذف تلقائيًا."), 13,
                getColor(R.color.gold_deep), 500, getColor(R.color.gold_deep));
        note.setPadding(dp(12), dp(10), dp(12), dp(10));
        note.setBackground(Ui.shape(getColor(R.color.chip), 14, 0, this));
        col.addView(note, Kit.gap(this, 4));

        List<News.Item> items = News.items(this);
        if (items.isEmpty()) {
            TextView t = Ui.text(this, L.t("لا توجد أخبار الآن.\nحين يصل إشعار جديد من التطبيق يظهر هنا."), 15, getColor(R.color.muted), 400);
            t.setGravity(Gravity.CENTER);
            t.setLineSpacing(dp(4), 1f);
            t.setPadding(0, dp(56), 0, 0);
            col.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        boolean first = true;
        for (News.Item it : items) {
            col.addView(card(it, first), Kit.gap(this, 12));
            first = false;
        }
    }

    private View card(News.Item it, boolean dark) {
        boolean isNew = it.at > seenBefore;
        int ink = dark ? 0xFFFFFFFF : getColor(R.color.ink);
        int soft = dark ? getColor(R.color.on_dark_muted) : getColor(R.color.muted);
        LinearLayout c;
        if (dark) {
            c = Kit.hero(this);
        } else {
            c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setPadding(dp(16), dp(14), dp(16), dp(14));
            c.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        }
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        if (isNew) {
            View dot = new View(this);
            dot.setBackground(Ui.shape(0xFFC4462F, 4, 0, this));
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(8), dp(8));
            dl.setMarginEnd(dp(8));
            top.addView(dot, dl);
        }
        top.addView(Ui.text(this, it.article > 0 ? L.t("مقال جديد") : L.t("من صاحب التطبيق"), 12,
                dark ? getColor(R.color.gold) : getColor(R.color.gold_deep), 700), new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(Ui.text(this, News.ago(it.at), 12, soft, 400));
        c.addView(top);

        if (!it.title.isEmpty()) {
            TextView t = Ui.text(this, it.title, 18, ink, 700);
            t.setPadding(0, dp(8), 0, 0);
            c.addView(t);
        }
        if (!it.body.isEmpty()) {
            TextView b = Ui.text(this, it.body, 14, dark ? getColor(R.color.on_dark_soft) : getColor(R.color.muted), 400);
            b.setLineSpacing(dp(4), 1f);
            b.setPadding(0, dp(6), 0, 0);
            b.setTextIsSelectable(false);
            c.addView(b);
        }
        Intent open = target(it);
        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, dp(12), 0, 0);
        TextView act = Ui.text(this, open == null ? "" : it.article > 0 ? L.t("اقرأ المقال") : L.t("افتح"), 13, ink, 700);
        foot.addView(act, new LinearLayout.LayoutParams(0, -2, 1f));
        boolean soon = it.leftMs() < 6 * 3_600_000L;
        foot.addView(Ui.text(this, News.left(it), 12, soon && !dark ? 0xFFB3412F : soft, soon ? 700 : 400));
        c.addView(foot);
        c.setContentDescription((it.article > 0 ? L.t("مقال جديد: ") : "") + it.title + L.t("، ") + it.body + L.t("، ") + News.left(it));
        if (open != null) c.setOnClickListener(v -> startActivity(open));
        return c;
    }

    private Intent target(News.Item it) {
        if (it.article > 0) return ArticleActivity.intent(this, it.article, it.url);
        if (it.url != null && it.url.startsWith("https://7awlalaalam.com/")) return App.openInApp(this, it.url);
        return null;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
