package com.hawlalaalam.quran;

import android.content.Context;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;

/**
 * متابعة الصلوات (مثل PrayerLog.swift في آيفون، بنفس المفتاح والصيغة فتنتقل بالنسخ الاحتياطي بين النظامين):
 * المفتاح «prayer_log» نص JSON: {"رقم اليوم": قناع} — البت ٠ الفجر، ١ الظهر، ٢ العصر، ٣ المغرب، ٤ العشاء.
 * رقم اليوم = الأيام منذ ١٩٧٠ بالتوقيت المحلي. نحتفظ بآخر ٤٠٠ يوم فقط.
 */
final class PrayerLog {
    static final String KEY = "prayer_log";
    static final String ACTION_PRAYED = "com.hawlalaalam.quran.PRAYED";
    static final String[] NAMES = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
    static final int[] INDEX = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    static final int FULL = 0b11111;

    private PrayerLog() { }

    static int day(long millis) {
        return (int) Math.floor((millis + TimeZone.getDefault().getOffset(millis)) / 86_400_000.0);
    }

    static int today() { return day(System.currentTimeMillis()); }

    static Map<Integer, Integer> load(Context c) {
        Map<Integer, Integer> out = new HashMap<>();
        try {
            JSONObject o = new JSONObject(App.prefs(c).getString(KEY, "{}"));
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                try { out.put(Integer.parseInt(k), o.optInt(k, 0) & FULL); } catch (NumberFormatException ignored) { }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static void save(Context c, Map<Integer, Integer> m) {
        int keep = today() - 400;
        JSONObject o = new JSONObject();
        for (Map.Entry<Integer, Integer> e : m.entrySet()) {
            if (e.getKey() >= keep && e.getValue() != 0) {
                try { o.put(String.valueOf(e.getKey()), (int) e.getValue()); } catch (Exception ignored) { }
            }
        }
        App.prefs(c).edit().putString(KEY, o.toString()).apply();
    }

    static int mask(Context c, int d) {
        Integer v = load(c).get(d);
        return v == null ? 0 : v;
    }

    static void toggle(Context c, int d, int i) {
        Map<Integer, Integer> m = load(c);
        Integer v = m.get(d);
        m.put(d, (v == null ? 0 : v) ^ (1 << i));
        save(c, m);
    }

    static int count(int mask) { return Integer.bitCount(mask & FULL); }

    /** صلوات آخر ٧ أيام (منها اليوم) */
    static int week(Context c) {
        Map<Integer, Integer> m = load(c);
        int t = today(), n = 0;
        for (int k = 0; k < 7; k++) { Integer v = m.get(t - k); if (v != null) n += count(v); }
        return n;
    }

    /** أيام متتالية بالصلوات الخمس كاملة (اليوم يُحسب إن اكتمل، وإلا نبدأ من أمس) */
    static int streak(Context c) {
        Map<Integer, Integer> m = load(c);
        int d = today();
        Integer v = m.get(d);
        if (v == null || v != FULL) d--;
        int n = 0;
        while (true) {
            Integer x = m.get(d);
            if (x == null || x != FULL) break;
            n++;
            d--;
        }
        return n;
    }

    // ------------------------------------------------------------------ الواجهات (نفس آيفون)

    /** بطاقة «صلواتي اليوم» في الشاشة الرئيسية */
    static View card(Context c, Runnable onChange, View.OnClickListener openJourney) {
        int ink = c.getColor(R.color.ink), muted = c.getColor(R.color.muted), gold = c.getColor(R.color.gold_deep),
                goldL = c.getColor(R.color.gold), chip = c.getColor(R.color.chip);
        long now = System.currentTimeMillis();
        long[] t = Adhan.times(c, Calendar.getInstance());
        int today = day(now), m = mask(c, today);

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12));
        card.setBackground(Ui.shape(c.getColor(R.color.card), 18, c.getColor(R.color.line), c));

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(c, "صلواتي اليوم", 15, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(Ui.text(c, Ui.arabicNum(count(m)) + " من ٥", 13, gold, 700));
        card.addView(head);

        LinearLayout row = new LinearLayout(c);
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            boolean on = (m & (1 << i)) != 0;
            boolean due = t[INDEX[i]] <= now;
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setMinimumHeight(Ui.dp(c, 56));
            cell.setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 6));
            cell.setBackground(Ui.shape(on ? chip : 0x00000000, 12, 0, c));
            TextView mark = Ui.text(c, on ? "✓" : "○", 20, on ? goldL : (due ? muted : (muted & 0x00FFFFFF) | 0x59000000), 700);
            mark.setGravity(Gravity.CENTER);
            cell.addView(mark);
            TextView n = Ui.text(c, NAMES[i], 12, due || on ? ink : (muted & 0x00FFFFFF) | 0x99000000, on ? 700 : 500);
            n.setGravity(Gravity.CENTER);
            n.setMaxLines(1);
            cell.addView(n);
            cell.setEnabled(due || on);
            cell.setContentDescription(NAMES[i] + (on ? "، صلّيتها" : due ? "، لم تُسجَّل بعد" : "، لم يدخل وقتها"));
            cell.setOnClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                toggle(c, today, idx);
                onChange.run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(Ui.dp(c, 6));
            row.addView(cell, lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = Ui.dp(c, 10);
        card.addView(row, rl);

        TextView wk = Ui.text(c, "هذا الأسبوع: " + Ui.arabicNum(week(c)) + " من ٣٥ صلاة", 12, muted, 400);
        wk.setPadding(0, Ui.dp(c, 10), 0, 0);
        wk.setOnClickListener(openJourney);
        card.addView(wk);
        return card;
    }

    /** قسم الصلوات في «رحلتي»: آخر ٧ أيام × ٥ صلوات، والمجموع، والسلسلة */
    static View journey(Context c) {
        int ink = c.getColor(R.color.ink), muted = c.getColor(R.color.muted), gold = c.getColor(R.color.gold_deep),
                goldL = c.getColor(R.color.gold), chip = c.getColor(R.color.chip);
        Map<Integer, Integer> m = load(c);
        int t = today();

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 16), Ui.dp(c, 16), Ui.dp(c, 16));
        card.setBackground(Ui.shape(c.getColor(R.color.card), 18, c.getColor(R.color.line), c));
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(c, "صلواتي", 15, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(Ui.text(c, Ui.arabicNum(week(c)) + " من ٣٥ هذا الأسبوع", 13, muted, 400));
        card.addView(head);

        GridLayout g = new GridLayout(c);
        g.setColumnCount(6);
        g.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addCell(c, g, Ui.text(c, "", 11, muted, 400), 0, true);
        for (String n : NAMES) {
            TextView h = Ui.text(c, n, 11, muted, 400);
            h.setGravity(Gravity.CENTER);
            h.setMaxLines(1);
            addCell(c, g, h, 0, false);
        }
        String[] wd = {"الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"};
        for (int k = 6; k >= 0; k--) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, -k);
            TextView lab = Ui.text(c, k == 0 ? "اليوم" : wd[cal.get(Calendar.DAY_OF_WEEK) - 1], 11, ink, k == 0 ? 700 : 400);
            addCell(c, g, lab, 0, true);
            Integer v = m.get(t - k);
            int mask = v == null ? 0 : v;
            for (int i = 0; i < 5; i++) {
                View box = new View(c);
                box.setBackground(Ui.shape((mask & (1 << i)) != 0 ? goldL : chip, 6, 0, c));
                addCell(c, g, box, Ui.dp(c, 22), false);
            }
        }
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2);
        gl.topMargin = Ui.dp(c, 10);
        card.addView(g, gl);

        int s = streak(c);
        if (s >= 1) {
            TextView st = Ui.text(c, "🔥 " + (s == 1 ? "يوم كامل بالصلوات الخمس" : Ui.arabicNum(s) + " أيام متتالية بالصلوات الخمس"), 13, gold, 700);
            st.setPadding(0, Ui.dp(c, 10), 0, 0);
            card.addView(st);
        }
        TextView hint = Ui.text(c, "سجّل صلواتك من بطاقة «صلواتي اليوم» في الصفحة الرئيسية.", 12, muted, 400);
        hint.setPadding(0, Ui.dp(c, 8), 0, 0);
        card.addView(hint);
        return card;
    }

    private static void addCell(Context c, GridLayout g, View v, int h, boolean label) {
        GridLayout.LayoutParams lp = label
                ? new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED))
                : new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = label ? Ui.dp(c, 52) : 0;
        lp.height = h > 0 ? h : -2;
        lp.setMargins(Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2));
        if (v instanceof TextView) ((TextView) v).setGravity(label ? Gravity.START | Gravity.CENTER_VERTICAL : Gravity.CENTER);
        g.addView(v, lp);
    }
}
