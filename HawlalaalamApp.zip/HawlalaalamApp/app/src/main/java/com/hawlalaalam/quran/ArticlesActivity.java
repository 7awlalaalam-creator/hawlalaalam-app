package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** «المقالات»: مقالات الموقع مرتّبة بالأحدث، مع تصنيفات، وتُقرأ داخل التطبيق (وآخرها دون إنترنت) */
public class ArticlesActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private LinearLayout col;
    private JSONObject data;
    private String category = "";
    private boolean loading = true, failed;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
        if (state != null) category = state.getString("cat", "");
        data = Articles.cachedList(this);
        render();
        Context app = getApplicationContext();
        new Thread(() -> {
            JSONObject fresh = Articles.refresh(app);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                if (fresh != null) data = fresh; else failed = true;
                render();
            });
        }).start();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("cat", category);
    }

    private void render() {
        col.removeAllViews();
        col.addView(Kit.header(this, L.t("المقالات"), L.t("من موقع حول العالم"), null));

        List<Articles.Item> all = new ArrayList<>();
        List<String> cats = new ArrayList<>();
        if (data != null) {
            JSONArray a = data.optJSONArray("articles");
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject x = a.optJSONObject(i);
                if (x != null) all.add(Articles.Item.from(x));
            }
            JSONArray cs = data.optJSONArray("categories");
            for (int i = 0; cs != null && i < cs.length(); i++) cats.add(cs.optString(i));
        }

        if (all.isEmpty()) {
            TextView t = Ui.text(this, loading ? L.t("جارٍ جلب المقالات…") : failed
                    ? L.t("تحتاج اتصالًا بالإنترنت لأول مرة لجلب المقالات") : L.t("لا توجد مقالات بعد"), 15, getColor(R.color.muted), 400);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(60), 0, 0);
            col.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        if (cats.size() > 1) col.addView(chips(cats), Kit.gap(this, 6));

        boolean first = true;
        for (Articles.Item a : all) {
            if (!category.isEmpty() && !category.equals(a.category)) continue;
            col.addView(first ? featured(a) : row(a), Kit.gap(this, first ? 12 : 8));
            first = false;
        }

        TextView off = Ui.text(this, failed ? L.t("أنت دون إنترنت: تظهر المقالات المحفوظة على جوالك")
                : L.t("آخر ") + Ui.arabicNum(Articles.KEEP_OFFLINE) + L.t(" مقالًا محفوظة للقراءة دون إنترنت"), 12, getColor(R.color.muted), 400);
        off.setGravity(Gravity.CENTER);
        off.setPadding(0, dp(14), 0, 0);
        col.addView(off, new LinearLayout.LayoutParams(-1, -2));
    }

    private View chips(List<String> cats) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        List<String> all = new ArrayList<>();
        all.add("");
        all.addAll(cats);
        for (String c : all) {
            boolean on = c.equals(category);
            TextView t = Ui.text(this, c.isEmpty() ? L.t("الكل") : c, 14, on ? 0xFFFFFFFF : getColor(R.color.ink), 700);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), 0, dp(16), 0);
            t.setBackground(Ui.shape(on ? getColor(R.color.primary) : getColor(R.color.card), 18, on ? 0 : getColor(R.color.line), this));
            t.setContentDescription((c.isEmpty() ? L.t("الكل") : c) + (on ? L.t("، محدد") : ""));
            t.setOnClickListener(v -> { category = c; render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
            lp.setMarginEnd(dp(8));
            row.addView(t, lp);
        }
        hs.addView(row);
        return hs;
    }

    private View featured(Articles.Item a) {
        LinearLayout h = Kit.hero(this);
        h.addView(Ui.text(this, meta(a), 12, getColor(R.color.gold), 700));
        TextView t = Ui.text(this, a.title, 21, 0xFFFFFFFF, 700);
        t.setTypeface(amiri());
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(6), 0, 0);
        h.addView(t);
        if (!a.excerpt.isEmpty()) {
            TextView e = Ui.text(this, a.excerpt, 14, getColor(R.color.on_dark_muted), 400);
            e.setMaxLines(3);
            e.setEllipsize(TextUtils.TruncateAt.END);
            e.setLineSpacing(dp(3), 1f);
            e.setPadding(0, dp(6), 0, 0);
            h.addView(e);
        }
        h.setContentDescription(a.title);
        h.setOnClickListener(v -> startActivity(ArticleActivity.intent(this, a.id, a.url)));
        return h;
    }

    private View row(Articles.Item a) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        r.setBackground(Ui.shape(getColor(R.color.card), 16, getColor(R.color.line), this));
        r.addView(Ui.text(this, meta(a), 12, getColor(R.color.gold_deep), 700));
        TextView t = Ui.text(this, a.title, 16, getColor(R.color.ink), 700);
        t.setLineSpacing(dp(2), 1f);
        t.setPadding(0, dp(4), 0, 0);
        r.addView(t);
        r.setContentDescription(a.title);
        r.setOnClickListener(v -> startActivity(ArticleActivity.intent(this, a.id, a.url)));
        return r;
    }

    private String meta(Articles.Item a) {
        String d = Articles.day(a.date);
        String m = a.minutes == 1 ? L.t("دقيقة قراءة") : a.minutes == 2 ? L.t("دقيقتا قراءة")
                : Ui.arabicNum(a.minutes) + (a.minutes <= 10 ? L.t(" دقائق") : L.t(" دقيقة")) + L.t(" قراءة");
        return (a.category.isEmpty() ? "" : a.category + " · ") + (d.isEmpty() ? "" : d + " · ") + m;
    }

    private android.graphics.Typeface amiri() {
        try { return getResources().getFont(R.font.amiri_quran); } catch (Exception e) { return Ui.font(this, 700); }
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
