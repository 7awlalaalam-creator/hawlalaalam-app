package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * «من الموقع»: خدمات وإعلان يُدارون من صفحة الإدارة في الموقع (api/v1/app-services)،
 * فتظهر في «الأدوات» و«اليوم» دون تحديث التطبيق. يُحفظ آخر رد محليًا ليعمل بلا إنترنت.
 * إن لم تكن واجهة الموقع جاهزة بعد تُقرأ قائمة تجريبية من مستودع GitHub.
 */
final class SiteServices {
    static final String FALLBACK = "https://raw.githubusercontent.com/7awlalaalam-creator/hawlalaalam-app/main/data/app-services.json";
    private static final String K_JSON = "svc_json", K_AT = "svc_at", K_CLOSED = "svc_closed", K_OPENED = "svc_opened";

    static final class Item {
        String id, title, icon, url, badge;
    }

    static final class Notice {
        String id, title, body, button, url;
    }

    private SiteServices() { }

    /** تحديث في الخلفية (مرة كل دقيقتين على الأكثر)؛ onChanged على الخيط الرئيسي إن تغيّر شيء */
    static void refresh(Activity a, Runnable onChanged) {
        final Context c = a.getApplicationContext();
        long at = App.prefs(c).getLong(K_AT, 0);
        if (System.currentTimeMillis() - at < 2 * 60_000L) return;
        new Thread(() -> {
            String txt = null;
            String[] r = Api.request("app-services", "GET", null);
            if ("200".equals(r[0]) && valid(r[1])) txt = r[1];
            if (txt == null) {
                try {
                    String g = App.get(FALLBACK + "?t=" + (System.currentTimeMillis() / 300_000L), 200_000);
                    if (valid(g)) txt = g;
                } catch (Exception ignored) { }
            }
            if (txt == null) return;                        // بلا إنترنت: نبقى على المحفوظ
            String old = App.prefs(c).getString(K_JSON, "");
            App.prefs(c).edit().putString(K_JSON, txt).putLong(K_AT, System.currentTimeMillis()).apply();
            if (!txt.equals(old) && onChanged != null) a.runOnUiThread(() -> { if (!a.isFinishing()) onChanged.run(); });
        }).start();
    }

    private static boolean valid(String s) {
        try { return s != null && new JSONObject(s).has("services"); } catch (Exception e) { return false; }
    }

    private static JSONObject data(Context c) {
        try { return new JSONObject(App.prefs(c).getString(K_JSON, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    private static String today() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Riyadh"));
        return f.format(new Date());
    }

    /** يظهر في أندرويد وضمن مدته */
    private static boolean live(JSONObject o) {
        JSONArray p = o.optJSONArray("platforms");
        if (p != null && p.length() > 0) {
            boolean ok = false;
            for (int i = 0; i < p.length(); i++) if ("android".equalsIgnoreCase(p.optString(i))) ok = true;
            if (!ok) return false;
        }
        String d = today(), from = o.optString("from", ""), to = o.optString("to", "");
        if (from.length() >= 10 && d.compareTo(from.substring(0, 10)) < 0) return false;
        return !(to.length() >= 10 && d.compareTo(to.substring(0, 10)) > 0);
    }

    static List<Item> items(Context c) {
        List<Item> out = new ArrayList<>();
        JSONArray a = data(c).optJSONArray("services");
        if (a == null) return out;
        String opened = App.prefs(c).getString(K_OPENED, "");
        for (int i = 0; i < a.length() && out.size() < 12; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !live(o)) continue;
            Item it = new Item();
            it.id = o.optString("id", "");
            it.title = L.en() && !o.optString("title_en", "").isEmpty() ? o.optString("title_en") : o.optString("title", "");
            it.icon = o.optString("icon", "✦");
            it.url = o.optString("url", "");
            // شارة «جديد» تختفي بعد أن يفتح المستخدم الخدمة
            it.badge = "new".equals(o.optString("badge")) && !opened.contains("|" + it.id + "|") ? L.t("جديد") : "";
            if (it.title.isEmpty() || !(it.url.startsWith("https://") || it.url.startsWith("hawlapp://"))) continue;
            out.add(it);
        }
        return out;
    }

    static Notice notice(Context c) {
        JSONObject o = data(c).optJSONObject("announcement");
        if (o == null || !live(o)) return null;
        Notice n = new Notice();
        n.id = o.optString("id", "");
        n.title = o.optString("title", "");
        n.body = o.optString("body", "");
        n.button = o.optString("button", "");
        n.url = o.optString("url", "");
        if (n.id.isEmpty() || n.title.isEmpty()) return null;
        if (App.prefs(c).getString(K_CLOSED, "").contains("|" + n.id + "|")) return null;
        return n;
    }

    static void close(Context c, String id) {
        String s = App.prefs(c).getString(K_CLOSED, "");
        App.prefs(c).edit().putString(K_CLOSED, ("|" + id + "|" + s).substring(0, Math.min(400, s.length() + id.length() + 2))).apply();
    }

    /**
     * شاشات التطبيق نفسها: hawlapp://tools أو mosques أو qibla ...؛
     * وصفحة «كل الأدوات» في الموقع تفتح «الأدوات» في التطبيق بدلها.
     */
    static Intent appScreen(Activity a, Uri u) {
        String key = null;
        if ("hawlapp".equals(u.getScheme())) key = u.getHost();
        else if (u.getPath() != null && u.getPath().endsWith("/all-tools.html")) key = "tools";
        if (key == null) return null;
        Class<?> c;
        switch (key) {
            case "tools": c = ToolsActivity.class; break;
            case "mosques": c = MosquesActivity.class; break;
            case "qibla": c = QiblaActivity.class; break;
            case "khatma": c = KhatmaActivity.class; break;
            case "azkar": c = AzkarActivity.class; break;
            case "prayer": case "prayertimes": c = PrayerTimesActivity.class; break;
            case "listen": c = ListenActivity.class; break;
            case "family": c = FamilyActivity.class; break;
            case "journey": c = JourneyActivity.class; break;
            case "articles": c = ArticlesActivity.class; break;
            case "hadith": c = HadithActivity.class; break;
            case "tasbeeh": c = TasbeehActivity.class; break;
            case "dedicate": c = DedicateActivity.class; break;
            case "news": c = NewsActivity.class; break;
            case "settings": c = SettingsActivity.class; break;
            case "mushaf": return Nav.mushafIntent(a, 0);
            default: return null;
        }
        return new Intent(a, c);
    }

    /** صفحات الموقع تُفتح داخل التطبيق، وغيرها في المتصفح */
    static void open(Activity a, String id, String url) {
        if (id != null && !id.isEmpty()) {
            String s = App.prefs(a).getString(K_OPENED, "");
            if (!s.contains("|" + id + "|")) App.prefs(a).edit().putString(K_OPENED, "|" + id + "|" + (s.length() > 400 ? s.substring(0, 400) : s)).apply();
        }
        Uri u = Uri.parse(url);
        Intent in = appScreen(a, u);
        if (in != null) { try { a.startActivity(in); } catch (Exception ignored) { } return; }
        try {
            if ("7awlalaalam.com".equals(u.getHost()) || "www.7awlalaalam.com".equals(u.getHost())) {
                a.startActivity(new Intent(Intent.ACTION_VIEW, u, a, MainActivity.class).putExtra(HomeActivity.EXTRA_FROM_HOME, true));
            } else {
                a.startActivity(new Intent(Intent.ACTION_VIEW, u));
            }
        } catch (Exception ignored) { }
    }
}
