package com.hawlalaalam.quran;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** عناصر الواجهة بهوية الموقع (Tajawal، الكحلي والذهبي) */
final class Ui {
    private Ui() { }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static Typeface font(Context c, int weight) {
        try {
            int id = weight >= 700 ? R.font.tajawal_bold : weight >= 500 ? R.font.tajawal_medium : R.font.tajawal_regular;
            return c.getResources().getFont(id);
        } catch (Exception e) {
            return weight >= 600 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }

    static Typeface quran(Context c) {
        try { return c.getResources().getFont(R.font.amiri_quran); } catch (Exception e) { return Typeface.SERIF; }
    }

    static TextView text(Context c, CharSequence s, float sp, int color, int weight) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(font(c, weight));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 3), 1f);
        return t;
    }

    static GradientDrawable shape(int fill, float radiusDp, int strokeColor, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(dp(c, 1), strokeColor);
        return g;
    }

    /** أيقونة خطية ملوّنة */
    static android.widget.ImageView icon(Context c, int res, int color, int sizeDp) {
        android.widget.ImageView v = new android.widget.ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(color);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return v;
    }

    /** عنوان بأيقونة بدل الإيموجي */
    static LinearLayout iconTitle(Context c, int res, CharSequence s, float sp, int color, int weight, int iconColor) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView i = icon(c, res, iconColor, Math.round(sp + 4));
        r.addView(i);
        TextView t = text(c, s, sp, color, weight);
        t.setPadding(dp(c, 8), 0, 0, 0);
        r.addView(t);
        return r;
    }

    /** الوضع الليلي: 0 تلقائي (يتبع الجوال)، 1 نهاري، 2 ليلي — يُطبَّق فورًا على كل الإصدارات */
    static boolean canSetTheme() { return true; }

    static int themeMode(Context c) { return App.prefs(c).getInt("theme_mode", 0); }

    static void applyTheme(Context c, int mode) {
        App.prefs(c).edit().putInt("theme_mode", mode).apply();
        // تنظيف أي وضع قديم ثبّتته النسخة السابقة على مستوى النظام
        if (android.os.Build.VERSION.SDK_INT >= 31 && !App.prefs(c).getBoolean("theme_sys_reset", false)) {
            android.app.UiModeManager um = c.getSystemService(android.app.UiModeManager.class);
            if (um != null) um.setApplicationNightMode(android.app.UiModeManager.MODE_NIGHT_AUTO);
            App.prefs(c).edit().putBoolean("theme_sys_reset", true).apply();
        }
    }

    /** يُستدعى من attachBaseContext في كل شاشة أصلية: يفرض الوضع المختار لحظيًا */
    static Context wrap(Context base) {
        int mode = App.prefs(base).getInt("theme_mode", 0);
        if (mode == 0) return base;
        android.content.res.Configuration conf = new android.content.res.Configuration(base.getResources().getConfiguration());
        conf.uiMode = (conf.uiMode & ~android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                | (mode == 2 ? android.content.res.Configuration.UI_MODE_NIGHT_YES : android.content.res.Configuration.UI_MODE_NIGHT_NO);
        return base.createConfigurationContext(conf);
    }

    static boolean isNight(Context c) {
        return (c.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    /** شريط التطبيق السفلي الموحّد — نفسه في «اليوم» وفي صفحات الموقع داخل التطبيق.
     *  0 اليوم · 1 المصحف · 2 الاستماع · 3 الموقع · 4 الإعدادات */
    static LinearLayout appNav(Context c, int active, java.util.function.IntConsumer onTap) {
        LinearLayout nav = new LinearLayout(c);
        nav.setId(R.id.app_nav);
        nav.setBackgroundColor(c.getColor(R.color.card));
        nav.setElevation(dp(c, 8));
        nav.setPadding(0, dp(c, 6), 0, dp(c, 6));
        int gold = c.getColor(R.color.gold_deep), muted = c.getColor(R.color.muted);
        String[] labels = {"اليوم", "المصحف", "الاستماع", "الموقع", "الإعدادات"};
        int[] icons = {R.drawable.ic_nav_today, R.drawable.ic_nav_mushaf, R.drawable.ic_nav_listen,
                R.drawable.ic_nav_more, R.drawable.ic_nav_settings};
        for (int i = 0; i < labels.length; i++) {
            LinearLayout b = new LinearLayout(c);
            b.setOrientation(LinearLayout.VERTICAL);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(c, 4), 0, dp(c, 4));
            b.setContentDescription(labels[i]);
            b.setTag(i);
            android.widget.ImageView ic = new android.widget.ImageView(c);
            ic.setImageResource(icons[i]);
            ic.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            b.addView(ic, new LinearLayout.LayoutParams(dp(c, 24), dp(c, 24)));
            TextView l = text(c, labels[i], 11, muted, 500);
            l.setPadding(0, dp(c, 3), 0, 0);
            // التسمية في منتصف العنصر دائمًا (كانت تلتصق بالحافة فتُقص «اليوم» عند طرف الشاشة)
            l.setGravity(Gravity.CENTER);
            l.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            l.setMaxLines(1);
            b.addView(l, new LinearLayout.LayoutParams(-1, -2));
            final int idx = i;
            b.setOnClickListener(v -> onTap.accept(idx));
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        setNavActive(nav, active);
        return nav;
    }

    /** يحدّث العنصر المميّز في الشريط دون إعادة بنائه */
    static void setNavActive(LinearLayout nav, int active) {
        Context c = nav.getContext();
        int gold = c.getColor(R.color.gold_deep), muted = c.getColor(R.color.muted);
        for (int i = 0; i < nav.getChildCount(); i++) {
            LinearLayout b = (LinearLayout) nav.getChildAt(i);
            boolean on = i == active;
            ((android.widget.ImageView) b.getChildAt(0)).setColorFilter(on ? gold : muted);
            TextView l = (TextView) b.getChildAt(1);
            l.setTextColor(on ? gold : muted);
            l.setTypeface(Typeface.create(l.getTypeface(), on ? Typeface.BOLD : Typeface.NORMAL));
            b.setSelected(on);
        }
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 16), dp(c, 6), dp(c, 16), dp(c, 6));
        l.setBackground(shape(c.getColor(R.color.card), 18, c.getColor(R.color.line), c));
        return l;
    }

    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(font(c, primary ? 700 : 500));
        b.setTextSize(primary ? 16 : 14);
        b.setTextColor(primary ? 0xFFFFFFFF : c.getColor(R.color.ink));
        b.setBackground(primary ? shape(c.getColor(R.color.primary), 28, 0, c) : shape(c.getColor(R.color.card), 28, c.getColor(R.color.field_border), c));
        return b;
    }

    static Button chip(Context c, String s) {
        Button b = new Button(c, null, android.R.attr.borderlessButtonStyle);
        b.setText(s);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(font(c, 500));
        b.setTextSize(14);
        b.setTextColor(c.getColor(R.color.gold_key));
        b.setBackground(shape(c.getColor(R.color.ivory), 20, c.getColor(R.color.ivory_border), c));
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_clock, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(c, 8));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    static Switch toggle(Context c) {
        Switch s = new Switch(c);
        int[][] states = {{android.R.attr.state_checked}, {}};
        // المفعّل: مقبض ذهبي، المطفأ: أبيض. يتميّز بوضوح في الوضعين حتى لو تغيّر لون المسار
        s.setThumbTintList(new ColorStateList(states, new int[]{0xFFC9A876, 0xFFFFFFFF}));
        s.setTrackTintList(new ColorStateList(states, new int[]{c.getColor(R.color.switch_on), c.getColor(R.color.switch_off)}));
        s.setTrackTintMode(android.graphics.PorterDuff.Mode.SRC_IN);
        return s;
    }

    /** صف: عنوان + وصف + مفتاح */
    static LinearLayout row(Context c, String title, String sub, Switch sw) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(c, 12), 0, dp(c, 12));
        LinearLayout texts = new LinearLayout(c);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(c, title, 16, c.getColor(R.color.ink), 700));
        TextView st = text(c, sub, 13, c.getColor(R.color.muted), 400);
        st.setPadding(0, dp(c, 4), 0, 0);
        texts.addView(st);
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(sw);
        return r;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(c.getColor(R.color.divider));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(c, 1)));
        return v;
    }

    /** «الأربعاء ١٩ ربيع الآخر» */
    static String hijriToday() {
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            android.icu.text.SimpleDateFormat f = new android.icu.text.SimpleDateFormat("EEEE d MMMM", loc);
            return Adhan.arabic(f.format(new java.util.Date()));
        } catch (Throwable t) {
            return "";
        }
    }

    static String hijriShort() {
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            return Adhan.arabic(new android.icu.text.SimpleDateFormat("d MMMM", loc).format(new java.util.Date()));
        } catch (Throwable t) {
            return "";
        }
    }

    /** أندرويد 15+ يرسم خلف أشرطة النظام؛ نحجز مساحتها */
    static void applyInsets(View root) {
        if (android.os.Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets i = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                    | android.view.WindowInsets.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return android.view.WindowInsets.CONSUMED;
        });
    }

    static String arabicNum(long n) { return Adhan.arabic(String.valueOf(n)); }
}
