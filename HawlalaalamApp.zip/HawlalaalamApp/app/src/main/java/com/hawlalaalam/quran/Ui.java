package com.hawlalaalam.quran;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** عناصر الواجهة بهوية الموقع (Tajawal، الكحلي والذهبي) */
final class Ui {
    private Ui() { }

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static Typeface font(Context c, int weight) {
        try {
            int id = weight >= 700 ? R.font.tajawal_bold : weight >= 500 ? R.font.tajawal_medium : R.font.tajawal_regular;
            return c.getResources().getFont(id);
        } catch (Exception e) {
            return weight >= 600 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }

    static Typeface quran(Context c) {
        try { return c.getResources().getFont(R.font.amiri_quran); } catch (Exception e) { return Typeface.SERIF; }
    }

    static TextView text(Context c, CharSequence s, float sp, int color, int weight) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(font(c, weight));
        t.setIncludeFontPadding(false);
        t.setLineSpacing(dp(c, 3), 1f);
        return t;
    }

    static GradientDrawable shape(int fill, float radiusDp, int strokeColor, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(dp(c, 1), strokeColor);
        return g;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 16), dp(c, 6), dp(c, 16), dp(c, 6));
        l.setBackground(shape(0xFFFFFFFF, 18, c.getColor(R.color.line), c));
        return l;
    }

    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(font(c, primary ? 700 : 500));
        b.setTextSize(primary ? 16 : 14);
        b.setTextColor(primary ? 0xFFFFFFFF : c.getColor(R.color.ink));
        b.setBackground(primary ? shape(c.getColor(R.color.ink), 28, 0, c) : shape(0xFFFFFFFF, 28, 0xFFD5DADF, c));
        return b;
    }

    static Button chip(Context c, String s) {
        Button b = new Button(c, null, android.R.attr.borderlessButtonStyle);
        b.setText(s);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(font(c, 500));
        b.setTextSize(14);
        b.setTextColor(c.getColor(R.color.gold_key));
        b.setBackground(shape(c.getColor(R.color.ivory), 20, c.getColor(R.color.ivory_border), c));
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_clock, 0, 0, 0);
        b.setCompoundDrawablePadding(dp(c, 8));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    static Switch toggle(Context c) {
        Switch s = new Switch(c);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{0xFFFFFFFF, 0xFFFFFFFF}));
        s.setTrackTintList(new ColorStateList(states, new int[]{c.getColor(R.color.ink), 0xFFC9D0D4}));
        s.setTrackTintMode(android.graphics.PorterDuff.Mode.SRC_IN);
        return s;
    }

    /** صف: عنوان + وصف + مفتاح */
    static LinearLayout row(Context c, String title, String sub, Switch sw) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(c, 12), 0, dp(c, 12));
        LinearLayout texts = new LinearLayout(c);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(c, title, 16, c.getColor(R.color.ink), 700));
        TextView st = text(c, sub, 13, c.getColor(R.color.muted), 400);
        st.setPadding(0, dp(c, 4), 0, 0);
        texts.addView(st);
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(sw);
        return r;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0xFFEEF0F2);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(c, 1)));
        return v;
    }

    /** «الأربعاء ١٩ ربيع الآخر» */
    static String hijriToday() {
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            android.icu.text.SimpleDateFormat f = new android.icu.text.SimpleDateFormat("EEEE d MMMM", loc);
            return f.format(new java.util.Date());
        } catch (Throwable t) {
            return "";
        }
    }

    static String hijriShort() {
        try {
            android.icu.util.ULocale loc = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            return new android.icu.text.SimpleDateFormat("d MMMM", loc).format(new java.util.Date());
        } catch (Throwable t) {
            return "";
        }
    }

    /** أندرويد 15+ يرسم خلف أشرطة النظام؛ نحجز مساحتها */
    static void applyInsets(View root) {
        if (android.os.Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets i = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                    | android.view.WindowInsets.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return android.view.WindowInsets.CONSUMED;
        });
    }

    static String arabicNum(long n) { return Adhan.arabic(String.valueOf(n)); }
}
