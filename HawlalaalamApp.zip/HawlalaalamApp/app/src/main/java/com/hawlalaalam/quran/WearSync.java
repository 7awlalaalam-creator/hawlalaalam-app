package com.hawlalaalam.quran;

import android.content.Context;

import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.Wearable;

/**
 * يرسل لتطبيق الساعة (Wear OS) ما يحتاجه ليعمل مثل الجوال: الموقع والمدينة والدولة وطريقة الحساب واللغة
 * وسلسلة أيام القراءة وآية اليوم. لا يُرسل شيء إن لم تكن هناك ساعة متصلة، ولا يتكرر الإرسال إن لم يتغير شيء.
 */
final class WearSync {
    private WearSync() { }

    static void push(Context c) {
        Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                PutDataMapRequest r = PutDataMapRequest.create("/hawl");
                DataMap m = r.getDataMap();
                if (Adhan.hasLocation(app)) {
                    m.putDouble("lat", App.prefs(app).getFloat("lat", 0));
                    m.putDouble("lng", App.prefs(app).getFloat("lng", 0));
                    m.putString("city", Adhan.city(app));
                }
                m.putString("country", Adhan.country(app));
                m.putInt("method", Adhan.methodIndex(app));
                m.putString("lang", L.lang(app));
                m.putInt("streak", Reading.streak(app));
                VerseRepo.Verse v = VerseRepo.cached(app);
                if (v != null && v.text != null) {
                    m.putString("verse_text", v.text);
                    m.putInt("verse_s", v.surah);
                    m.putInt("verse_a", v.ayah);
                    m.putString("verse_date", VerseRepo.today());
                }
                // نفس البيانات = لا إرسال (الطبقة لا تُبلغ الساعة إلا بالتغيير، لكن نوفّر الاستدعاء أيضًا)
                StringBuilder sb = new StringBuilder();
                for (String k : new java.util.TreeSet<>(m.keySet())) sb.append(k).append('=').append(String.valueOf((Object) m.get(k))).append(';');
                String sig = sb.toString();
                if (sig.equals(App.prefs(app).getString("wear_sig", ""))) return;
                Wearable.getDataClient(app).putDataItem(r.asPutDataRequest().setUrgent())
                        .addOnSuccessListener(x -> App.prefs(app).edit().putString("wear_sig", sig).apply());
            } catch (Throwable ignored) { }   // جوال بلا خدمات Google (هواوي مثلًا) أو بلا ساعة
        }).start();
    }
}
