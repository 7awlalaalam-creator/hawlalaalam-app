package com.hawlalaalam.quran;

import android.content.Context;

import java.util.Calendar;

/** وضع رمضان: يتفعّل تلقائيًا حسب تقويم أم القرى */
final class Ramadan {
    private Ramadan() { }

    private static android.icu.util.IslamicCalendar hijri(long millis) {
        android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
        ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
        ic.setTimeInMillis(millis);
        return ic;
    }

    static boolean active() {
        try {
            return hijri(System.currentTimeMillis()).get(android.icu.util.Calendar.MONTH)
                    == android.icu.util.IslamicCalendar.RAMADAN;
        } catch (Throwable t) {
            return false;
        }
    }

    /** اليوم من رمضان (1..30) أو 0 */
    static int day() {
        try {
            android.icu.util.IslamicCalendar ic = hijri(System.currentTimeMillis());
            return ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN
                    ? ic.get(android.icu.util.Calendar.DAY_OF_MONTH) : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** أيام حتى بداية رمضان القادم (0 إن كان قائمًا) */
    static int daysUntil() {
        if (active()) return 0;
        Calendar c = Calendar.getInstance();
        for (int i = 1; i < 400; i++) {
            c.add(Calendar.DAY_OF_MONTH, 1);
            try {
                android.icu.util.IslamicCalendar ic = hijri(c.getTimeInMillis());
                if (ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN) return i;
            } catch (Throwable t) {
                return -1;
            }
        }
        return -1;
    }

    /** الأيام المتبقية من رمضان بما فيها اليوم */
    static int daysLeftInRamadan() {
        if (!active()) return 0;
        Calendar c = Calendar.getInstance();
        int n = 0;
        while (n < 31) {
            try {
                if (hijri(c.getTimeInMillis()).get(android.icu.util.Calendar.MONTH)
                        != android.icu.util.IslamicCalendar.RAMADAN) break;
            } catch (Throwable t) {
                break;
            }
            n++;
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return Math.max(1, n);
    }

    /** الإمساك: قبل الفجر بعشر دقائق */
    static long imsak(Context c, Calendar day) {
        return Adhan.times(c, day)[PrayerCalc.FAJR] - 10 * 60_000L;
    }

    static long iftar(Context c, Calendar day) {
        return Adhan.times(c, day)[PrayerCalc.MAGHRIB];
    }

    /** الحدث القادم: [0=الإمساك، 1=الإفطار، الوقت] */
    static long[] nextEvent(Context c) {
        long now = System.currentTimeMillis();
        Calendar today = Calendar.getInstance();
        long im = imsak(c, today), ift = iftar(c, today);
        if (now < im) return new long[]{0, im};
        if (now < ift) return new long[]{1, ift};
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        return new long[]{0, imsak(c, tomorrow)};
    }

    static String tadabburUrl() {
        int d = day();
        return d > 0 ? App.HOME + "ramadan-day-" + d + ".html" : App.HOME + "ramadan-tadabbur-ar.html";
    }

    static String ordinal(int d) {
        String[] o = {"", "الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع", "العاشر"};
        if (d >= 1 && d <= 10) return "اليوم " + o[d];
        return "اليوم " + Adhan.arabic(String.valueOf(d));
    }
}
