package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Calendar;

/** جدولة التذكيرات اليومية */
final class Reminders {
    static final String VERSE = "verse";
    static final String WIRD = "wird";
    static final String ACTION_PREFIX = "com.hawlalaalam.quran.REMIND_";

    private Reminders() { }

    static boolean enabled(Context c, String kind) {
        return App.prefs(c).getBoolean(kind + "_on", false);
    }

    static int hour(Context c, String kind) {
        return App.prefs(c).getInt(kind + "_h", VERSE.equals(kind) ? 7 : 21);
    }

    static int minute(Context c, String kind) {
        return App.prefs(c).getInt(kind + "_m", 0);
    }

    static void set(Context c, String kind, boolean on, int h, int m) {
        App.prefs(c).edit().putBoolean(kind + "_on", on).putInt(kind + "_h", h).putInt(kind + "_m", m).apply();
        schedule(c, kind);
    }

    private static PendingIntent pending(Context c, String kind) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_PREFIX + kind);
        return PendingIntent.getBroadcast(c, VERSE.equals(kind) ? 201 : 202, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c, String kind) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = pending(c, kind);
        if (!enabled(c, kind)) {
            am.cancel(pi);
            return;
        }
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, hour(c, kind));
        next.set(Calendar.MINUTE, minute(c, kind));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis() + 30_000) next.add(Calendar.DAY_OF_MONTH, 1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
    }

    static void scheduleAll(Context c) {
        schedule(c, VERSE);
        schedule(c, WIRD);
    }

    static boolean askedBefore(Context c) {
        SharedPreferences p = App.prefs(c);
        return p.getBoolean("reminders_asked", false);
    }

    static void markAsked(Context c) {
        App.prefs(c).edit().putBoolean("reminders_asked", true).apply();
    }
}
