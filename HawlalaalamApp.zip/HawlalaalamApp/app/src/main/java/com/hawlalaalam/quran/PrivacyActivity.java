package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** «شهادة الخصوصية»: ما الذي لا يجمعه التطبيق، بوضوح وصدق */
public class PrivacyActivity extends Activity {

    static final String[][] POINTS = {
            {L.t("بلا إعلانات أبدًا"), L.t("لا قبل المواقيت ولا بين الصفحات")},
            {L.t("بلا حساب ولا تسجيل"), L.t("لا رقم جوال ولا بريد ولا كلمة مرور")},
            {L.t("موقعك لا يصلنا"), L.t("المواقيت والقبلة تُحسب على جوالك نفسه")},
            {L.t("تلاوتك لا تُحفظ ولا تصلنا"), L.t("التسميع يمرّ بخدمة التعرّف في جوالك، ولا يُحفظ الصوت")},
            {L.t("لا بيع ولا مشاركة لبياناتك"), L.t("ولا مكتبات تتبّع أو تحليلات")},
    };

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = Kit.scrollPage(this, null);
        col.addView(Kit.header(this, L.t("خصوصيتك"), null, null));

        LinearLayout hero = Kit.hero(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(18), dp(22), dp(18), dp(22));
        hero.addView(Ui.icon(this, R.drawable.ic_l_shield, getColor(R.color.gold), 52));
        TextView h = Ui.text(this, L.t("تطبيق بلا مقابل، وبلا ثمن خفي"), 21, 0xFFFFFFFF, 700);
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, dp(10), 0, dp(4));
        hero.addView(h);
        TextView hs = Ui.text(this, L.t("صدقة جارية: لا نبيع شيئًا، ولا نجمع شيئًا عنك"), 13, getColor(R.color.on_dark_muted), 400);
        hs.setGravity(Gravity.CENTER);
        hero.addView(hs);
        col.addView(hero, Kit.gap(this, 4));

        LinearLayout card = Ui.card(this);
        for (int i = 0; i < POINTS.length; i++) {
            if (i > 0) card.addView(Ui.divider(this));
            TextView ok = Ui.text(this, "✓", 15, 0xFF2F8F5B, 700);
            ok.setGravity(Gravity.CENTER);
            ok.setBackground(Ui.shape(0x332F8F5B, 15, 0, this));
            ok.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
            card.addView(Kit.listRow(this, ok, POINTS[i][0], POINTS[i][1], null));
        }
        col.addView(card, Kit.gap(this, 12));

        SpannableStringBuilder t = new SpannableStringBuilder(L.t("للشفافية: "));
        t.setSpan(new ForegroundColorSpan(getColor(R.color.ink)), 0, t.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.append(L.t("الإشعارات الفورية تصل عبر خدمة Firebase بمعرّف جهاز مجهول لا يُربط باسمك، ويمكنك إيقافها من «التنبيهات». ")
                + L.t("واسم مدينتك يعرفه الجوال من خدمة نظامه (جوجل). ")
                + L.t("وإن فعّلت «أضِف قراءتي للخريطة» أو أدخلت رمز دعوة، يُرسل عدد الصفحات واسم الدولة أو رمز الدعوة فقط، بلا أي معرّف."));
        TextView tr = Ui.text(this, t, 12, getColor(R.color.muted), 400);
        tr.setLineSpacing(dp(4), 1f);
        tr.setPadding(dp(4), 0, dp(4), 0);
        col.addView(tr, Kit.gap(this, 14));

        Button share = Ui.button(this, L.t("شارك هذا مع من يسأل عن تطبيق آمن"), false);
        share.setOnClickListener(v -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, shareText()), L.t("مشاركة"))));
        col.addView(Ui.minH(share, 48), Kit.gap(this, 14));
    }

    static String shareText() {
        StringBuilder b = new StringBuilder(L.t("تطبيق «القرآن حول العالم» صدقة جارية:\n"));
        for (String[] p : POINTS) b.append("✓ ").append(p[0]).append("\n");
        return b.append(L.t("\nحمّله: https://7awlalaalam.com/app")).toString();
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
