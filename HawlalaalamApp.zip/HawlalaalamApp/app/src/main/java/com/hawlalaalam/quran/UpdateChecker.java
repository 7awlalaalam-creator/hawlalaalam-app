package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import org.json.JSONObject;

/** يفحص GitHub عن إصدار أحدث ويعرض زر التحديث */
final class UpdateChecker {
    private static volatile boolean showing;

    private UpdateChecker() { }

    static void check(Activity a, boolean manual) {
        // نسخة المتجر: التحديثات من Google Play فقط (شرط سياسة إساءة استخدام الأجهزة والشبكات)
        if (App.fromPlay(a)) {
            if (manual) App.openPlayListing(a);
            return;
        }
        long last = App.prefs(a).getLong("update_checked", 0);
        if (!manual && System.currentTimeMillis() - last < 3 * 3_600_000L) return;
        Handler main = new Handler(Looper.getMainLooper());
        if (manual) Toast.makeText(a, "جارٍ البحث عن تحديث…", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            int latest = -1;
            try {
                String tag = new JSONObject(App.get(App.LATEST_API, 300_000)).optString("tag_name", "");
                latest = Integer.parseInt(tag.substring(tag.lastIndexOf('.') + 1).trim());
                App.prefs(a).edit().putLong("update_checked", System.currentTimeMillis()).apply();
            } catch (Exception ignored) { }
            final int newest = latest;
            main.post(() -> {
                if (a.isFinishing() || a.isDestroyed()) return;
                long current = App.versionCode(a);
                if (newest > current && !showing) {
                    showing = true;
                    showSheet(a, newest);
                } else if (manual && newest <= current) {
                    Toast.makeText(a, newest < 0 ? "تعذّر التحقق، حاول لاحقًا" : "أنت على آخر إصدار ✓",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    private static void showSheet(Activity a, int newest) {
        android.app.Dialog d = new android.app.Dialog(a);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        android.widget.LinearLayout col = new android.widget.LinearLayout(a);
        col.setOrientation(android.widget.LinearLayout.VERTICAL);
        col.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(Ui.dp(a, 24), Ui.dp(a, 12), Ui.dp(a, 24), Ui.dp(a, 28));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(a.getColor(R.color.ivory));
        float r = Ui.dp(a, 28);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        col.setBackground(bg);

        View handle = new View(a);
        handle.setBackground(Ui.shape(0xFFD5DADF, 3, 0, a));
        col.addView(handle, new android.widget.LinearLayout.LayoutParams(Ui.dp(a, 44), Ui.dp(a, 5)));

        android.widget.ImageView logo = new android.widget.ImageView(a);
        logo.setImageResource(R.drawable.app_logo_png);
        logo.setClipToOutline(true);
        logo.setBackground(Ui.shape(0xFF0E2C31, 20, 0, a));
        android.widget.LinearLayout.LayoutParams llp = new android.widget.LinearLayout.LayoutParams(Ui.dp(a, 84), Ui.dp(a, 84));
        llp.topMargin = Ui.dp(a, 18);
        col.addView(logo, llp);

        android.widget.TextView t = Ui.text(a, "تحديث جديد متوفر", 21, a.getColor(R.color.ink), 700);
        t.setPadding(0, Ui.dp(a, 16), 0, Ui.dp(a, 6));
        col.addView(t);
        col.addView(Ui.text(a, "الإصدار " + Adhan.arabic("1.0." + newest).replace('.', '٫')
                + " جاهز · أنت على " + Adhan.arabic(App.versionName(a)).replace('.', '٫'), 14, a.getColor(R.color.muted), 400));
        android.widget.TextView hint = Ui.text(a, "بعد اكتمال التحميل افتح الملف واضغط «تحديث».", 13, a.getColor(R.color.muted), 400);
        hint.setPadding(0, Ui.dp(a, 6), 0, 0);
        col.addView(hint);

        android.widget.Button go = Ui.button(a, "تحديث الآن", true);
        android.widget.LinearLayout.LayoutParams glp = new android.widget.LinearLayout.LayoutParams(-1, Ui.dp(a, 54));
        glp.topMargin = Ui.dp(a, 22);
        go.setOnClickListener(v -> {
            d.dismiss();
            try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.APK_URL))); } catch (Exception ignored) { }
        });
        col.addView(go, glp);
        android.widget.Button later = new android.widget.Button(a, null, android.R.attr.borderlessButtonStyle);
        later.setText("لاحقًا");
        later.setAllCaps(false);
        later.setTypeface(Ui.font(a, 500));
        later.setTextColor(a.getColor(R.color.muted));
        later.setOnClickListener(v -> d.dismiss());
        col.addView(later, new android.widget.LinearLayout.LayoutParams(-1, Ui.dp(a, 48)));

        d.setContentView(col);
        d.setOnDismissListener(x -> showing = false);
        android.view.Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            w.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(android.view.Gravity.BOTTOM);
            w.setDimAmount(0.5f);
        }
        d.show();
    }
}
