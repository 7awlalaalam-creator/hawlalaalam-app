package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import org.json.JSONObject;

/** يفحص GitHub عن إصدار أحدث ويعرض زر التحديث */
final class UpdateChecker {
    private UpdateChecker() { }

    static void check(Activity a, boolean manual) {
        long last = App.prefs(a).getLong("update_checked", 0);
        if (!manual && System.currentTimeMillis() - last < 6 * 3_600_000L) return;
        Handler main = new Handler(Looper.getMainLooper());
        if (manual) Toast.makeText(a, "جارٍ البحث عن تحديث…", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            int latest = -1;
            try {
                String tag = new JSONObject(App.get(App.LATEST_API, 300_000)).optString("tag_name", "");
                latest = Integer.parseInt(tag.substring(tag.lastIndexOf('.') + 1).trim());
                App.prefs(a).edit().putLong("update_checked", System.currentTimeMillis()).apply();
            } catch (Exception ignored) { }
            final int newest = latest;
            main.post(() -> {
                if (a.isFinishing() || a.isDestroyed()) return;
                long current = App.versionCode(a);
                if (newest > current) {
                    AlertDialog d = new AlertDialog.Builder(a, android.R.style.Theme_Material_Light_Dialog_Alert)
                            .setTitle("تحديث جديد متوفر ✨")
                            .setMessage("الإصدار 1.0." + newest + " جاهز للتحميل.\nأنت الآن على الإصدار "
                                    + App.versionName(a) + ".\n\nبعد اكتمال التحميل افتح الملف واضغط «تحديث».")
                            .setPositiveButton("تحديث الآن", (x, w) -> {
                                try {
                                    a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(App.APK_URL)));
                                } catch (Exception ignored) { }
                            })
                            .setNegativeButton("لاحقًا", null)
                            .create();
                    d.show();
                    if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                } else if (manual) {
                    Toast.makeText(a, newest < 0 ? "تعذّر التحقق، حاول لاحقًا" : "أنت على آخر إصدار ✓",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}
