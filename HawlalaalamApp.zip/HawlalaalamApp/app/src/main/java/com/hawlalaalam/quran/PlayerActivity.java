package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/** المشغّل الكامل: التقدّم، التالي والسابق، ±١٥ ث، السرعة، مؤقت النوم، تكرار السورة، التحميل */
public class PlayerActivity extends Activity implements PlayerService.Listener {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView title, sub, pos, dur, speedBtn, sleepBtn, repeatBtn, dlBtn;
    private SeekBar seek;
    private ImageButton play, next, prev;
    private boolean dragging;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateProgress();
            // التلاوة متوقفة: لا داعي لتحديث الشريط مرتين في الثانية (يعود مع changed())
            if (PlayerService.isPlaying() || PlayerService.isPreparing()) main.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout col = Kit.scrollPage(this, new ScrollView[1]);
        col.addView(Kit.header(this, "المشغّل", null, null));

        LinearLayout h = Kit.hero(this);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        h.setPadding(Ui.dp(this, 20), Ui.dp(this, 26), Ui.dp(this, 20), Ui.dp(this, 22));
        TextView badge = Ui.text(this, "القرآن حول العالم", 12, getColor(R.color.gold), 700);
        badge.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 4));
        badge.setBackground(Ui.shape(0x1AFFFFFF, 12, 0, this));
        h.addView(badge);
        title = Ui.text(this, "", 26, 0xFFFFFFFF, 700);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        h.addView(title, new LinearLayout.LayoutParams(-1, -2));
        sub = Ui.text(this, "", 15, getColor(R.color.on_dark_muted), 400);
        sub.setGravity(Gravity.CENTER);
        h.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        seek = new SeekBar(this);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.gold)));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.gold)));
        seek.setContentDescription("موضع التلاوة");
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) pos.setText(clock(p)); }
            @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { dragging = false; PlayerService.seek(s.getProgress()); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = Ui.dp(this, 20);
        h.addView(seek, sp);
        LinearLayout times = new LinearLayout(this);
        times.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pos = Ui.text(this, "", 12, getColor(R.color.on_dark_muted), 400);
        dur = Ui.text(this, "", 12, getColor(R.color.on_dark_muted), 400);
        times.addView(pos, new LinearLayout.LayoutParams(0, -2, 1f));
        times.addView(dur);
        h.addView(times, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout ctl = new LinearLayout(this);
        ctl.setGravity(Gravity.CENTER);
        ctl.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);      // التالي يمين كما في كل المشغّلات… لكن العربية: السابق يمين
        ctl.setPadding(0, Ui.dp(this, 12), 0, 0);
        next = ctlButton(R.drawable.ic_next, "السورة التالية", 44);
        ImageButton fwd = ctlButton(R.drawable.ic_fwd15, "تقديم ١٥ ثانية", 44);
        play = ctlButton(R.drawable.ic_play, "تشغيل", 64);
        play.setBackground(Ui.shape(getColor(R.color.gold), 32, 0, this));
        play.setColorFilter(getColor(R.color.dark));
        ImageButton back = ctlButton(R.drawable.ic_back15, "رجوع ١٥ ثانية", 44);
        prev = ctlButton(R.drawable.ic_prev, "السورة السابقة", 44);
        // الاتجاه العربي: السابق على اليمين والتالي على اليسار
        ctl.addView(next); ctl.addView(fwd); ctl.addView(play); ctl.addView(back); ctl.addView(prev);
        next.setOnClickListener(v -> PlayerService.command(this, PlayerService.ACT_NEXT));
        prev.setOnClickListener(v -> PlayerService.command(this, PlayerService.ACT_PREV));
        fwd.setOnClickListener(v -> PlayerService.skip(15_000));
        back.setOnClickListener(v -> PlayerService.skip(-15_000));
        play.setOnClickListener(v -> PlayerService.command(this, PlayerService.ACT_TOGGLE));
        h.addView(ctl, new LinearLayout.LayoutParams(-1, -2));
        col.addView(h, Kit.gap(this, 12));

        LinearLayout opts = Ui.card(this);
        opts.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        LinearLayout r1 = new LinearLayout(this);
        speedBtn = option("السرعة");
        sleepBtn = option("مؤقت النوم");
        r1.addView(speedBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(sleepBtn, weighted());
        opts.addView(r1);
        LinearLayout r2 = new LinearLayout(this);
        repeatBtn = option("تكرار السورة");
        dlBtn = option("تحميل");
        r2.addView(repeatBtn, new LinearLayout.LayoutParams(0, -2, 1f));
        r2.addView(dlBtn, weighted());
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = Ui.dp(this, 8);
        opts.addView(r2, r2p);
        col.addView(opts, Kit.gap(this, 12));

        speedBtn.setOnClickListener(v -> pickSpeed());
        sleepBtn.setOnClickListener(v -> pickSleep());
        repeatBtn.setOnClickListener(v -> PlayerService.setRepeat(!PlayerService.repeatOne()));
        dlBtn.setOnClickListener(v -> {
            PlayerService.Track t = PlayerService.current();
            if (t == null || t.live) return;
            if (Downloads.status(this, t.url) == Downloads.DONE) return;
            Downloads.start(this, t.url, t.title, t.reciter);
            android.widget.Toast.makeText(this, "بدأ التحميل", android.widget.Toast.LENGTH_SHORT).show();
            changed();
        });

        TextView n = Ui.text(this, "يستمر الاستماع مع قفل الشاشة، وتتحكم به من الإشعار والسماعة", 13, getColor(R.color.muted), 400);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, Ui.dp(this, 16), 0, 0);
        col.addView(n, new LinearLayout.LayoutParams(-1, -2));
        changed();
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMarginStart(Ui.dp(this, 8));
        return lp;
    }

    private ImageButton ctlButton(int icon, String desc, int size) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setColorFilter(getColor(R.color.gold));
        b.setBackground(null);
        b.setContentDescription(desc);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, size), Ui.dp(this, size));
        lp.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView option(String label) {
        TextView t = Ui.text(this, label, 14, getColor(R.color.ink), 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12));
        t.setBackground(Ui.shape(getColor(R.color.chip), 14, 0, this));
        t.setMaxLines(2);
        return t;
    }

    private void pickSpeed() {
        float[] sp = PlayerService.SPEEDS;
        String[] names = new String[sp.length];
        int checked = 1;
        for (int i = 0; i < sp.length; i++) {
            names[i] = speedLabel(sp[i]);
            if (Math.abs(sp[i] - PlayerService.speed()) < 0.01f) checked = i;
        }
        new AlertDialog.Builder(this, Ui.dialogTheme(this)).setTitle("سرعة التلاوة")
                .setSingleChoiceItems(names, checked, (d, w) -> { PlayerService.setSpeed(this, sp[w]); d.dismiss(); })
                .show();
    }

    static String speedLabel(float f) {
        if (Math.abs(f - 1f) < 0.01f) return "عادية";
        if (Math.abs(f - 0.75f) < 0.01f) return "٠٫٧٥×";
        if (Math.abs(f - 1.25f) < 0.01f) return "١٫٢٥×";
        if (Math.abs(f - 1.5f) < 0.01f) return "١٫٥×";
        return Adhan.arabic(String.valueOf(f)) + "×";
    }

    private void pickSleep() {
        String[] names = {"إيقاف المؤقت", "١٥ دقيقة", "٣٠ دقيقة", "٤٥ دقيقة", "ساعة", "عند نهاية السورة"};
        int[] mins = {0, 15, 30, 45, 60, -1};
        new AlertDialog.Builder(this, Ui.dialogTheme(this)).setTitle("مؤقت النوم")
                .setItems(names, (d, w) -> PlayerService.setSleep(mins[w]))
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PlayerService.addListener(this);
        changed();
        main.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        PlayerService.removeListener(this);
        main.removeCallbacks(tick);
    }

    @Override
    public void changed() {
        main.removeCallbacks(tick);
        if (!isFinishing()) main.post(tick);
        PlayerService.Track t = PlayerService.current();
        if (t == null) {
            title.setText("لا توجد تلاوة");
            sub.setText("اختر قارئًا وسورة من «الاستماع»");
            play.setEnabled(false);
            return;
        }
        play.setEnabled(true);
        title.setText(t.title);
        String err = PlayerService.error();
        sub.setText(err != null ? err : PlayerService.isPreparing() ? "جارٍ التحميل…" : t.reciter);
        boolean on = PlayerService.isPlaying();
        play.setImageResource(on ? R.drawable.ic_pause : R.drawable.ic_play);
        play.setContentDescription(on ? "إيقاف مؤقت" : "تشغيل");
        next.setAlpha(PlayerService.hasNext() ? 1f : 0.35f);
        prev.setAlpha(1f);
        seek.setVisibility(t.live ? View.INVISIBLE : View.VISIBLE);
        speedBtn.setText("السرعة\n" + speedLabel(PlayerService.speed()));
        speedBtn.setEnabled(!t.live);
        long sl = PlayerService.sleepAt();
        sleepBtn.setText("مؤقت النوم\n" + (PlayerService.sleepEndOfTrack() ? "نهاية السورة"
                : sl > 0 ? Adhan.remaining(sl - System.currentTimeMillis(), false) : "متوقف"));
        repeatBtn.setText("تكرار السورة\n" + (PlayerService.repeatOne() ? "مفعّل" : "متوقف"));
        int st = t.live ? Downloads.NONE : Downloads.status(this, t.url);
        dlBtn.setText(t.live ? "بث مباشر\n—" : st == Downloads.DONE ? "محمّلة\n✓ دون إنترنت" : st == Downloads.RUNNING ? "تحميل\nجارٍ…" : "تحميل\nللاستماع دون إنترنت");
        updateProgress();
    }

    private void updateProgress() {
        PlayerService.Track t = PlayerService.current();
        if (t == null || t.live) { pos.setText(""); dur.setText(t != null ? "مباشر" : ""); return; }
        long d = PlayerService.duration(), p = PlayerService.position();
        if (d > 0) seek.setMax((int) d);
        if (!dragging) seek.setProgress((int) Math.min(p, Math.max(d, 0)));
        if (!dragging) pos.setText(clock(p));
        dur.setText(d > 0 ? clock(d) : "");
        if (PlayerService.sleepAt() > 0) {
            sleepBtn.setText("مؤقت النوم\n" + Adhan.remaining(PlayerService.sleepAt() - System.currentTimeMillis(), false));
        }
    }

    static String clock(long ms) {
        long t = Math.max(0, ms / 1000);
        String s = t >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
                : String.format(Locale.US, "%d:%02d", t / 60, t % 60);
        return Adhan.arabic(s);
    }
}
