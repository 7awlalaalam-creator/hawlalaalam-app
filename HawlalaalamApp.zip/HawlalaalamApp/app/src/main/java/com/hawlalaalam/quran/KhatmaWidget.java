package com.hawlalaalam.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** ويدجت الختمة: التقدّم وورد اليوم */
public class KhatmaWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        render(context.getApplicationContext(), mgr, ids);
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, KhatmaWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids);
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_khatma);
        Intent open;
        if (Khatma.active(c) && !Khatma.done(c)) {
            int pct = Khatma.percent(c);
            rv.setTextViewText(R.id.kw_pct, Adhan.arabic(String.valueOf(pct)) + "٪");
            rv.setProgressBar(R.id.kw_bar, 100, pct, false);
            rv.setTextViewText(R.id.kw_today, Khatma.todayLine(c));
            open = App.openInApp(c, Khatma.pageUrl(Khatma.nextPage(c)));
        } else {
            rv.setTextViewText(R.id.kw_pct, "");
            rv.setProgressBar(R.id.kw_bar, 100, 0, false);
            rv.setTextViewText(R.id.kw_today, "اضغط لتبدأ ختمتك");
            open = new Intent(c, KhatmaActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        rv.setOnClickPendingIntent(R.id.kw_root, PendingIntent.getActivity(c, 304, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        mgr.updateAppWidget(ids, rv);
    }
}
