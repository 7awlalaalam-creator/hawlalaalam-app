package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** إعدادات التطبيق: التذكيرات، الشاشة، المشاركة، التحديث */
public class SettingsActivity extends Activity {
    private static final int REQ_NOTIF = 31;

    private Switch verseSwitch, wirdSwitch;
    private Button verseTime, wirdTime;
    private String pendingKind;

    private int ink, muted, gold, page;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        page = getColor(R.color.page);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(dp(20), dp(20), dp(20), dp(32));

        TextView title = text("الإعدادات", 26, ink, true);
        col.addView(title);
        col.addView(text("حول العالم | القرآن الكريم · الإصدار " + App.versionName(this), 13, muted, false));

        // --- التذكيرات
        col.addView(section("التذكيرات اليومية"));
        LinearLayout c1 = card();
        verseSwitch = sw("✦ إشعار آية اليوم", "آية كل يوم مع تفسيرها وزر مشاركتها");
        verseTime = timeButton(Reminders.VERSE);
        c1.addView(verseSwitch);
        c1.addView(verseTime);
        col.addView(c1);

        LinearLayout c2 = card();
        wirdSwitch = sw("📖 تذكير الورد اليومي", "تذكير بقراءة وردك وإكمال ختمتك");
        wirdTime = timeButton(Reminders.WIRD);
        c2.addView(wirdSwitch);
        c2.addView(wirdTime);
        col.addView(c2);

        verseSwitch.setChecked(Reminders.enabled(this, Reminders.VERSE));
        wirdSwitch.setChecked(Reminders.enabled(this, Reminders.WIRD));
        verseSwitch.setOnCheckedChangeListener((b, on) -> toggle(Reminders.VERSE, on));
        wirdSwitch.setOnCheckedChangeListener((b, on) -> toggle(Reminders.WIRD, on));

        Button test = button("جرّب إشعار آية اليوم الآن", false);
        test.setOnClickListener(v -> {
            if (!Notifier.allowed(this)) {
                askNotifPermission(Reminders.VERSE);
                return;
            }
            Toast.makeText(this, "جارٍ جلب آية اليوم…", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                VerseRepo.Verse vr = VerseRepo.fetchToday(getApplicationContext());
                Notifier.verse(getApplicationContext(), vr);
                VerseWidget.updateAll(getApplicationContext());
            }).start();
        });
        col.addView(test);

        // --- القراءة
        col.addView(section("القراءة"));
        LinearLayout c3 = card();
        Switch screen = sw("إبقاء الشاشة مضاءة", "لا تنطفئ الشاشة أثناء القراءة والاستماع");
        screen.setChecked(App.prefs(this).getBoolean("keep_screen", true));
        screen.setOnCheckedChangeListener((b, on) -> App.prefs(this).edit().putBoolean("keep_screen", on).apply());
        c3.addView(screen);
        col.addView(c3);
        col.addView(text("💡 أضف «ويدجت آية اليوم» من الشاشة الرئيسية: اضغط مطولًا على مكان فارغ ← الأدوات (Widgets) ← حول العالم.",
                13, muted, false));

        // --- عام
        col.addView(section("عام"));
        Button share = button("شارك التطبيق مع من تحب 🤍", true);
        share.setOnClickListener(v -> startActivity(Intent.createChooser(
                new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, App.shareText()),
                "شارك التطبيق")));
        col.addView(share);

        Button update = button("البحث عن تحديث", false);
        update.setOnClickListener(v -> UpdateChecker.check(this, true));
        col.addView(update);

        Button feedback = button("أرسل ملاحظة أو اقتراحًا", false);
        feedback.setOnClickListener(v -> {
            startActivity(App.openInApp(this, App.CONTACT));
            finish();
        });
        col.addView(feedback);

        TextView foot = text("صدقة جارية لمحمد بن مفرح الشهري رحمه الله، ولموتى المسلمين.", 13, muted, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(24), 0, 0);
        col.addView(foot);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(page);
        scroll.addView(col);
        setContentView(scroll);
        applyInsets(scroll);
        refreshTimes();
    }

    // ------------------------------------------------------------------ منطق

    private void toggle(String kind, boolean on) {
        if (on && !Notifier.allowed(this)) {
            askNotifPermission(kind);
            return;
        }
        Reminders.set(this, kind, on, Reminders.hour(this, kind), Reminders.minute(this, kind));
        refreshTimes();
        if (on) Toast.makeText(this, "سيصلك التذكير يوميًا الساعة "
                + App.formatTime(Reminders.hour(this, kind), Reminders.minute(this, kind)), Toast.LENGTH_SHORT).show();
    }

    private void askNotifPermission(String kind) {
        pendingKind = kind;
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_NOTIF || pendingKind == null) return;
        String kind = pendingKind;
        pendingKind = null;
        if (Notifier.allowed(this)) {
            Reminders.set(this, kind, true, Reminders.hour(this, kind), Reminders.minute(this, kind));
        } else {
            Toast.makeText(this, "فعّل الإشعارات للتطبيق من إعدادات الجوال", Toast.LENGTH_LONG).show();
            Reminders.set(this, kind, false, Reminders.hour(this, kind), Reminders.minute(this, kind));
        }
        verseSwitch.setChecked(Reminders.enabled(this, Reminders.VERSE));
        wirdSwitch.setChecked(Reminders.enabled(this, Reminders.WIRD));
        refreshTimes();
    }

    private void pickTime(String kind) {
        new TimePickerDialog(this, (tp, h, m) -> {
            Reminders.set(this, kind, true, h, m);
            if (Reminders.VERSE.equals(kind)) verseSwitch.setChecked(true);
            else wirdSwitch.setChecked(true);
            refreshTimes();
        }, Reminders.hour(this, kind), Reminders.minute(this, kind), false).show();
    }

    private void refreshTimes() {
        verseTime.setText("🕐 الوقت: " + App.formatTime(Reminders.hour(this, Reminders.VERSE), Reminders.minute(this, Reminders.VERSE)));
        wirdTime.setText("🕐 الوقت: " + App.formatTime(Reminders.hour(this, Reminders.WIRD), Reminders.minute(this, Reminders.WIRD)));
    }

    // ------------------------------------------------------------------ واجهة

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView section(String s) {
        TextView t = text(s, 15, gold, true);
        t.setPadding(0, dp(22), 0, dp(8));
        return t;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFFE6E9EC);
        l.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        l.setLayoutParams(lp);
        return l;
    }

    private Switch sw(String title, String sub) {
        Switch s = new Switch(this);
        s.setText(title + "\n" + sub);
        s.setTextSize(15);
        s.setTextColor(ink);
        s.setPadding(0, dp(6), 0, dp(6));
        return s;
    }

    private Button timeButton(String kind) {
        Button b = new Button(this, null, android.R.attr.borderlessButtonStyle);
        b.setTextColor(gold);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setAllCaps(false);
        b.setOnClickListener(v -> pickTime(kind));
        return b;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(primary ? 0xFFFFFFFF : ink);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? ink : 0xFFFFFFFF);
        bg.setCornerRadius(dp(24));
        if (!primary) bg.setStroke(dp(1), 0xFFD5DADF);
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void applyInsets(View root) {
        if (Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsets.CONSUMED;
        });
    }
}
