package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * جولة في مميزات التطبيق: تظهر مرة بعد كل تحديث يضيف مميزات (TOUR_VERSION)،
 * وتُفتح متى شاء القارئ من الإعدادات. شرائح بسيطة: أيقونة، عنوان، شرح، وشارة «جديد» أو «مطوّر».
 */
public class FeaturesActivity extends Activity {

    /** ارفع الرقم عند إضافة مميزات جديدة إلى الجولة، فتظهر مرة أخرى للجميع بعد التحديث */
    static final int TOUR_VERSION = 8;

    static boolean shouldShow(Context c) {
        return App.prefs(c).getBoolean("welcomed", false) && App.prefs(c).getInt("tour_v", 0) < TOUR_VERSION;
    }

    /** {عنوان، شرح، أيقونة، شارة (0 بلا، 1 جديد، 2 مطوّر)} */
    private static final Object[][] SLIDES = {
            {L.t("أهلًا بك في الإصدار ٢٫٢"),
                    L.t("جديد «القرآن حول العالم»: المساجد القريبة، واسأل عن الآية، ومعنى الكلمة بلمسة، والبحث الذكي، والصفحة كاملة على الشاشة، وتفسير الجلالين.\nاسحب أو اضغط «التالي»."),
                    R.drawable.ic_mushaf_t, 0},
            {L.t("المساجد القريبة"),
                    L.t("خريطة بالمساجد حولك، مرتبة من الأقرب، مع المسافة ووقت المشي والسيارة، وزر «الاتجاهات» يفتح تطبيق الخرائط.\n\nمن «الأدوات» ← «مساجد قريبة»، أو زر «أقرب مسجد» في إشعار الأذان."),
                    R.drawable.ic_mosques, 1},
            {L.t("اسأل عن الآية ✦"),
                    L.t("اكتب سؤالك عن أي آية، فتصلك إجابة مختصرة من التفاسير الستة مع اسم مصدر كل قول، وزر لقراءة نص التفسير للتحقق.\n\nاضغط على آية ← «اسأل عن الآية». يحتاج اتصالًا بالإنترنت."),
                    R.drawable.ic_l_spark, 1},
            {L.t("معنى الكلمة بلمسة"),
                    L.t("الكلمات الغريبة عليها نقاط ذهبية خفيفة في وضع القراءة؛ اضغط عليها فيظهر معناها من «غريب القرآن» لمجمع الملك فهد.\n\nوفي «معاني الكلمات» من لوحة الآية تجد غريبها وجذورها."),
                    R.drawable.ic_book, 1},
            {L.t("البحث الذكي"),
                    L.t("يفهم صيغ الكلمة، ويصحّح الأخطاء الإملائية، ويبحث في المعنى، ويعرف «آية الكرسي» والمراجع مثل 2:255.\n\nمن 🔍 في المصحف ← «ذكي ✦». وبدون إنترنت يعمل البحث باللفظ والمعنى من جوالك."),
                    R.drawable.ic_search, 1},
            {L.t("الصفحة كاملة على الشاشة"),
                    L.t("تظهر الصفحة كلها دون أن تنزل أو تطلع؛ يُضبط الخط وحده ليناسب شاشتك.\n\nمن زر «Aa» في المصحف ← «الصفحة كاملة على الشاشة» ← نعم."),
                    R.drawable.ic_mushaf_t, 1},
            {L.t("الجلالين وآيات بمعناها"),
                    L.t("• تفسير الجلالين في مكتبة التفاسير، يُحمَّل مرة ويعمل دون إنترنت.\n• «آيات بمعناها» في لوحة كل آية: آيات قريبة منها في المعنى.\n• عند إتمام الختمة: زر لدعوة أهلك ليختموا معك."),
                    R.drawable.ic_l_drop, 1},
            {L.t("ساعتك الذكية"),
                    L.t("تطبيق الساعة يأخذ مدينتك وطريقة الحساب ولغتك وآية اليوم من الجوال تلقائيًا، وإذا فعّلت أذان الساعة لا يتكرر اهتزاز أذان الجوال عليها."),
                    R.drawable.ic_clock, 1},
            {L.t("التطبيق بالإنجليزية"),
                    L.t("اختر لغة التطبيق: العربية أو English، وتنقلب الشاشات مع اللغة، ويبقى نص القرآن بالعربية.\n\nمن «الإعدادات» ← «لغة التطبيق · Language»."),
                    R.drawable.ic_globe_t, 0},
            {L.t("وضع المسجد"),
                    L.t("يصمت جوالك تلقائيًا عند إقامة الصلاة، ويعود صوته بعد ١٥ أو ٢٠ أو ٣٠ دقيقة. والجمعة من الأذان الأول.\n\nمن «الأدوات» ← «وضع المسجد»."),
                    R.drawable.ic_silent, 0},
            {L.t("فحص الأذان"),
                    L.t("هل سيصلك الأذان في وقته؟ فحص للإشعارات والبطارية والمنبّه والموقع، مع زر إصلاح لكل مشكلة، و«جرّب الأذان الآن». ويُعاد الفحص كل أسبوع تلقائيًا.\n\nمن «الأدوات» ← «فحص الأذان»."),
                    R.drawable.ic_adhan_check, 0},
            {L.t("صوت أذان الحرم"),
                    L.t("تنبيه الأذان بتكبير أذان المسجد الحرام، أو الأذان كاملًا، أو نغمة الجوال، مع الاستماع قبل الاختيار، وأذان الفجر كاملًا.\n\nمن «التنبيهات» ← «صوت تنبيه الأذان»."),
                    R.drawable.ic_l_bell, 0},
            {L.t("القرآن حول العالم"),
                    L.t("خريطة تضيء بالدول التي يقرأ فيها المشاركون اليوم، وعدد الصفحات في كل دولة. المشاركة اختيارية: عدد الصفحات واسم الدولة فقط.\n\nمن «الأدوات» ← «حول العالم»."),
                    R.drawable.ic_world, 0},
            {L.t("أثرك"),
                    L.t("شارك رمز دعوتك؛ كل من يكتبه في التطبيق تُكتب لك صفحاته وختماته: «من دلّ على خير فله مثل أجر فاعله».\n\nمن «الأدوات» ← «أثرك»."),
                    R.drawable.ic_impact, 0},
            {L.t("المقالات والأخبار"),
                    L.t("مقالات الموقع داخل التطبيق، تُقرأ دون إنترنت وتصلك بإشعار عند نشرها. وأخبار التطبيق تبقى ٢٤ ساعة في 🔔 أعلى «الأدوات»."),
                    R.drawable.ic_article, 0},
            {L.t("الأحاديث الصحيحة"),
                    L.t("صحيح البخاري وصحيح مسلم كاملين دون إنترنت: حديث اليوم، والكتب، والبحث، والمفضلة، والسند والمتن والراوي.\n\nمن «الأدوات» ← «الأحاديث»."),
                    R.drawable.ic_hadith, 0},
            {L.t("خصوصيتك"),
                    L.t("بلا إعلانات ولا حساب، وموقعك لا يصلنا، ولا بيع لبياناتك. اقرأ التفاصيل وشاركها مع من يسأل عن تطبيق آمن.\n\nمن «الأدوات» ← «خصوصيتك»."),
                    R.drawable.ic_l_shield, 0},
            {L.t("الصلاة القادمة على شاشة القفل"),
                    L.t("عدّاد هادئ حتى دخول الوقت في الإشعارات وشاشة القفل، ويتحول وحده للصلاة التالية.\n\nفعّله من «الأدوات» ← «التنبيهات» ← «الصلاة القادمة على شاشة القفل»."),
                    R.drawable.ic_clock, 0},
            {L.t("«اليوم» أوضح"),
                    L.t("• مواقيت اليوم الخمس تحت الصلاة القادمة، والقادمة بالذهبي.\n• عدد أيامك المتتالية مع القرآن.\n• «صورة» في آية اليوم تُشارك البطاقة مباشرة.\n• بطاقة «مراجعة الحفظ» يوم تحين مراجعتك."),
                    R.drawable.ic_nav_today, 0},
            {L.t("صلواتي"),
                    L.t("سجّل صلواتك الخمس بلمسة من بطاقة «صلواتي اليوم» في الصفحة الرئيسية، أو من زر «✓ صلّيت» في إشعار الأذان.\n\nوفي «رحلتي» جدول أسبوعك وأيامك المتتالية بالصلوات الخمس."),
                    R.drawable.ic_l_check, 0},
            {L.t("الاستماع لكل القرّاء"),
                    L.t("كل قرّاء mp3quran بالروايات المختلفة، والإذاعات.\n\n• حمّل السور للاستماع دون إنترنت.\n• سرعة التلاوة ومؤقت النوم.\n• التحكم من شاشة القفل، والتلاوة تستمر وأنت خارج التطبيق."),
                    R.drawable.ic_l_headphones, 0},
            {L.t("الأذكار بعدّاد"),
                    L.t("أذكار الصباح والمساء والنوم وبعد الصلاة، دون إنترنت، وعدّاد لكل ذكر يعدّ معك حتى تتمّه.\n\nمن «اليوم» أو «الأدوات» ← «الأذكار»."),
                    R.drawable.ic_azkar_t, 0},
            {L.t("بوصلة القبلة الجديدة"),
                    L.t("الكعبة على القرص تشير إلى القبلة في أي اتجاه كان جوالك، مع الدرجة من الشمال والمسافة إلى الكعبة، وإرشاد «حرّك الجوال يمينًا أو يسارًا» واهتزاز خفيف حين تستقبل القبلة.\n\nضع الجوال مسطحًا، ومن «الأدوات» ← «القبلة»."),
                    R.drawable.ic_l_compass, 0},
            {L.t("المصحف مع التفسير"),
                    L.t("وضع جديد من زر «Aa» في المصحف: كل آية وتحتها تفسيرها الميسر، دون إنترنت.\n\nوفي المشغّل زر لتكرار كل آية ٣ أو ٥ أو ١٠ مرات، يعينك على الحفظ."),
                    R.drawable.ic_mushaf_t, 0},
            {L.t("التجويد والتفاسير والترجمات"),
                    L.t("• مصحف التجويد الملوّن مع دليل الأحكام.\n• مكتبة التفاسير: الميسر والسعدي، وابن كثير والطبري والبغوي والقرطبي تنزيلًا اختياريًا.\n• ترجمات معاني القرآن، وجذر الكلمة بلمسة مطوّلة، والآيات المتشابهة.\n\nمن زر «Aa» في المصحف."),
                    R.drawable.ic_l_drop, 0},
            {L.t("التمرير التلقائي"),
                    L.t("تنزل الصفحة وحدها وتنتقل إلى التالية، بالسرعة التي تختارها بزرّي − و+، ويتوقف ما دام إصبعك على الشاشة.\n\nمن زر «Aa» في المصحف ← «التمرير التلقائي للصفحات»."),
                    R.drawable.ic_l_wind, 0},
            {L.t("ظلّل وأضف ملاحظاتك"),
                    L.t("اضغط على آية فتظلّلها بأحد أربعة ألوان، أو تضيف لها ملاحظة، أو تجمعها في مجموعة باسمك.\n\nتجدها كلها في 🔖 «ملاحظاتي» في المصحف."),
                    R.drawable.ic_star, 0},
            {L.t("احفظ وراجع"),
                    L.t("اضغط على آية ثم «أضفها لحفظي»: الآية، أو إلى آخر الصفحة، أو إلى آخر السورة.\n\nنعرضها عليك في أوقات متباعدة: تظهر أول كلمتين والباقي مخفي، ثم تختار «نسيتها» أو «بتردد» أو «متقنة»، فتعود غدًا أو بعد أيام أو بعد أسبوع وأكثر."),
                    R.drawable.ic_l_sprout, 0},
            {L.t("سمّع بصوتك (تجريبي)"),
                    L.t("اقرأ من حفظك فتظهر الكلمات كلما قرأتها، والكلمة التي تتجاوزها تظهر بالبرتقالي.\n\nمن «سمّع من هنا» في لوحة الآية، أو 🎙️ في مراجعة الحفظ. التعرّف من جوالك نفسه، ولا يُحفظ صوتك."),
                    R.drawable.ic_l_spark, 0},
            {L.t("ابحث بالمعنى"),
                    L.t("اكتب ما تبحث عنه بكلماتك، مثل «بر الوالدين» أو «الصبر على المرض»، فتظهر الآيات التي معناها ما تقصد ولو لم تحمل لفظك، من التفسير الميسر.\n\nمن 🔍 في المصحف، أو «بحث بالمعنى» في «الأدوات»."),
                    R.drawable.ic_l_spark, 0},
            {L.t("ختمة العائلة"),
                    L.t("أنشئ ختمة وأرسل رابطها لأهلك؛ كل فرد يحجز جزءًا ويعلّم عليه حين يُتمّه، وتتابعون التقدّم معًا حتى الختم.\n\nمن «الأدوات» ← «ختمة العائلة»."),
                    R.drawable.ic_l_user, 0},
            {L.t("رحلتي"),
                    L.t("سلسلتك الحالية وأطولها، وأيام قراءتك في آخر ٣٠ يومًا، وختماتك، وحفظك.\n\nاضغط بطاقة الأيام المتتالية في «الأدوات»."),
                    R.drawable.ic_l_flame, 0},
            {L.t("نسختك محفوظة"),
                    L.t("نسخ احتياطي تلقائي في Google Drive لبياناتك: الختمة والحفظ والعلامات والملاحظات وصلواتك.\n\nومن «الإعدادات» ← «النسخ الاحتياطي» تصدّر ملفًا يُنقل إلى جوال آخر، ولو كان آيفون."),
                    R.drawable.ic_l_cloud, 0},
            {L.t("ختمتي وتذكير الورد"),
                    L.t("خطتك على مقاسك: المدة أو الورد اليومي وأيام الراحة، ويُوزَّع الباقي إن فاتك يوم، وتذكير يصلك في وقته ولا يصلك إن أتممت وردك."),
                    R.drawable.ic_khatma_t, 0},
            {L.t("اجعلها صدقة جارية"),
                    L.t("شارك التطبيق باسم من تحب، حيًّا أو ميتًا، ليصل القرآن إلى غيرك صدقةً عنه.\n\nوأضف إلى شاشة جوالك ويدجت: آية اليوم، ومواقيت الصلاة، وختمتي، ورمضان."),
                    R.drawable.ic_l_heart, 0},
    };

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Ui.wrap(base));
    }

    private int index;
    private LinearLayout slide, dots;
    private Button next, back;
    private float downX;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        App.prefs(this).edit().putInt("tour_v", TOUR_VERSION).apply();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(L.dir());
        root.setBackgroundColor(getColor(R.color.page));
        root.setPadding(dp(20), dp(16), dp(20), dp(20));

        TextView skip = Ui.text(this, L.t("تخطٍّ"), 15, getColor(R.color.muted), 500);
        skip.setPadding(dp(8), dp(8), dp(8), dp(8));
        skip.setOnClickListener(v -> finish());
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.START);
        top.addView(skip);
        root.addView(top);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        slide = new LinearLayout(this);
        slide.setOrientation(LinearLayout.VERTICAL);
        slide.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(slide);
        sv.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) downX = e.getX();
            else if (e.getAction() == MotionEvent.ACTION_UP) {
                float dx = e.getX() - downX;
                if (Math.abs(dx) > dp(70)) { show(index + (dx > 0 ? 1 : -1)); return true; }   // عربي: السحب يمينًا = التالي
            }
            return false;
        });
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, -2);
        dl.topMargin = dp(12);
        dl.bottomMargin = dp(14);
        root.addView(dots, dl);

        LinearLayout btns = new LinearLayout(this);
        back = Ui.button(this, L.t("السابق"), false);
        next = Ui.button(this, L.t("التالي"), true);
        back.setOnClickListener(v -> show(index - 1));
        next.setOnClickListener(v -> {
            if (index == SLIDES.length - 1) finish(); else show(index + 1);
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, -1, 1f);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, -1, 1.4f);
        nl.setMarginStart(dp(10));
        btns.addView(Ui.minH(back, 52), bl);
        btns.addView(Ui.minH(next, 52), nl);
        root.addView(btns);

        setContentView(root);
        Ui.applyInsets(root);
        show(0);
    }

    private void show(int i) {
        if (i < 0 || i >= SLIDES.length) return;
        index = i;
        Object[] s = SLIDES[i];
        slide.removeAllViews();

        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(Ui.shape(getColor(R.color.dark), 36, 0, this));
        ImageView icon = new ImageView(this);
        Drawable d = getDrawable((Integer) s[2]);
        if (d != null) { d = d.mutate(); d.setTint(getColor(R.color.gold)); }
        icon.setImageDrawable(d);
        FrameLayout.LayoutParams il = new FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER);
        iconBox.addView(icon, il);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(76), dp(76));
        bl.topMargin = dp(28);
        slide.addView(iconBox, bl);

        int badge = (Integer) s[3];
        if (badge != 0) {
            TextView b = Ui.text(this, badge == 1 ? L.t("جديد") : L.t("مطوّر"), 13, getColor(R.color.dark), 700);
            b.setPadding(dp(14), dp(4), dp(14), dp(4));
            b.setBackground(Ui.shape(getColor(R.color.gold), 14, 0, this));
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(-2, -2);
            l.topMargin = dp(16);
            slide.addView(b, l);
        }

        TextView t = Ui.text(this, (String) s[0], 24, getColor(R.color.ink), 700);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
        tl.topMargin = dp(16);
        slide.addView(t, tl);

        TextView body = Ui.text(this, (String) s[1], 16, getColor(R.color.ink), 400);
        body.setLineSpacing(0, 1.35f);
        body.setGravity(Gravity.START);
        body.setTextDirection(View.TEXT_DIRECTION_RTL);
        body.setPadding(dp(18), dp(16), dp(18), dp(16));
        body.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        LinearLayout.LayoutParams bdl = new LinearLayout.LayoutParams(-1, -2);
        bdl.topMargin = dp(18);
        slide.addView(body, bdl);

        dots.removeAllViews();
        for (int k = 0; k < SLIDES.length; k++) {
            View dot = new View(this);
            dot.setBackground(Ui.shape(k == i ? getColor(R.color.gold_deep) : getColor(R.color.line), 4, 0, this));
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(k == i ? dp(22) : dp(8), dp(8));
            l.setMarginStart(dp(3));
            l.setMarginEnd(dp(3));
            dots.addView(dot, l);
        }
        back.setVisibility(i == 0 ? View.INVISIBLE : View.VISIBLE);
        next.setText(i == SLIDES.length - 1 ? L.t("ابدأ") : L.t("التالي"));
        slide.setContentDescription((i + 1) + L.t(" من ") + SLIDES.length + ": " + s[0]);
    }

    static void open(Context c) { c.startActivity(new Intent(c, FeaturesActivity.class)); }

    private int dp(int v) { return Ui.dp(this, v); }
}
