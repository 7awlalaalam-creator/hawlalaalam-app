package com.hawlalaalam.quran;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.Locale;

/** تحديد الموقع بدون خدمات Google */
final class Loc {
    interface Callback { void done(Location l); }

    private Loc() { }

    static boolean hasPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressWarnings({"MissingPermission", "deprecation"})
    static void get(Context c, Callback cb) {
        Handler main = new Handler(Looper.getMainLooper());
        LocationManager lm = c.getSystemService(LocationManager.class);
        if (lm == null || !hasPermission(c)) { main.post(() -> cb.done(null)); return; }

        Location best = null;
        for (String p : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (SecurityException ignored) { }
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < 6 * 3_600_000L) {
            final Location b = best;
            main.post(() -> cb.done(b));
            return;
        }
        String provider = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ? LocationManager.NETWORK_PROVIDER
                : lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : null;
        final Location fallback = best;
        if (provider == null) { main.post(() -> cb.done(fallback)); return; }

        final boolean[] done = {false};
        Runnable timeout = () -> { if (!done[0]) { done[0] = true; cb.done(fallback); } };
        main.postDelayed(timeout, 20_000);
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, c.getMainExecutor(), l -> {
                    if (done[0]) return;
                    done[0] = true;
                    main.removeCallbacks(timeout);
                    cb.done(l != null ? l : fallback);
                });
            } else {
                lm.requestSingleUpdate(provider, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location l) {
                        if (done[0]) return;
                        done[0] = true;
                        main.removeCallbacks(timeout);
                        cb.done(l);
                    }
                    @Override public void onStatusChanged(String p, int s, android.os.Bundle e) { }
                    @Override public void onProviderEnabled(String p) { }
                    @Override public void onProviderDisabled(String p) { }
                }, Looper.getMainLooper());
            }
        } catch (Exception e) {
            main.removeCallbacks(timeout);
            done[0] = true;
            cb.done(fallback);
        }
    }

    /** اسم المدينة (من خيط خلفي) */
    @SuppressWarnings("deprecation")
    static String cityName(Context c, double lat, double lng) {
        try {
            List<Address> a = new Geocoder(c, new Locale("ar")).getFromLocation(lat, lng, 1);
            if (a != null && !a.isEmpty()) {
                Address x = a.get(0);
                if (x.getLocality() != null) return x.getLocality();
                if (x.getSubAdminArea() != null) return x.getSubAdminArea();
                if (x.getAdminArea() != null) return x.getAdminArea();
            }
        } catch (Exception ignored) { }
        return "";
    }
}
