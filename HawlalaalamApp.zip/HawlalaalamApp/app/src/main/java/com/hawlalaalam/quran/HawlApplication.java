package com.hawlalaalam.quran;

import android.app.Application;

/** يُهيّأ قبل أي شاشة أو خدمة: لازم لاستقبال الإشعار الفوري والتطبيق مغلق */
public class HawlApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // عملية إعادة التشغيل بعد تغيير اللغة لا تحتاج شيئًا
        if (android.os.Build.VERSION.SDK_INT >= 28 && getProcessName().endsWith(":restart")) return;
        Crash.install(this);
        L.init(this);                     // لغة التطبيق قبل أي شاشة أو إشعار
        Push.init(this);
    }
}
