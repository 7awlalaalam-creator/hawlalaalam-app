package com.hawlalaalam.quran;

import android.app.Application;

/** يُهيّأ قبل أي شاشة أو خدمة: لازم لاستقبال الإشعار الفوري والتطبيق مغلق */
public class HawlApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Crash.install(this);
        Push.init(this);
    }
}
