package com.hawlalaalam.quran;

import android.app.Activity;

import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

/**
 * نافذة التقييم الرسمية من Google Play، في لحظة مريحة: بعد قراءة ورد اليوم، ومع سلسلة ٣ أيام على الأقل،
 * وبعد ٧ أيام من التثبيت، ومرة كل ٤ أشهر على الأكثر (والمتجر نفسه يحدّ عدد مرات ظهورها).
 * لا تُسأل عن رضاك قبلها، ولا يُعرف إن قيّمت أم لا.
 */
final class Rate {
    private static final String KEY = "rate_asked_at";
    private static final long DAY = 86_400_000L;
    private static boolean askedThisRun;

    private Rate() { }

    static void maybeAsk(Activity a) {
        if (askedThisRun || !App.fromPlay(a)) return;
        long now = System.currentTimeMillis();
        long installed;
        try {
            installed = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).firstInstallTime;
        } catch (Exception e) {
            return;
        }
        if (now - installed < 7 * DAY) return;
        if (now - App.prefs(a).getLong(KEY, 0) < 120 * DAY) return;
        if (!Reading.readOn(a, java.util.Calendar.getInstance()) || Reading.streak(a) < 3) return;
        askedThisRun = true;
        App.prefs(a).edit().putLong(KEY, now).apply();
        try {
            ReviewManager m = ReviewManagerFactory.create(a);
            m.requestReviewFlow().addOnCompleteListener(task -> {
                if (!task.isSuccessful() || a.isFinishing() || a.isDestroyed()) return;
                ReviewInfo info = task.getResult();
                m.launchReviewFlow(a, info);
            });
        } catch (Exception ignored) { }
    }
}
