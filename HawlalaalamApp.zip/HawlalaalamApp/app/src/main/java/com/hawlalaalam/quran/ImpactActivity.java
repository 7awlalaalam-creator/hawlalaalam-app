package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/** «أثرك»: كم قرأ من دعوتهم للتطبيق — «من دلّ على خير فله مثل أجر فاعله» */
public class ImpactActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private LinearLayout col;
    private JSONObject data;
    private boolean loading, failed;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
        String cached = App.prefs(this).getString("st_impact_cache", null);
        if (cached != null) try { data = new JSONObject(cached); } catch (Exception ignored) { }
        render();
        load();
    }

    private void load() {
        loading = true;
        Context app = getApplicationContext();
        new Thread(() -> {
            JSONObject j = null;
            try {
                Stats.sync(app);
                j = Stats.impact(app);
                App.prefs(app).edit().putString("st_impact_cache", j.toString()).apply();
            } catch (Exception ignored) { }
            final JSONObject r = j;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                failed = r == null;
                if (r != null) data = r;
                render();
            });
        }).start();
    }

    private void render() {
        col.removeAllViews();
        col.addView(Kit.header(this, "أثرك", null, null));

        int pages = data == null ? 0 : data.optInt("pages");
        int today = data == null ? 0 : data.optInt("today");
        int joined = data == null ? 0 : data.optInt("joined");
        int khatmas = data == null ? 0 : data.optInt("khatmas");
        int days = data == null ? 0 : data.optInt("days");

        LinearLayout hero = Kit.hero(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(18), dp(24), dp(18), dp(22));
        TextView l = Ui.text(this, "صفحات قرأها من دعوتهم للتطبيق", 13, getColor(R.color.gold), 700);
        l.setGravity(Gravity.CENTER);
        hero.addView(l);
        TextView big = Ui.text(this, data == null && loading ? "…" : num(pages), 52, 0xFFE9D9B8, 700);
        big.setGravity(Gravity.CENTER);
        hero.addView(big);
        TextView t = Ui.text(this, joined == 0 ? "شارك رابطك، وكل صفحة يقرؤونها تُكتب في أثرك"
                : "منها " + Ui.arabicNum(today) + " اليوم", 14, getColor(R.color.on_dark_muted), 400);
        t.setGravity(Gravity.CENTER);
        hero.addView(t);
        TextView h = Ui.text(this, "«مَن دَلَّ على خيرٍ فله مِثلُ أجرِ فاعِلِه»", 19, getColor(R.color.on_dark_soft), 400);
        h.setTypeface(Ui.quran(this));
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, dp(12), 0, 0);
        hero.addView(h);
        TextView src = Ui.text(this, "رواه مسلم", 11, getColor(R.color.on_dark_muted), 400);
        src.setGravity(Gravity.CENTER);
        hero.addView(src);
        hero.setContentDescription("صفحات قرأها من دعوتهم: " + pages);
        col.addView(hero, Kit.gap(this, 4));

        LinearLayout grid = new LinearLayout(this);
        String[][] cells = {{num(joined), "سجّلوا رمزك"}, {num(khatmas), "ختمات أتمّوها"}, {num(days), "يومًا من الأثر"}};
        for (int i = 0; i < cells.length; i++) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(6), dp(12), dp(6), dp(12));
            c.setBackground(Ui.shape(getColor(R.color.card), 14, getColor(R.color.line), this));
            c.addView(Ui.text(this, cells[i][0], 22, getColor(R.color.ink), 700));
            TextView cl = Ui.text(this, cells[i][1], 12, getColor(R.color.muted), 400);
            cl.setGravity(Gravity.CENTER);
            c.addView(cl);
            c.setContentDescription(cells[i][0] + " " + cells[i][1]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(dp(8));
            grid.addView(c, lp);
        }
        col.addView(grid, Kit.gap(this, 12));
        if (failed && data == null) {
            TextView f = Ui.text(this, "تعذّر الاتصال الآن، تظهر أرقامك حين يتوفر الإنترنت", 12, getColor(R.color.muted), 400);
            f.setGravity(Gravity.CENTER);
            col.addView(f, Kit.gap(this, 8));
        }

        // رابطك ورمزك
        LinearLayout link = Ui.card(this);
        link.setPadding(dp(14), dp(14), dp(14), dp(14));
        link.addView(Ui.text(this, "رمز دعوتك", 14, getColor(R.color.ink), 700));
        TextView code = Ui.text(this, Stats.code(this), 24, getColor(R.color.gold_deep), 700);
        code.setGravity(Gravity.CENTER);
        code.setLetterSpacing(0.2f);
        code.setTextDirection(View.TEXT_DIRECTION_LTR);
        code.setBackground(Ui.shape(getColor(R.color.chip), 12, 0, this));
        code.setPadding(0, dp(10), 0, dp(10));
        code.setContentDescription("رمز دعوتك " + Stats.code(this) + "، اضغط للنسخ");
        code.setOnClickListener(v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("رمز الدعوة", Stats.code(this)));
            Toast.makeText(this, "نُسخ الرمز", Toast.LENGTH_SHORT).show();
        });
        link.addView(code, Kit.gap(this, 10));
        Button share = Ui.button(this, "شارك رابطك", true);
        share.setOnClickListener(v -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, Stats.shareText(this)), "شارك رابطك")));
        link.addView(Ui.minH(share, 50), Kit.gap(this, 10));
        col.addView(link, Kit.gap(this, 12));

        // من دعاك؟
        LinearLayout inv = Ui.card(this);
        inv.setPadding(dp(14), dp(14), dp(14), dp(14));
        String ref = Stats.ref(this);
        if (!ref.isEmpty()) {
            inv.addView(Ui.text(this, "دعاك صاحب الرمز " + ref, 14, getColor(R.color.ink), 700));
            TextView s = Ui.text(this, "جزاك الله خيرًا: قراءتك تُكتب في أثره أيضًا", 12, getColor(R.color.muted), 400);
            s.setPadding(0, dp(4), 0, 0);
            inv.addView(s);
        } else {
            inv.addView(Ui.text(this, "هل دعاك أحد للتطبيق؟", 14, getColor(R.color.ink), 700));
            TextView s = Ui.text(this, "اكتب رمزه ليُكتب له أثر قراءتك", 12, getColor(R.color.muted), 400);
            s.setPadding(0, dp(4), 0, dp(8));
            inv.addView(s);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            EditText in = new EditText(this);
            in.setHint("K7Q2MA");
            in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            in.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
            in.setTextDirection(View.TEXT_DIRECTION_LTR);
            in.setTypeface(Ui.font(this, 700));
            in.setTextColor(getColor(R.color.ink));
            in.setHintTextColor(getColor(R.color.muted));
            in.setBackground(Ui.shape(getColor(R.color.page), 12, getColor(R.color.field_border), this));
            in.setPadding(dp(12), 0, dp(12), 0);
            row.addView(in, new LinearLayout.LayoutParams(0, dp(46), 1f));
            Button ok = Ui.button(this, "حفظ", false);
            ok.setOnClickListener(v -> {
                String err = Stats.setRef(this, in.getText().toString());
                if (err != null) { Toast.makeText(this, err, Toast.LENGTH_LONG).show(); return; }
                Toast.makeText(this, "تم، جزاك الله خيرًا", Toast.LENGTH_SHORT).show();
                Context app = getApplicationContext();
                new Thread(() -> Stats.sync(app)).start();
                render();
            });
            LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(dp(84), dp(46));
            ol.setMarginStart(dp(8));
            row.addView(ok, ol);
            inv.addView(row);
        }
        col.addView(inv, Kit.gap(this, 12));

        TextView note = Ui.text(this, "لا نعرف من دعوت ولا أسماءهم: جهاز من دعوته يرسل عدد الصفحات مع رمز الدعوة فقط، دون أي بيانات أخرى.",
                12, getColor(R.color.muted), 400);
        note.setLineSpacing(dp(4), 1f);
        note.setPadding(dp(4), 0, dp(4), 0);
        col.addView(note, Kit.gap(this, 12));
    }

    /** الصفر بالأرقام العربية نقطة صغيرة يخطئها القارئ (وفي خط تجوّل معيّن): شرطة بدلها */
    static String num(int n) { return n <= 0 ? "—" : Ui.arabicNum(n); }

    private int dp(int v) { return Ui.dp(this, v); }
}
