package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** «فحص الأذان»: هل سيصلك الأذان في وقته؟ مع زر إصلاح لكل مشكلة وتجربة فورية */
public class AdhanCheckActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private LinearLayout col;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AdhanCheck.markRun(this);
        AdhanCheck.schedule(this);
        render();
    }

    private void render() {
        col.removeAllViews();
        col.addView(Kit.header(this, "فحص الأذان", null, null));
        List<AdhanCheck.Item> items = AdhanCheck.run(this);
        int n = AdhanCheck.problems(items);

        // الخلاصة
        LinearLayout sum = new LinearLayout(this);
        sum.setGravity(Gravity.CENTER_VERTICAL);
        sum.setPadding(dp(16), dp(16), dp(16), dp(16));
        boolean ok = n == 0;
        int fg = ok ? 0xFF2F8F5B : 0xFF6E5326;
        sum.setBackground(Ui.shape(ok ? 0x1F2F8F5B : 0x33EFD9A8, 20, ok ? 0x552F8F5B : 0xFFEFD9A8, this));
        sum.addView(Ui.icon(this, ok ? R.drawable.ic_l_check : R.drawable.ic_adhan_check, fg, 30), new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        st.setPadding(dp(12), 0, 0, 0);
        String title = ok ? "الأذان سيصلك في وقته بإذن الله"
                : n == 1 ? "شيء واحد قد يؤخّر الأذان" : Ui.arabicNum(n) + " أشياء قد تؤخّر الأذان";
        st.addView(Ui.text(this, title, 17, Ui.isNight(this) && !ok ? getColor(R.color.gold) : fg, 700));
        TextView when = Ui.text(this, "آخر فحص: الآن · يُعاد كل أسبوع تلقائيًا", 12, getColor(R.color.muted), 400);
        when.setPadding(0, dp(2), 0, 0);
        st.addView(when);
        sum.addView(st, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(sum, Kit.gap(this, 4));

        // البنود
        LinearLayout card = Ui.card(this);
        for (int i = 0; i < items.size(); i++) {
            AdhanCheck.Item it = items.get(i);
            if (i > 0) card.addView(Ui.divider(this));
            TextView mark = Ui.text(this, it.ok ? "✓" : "!", 15, it.ok ? 0xFF2F8F5B : 0xFFB3412F, 700);
            mark.setGravity(Gravity.CENTER);
            mark.setBackground(Ui.shape(it.ok ? 0x262F8F5B : 0x26B3412F, 14, 0, this));
            mark.setLayoutParams(new LinearLayout.LayoutParams(dp(28), dp(28)));
            Button fix = null;
            if (!it.ok && it.intent != null) {
                fix = Ui.button(this, it.fix, true);
                fix.setTextSize(13);
                fix.setPadding(dp(14), 0, dp(14), 0);
                fix.setMinWidth(0);
                fix.setMinimumWidth(0);
                fix.setOnClickListener(v -> {
                    try { startActivity(it.intent); }
                    catch (Exception e) { Toast.makeText(this, "افتح إعدادات الجوال ← التطبيقات ← «حول العالم»", Toast.LENGTH_LONG).show(); }
                });
                fix.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(38)));
            }
            card.addView(Kit.listRow(this, mark, it.title, it.sub, fix));
        }
        col.addView(card, Kit.gap(this, 12));

        Button test = Ui.button(this, "جرّب الأذان الآن", true);
        test.setBackground(Ui.shape(getColor(R.color.gold), 28, 0, this));
        test.setTextColor(0xFF0E2C31);
        test.setOnClickListener(v -> {
            if (!Notifier.allowed(this)) {
                Toast.makeText(this, "فعّل الإشعارات أولًا", Toast.LENGTH_LONG).show();
                return;
            }
            AdhanCheck.test(this);
            Toast.makeText(this, "يصلك أذان تجريبي بعد ١٠ ثوانٍ. يمكنك قفل الشاشة", Toast.LENGTH_LONG).show();
        });
        col.addView(Ui.minH(test, 50), Kit.gap(this, 16));
        TextView hint = Ui.text(this, "يصلك إشعار أذان تجريبي بعد ١٠ ثوانٍ بنفس الصوت المختار (" + Adhan.soundName(Adhan.sound(this))
                + ")، لتتأكد أنه يُسمع.", 12, getColor(R.color.muted), 400);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(dp(3), 1f);
        col.addView(hint, Kit.gap(this, 8));
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
