package com.hawlalaalam.quran;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * ختمة العائلة الأصلية: «ختماتي» وإنشاء ختمة، وشبكة الأجزاء الثلاثين، وأجزائي، والمشاركون، والدعوة برابط.
 * تعمل مع الموقع نفسه (الرابط ?id=XXXXXX يفتح هذه الشاشة). لا خانة إهداء.
 */
public class FamilyActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    static final String EXTRA_ID = "id";

    private LinearLayout col;
    private ScrollView scroll;
    private FamilyKhatma.Group cur;
    private String openId;
    private boolean busy;
    /** رقم آخر طلب أُرسل؛ ردّ تحديث دوري أقدم من آخر إجراء لا يُعرض (حتى لا يُرجع الشاشة لحالة قديمة) */
    private int reqSeq, lastActSeq;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override public void run() { if (cur != null) load(cur.id, false); main.postDelayed(this, 20_000); }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView[] sv = new ScrollView[1];
        col = Kit.scrollPage(this, sv);
        scroll = sv[0];
        openId = state != null ? state.getString("open") : getIntent().getStringExtra(EXTRA_ID);
        if (openId != null && !openId.isEmpty()) loading(); else home();
        if (openId != null && !openId.isEmpty()) load(openId, true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String id = intent.getStringExtra(EXTRA_ID);
        if (id != null && !id.isEmpty()) { openId = id; loading(); load(id, true); }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("open", cur != null ? cur.id : openId);
    }

    @Override
    protected void onResume() {
        super.onResume();
        main.removeCallbacks(poll);
        main.postDelayed(poll, 20_000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        main.removeCallbacks(poll);
    }

    private int c(int res) { return getColor(res); }
    private int dp(int v) { return Ui.dp(this, v); }

    private void loading() {
        col.removeAllViews();
        col.addView(Kit.header(this, "ختمة العائلة", null, null));
        TextView t = Ui.text(this, "جارٍ فتح الختمة…", 14, c(R.color.muted), 400);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(40), 0, 0);
        col.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    // ------------------------------------------------------------------ ختماتي + إنشاء

    private void home() {
        cur = null;
        col.removeAllViews();
        col.addView(Kit.header(this, "ختمة العائلة", "نختم القرآن معًا", null));
        LinearLayout h = Kit.hero(this);
        h.addView(Ui.text(this, "ختمة جماعية", 13, c(R.color.gold), 700));
        TextView d = Ui.text(this, "أنشئ ختمة وأرسل رابطها لأهلك، وكل فرد يحجز جزءًا يقرؤه، وتتابعون التقدّم معًا حتى الختم.",
                14, c(R.color.on_dark_soft), 400);
        d.setPadding(0, dp(6), 0, 0);
        h.addView(d);
        col.addView(h, Kit.gap(this, 12));

        JSONArray mine = FamilyKhatma.saved(this);
        if (mine.length() > 0) {
            col.addView(Kit.section(this, "ختماتي"), Kit.gap(this, 18));
            LinearLayout card = Ui.card(this);
            for (int i = 0; i < mine.length(); i++) {
                JSONObject o = mine.optJSONObject(i);
                if (o == null) continue;
                String id = o.optString("id");
                boolean admin = !o.optString("adminKey").isEmpty();
                TextView chev = Ui.text(this, "‹", 22, c(R.color.gold_deep), 700);
                LinearLayout row = Kit.listRow(this, Kit.badge(this, first(o.optString("name")), true),
                        o.optString("name"), admin ? "أنشأتها أنت · الرمز " + id : "الرمز " + id, chev);
                row.setOnClickListener(v -> { loading(); load(id, true); });
                if (card.getChildCount() > 0) card.addView(Ui.divider(this));
                card.addView(row);
            }
            col.addView(card, Kit.gap(this, 6));
        }

        col.addView(Kit.section(this, "ختمة جديدة"), Kit.gap(this, 18));
        LinearLayout f = Ui.card(this);
        f.setPadding(dp(16), dp(14), dp(16), dp(16));
        EditText name = field("اسم الختمة، مثل: ختمة رمضان للعائلة", 40);
        EditText owner = field("اسمك كما يراه أهلك", 30);
        owner.setText(FamilyKhatma.myName(this));
        f.addView(label("اسم الختمة"));
        f.addView(name, Kit.gap(this, 6));
        f.addView(label("اسمك"), Kit.gap(this, 12));
        f.addView(owner, Kit.gap(this, 6));
        final String[] deadline = {""};
        TextView date = Ui.text(this, "نختم قبل (اختياري): لم يُحدَّد", 14, c(R.color.gold_deep), 700);
        date.setPadding(0, dp(14), 0, dp(4));
        date.setOnClickListener(v -> {
            Calendar now = Calendar.getInstance();
            DatePickerDialog dp = new DatePickerDialog(this, Ui.dialogTheme(this), (picker, y, m, dd) -> {
                deadline[0] = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, dd);
                date.setText("نختم قبل: " + Ui.arabicNum(dd) + "/" + Ui.arabicNum(m + 1) + "/" + Ui.arabicNum(y));
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
            dp.getDatePicker().setMinDate(System.currentTimeMillis());
            dp.show();
        });
        f.addView(date);
        View create = Ui.pill(this, 0, "أنشئ الختمة", true);
        create.setOnClickListener(v -> {
            String n = name.getText().toString().trim(), o = owner.getText().toString().trim();
            if (n.isEmpty() || o.isEmpty()) { toast("اكتب اسم الختمة واسمك"); return; }
            run(() -> FamilyKhatma.create(getApplicationContext(), n, o, deadline[0]), g -> { toast("أُنشئت الختمة، ادعُ أهلك برابطها"); show(g); });
        });
        f.addView(Ui.minH(create, 48), Kit.gap(this, 12));
        col.addView(f, Kit.gap(this, 6));

        TextView join = Ui.text(this, "عندك رمز ختمة؟ انضم إليها", 15, c(R.color.gold_deep), 700);
        join.setGravity(Gravity.CENTER);
        join.setPadding(0, dp(18), 0, dp(6));
        join.setOnClickListener(v -> askCode());
        col.addView(join, new LinearLayout.LayoutParams(-1, -2));
        TextView priv = Ui.text(this, "لا نطلب بريدًا ولا رقمًا. الختمة يراها من معه رابطها فقط.", 12, c(R.color.muted), 400);
        priv.setGravity(Gravity.CENTER);
        col.addView(priv, new LinearLayout.LayoutParams(-1, -2));
    }

    private static String first(String s) { return s == null || s.isEmpty() ? "؟" : s.substring(0, 1); }

    private TextView label(String s) { return Ui.text(this, s, 13, c(R.color.ink), 700); }

    private EditText field(String hint, int max) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTypeface(Ui.font(this, 400));
        e.setTextColor(c(R.color.ink));
        e.setHintTextColor(c(R.color.muted));
        e.setSingleLine(true);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        e.setBackground(Ui.shape(c(R.color.page), 12, c(R.color.field_border), this));
        return e;
    }

    private void askCode() {
        EditText e = field("الرمز من ٦ أحرف أو الرابط", 120);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this, Ui.dialogTheme(this)).setTitle("الانضمام إلى ختمة").setView(box)
                .setPositiveButton("افتح", (d, w) -> {
                    String s = e.getText().toString().trim();
                    // يقبل الرمز وحده، أو الرابط، أو رسالة الدعوة كاملة (مع أسطر بعد الرابط أو معاملات إضافية)
                    String code = codeIn(s);
                    if (code == null) { toast("الرمز غير صحيح"); return; }
                    loading();
                    load(code, true);
                })
                .setNegativeButton("إلغاء", null).show();
    }

    static String codeIn(String s) {
        if (s == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("[?&]id=([A-Za-z2-9]{6})(?![A-Za-z0-9])").matcher(s);
        if (m.find()) return m.group(1).toUpperCase(Locale.ROOT);
        String t = s.trim();
        return t.matches("[A-Za-z2-9]{6}") ? t.toUpperCase(Locale.ROOT) : null;
    }

    // ------------------------------------------------------------------ الختمة

    private void load(String id, boolean first) {
        if (busy && !first) return;
        Context app = getApplicationContext();
        final int seq = ++reqSeq;
        run(() -> FamilyKhatma.get(app, id), g -> { if (seq < lastActSeq) return; if (first || (cur != null && cur.id.equals(g.id))) show(g); },
                first ? err -> { toast(err); if (err.contains("حُذفت")) FamilyKhatma.forget(app, id); home(); } : err -> { });
    }

    private void show(FamilyKhatma.Group g) {
        int scrollY = cur != null && cur.id.equals(g.id) ? scroll.getScrollY() : 0;
        cur = g;
        openId = g.id;
        col.removeAllViews();
        col.addView(Kit.header(this, g.name, "أنشأها " + g.owner + (g.round > 1 ? " · الختمة " + Ui.arabicNum(g.round) : ""), null));

        int done = g.doneCount();
        LinearLayout h = Kit.hero(this);
        h.addView(Ui.text(this, "ختمة جماعية", 13, c(R.color.gold), 700));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.BOTTOM);
        top.setPadding(0, dp(6), 0, dp(8));
        top.addView(Ui.text(this, "أُنجز " + Ui.arabicNum(done) + " من ٣٠ جزءًا", 20, 0xFFFFFFFF, 700),
                new LinearLayout.LayoutParams(0, -2, 1f));
        Map<String, int[]> people = people(g);
        top.addView(Ui.text(this, Ui.arabicNum(people.size()) + " مشاركين", 13, c(R.color.on_dark_muted), 400));
        h.addView(top);
        h.addView(Kit.progress(this, done / 30f, true));
        if (!g.deadline.isEmpty()) {
            TextView dl = Ui.text(this, "نختم قبل " + g.deadline.replace('-', '/'), 12, c(R.color.on_dark_muted), 400);
            dl.setText("نختم قبل " + Adhan.arabic(g.deadline.replace('-', '/')));
            dl.setPadding(0, dp(8), 0, 0);
            h.addView(dl);
        }
        col.addView(h, Kit.gap(this, 12));

        if (done == 30) {
            LinearLayout fin = Ui.card(this);
            fin.setPadding(dp(16), dp(16), dp(16), dp(16));
            fin.addView(Ui.text(this, "تمّت الختمة بفضل الله", 18, c(R.color.gold_deep), 700));
            fin.addView(Ui.text(this, "تقبّل الله منكم جميعًا.", 14, c(R.color.muted), 400));
            if (g.admin) {
                View nr = Ui.pill(this, R.drawable.ic_refresh, "ابدأ ختمة جديدة بالرابط نفسه", true);
                nr.setOnClickListener(v -> run(() -> FamilyKhatma.newRound(getApplicationContext(), g.id), this::show));
                fin.addView(Ui.minH(nr, 46), Kit.gap(this, 12));
            }
            col.addView(fin, Kit.gap(this, 12));
        }

        // أجزائي
        LinearLayout mine = Ui.card(this);
        for (FamilyKhatma.Part p : g.parts) {
            if (!p.mine) continue;
            if (mine.getChildCount() == 0) mine.addView(Ui.text(this, "أجزائي", 15, c(R.color.ink), 700), Kit.gap(this, 8));
            else mine.addView(Ui.divider(this));
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(0, dp(8), 0, dp(8));
            r.addView(Kit.badge(this, Ui.arabicNum(p.n), false));
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setPadding(dp(12), 0, dp(8), 0);
            t.addView(Ui.text(this, "الجزء " + Ui.arabicNum(p.n), 15, c(R.color.ink), 700));
            t.addView(Ui.text(this, p.done ? "أتممته، تقبّل الله" : "من صفحة " + Ui.arabicNum(Khatma.JUZ_START[p.n - 1]), 12, c(R.color.muted), 400));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (!p.done) {
                TextView read = small("اقرأ", false);
                read.setOnClickListener(v -> startActivity(Nav.mushafIntent(this, Khatma.JUZ_START[p.n - 1])));
                r.addView(read);
                TextView ok = small("أتممته", true);
                LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-2, -2);
                op.setMarginStart(dp(6));
                ok.setOnClickListener(v -> act("done", p.n, "تقبّل الله منك 🤍"));
                r.addView(ok, op);
            } else {
                TextView undo = small("تراجع", false);
                undo.setOnClickListener(v -> act("undo", p.n, null));
                r.addView(undo);
            }
            mine.addView(r);
        }
        if (mine.getChildCount() > 0) col.addView(mine, Kit.gap(this, 12));

        // الشبكة
        LinearLayout gc = Ui.card(this);
        gc.setPadding(dp(14), dp(12), dp(14), dp(14));
        LinearLayout gh = new LinearLayout(this);
        gh.addView(Ui.text(this, "الأجزاء", 15, c(R.color.ink), 700), new LinearLayout.LayoutParams(0, -2, 1f));
        gh.addView(Ui.text(this, "متاح " + Ui.arabicNum(30 - g.takenCount()), 12, c(R.color.muted), 400));
        gc.addView(gh);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(6);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (FamilyKhatma.Part p : g.parts) {
            TextView cell = Ui.text(this, Ui.arabicNum(p.n), 15, p.done ? c(R.color.dark) : c(R.color.ink), 700);
            cell.setGravity(Gravity.CENTER);
            int fill = p.done ? c(R.color.gold) : p.by != null ? c(R.color.chip) : c(R.color.card);
            int stroke = p.mine ? c(R.color.gold_deep) : c(R.color.line);
            android.graphics.drawable.GradientDrawable bg = Ui.shape(fill, 10, 0, this);
            bg.setStroke(dp(p.mine ? 2 : 1), stroke);
            cell.setBackground(bg);
            cell.setContentDescription("الجزء " + Ui.arabicNum(p.n) + "، " + (p.done ? "مقروء" : p.by != null ? "محجوز باسم " + p.by : "متاح"));
            cell.setOnClickListener(v -> partSheet(p));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(46);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(cell, lp);
        }
        gc.addView(grid, Kit.gap(this, 10));
        TextView legend = Ui.text(this, "ذهبي: مقروء · فاتح: محجوز · أبيض: متاح · الإطار: أجزائي", 12, c(R.color.muted), 400);
        legend.setPadding(0, dp(8), 0, 0);
        gc.addView(legend);
        TextView hint = Ui.text(this, "اضغط على جزء متاح لتحجزه.", 12, c(R.color.muted), 400);
        gc.addView(hint);
        col.addView(gc, Kit.gap(this, 12));

        // المشاركون
        if (!people.isEmpty()) {
            LinearLayout pc = Ui.card(this);
            pc.addView(Ui.text(this, "المشاركون (" + Ui.arabicNum(people.size()) + ")", 15, c(R.color.ink), 700), Kit.gap(this, 8));
            for (Map.Entry<String, int[]> e : people.entrySet()) {
                int[] v = e.getValue();
                TextView cnt = Ui.text(this, Ui.arabicNum(v[1]) + "/" + Ui.arabicNum(v[0]), 13, c(R.color.gold_deep), 700);
                pc.addView(Ui.divider(this));
                pc.addView(Kit.listRow(this, Kit.badge(this, first(e.getKey()), true), e.getKey(),
                        (v[0] == 1 ? "جزء واحد" : Ui.arabicNum(v[0]) + " أجزاء") + (v[1] > 0 ? "، أتمّ " + Ui.arabicNum(v[1]) : ""), cnt));
            }
            col.addView(pc, Kit.gap(this, 12));
        }

        LinearLayout btns = new LinearLayout(this);
        View invite = Ui.pill(this, R.drawable.ic_share, "ادعُ أهلك برابط", true);
        invite.setOnClickListener(v -> invite(g));
        btns.addView(Ui.minH(invite, 46), new LinearLayout.LayoutParams(0, -2, 1.3f));
        View mineBtn = Ui.pill(this, 0, "ختماتي", false);
        mineBtn.setOnClickListener(v -> home());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, -2, 1f);
        mp.setMarginStart(dp(8));
        btns.addView(Ui.minH(mineBtn, 46), mp);
        col.addView(btns, Kit.gap(this, 14));
        if (g.admin) {
            TextView del = Ui.text(this, "حذف الختمة", 14, 0xFFC0573A, 700);
            del.setGravity(Gravity.CENTER);
            del.setPadding(0, dp(16), 0, dp(4));
            del.setOnClickListener(v -> new AlertDialog.Builder(this, Ui.dialogTheme(this))
                    .setMessage("حذف «" + g.name + "» نهائيًا لكل المشاركين؟")
                    .setPositiveButton("حذف", (d, w) -> run(() -> { FamilyKhatma.delete(getApplicationContext(), g.id); return null; },
                            x -> { toast("حُذفت الختمة"); home(); }))
                    .setNegativeButton("إلغاء", null).show());
            col.addView(del, new LinearLayout.LayoutParams(-1, -2));
        }
        if (scrollY > 0) scroll.post(() -> scroll.scrollTo(0, scrollY));
    }

    private TextView small(String s, boolean primary) {
        TextView t = Ui.text(this, s, 13, primary ? 0xFFFFFFFF : c(R.color.ink), 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        t.setBackground(primary ? Ui.shape(c(R.color.primary), 16, 0, this) : Ui.shape(c(R.color.card), 16, c(R.color.field_border), this));
        return t;
    }

    /** اسم المشارك ← {عدد أجزائه، المقروء منها} */
    private static Map<String, int[]> people(FamilyKhatma.Group g) {
        Map<String, int[]> m = new LinkedHashMap<>();
        for (FamilyKhatma.Part p : g.parts) {
            if (p.by == null) continue;
            int[] v = m.get(p.by);
            if (v == null) { v = new int[2]; m.put(p.by, v); }
            v[0]++;
            if (p.done) v[1]++;
        }
        return m;
    }

    private void partSheet(FamilyKhatma.Part p) {
        int page = Khatma.JUZ_START[p.n - 1];
        AlertDialog.Builder b = new AlertDialog.Builder(this, Ui.dialogTheme(this)).setTitle("الجزء " + Ui.arabicNum(p.n));
        if (p.by == null) {
            EditText who = field("اسمك", 30);
            who.setText(FamilyKhatma.myName(this));
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(20), dp(4), dp(20), 0);
            box.addView(Ui.text(this, "يبدأ من صفحة " + Ui.arabicNum(page) + ". اكتب اسمك ليعرف أهلك من يقرؤه.", 14, c(R.color.muted), 400));
            box.addView(who, Kit.gap(this, 10));
            b.setView(box).setPositiveButton("احجزه", (d, w) -> {
                String n = who.getText().toString().trim();
                if (n.isEmpty()) { toast("اكتب اسمك"); return; }
                FamilyKhatma.setMyName(this, n);
                actWho("take", p.n, "حُجز الجزء " + Ui.arabicNum(p.n) + " باسمك", n);
            }).setNegativeButton("إلغاء", null);
        } else if (p.mine) {
            b.setMessage(p.done ? "أتممت هذا الجزء، تقبّل الله منك." : "محجوز باسمك · يبدأ من صفحة " + Ui.arabicNum(page))
                    .setPositiveButton(p.done ? "تراجع" : "أتممته", (d, w) -> act(p.done ? "undo" : "done", p.n, p.done ? null : "تقبّل الله منك 🤍"))
                    .setNeutralButton("اقرأ", (d, w) -> startActivity(Nav.mushafIntent(this, page)));
            if (!p.done) b.setNegativeButton("ألغِ الحجز", (d, w) -> act("release", p.n, "أُلغي الحجز"));
        } else {
            b.setMessage((p.done ? "قرأه " : "يقرؤه ") + p.by + " · يبدأ من صفحة " + Ui.arabicNum(page))
                    .setPositiveButton("اقرأ", (d, w) -> startActivity(Nav.mushafIntent(this, page)))
                    .setNegativeButton("إغلاق", null);
        }
        AlertDialog d = b.show();
        if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    private void act(String action, int part, String msg) { actWho(action, part, msg, null); }

    private void actWho(String action, int part, String msg, String who) {
        if (cur == null) return;
        String id = cur.id;
        lastActSeq = ++reqSeq;
        run(() -> FamilyKhatma.act(getApplicationContext(), action, id, part, who), g -> {
            if (cur != null && cur.id.equals(id)) show(g);
            if (msg != null) toast(msg);
        }, err -> { toast(err); load(id, false); });
    }

    private void invite(FamilyKhatma.Group g) {
        String text = "انضم إلى «" + g.name + "» ونختم القرآن معًا 🤍\nاحجز جزءًا واقرأه:\n" + FamilyKhatma.inviteUrl(g.id)
                + "\n\nمن تطبيق «القرآن حول العالم»";
        try {
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "ادعُ أهلك"));
        } catch (Exception ignored) { }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ------------------------------------------------------------------ تشغيل في الخلفية

    interface Job<T> { T run() throws FamilyKhatma.Failure; }
    interface Done<T> { void ok(T t); }
    interface Err { void fail(String msg); }

    private <T> void run(Job<T> job, Done<T> done) { run(job, done, this::toast); }

    private <T> void run(Job<T> job, Done<T> done, Err err) {
        busy = true;
        new Thread(() -> {
            try {
                T t = job.run();
                runOnUiThread(() -> { busy = false; if (!isFinishing() && !isDestroyed()) done.ok(t); });
            } catch (FamilyKhatma.Failure f) {
                runOnUiThread(() -> { busy = false; if (!isFinishing() && !isDestroyed()) err.fail(f.getMessage()); });
            }
        }).start();
    }
}
