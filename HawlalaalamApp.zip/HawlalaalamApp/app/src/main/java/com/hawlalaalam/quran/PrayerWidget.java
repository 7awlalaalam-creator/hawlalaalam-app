package com.hawlalaalam.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.os.SystemClock;
import android.widget.RemoteViews;

import java.util.Calendar;

/** ويدجت مواقيت الصلاة: الصلاة القادمة مع عدّاد تنازلي */
public class PrayerWidget extends AppWidgetProvider {
    private static final int[] CELLS = {R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4};
    private static final int[] PRAYERS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        render(context.getApplicationContext(), mgr, ids);
        Adhan.scheduleNext(context.getApplicationContext());
    }

    static boolean hasWidgets(Context c) {
        int[] ids = AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, PrayerWidget.class));
        return ids != null && ids.length > 0;
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, PrayerWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids);
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_prayer);
        PendingIntent open = PendingIntent.getActivity(c, 302,
                Adhan.hasLocation(c) ? App.openInApp(c, App.HOME + "prayer-times-ar.html")
                        : new android.content.Intent(c, SettingsActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.pw_root, open);

        if (!Adhan.hasLocation(c)) {
            rv.setTextViewText(R.id.pw_next, "حدّد موقعك");
            rv.setTextViewText(R.id.pw_city, "اضغط لفتح الإعدادات وتحديد موقعك");
            rv.setTextViewText(R.id.pw_after, "");
            rv.setChronometer(R.id.pw_timer, SystemClock.elapsedRealtime(), "", false);
            mgr.updateAppWidget(ids, rv);
            return;
        }

        long now = System.currentTimeMillis();
        long[] t = Adhan.times(c, Calendar.getInstance());
        int next = -1;
        long nextAt = 0;
        for (int k = 0; k < PRAYERS.length; k++) {
            if (t[PRAYERS[k]] > now) { next = k; nextAt = t[PRAYERS[k]]; break; }
        }
        if (next < 0) { // بعد العشاء: فجر الغد
            Calendar tomorrow = Calendar.getInstance();
            tomorrow.add(Calendar.DAY_OF_MONTH, 1);
            next = 0;
            nextAt = Adhan.times(c, tomorrow)[PrayerCalc.FAJR];
        }

        rv.setTextViewText(R.id.pw_next, Adhan.NAMES[PRAYERS[next]] + " " + Adhan.clock(nextAt));
        rv.setTextViewText(R.id.pw_after, "بعد");
        rv.setChronometer(R.id.pw_timer, SystemClock.elapsedRealtime() + (nextAt - now), null, true);
        rv.setChronometerCountDown(R.id.pw_timer, true);

        for (int k = 0; k < CELLS.length; k++) {
            String hm = Adhan.clock(t[PRAYERS[k]]).replace(" ص", "").replace(" م", "");
            rv.setTextViewText(CELLS[k], Adhan.NAMES[PRAYERS[k]] + "\n" + hm);
            boolean isNext = k == next && nextAt - now < 20 * 3_600_000L;
            rv.setTextColor(CELLS[k], isNext ? c.getColor(R.color.gold) : c.getColor(R.color.on_dark_muted));
            rv.setInt(CELLS[k], "setBackgroundResource", isNext ? R.drawable.cell_next : 0);
        }
        String city = Adhan.city(c);
        rv.setTextViewText(R.id.pw_city, (city.isEmpty() ? "" : city + " · ") + "أم القرى");
        mgr.updateAppWidget(ids, rv);
    }
}
