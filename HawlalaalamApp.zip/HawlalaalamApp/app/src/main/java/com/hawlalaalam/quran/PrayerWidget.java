package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.SizeF;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * ويدجت مواقيت الصلاة الذكي:
 * الصلاة القادمة مع عدّاد حي، شريط تقدّم من الصلاة السابقة، التاريخ الهجري،
 * وبطاقة ذكية تتغير حسب الوقت (الشروق، الضحى، ساعة الإجابة، الثلث الأخير، الصيام المسنون، رمضان…).
 * يتكيّف مع الحجم: نسخة مصغّرة عند تصغير الويدجت (أندرويد 12+).
 */
public class PrayerWidget extends AppWidgetProvider {
    static final String ACTION_TICK = "com.hawlalaalam.quran.WIDGET_TICK";
    private static final int[] CELLS = {R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4};
    private static final int[] PRAYERS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        render(context.getApplicationContext(), mgr, ids);
        Adhan.scheduleNext(context.getApplicationContext());
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id, Bundle opts) {
        render(context.getApplicationContext(), mgr, new int[]{id});
    }

    @Override
    public void onDisabled(Context context) {
        context.getSystemService(AlarmManager.class).cancel(tickIntent(context));
    }

    static boolean hasWidgets(Context c) {
        int[] ids = AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, PrayerWidget.class));
        return ids != null && ids.length > 0;
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, PrayerWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids);
    }

    /** حالة واحدة تُحسب مرة وتُرسم على النسختين */
    private static final class State {
        boolean located;
        String next, date;
        long nextAt, now;
        int nextCell = -1, progress;
        long[] today;
        Smart.Tip tip;
    }

    private static State compute(Context c) {
        State s = new State();
        s.now = System.currentTimeMillis();
        s.located = Adhan.hasLocation(c);
        String city = Adhan.city(c);
        String hijri = Ui.hijriToday();
        s.date = hijri + (city.isEmpty() ? "" : " · " + city);
        if (!s.located) return s;

        Calendar cal = Calendar.getInstance();
        s.today = Adhan.times(c, cal);
        for (int k = 0; k < PRAYERS.length; k++) {
            if (s.today[PRAYERS[k]] > s.now) { s.nextCell = k; s.nextAt = s.today[PRAYERS[k]]; break; }
        }
        int nextIndex;
        if (s.nextCell < 0) { // بعد العشاء: فجر الغد
            Calendar tomorrow = Calendar.getInstance();
            tomorrow.add(Calendar.DAY_OF_MONTH, 1);
            s.nextCell = 0;
            s.nextAt = Adhan.times(c, tomorrow)[PrayerCalc.FAJR];
            nextIndex = PrayerCalc.FAJR;
        } else {
            nextIndex = PRAYERS[s.nextCell];
        }
        boolean friday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY && nextIndex == PrayerCalc.DHUHR;
        s.next = (friday ? "الجمعة" : Adhan.NAMES[nextIndex]) + " " + Adhan.clock(s.nextAt);

        // بداية الفترة الحالية: آخر صلاة (أو الشروق) مضت
        long prev = 0;
        for (int i = PrayerCalc.FAJR; i <= PrayerCalc.ISHA; i++) if (s.today[i] <= s.now) prev = s.today[i];
        if (prev == 0) { // قبل الفجر: من عشاء أمس
            Calendar y = Calendar.getInstance();
            y.add(Calendar.DAY_OF_MONTH, -1);
            prev = Adhan.times(c, y)[PrayerCalc.ISHA];
        }
        long span = Math.max(1, s.nextAt - prev);
        s.progress = (int) Math.max(0, Math.min(100, (s.now - prev) * 100 / span));

        try { s.tip = Smart.tip(c); } catch (Exception e) { s.tip = null; }
        return s;
    }

    private static RemoteViews build(Context c, State s, boolean full) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), full ? R.layout.widget_prayer : R.layout.widget_prayer_small);
        PendingIntent open = PendingIntent.getActivity(c, 302,
                s.located ? App.openInApp(c, App.HOME + "prayer-times-ar.html")
                        : new Intent(c, SettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.pw_root, open);

        if (!s.located) {
            rv.setTextViewText(R.id.pw_next, "حدّد موقعك");
            rv.setTextViewText(R.id.pw_tip, "اضغط لفتح الإعدادات وتحديد موقعك");
            rv.setChronometer(R.id.pw_timer, SystemClock.elapsedRealtime(), "", false);
            rv.setProgressBar(R.id.pw_progress, 100, 0, false);
            if (full) {
                rv.setTextViewText(R.id.pw_date, s.date);
                rv.setTextViewText(R.id.pw_after, "");
                for (int cell : CELLS) rv.setTextViewText(cell, "");
            }
            return rv;
        }

        rv.setTextViewText(R.id.pw_next, s.next);
        rv.setChronometer(R.id.pw_timer, SystemClock.elapsedRealtime() + (s.nextAt - s.now), null, true);
        rv.setChronometerCountDown(R.id.pw_timer, true);
        rv.setProgressBar(R.id.pw_progress, 100, s.progress, false);

        if (s.tip != null) {
            rv.setTextViewText(R.id.pw_tip, s.tip.text);
            rv.setOnClickPendingIntent(R.id.pw_tip, PendingIntent.getActivity(c, 306, App.openInApp(c, s.tip.url),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        } else {
            rv.setTextViewText(R.id.pw_tip, "");
        }

        if (full) {
            rv.setTextViewText(R.id.pw_date, s.date);
            rv.setTextViewText(R.id.pw_after, "بعد");
            for (int k = 0; k < CELLS.length; k++) {
                String hm = Adhan.clock(s.today[PRAYERS[k]]).replace(" ص", "").replace(" م", "");
                rv.setTextViewText(CELLS[k], Adhan.NAMES[PRAYERS[k]] + "\n" + hm);
                boolean isNext = k == s.nextCell && s.nextAt - s.now < 20 * 3_600_000L;
                rv.setTextColor(CELLS[k], isNext ? c.getColor(R.color.gold) : c.getColor(R.color.on_dark_muted));
                rv.setInt(CELLS[k], "setBackgroundResource", isNext ? R.drawable.cell_next : 0);
            }
        }
        return rv;
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids) {
        State s = compute(c);
        for (int id : ids) {
            RemoteViews views;
            if (Build.VERSION.SDK_INT >= 31) {
                Map<SizeF, RemoteViews> sizes = new HashMap<>();
                sizes.put(new SizeF(110f, 40f), build(c, s, false));
                sizes.put(new SizeF(220f, 140f), build(c, s, true));
                views = new RemoteViews(sizes);
            } else {
                Bundle o = mgr.getAppWidgetOptions(id);
                int h = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
                views = build(c, s, h == 0 || h >= 120);
            }
            mgr.updateAppWidget(id, views);
        }
        scheduleTick(c, s);
    }

    // ---------------------------------------------------------------- تحديث عند تبدّل البطاقة

    private static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 209, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** منبّه غير دقيق (لا يحتاج إذنًا خاصًا) عند تغيّر البطاقة الذكية أو منتصف الليل */
    private static void scheduleTick(Context c, State s) {
        if (!s.located) return;
        long midnight = Smart.startOfDay(tomorrow());
        long at = midnight;
        if (s.tip != null && s.tip.until > s.now + 60_000L) at = Math.min(at, s.tip.until + 5_000L);
        c.getSystemService(AlarmManager.class).setAndAllowWhileIdle(AlarmManager.RTC, at, tickIntent(c));
    }

    private static Calendar tomorrow() {
        Calendar t = Calendar.getInstance();
        t.add(Calendar.DAY_OF_MONTH, 1);
        return t;
    }
}
