package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;

/**
 * إعادة تشغيل التطبيق بعد تغيير اللغة (مثل ProcessPhoenix): تعمل في عملية مستقلة «:restart»،
 * تنهي عملية التطبيق الأصلية ثم تفتح الرئيسية في عملية جديدة فتُبنى النصوص باللغة المختارة.
 */
public class RestartActivity extends Activity {
    static final String EXTRA_PID = "main_pid";

    static void restart(Activity a) {
        Intent i = new Intent(a, RestartActivity.class)
                .putExtra(EXTRA_PID, Process.myPid())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        a.startActivity(i);
        a.finishAffinity();
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        int pid = getIntent().getIntExtra(EXTRA_PID, -1);
        if (pid > 0) Process.killProcess(pid);
        startActivity(new Intent(this, HomeActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
        finish();
        Runtime.getRuntime().exit(0);
    }
}
