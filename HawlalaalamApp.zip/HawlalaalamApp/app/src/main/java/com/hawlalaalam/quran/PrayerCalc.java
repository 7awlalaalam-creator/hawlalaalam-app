package com.hawlalaalam.quran;

/**
 * حساب مواقيت الصلاة فلكيًا (طريقة أم القرى: الفجر 18.5°، العشاء بعد المغرب بـ90 دقيقة، 120 في رمضان، العصر المثل الأول).
 * مبني على خوارزمية PrayTimes المعروفة.
 */
final class PrayerCalc {
    static final int FAJR = 0, SUNRISE = 1, DHUHR = 2, ASR = 3, MAGHRIB = 4, ISHA = 5;

    private PrayerCalc() { }

    /** @return ساعات محلية عشرية لـ [الفجر، الشروق، الظهر، العصر، المغرب، العشاء] */
    static double[] compute(int year, int month, int day, double lat, double lng, double tz, boolean ramadan) {
        double jd = julian(year, month, day) - lng / (15.0 * 24.0);
        double fajr = sunAngleTime(jd, lat, 18.5, 5 / 24.0, true);
        double sunrise = sunAngleTime(jd, lat, 0.833, 6 / 24.0, true);
        double dhuhr = midDay(jd, 12 / 24.0);
        double asr = asrTime(jd, lat, 1, 13 / 24.0);
        double sunset = sunAngleTime(jd, lat, 0.833, 18 / 24.0, false);

        double adj = tz - lng / 15.0;
        double[] t = {fajr + adj, sunrise + adj, dhuhr + adj, asr + adj, sunset + adj, 0};
        t[ISHA] = t[MAGHRIB] + (ramadan ? 120 : 90) / 60.0;
        return t;
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    /** [الميل، معادلة الزمن] */
    private static double[] sunPosition(double jd) {
        double dd = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * dd);
        double q = fixAngle(280.459 + 0.98564736 * dd);
        double l = fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
        double e = 23.439 - 0.00000036 * dd;
        double ra = atan2(cos(e) * sin(l), cos(l)) / 15.0;
        double eqt = q / 15.0 - fixHour(ra);
        double decl = asin(sin(e) * sin(l));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jd, double t) {
        double eqt = sunPosition(jd + t)[1];
        return fixHour(12 - eqt);
    }

    private static double sunAngleTime(double jd, double lat, double angle, double t, boolean ccw) {
        double decl = sunPosition(jd + t)[0];
        double noon = midDay(jd, t);
        double x = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
        x = Math.max(-1, Math.min(1, x));
        double tt = acos(x) / 15.0;
        return noon + (ccw ? -tt : tt);
    }

    private static double asrTime(double jd, double lat, double factor, double t) {
        double decl = sunPosition(jd + t)[0];
        double angle = -acot(factor + tan(Math.abs(lat - decl)));
        return sunAngleTime(jd, lat, angle, t, false);
    }

    // --- حساب زوايا بالدرجات
    private static double sin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double cos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double tan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double asin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double acos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double atan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double acot(double x) { return Math.toDegrees(Math.atan(1 / x)); }
    private static double fixAngle(double a) { a = a - 360 * Math.floor(a / 360.0); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24 * Math.floor(a / 24.0); return a < 0 ? a + 24 : a; }

    /** 16.25 ← 4:15 م */
    static String format(double h) {
        int total = (int) Math.round(h * 60);
        total = ((total % 1440) + 1440) % 1440;
        return App.formatTime(total / 60, total % 60);
    }
}
