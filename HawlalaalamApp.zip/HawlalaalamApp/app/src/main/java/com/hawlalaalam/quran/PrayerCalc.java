package com.hawlalaalam.quran;

/**
 * حساب مواقيت الصلاة فلكيًا. مبني على خوارزمية PrayTimes المعروفة.
 * طريقة الحساب تُختار تلقائيًا حسب الدولة (أم القرى في السعودية، الهيئة المصرية في مصر…) أو يدويًا من الإعدادات.
 * العصر بالمثل الأول (الجمهور).
 */
final class PrayerCalc {
    static final int FAJR = 0, SUNRISE = 1, DHUHR = 2, ASR = 3, MAGHRIB = 4, ISHA = 5;

    /** طريقة حساب: زاوية الفجر، وزاوية العشاء أو مدة ثابتة بعد المغرب (بالدقائق) */
    static final class Method {
        final String name;
        final double fajr, isha;
        final int ishaMin, ishaMinRamadan;

        Method(String name, double fajr, double isha) { this(name, fajr, isha, 0, 0); }

        Method(String name, double fajr, double isha, int ishaMin, int ishaMinRamadan) {
            this.name = name; this.fajr = fajr; this.isha = isha;
            this.ishaMin = ishaMin; this.ishaMinRamadan = ishaMinRamadan;
        }

        /** «الفجر ١٨٫٥° · العشاء بعد المغرب بـ٩٠ دقيقة» */
        String detail() {
            String f = L.t("الفجر ") + deg(fajr);
            String i = ishaMin > 0 ? L.t("العشاء بعد المغرب بـ") + Adhan.arabic(String.valueOf(ishaMin)) + L.t(" دقيقة")
                    + (ishaMinRamadan > ishaMin ? " (" + Adhan.arabic(String.valueOf(ishaMinRamadan)) + L.t(" في رمضان)") : "")
                    : L.t("العشاء ") + deg(isha);
            return f + " · " + i;
        }

        private static String deg(double d) {
            String s = d == Math.floor(d) ? String.valueOf((int) d) : String.valueOf(d).replace('.', '٫');
            return Adhan.arabic(s) + "°";
        }
    }

    /** الفهرس 0 محجوز لـ«تلقائي حسب الدولة» */
    static final Method[] METHODS = {
            null,
            new Method(L.t("أم القرى (السعودية)"), 18.5, 0, 90, 120),
            new Method(L.t("الهيئة المصرية العامة للمساحة"), 19.5, 17.5),
            new Method(L.t("رابطة العالم الإسلامي"), 18, 17),
            new Method(L.t("جامعة العلوم الإسلامية بكراتشي"), 18, 18),
            new Method(L.t("الجمعية الإسلامية لأمريكا الشمالية"), 15, 15),
            new Method(L.t("دبي (الإمارات)"), 18.2, 18.2),
            new Method(L.t("الكويت"), 18, 17.5),
            new Method(L.t("قطر"), 18, 0, 90, 90),
            new Method(L.t("الخليج (البحرين وعُمان)"), 19.5, 0, 90, 90),
            new Method(L.t("وزارة الأوقاف المغربية"), 19, 17),
            new Method(L.t("الجزائر"), 18, 17),
            new Method(L.t("تونس"), 18, 18),
            new Method(L.t("الأردن"), 18, 18),
            new Method(L.t("رئاسة الشؤون الدينية التركية"), 18, 17),
            new Method(L.t("ماليزيا وسنغافورة وإندونيسيا"), 20, 18),
            new Method(L.t("روسيا"), 16, 15),
    };
    static final int UMM_AL_QURA = 1, EGYPT = 2, MWL = 3, KARACHI = 4, ISNA = 5, DUBAI = 6, KUWAIT = 7, QATAR = 8,
            GULF = 9, MOROCCO = 10, ALGERIA = 11, TUNISIA = 12, JORDAN = 13, TURKEY = 14, SEA = 15, RUSSIA = 16;

    /** الطريقة المعتمدة في الدولة (رمز ISO من حرفين)؛ غير المعروف ← رابطة العالم الإسلامي */
    static int forCountry(String cc) {
        if (cc == null) return MWL;
        switch (cc.toUpperCase(java.util.Locale.ROOT)) {
            case "SA": case "YE": return UMM_AL_QURA;
            case "AE": return DUBAI;
            case "KW": return KUWAIT;
            case "QA": return QATAR;
            case "BH": case "OM": return GULF;
            case "EG": case "SD": case "SS": case "LY": case "SY": case "LB": case "IQ": case "PS": return EGYPT;
            case "JO": return JORDAN;
            case "MA": return MOROCCO;
            case "DZ": return ALGERIA;
            case "TN": return TUNISIA;
            case "TR": return TURKEY;
            case "PK": case "IN": case "BD": case "AF": return KARACHI;
            case "US": case "CA": return ISNA;
            case "MY": case "SG": case "ID": case "BN": return SEA;
            case "RU": return RUSSIA;
            default: return MWL;
        }
    }

    private PrayerCalc() { }

    /** أم القرى (للتوافق مع الاستدعاءات القديمة) */
    static double[] compute(int year, int month, int day, double lat, double lng, double tz, boolean ramadan) {
        return compute(year, month, day, lat, lng, tz, ramadan, METHODS[UMM_AL_QURA]);
    }

    /** @return ساعات محلية عشرية لـ [الفجر، الشروق، الظهر، العصر، المغرب، العشاء] */
    static double[] compute(int year, int month, int day, double lat, double lng, double tz, boolean ramadan, Method m) {
        double jd = julian(year, month, day) - lng / (15.0 * 24.0);
        double fajr = sunAngleTime(jd, lat, m.fajr, 5 / 24.0, true);
        double sunrise = sunAngleTime(jd, lat, 0.833, 6 / 24.0, true);
        double dhuhr = midDay(jd, 12 / 24.0);
        double asr = asrTime(jd, lat, 1, 13 / 24.0);
        double sunset = sunAngleTime(jd, lat, 0.833, 18 / 24.0, false);
        double isha = m.ishaMin > 0 ? sunset + (ramadan ? m.ishaMinRamadan : m.ishaMin) / 60.0
                : sunAngleTime(jd, lat, m.isha, 18 / 24.0, false);

        // خطوط العرض العليا: قد لا تبلغ الشمس زاوية الفجر/العشاء صيفًا، فنحدّها بنسبة من الليل (AngleBased)
        double night = 24 - (sunset - sunrise);
        double fajrLimit = m.fajr / 60.0 * night;
        if (Double.isNaN(fajr) || sunrise - fajr > fajrLimit) fajr = sunrise - fajrLimit;
        if (m.ishaMin == 0) {
            double ishaLimit = m.isha / 60.0 * night;
            if (Double.isNaN(isha) || isha - sunset > ishaLimit) isha = sunset + ishaLimit;
        }

        double adj = tz - lng / 15.0;
        return new double[]{fajr + adj, sunrise + adj, dhuhr + adj, asr + adj, sunset + adj, isha + adj};
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    /** [الميل، معادلة الزمن] */
    private static double[] sunPosition(double jd) {
        double dd = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * dd);
        double q = fixAngle(280.459 + 0.98564736 * dd);
        double l = fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
        double e = 23.439 - 0.00000036 * dd;
        double ra = atan2(cos(e) * sin(l), cos(l)) / 15.0;
        double eqt = q / 15.0 - fixHour(ra);
        double decl = asin(sin(e) * sin(l));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jd, double t) {
        double eqt = sunPosition(jd + t)[1];
        return fixHour(12 - eqt);
    }

    private static double sunAngleTime(double jd, double lat, double angle, double t, boolean ccw) {
        double decl = sunPosition(jd + t)[0];
        double noon = midDay(jd, t);
        double x = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
        x = Math.max(-1, Math.min(1, x));
        double tt = acos(x) / 15.0;
        return noon + (ccw ? -tt : tt);
    }

    private static double asrTime(double jd, double lat, double factor, double t) {
        double decl = sunPosition(jd + t)[0];
        double angle = -acot(factor + tan(Math.abs(lat - decl)));
        return sunAngleTime(jd, lat, angle, t, false);
    }

    // --- حساب زوايا بالدرجات
    private static double sin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double cos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double tan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double asin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double acos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double atan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double acot(double x) { return Math.toDegrees(Math.atan(1 / x)); }
    private static double fixAngle(double a) { a = a - 360 * Math.floor(a / 360.0); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24 * Math.floor(a / 24.0); return a < 0 ? a + 24 : a; }

    /** 16.25 ← 4:15 م */
    static String format(double h) {
        int total = (int) Math.round(h * 60);
        total = ((total % 1440) + 1440) % 1440;
        return App.formatTime(total / 60, total % 60);
    }
}
