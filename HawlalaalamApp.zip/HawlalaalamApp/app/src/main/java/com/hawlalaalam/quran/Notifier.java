package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.os.Build;

final class Notifier {
    static final String CH_VERSE = "verse";
    static final String CH_WIRD = "wird";
    static final String CH_ADHAN = "adhan";
    static final String CH_REMIND = "reminders";

    private Notifier() { }

    static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_VERSE, "آية اليوم", NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel(CH_WIRD, "تذكير الورد اليومي", NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel(CH_ADHAN, "الأذان", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(CH_REMIND, "الأذكار وسورة الكهف", NotificationManager.IMPORTANCE_DEFAULT));
    }

    static boolean allowed(Context c) {
        return Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private static PendingIntent open(Context c, String url, int req) {
        return PendingIntent.getActivity(c, req, App.openInApp(c, url),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static Notification.Builder base(Context c, String ch) {
        return new Notification.Builder(c, ch)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(c.getColor(R.color.gold_deep))
                .setAutoCancel(true);
    }

    static void verse(Context c, VerseRepo.Verse v) {
        if (!allowed(c)) return;
        ensureChannels(c);
        Notification.Builder b = base(c, CH_VERSE).setContentTitle("✦ آية اليوم");
        if (v != null && v.text != null && !v.text.isEmpty()) {
            b.setContentText("﴿ " + v.text + " ﴾")
             .setStyle(new Notification.BigTextStyle().bigText("﴿ " + v.text + " ﴾\n" + v.ref()))
             .setContentIntent(open(c, v.tafsirUrl(), 101))
             .addAction(new Notification.Action.Builder(
                     Icon.createWithResource(c, R.drawable.ic_stat_quran), "شارك كصورة",
                     open(c, v.cardUrl(), 102)).build())
             .addAction(new Notification.Action.Builder(
                     Icon.createWithResource(c, R.drawable.ic_stat_quran), "التفسير",
                     open(c, v.tafsirUrl(), 103)).build());
        } else {
            b.setContentText("آية اليوم بانتظارك، افتح وتدبّر 🌿")
             .setContentIntent(open(c, App.HOME, 104));
        }
        c.getSystemService(NotificationManager.class).notify(1, b.build());
    }

    static void wird(Context c) {
        if (!allowed(c)) return;
        ensureChannels(c);
        Notification.Builder b = base(c, CH_WIRD);
        if (Khatma.active(c) && !Khatma.done(c)) {
            int left = Khatma.todayRemaining(c);
            if (left == 0) return;                       // أتمّ ورده، لا داعي للتذكير
            int[] r = Khatma.todayRange(c);
            int open = Math.max(r[0], Khatma.nextPage(c));
            b.setContentTitle("📖 ورد الختمة")
             .setContentText(left < Khatma.dailyTarget(c)
                     ? "بقي لك " + Adhan.arabic(String.valueOf(left)) + " صفحات من ورد اليوم"
                     : "ورد اليوم: صفحة " + Adhan.arabic(String.valueOf(r[0])) + " إلى " + Adhan.arabic(String.valueOf(r[1])))
             .setContentIntent(open(c, Khatma.pageUrl(open), 105))
             .addAction(new Notification.Action.Builder(
                     Icon.createWithResource(c, R.drawable.ic_stat_quran),
                     "افتح الصفحة " + Adhan.arabic(String.valueOf(open)), open(c, Khatma.pageUrl(open), 106)).build());
        } else {
            b.setContentTitle("📖 وردك اليومي")
             .setContentText("قليلٌ دائم، وأثرٌ في القلب. أكمل من حيث توقفت")
             .setContentIntent(open(c, App.HOME, 105))
             .addAction(new Notification.Action.Builder(
                     Icon.createWithResource(c, R.drawable.ic_stat_quran), "افتح المصحف",
                     open(c, App.MUSHAF, 106)).build());
        }
        c.getSystemService(NotificationManager.class).notify(2, b.build());
    }

    /** عند أذان المغرب في رمضان */
    static void iftar(Context c) {
        if (!allowed(c)) return;
        ensureChannels(c);
        Notification n = base(c, CH_ADHAN)
                .setContentTitle("🌙 حان وقت الإفطار")
                .setContentText("ذهب الظمأ وابتلّت العروق وثبت الأجر إن شاء الله")
                .setStyle(new Notification.BigTextStyle().bigText(
                        "«ذَهَبَ الظَّمَأُ، وَابْتَلَّتِ الْعُرُوقُ، وَثَبَتَ الأَجْرُ إِنْ شَاءَ اللَّهُ»\nتقبّل الله صيامكم"))
                .setContentIntent(open(c, Ramadan.tadabburUrl(), 108))
                .build();
        c.getSystemService(NotificationManager.class).notify(8, n);
    }

    /** زر «شارك الأجر»: نشر الفضل مع رابط الموقع (الدال على الخير كفاعله) */
    private static PendingIntent shareFadl(Context c, String[] f, int req) {
        String text = f[0] + "\n— " + f[1] + "\n\n" + App.HOME;
        Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
        Intent chooser = Intent.createChooser(send, "شارك الأجر").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, req, chooser,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static String nextLine(Context c, int index) {
        String[] nx = Adhan.after(c, index);
        return nx == null ? "" : "\n\n⏱ التالي: " + nx[0] + " " + nx[1];
    }

    static void adhan(Context c, int index) {
        if (!allowed(c)) return;
        ensureChannels(c);
        java.util.Calendar now = java.util.Calendar.getInstance();
        boolean friday = now.get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.FRIDAY;
        String name = (friday && index == PrayerCalc.DHUHR) ? "الجمعة" : Adhan.NAMES[index];
        String city = Adhan.city(c);
        String[] f = Fadl.of(index, now);
        String big = f[0] + "\n— " + f[1] + nextLine(c, index)
                + (city.isEmpty() ? "" : "\n📍 حسب التوقيت المحلي لـ" + city);
        Notification n = base(c, CH_ADHAN)
                .setContentTitle("🕌 حان الآن موعد صلاة " + name)
                .setContentText(f[0])
                .setStyle(new Notification.BigTextStyle().bigText(big))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(open(c, App.HOME + "prayer-times-ar.html", 107))
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_stat_quran), "شارك الأجر",
                        shareFadl(c, f, 120 + index)).build())
                .build();
        c.getSystemService(NotificationManager.class).notify(4, n);
    }

    /** الشروق: انتهاء وقت الفجر، وفضل الجلوس للذكر وصلاة الضحى */
    static void sunrise(Context c) {
        if (!allowed(c)) return;
        ensureChannels(c);
        String[] f = Fadl.of(PrayerCalc.SUNRISE, java.util.Calendar.getInstance());
        String duha = Adhan.clock(System.currentTimeMillis() + 15 * 60_000L);
        String big = f[0] + "\n— " + f[1]
                + "\n\n☀️ يبدأ وقت الضحى بعد ارتفاع الشمس، نحو " + duha + nextLine(c, PrayerCalc.SUNRISE);
        Notification n = base(c, CH_ADHAN)
                .setContentTitle("🌅 أشرقت الشمس · انتهى وقت الفجر")
                .setContentText(f[0])
                .setStyle(new Notification.BigTextStyle().bigText(big))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(open(c, App.HOME + "azkar-morning-evening-ar.html", 109))
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_stat_quran), "أذكار الصباح",
                        open(c, App.HOME + "azkar-morning-evening-ar.html", 119)).build())
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_stat_quran), "شارك الأجر",
                        shareFadl(c, f, 126)).build())
                .build();
        c.getSystemService(NotificationManager.class).notify(9, n);
    }

    /** ليلة يوم الصيام المسنون (عند العشاء) */
    static void fasting(Context c, String[] fast) {
        if (!allowed(c) || fast == null) return;
        ensureChannels(c);
        String big = "غدًا " + fast[0] + "، ولا تنسَ نية الصيام والسحور فإن فيه بركة.\n\n"
                + fast[1] + "\n— " + fast[2] + "\n\n(حسب تقويم أم القرى)";
        Notification n = base(c, CH_REMIND)
                .setContentTitle("🌙 غدًا " + fast[0])
                .setContentText(fast[1])
                .setStyle(new Notification.BigTextStyle().bigText(big))
                .setContentIntent(open(c, App.HOME, 127))
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_stat_quran), "ذكّر من تحب",
                        shareFadl(c, new String[]{"🌙 غدًا " + fast[0] + "\n" + fast[1], fast[2]}, 128)).build())
                .build();
        c.getSystemService(NotificationManager.class).notify(10, n);
    }

    /** أذكار الصباح والمساء وسورة الكهف */
    static void reminder(Context c, String kind) {
        if (!allowed(c)) return;
        ensureChannels(c);
        String title, text, url;
        int id;
        switch (kind) {
            case Reminders.AZKAR_AM:
                title = "☀️ أذكار الصباح"; text = "حصّن يومك بذكر الله"; url = App.HOME + "azkar-morning-evening-ar.html"; id = 5; break;
            case Reminders.AZKAR_PM:
                title = "🌙 أذكار المساء"; text = "اختم نهارك بذكر الله"; url = App.HOME + "azkar-morning-evening-ar.html"; id = 6; break;
            default:
                title = "📖 سورة الكهف"; text = "يوم الجمعة: نورٌ لك ما بين الجمعتين"; url = App.HOME + "surah-18.html"; id = 7;
        }
        Notification n = base(c, CH_REMIND)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open(c, url, 110 + id))
                .build();
        c.getSystemService(NotificationManager.class).notify(id, n);
    }
}
