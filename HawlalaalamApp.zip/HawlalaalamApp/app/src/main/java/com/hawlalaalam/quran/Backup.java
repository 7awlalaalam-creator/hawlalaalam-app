package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * ملف النسخة الاحتياطية الموحّد بين أندرويد وآيفون:
 * {"app":"hawlalaalam","v":1,"at":unix,"platform":"android","prefs":{...},"types":{...},"web":{...}}
 * prefs: إعدادات «settings» بأسمائها، وبقية الملفات بمقدّمة «khatma.» و«reading.» و«tasbeeh.»
 * web: مفاتيح localStorage لصفحة المصحف (العلامات، الحفظ، الملاحظات، التظليل) — متطابقة في النسختين.
 * لا تُضمَّن مفاتيح تقنية خاصة بالجهاز ولا التلاوات المحمّلة.
 */
final class Backup {
    private Backup() { }

    static final String[] FILES = {"settings", "khatma", "reading", "tasbeeh"};

    /** مفاتيح لا تُنقل بين الأجهزة */
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            "bridge_diag", "crash_meta", "crash_text", "internal_device", "notice_checked", "notice_seen",
            "update_checked", "theme_sys_reset", "adhan_when", "adhan_blocked_at", "push_token", "fcm_token",
            "web_state", "web_restore_pending", "backup_last_export", "reminders_asked_v"));

    private static boolean skip(String key) {
        return SKIP.contains(key) || key.startsWith("crash_") || key.startsWith("adhan_late") || key.endsWith("_token");
    }

    /*
     * أسماء موحّدة بين النسختين (مثل آيفون): khatma_X و tasbeeh_X و read_days (مصفوفة أيام yyyy-MM-dd)
     * و listen_favs (مصفوفة أرقام) و listen_last ({reciter,moshaf,surah,pos بالثواني}).
     * الاستيراد يقبل أيضًا الصيغة القديمة (khatma.X …) من نسخ أندرويد السابقة.
     */
    private static final Set<String> KH_LONG = new HashSet<>(Arrays.asList("base_day", "day", "end", "last_read", "start", "total"));
    private static final Set<String> KH_BOOL = new HashSet<>(Arrays.asList("active", "extend", "extended_note", "just_done"));
    private static final Set<String> KH_STR = new HashSet<>(Arrays.asList("history", "label", "log", "mode", "pages"));

    static String exportJson(Context c) throws Exception {
        JSONObject prefs = new JSONObject(), types = new JSONObject();
        for (String file : FILES) {
            SharedPreferences sp = c.getSharedPreferences(file, Context.MODE_PRIVATE);
            for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
                String k = e.getKey();
                if (skip(k)) continue;
                Object v = e.getValue();
                String key;
                if (file.equals("settings")) key = k;
                else if (file.equals("khatma")) key = "khatma_" + k;
                else if (file.equals("tasbeeh")) key = "tasbeeh_" + k;
                else if (file.equals("reading") && k.equals("days")) {
                    JSONArray days = new JSONArray();
                    for (String d : String.valueOf(v).split(",")) if (!d.trim().isEmpty()) days.put(d.trim());
                    prefs.put("read_days", days); types.put("read_days", "days");
                    continue;
                } else key = file + "." + k;
                if (key.equals("listen_favs") && v instanceof String) {
                    JSONArray favs = new JSONArray();
                    try { JSONArray in = new JSONArray((String) v); for (int i = 0; i < in.length(); i++) favs.put(in.optInt(i)); } catch (Exception ignored) { }
                    prefs.put(key, favs); types.put(key, "favs");
                    continue;
                }
                if (key.equals("listen_last") && v instanceof String) {
                    try {
                        JSONObject l = new JSONObject((String) v);
                        prefs.put(key, new JSONObject().put("reciter", l.optInt("reciter")).put("moshaf", l.optInt("moshaf"))
                                .put("surah", l.optInt("surah")).put("pos", l.optLong("pos") / 1000.0));
                        types.put(key, "last");
                    } catch (Exception ignored) { }
                    continue;
                }
                if (v instanceof Boolean) { prefs.put(key, v); types.put(key, "b"); }
                else if (v instanceof Integer) { prefs.put(key, v); types.put(key, "i"); }
                else if (v instanceof Long) { prefs.put(key, v); types.put(key, "l"); }
                else if (v instanceof Float) { prefs.put(key, ((Float) v).doubleValue()); types.put(key, "f"); }
                else if (v instanceof String) { prefs.put(key, v); types.put(key, "s"); }
                else if (v instanceof Set) {
                    JSONArray arr = new JSONArray();
                    for (Object x : (Set<?>) v) arr.put(String.valueOf(x));
                    prefs.put(key, arr);
                    types.put(key, "set");
                }
            }
        }
        JSONObject web = new JSONObject();
        try { web = new JSONObject(App.prefs(c).getString("web_state", "{}")); } catch (Exception ignored) { }
        return new JSONObject().put("app", "hawlalaalam").put("v", 1).put("at", System.currentTimeMillis() / 1000)
                .put("platform", "android").put("version", App.versionName(c))
                .put("prefs", prefs).put("types", types).put("web", web).toString(1);
    }

    static final class Summary { int keys, web; long at; String platform; }

    static Summary inspect(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!"hawlalaalam".equals(o.optString("app"))) throw new IllegalArgumentException(L.t("ليس ملف نسخة احتياطية من التطبيق"));
        Summary s = new Summary();
        JSONObject p = o.optJSONObject("prefs");
        JSONObject w = o.optJSONObject("web");
        s.keys = p == null ? 0 : p.length();
        s.web = w == null ? 0 : w.length();
        s.at = o.optLong("at") * 1000;
        s.platform = o.optString("platform");
        return s;
    }

    /** يستبدل بيانات التطبيق بما في الملف (من أندرويد أو آيفون) */
    static void restore(Context c, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!"hawlalaalam".equals(o.optString("app"))) throw new IllegalArgumentException(L.t("ليس ملف نسخة احتياطية من التطبيق"));
        JSONObject prefs = o.optJSONObject("prefs");
        JSONObject types = o.optJSONObject("types");
        if (types == null) types = new JSONObject();
        boolean fromAndroid = "android".equals(o.optString("platform"));
        if (prefs != null) {
            SharedPreferences.Editor[] eds = new SharedPreferences.Editor[FILES.length];
            for (int i = 0; i < FILES.length; i++) {
                SharedPreferences sp = c.getSharedPreferences(FILES[i], Context.MODE_PRIVATE);
                eds[i] = sp.edit();
                // من أندرويد: استبدال كامل. من آيفون: نستبدل الختمة/التسبيح/أيام القراءة فقط إن كانت في الملف
                boolean replace = fromAndroid
                        || (i == 1 && hasPrefix(prefs, "khatma_")) || (i == 3 && hasPrefix(prefs, "tasbeeh_"));
                if (replace) { for (String k : sp.getAll().keySet()) if (!skip(k)) eds[i].remove(k); }
                else if (i == 2 && prefs.has("read_days")) eds[i].remove("days");
            }
            Iterator<String> it = prefs.keys();
            while (it.hasNext()) {
                String key = it.next();
                Object v = prefs.get(key);
                String t = types.optString(key, "");
                int fi = 0;
                String k = key;
                if (key.startsWith("khatma_") || key.startsWith("khatma.")) { fi = 1; k = key.substring(7); }
                else if (key.startsWith("tasbeeh_") || key.startsWith("tasbeeh.")) { fi = 3; k = key.substring(8); }
                else if (key.equals("read_days")) {
                    StringBuilder sb = new StringBuilder();
                    if (v instanceof JSONArray) for (int j = 0; j < ((JSONArray) v).length(); j++) { if (sb.length() > 0) sb.append(','); sb.append(((JSONArray) v).optString(j)); }
                    else sb.append(String.valueOf(v));
                    eds[2].putString("days", sb.toString());
                    continue;
                } else if (key.startsWith("reading.")) { fi = 2; k = key.substring(8); }
                if (skip(k)) continue;
                if (fi == 0 && key.equals("listen_favs")) {
                    JSONArray favs = new JSONArray();
                    try {
                        JSONArray in = v instanceof JSONArray ? (JSONArray) v : new JSONArray(String.valueOf(v));
                        for (int j = 0; j < in.length(); j++) if (in.optInt(j) > 0) favs.put(in.optInt(j));
                    } catch (Exception ignored) { }
                    eds[0].putString("listen_favs", favs.toString());
                    continue;
                }
                if (fi == 0 && key.equals("listen_last")) {
                    try {
                        JSONObject l = v instanceof JSONObject ? (JSONObject) v : new JSONObject(String.valueOf(v));
                        double pos = l.optDouble("pos", 0);
                        if (!"last".equals(t) && !fromAndroid && l.has("track")) {
                            // صيغة آيفون القديمة: {track:{…}, pos}
                            JSONObject tr = l.optJSONObject("track");
                            if (tr != null) l = new JSONObject().put("reciter", tr.optInt("reciterId", tr.optInt("reciter")))
                                    .put("moshaf", tr.optInt("moshafId", tr.optInt("moshaf"))).put("surah", tr.optInt("surah"));
                        }
                        long ms = fromAndroid && !"last".equals(t) ? (long) pos : (long) (pos * 1000);
                        if (l.optInt("reciter") > 0 && l.optInt("surah") > 0)
                            eds[0].putString("listen_last", new JSONObject().put("reciter", l.optInt("reciter")).put("moshaf", l.optInt("moshaf"))
                                    .put("surah", l.optInt("surah")).put("pos", ms).put("at", System.currentTimeMillis()).toString());
                    } catch (Exception ignored) { }
                    continue;
                }
                if (t.isEmpty() || "s".equals(t) && fi == 1 && !KH_STR.contains(k)) {
                    if (fi == 1) t = KH_BOOL.contains(k) ? "b" : KH_LONG.contains(k) ? "l" : KH_STR.contains(k) ? "s" : "i";
                    else if (fi == 3) t = k.equals("total") ? "l" : "i";
                    else {
                        Object curV = c.getSharedPreferences(FILES[fi], Context.MODE_PRIVATE).getAll().get(k);
                        t = curV instanceof Boolean ? "b" : curV instanceof Integer ? "i" : curV instanceof Long ? "l"
                                : curV instanceof Float ? "f" : curV instanceof Set ? "set" : v instanceof Boolean ? "b"
                                : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Number ? "f" : "s";
                    }
                }
                SharedPreferences.Editor e = eds[fi];
                switch (t) {
                    case "b": e.putBoolean(k, v instanceof Boolean ? (Boolean) v : Boolean.parseBoolean(String.valueOf(v))); break;
                    case "i": e.putInt(k, ((Number) num(v)).intValue()); break;
                    case "l": e.putLong(k, ((Number) num(v)).longValue()); break;
                    case "f": e.putFloat(k, ((Number) num(v)).floatValue()); break;
                    case "set": {
                        Set<String> set = new HashSet<>();
                        if (v instanceof JSONArray) for (int j = 0; j < ((JSONArray) v).length(); j++) set.add(((JSONArray) v).optString(j));
                        e.putStringSet(k, set);
                        break;
                    }
                    default: e.putString(k, v instanceof String ? (String) v : String.valueOf(v));
                }
            }
            for (SharedPreferences.Editor e : eds) e.commit();
        }
        JSONObject web = o.optJSONObject("web");
        if (web != null && web.length() > 0) {
            App.prefs(c).edit().putString("web_state", web.toString()).putBoolean("web_restore_pending", true).commit();
        }
        // إعادة الجدولة والويدجات بالبيانات الجديدة
        Context a = c.getApplicationContext();
        try { Reminders.scheduleAll(a); } catch (Throwable ignored) { }
        try { Adhan.scheduleNext(a); } catch (Throwable ignored) { }
        try { PrayerWidget.updateAll(a); VerseWidget.updateAll(a); KhatmaWidget.updateAll(a); } catch (Throwable ignored) { }
    }

    private static boolean hasPrefix(JSONObject p, String pre) {
        Iterator<String> it = p.keys();
        while (it.hasNext()) if (it.next().startsWith(pre)) return true;
        return false;
    }

    private static Object num(Object v) {
        if (v instanceof Number) return v;
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    static String fileName() {
        return "hawlalaalam-backup-" + new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()) + ".json";
    }
}
