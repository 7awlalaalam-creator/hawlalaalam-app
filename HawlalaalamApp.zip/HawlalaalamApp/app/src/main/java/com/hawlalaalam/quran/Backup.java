package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * ملف النسخة الاحتياطية الموحّد بين أندرويد وآيفون:
 * {"app":"hawlalaalam","v":1,"at":unix,"platform":"android","prefs":{...},"types":{...},"web":{...}}
 * prefs: إعدادات «settings» بأسمائها، وبقية الملفات بمقدّمة «khatma.» و«reading.» و«tasbeeh.»
 * web: مفاتيح localStorage لصفحة المصحف (العلامات، الحفظ، الملاحظات، التظليل) — متطابقة في النسختين.
 * لا تُضمَّن مفاتيح تقنية خاصة بالجهاز ولا التلاوات المحمّلة.
 */
final class Backup {
    private Backup() { }

    static final String[] FILES = {"settings", "khatma", "reading", "tasbeeh"};

    /** مفاتيح لا تُنقل بين الأجهزة */
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            "bridge_diag", "crash_meta", "crash_text", "internal_device", "notice_checked", "notice_seen",
            "update_checked", "theme_sys_reset", "adhan_when", "adhan_blocked_at", "push_token", "fcm_token",
            "web_state", "web_restore_pending", "backup_last_export", "reminders_asked_v"));

    private static boolean skip(String key) {
        return SKIP.contains(key) || key.startsWith("crash_") || key.startsWith("adhan_late") || key.endsWith("_token");
    }

    static String exportJson(Context c) throws Exception {
        JSONObject prefs = new JSONObject(), types = new JSONObject();
        for (String file : FILES) {
            SharedPreferences sp = c.getSharedPreferences(file, Context.MODE_PRIVATE);
            for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
                String k = e.getKey();
                if (skip(k)) continue;
                String key = file.equals("settings") ? k : file + "." + k;
                Object v = e.getValue();
                if (v instanceof Boolean) { prefs.put(key, v); types.put(key, "b"); }
                else if (v instanceof Integer) { prefs.put(key, v); types.put(key, "i"); }
                else if (v instanceof Long) { prefs.put(key, v); types.put(key, "l"); }
                else if (v instanceof Float) { prefs.put(key, ((Float) v).doubleValue()); types.put(key, "f"); }
                else if (v instanceof String) { prefs.put(key, v); types.put(key, "s"); }
                else if (v instanceof Set) {
                    JSONArray a = new JSONArray();
                    for (Object x : (Set<?>) v) a.put(String.valueOf(x));
                    prefs.put(key, a);
                    types.put(key, "set");
                }
            }
        }
        JSONObject web = new JSONObject();
        try { web = new JSONObject(App.prefs(c).getString("web_state", "{}")); } catch (Exception ignored) { }
        return new JSONObject().put("app", "hawlalaalam").put("v", 1).put("at", System.currentTimeMillis() / 1000)
                .put("platform", "android").put("version", App.versionName(c))
                .put("prefs", prefs).put("types", types).put("web", web).toString(1);
    }

    static final class Summary { int keys, web; long at; String platform; }

    static Summary inspect(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!"hawlalaalam".equals(o.optString("app"))) throw new IllegalArgumentException("ليس ملف نسخة احتياطية من التطبيق");
        Summary s = new Summary();
        JSONObject p = o.optJSONObject("prefs");
        JSONObject w = o.optJSONObject("web");
        s.keys = p == null ? 0 : p.length();
        s.web = w == null ? 0 : w.length();
        s.at = o.optLong("at") * 1000;
        s.platform = o.optString("platform");
        return s;
    }

    /** يستبدل بيانات التطبيق بما في الملف. القيم من نسخة آيفون تُطابَق بأنواع القيم الحالية إن وُجدت */
    static void restore(Context c, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        if (!"hawlalaalam".equals(o.optString("app"))) throw new IllegalArgumentException("ليس ملف نسخة احتياطية من التطبيق");
        JSONObject prefs = o.optJSONObject("prefs");
        JSONObject types = o.optJSONObject("types");
        if (types == null) types = new JSONObject();
        boolean fromAndroid = "android".equals(o.optString("platform"));
        if (prefs != null) {
            SharedPreferences.Editor[] eds = new SharedPreferences.Editor[FILES.length];
            for (int i = 0; i < FILES.length; i++) {
                SharedPreferences sp = c.getSharedPreferences(FILES[i], Context.MODE_PRIVATE);
                eds[i] = sp.edit();
                if (fromAndroid) {
                    // استبدال كامل: نحذف ما ليس تقنيًا ثم نكتب ما في الملف
                    for (String k : sp.getAll().keySet()) if (!skip(k)) eds[i].remove(k);
                }
            }
            Iterator<String> it = prefs.keys();
            while (it.hasNext()) {
                String key = it.next();
                int fi = 0;
                String k = key;
                for (int i = 1; i < FILES.length; i++) {
                    if (key.startsWith(FILES[i] + ".")) { fi = i; k = key.substring(FILES[i].length() + 1); break; }
                }
                if (skip(k)) continue;
                Object v = prefs.get(key);
                String t = types.optString(key, "");
                if (t.isEmpty()) {
                    // من آيفون: نستنتج النوع من القيمة الحالية على الجهاز إن وُجدت
                    Object curV = c.getSharedPreferences(FILES[fi], Context.MODE_PRIVATE).getAll().get(k);
                    t = curV instanceof Boolean ? "b" : curV instanceof Integer ? "i" : curV instanceof Long ? "l"
                            : curV instanceof Float ? "f" : curV instanceof Set ? "set" : v instanceof Boolean ? "b"
                            : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Number ? "f" : "s";
                    if (!fromAndroid && curV == null && !"settings".equals(FILES[fi])) continue;
                }
                SharedPreferences.Editor e = eds[fi];
                switch (t) {
                    case "b": e.putBoolean(k, v instanceof Boolean ? (Boolean) v : Boolean.parseBoolean(String.valueOf(v))); break;
                    case "i": e.putInt(k, ((Number) num(v)).intValue()); break;
                    case "l": e.putLong(k, ((Number) num(v)).longValue()); break;
                    case "f": e.putFloat(k, ((Number) num(v)).floatValue()); break;
                    case "set": {
                        Set<String> set = new HashSet<>();
                        if (v instanceof JSONArray) for (int j = 0; j < ((JSONArray) v).length(); j++) set.add(((JSONArray) v).optString(j));
                        e.putStringSet(k, set);
                        break;
                    }
                    default: e.putString(k, v instanceof String ? (String) v : String.valueOf(v));
                }
            }
            for (SharedPreferences.Editor e : eds) e.commit();
        }
        JSONObject web = o.optJSONObject("web");
        if (web != null && web.length() > 0) {
            App.prefs(c).edit().putString("web_state", web.toString()).putBoolean("web_restore_pending", true).commit();
        }
        // إعادة الجدولة والويدجات بالبيانات الجديدة
        Context a = c.getApplicationContext();
        try { Reminders.scheduleAll(a); } catch (Throwable ignored) { }
        try { Adhan.scheduleNext(a); } catch (Throwable ignored) { }
        try { PrayerWidget.updateAll(a); VerseWidget.updateAll(a); KhatmaWidget.updateAll(a); } catch (Throwable ignored) { }
    }

    private static Object num(Object v) {
        if (v instanceof Number) return v;
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    static String fileName() {
        return "hawlalaalam-backup-" + new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()) + ".json";
    }
}
