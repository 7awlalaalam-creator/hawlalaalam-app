package com.hawlalaalam.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

/**
 * ختمة العائلة: نفس خادم الموقع (khatma-api.php) ونفس رموز الختمات وروابط الدعوة، فيشارك من التطبيق
 * ومن الموقع في الختمة نفسها. لا حساب ولا بريد: رمز عشوائي يحفظه الجهاز.
 */
final class FamilyKhatma {
    private FamilyKhatma() { }

    static final String API = App.HOME + "khatma-api.php";
    static final String PAGE = App.HOME + "family-khatma.html";

    static final class Part { int n; String by; boolean done, mine; }

    static final class Group {
        String id, name, owner, deadline;
        int round;
        boolean admin;
        final Part[] parts = new Part[30];

        int doneCount() { int d = 0; for (Part p : parts) if (p != null && p.done) d++; return d; }
        int takenCount() { int d = 0; for (Part p : parts) if (p != null && p.by != null) d++; return d; }
    }

    static final class Failure extends Exception { Failure(String m) { super(m); } }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static String member(Context c) {
        String m = p(c).getString("family_member", null);
        if (m == null || m.length() < 16) {
            String abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            SecureRandom r = new SecureRandom();
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 32; i++) b.append(abc.charAt(r.nextInt(abc.length())));
            m = b.toString();
            p(c).edit().putString("family_member", m).apply();
        }
        return m;
    }

    static String myName(Context c) { return p(c).getString("family_name", ""); }
    static void setMyName(Context c, String n) { p(c).edit().putString("family_name", n).apply(); }

    static String inviteUrl(String id) { return PAGE + "?id=" + id; }

    // ------------------------------------------------------------------ ختماتي المحفوظة

    static JSONArray saved(Context c) {
        try { return new JSONArray(p(c).getString("family_groups", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    static String adminKey(Context c, String id) {
        JSONArray a = saved(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return o.optString("adminKey", "");
        }
        return "";
    }

    static void remember(Context c, Group g, String adminKey) {
        JSONArray a = saved(c), out = new JSONArray();
        String key = adminKey != null && !adminKey.isEmpty() ? adminKey : adminKey(c, g.id);
        try {
            JSONObject me = new JSONObject().put("id", g.id).put("name", g.name);
            if (!key.isEmpty()) me.put("adminKey", key);
            out.put(me);
            for (int i = 0; i < a.length() && out.length() < 30; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && !g.id.equals(o.optString("id"))) out.put(o);
            }
        } catch (Exception ignored) { }
        p(c).edit().putString("family_groups", out.toString()).apply();
    }

    static void forget(Context c, String id) {
        JSONArray a = saved(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !id.equals(o.optString("id"))) out.put(o);
        }
        p(c).edit().putString("family_groups", out.toString()).apply();
    }

    // ------------------------------------------------------------------ الخادم (خيط خلفي فقط)

    private static JSONObject post(JSONObject body) throws Failure {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(API).openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(15000);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("User-Agent", "HawlalaalamApp/2 (Android)");
            try (OutputStream out = con.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            if (in == null) throw new Failure(code == 404 ? L.t("خدمة ختمة العائلة غير متاحة الآن") : L.t("تعذّر الاتصال، حاول مرة أخرى"));
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && b.size() < 200_000) b.write(buf, 0, n);
            in.close();
            JSONObject o;
            try { o = new JSONObject(b.toString("UTF-8")); }
            catch (Exception e) { throw new Failure(L.t("خدمة ختمة العائلة غير متاحة الآن")); }
            if (!o.optBoolean("ok")) throw new Failure(o.optString("error", L.t("حدث خطأ، حاول مرة أخرى")));
            return o;
        } catch (Failure f) {
            throw f;
        } catch (Exception e) {
            throw new Failure(L.t("تعذّر الاتصال بالإنترنت"));
        } finally {
            if (con != null) con.disconnect();
        }
    }

    static Group parse(JSONObject g) {
        Group out = new Group();
        out.id = g.optString("id");
        out.name = g.optString("name");
        out.owner = g.optString("owner");
        out.deadline = g.optString("deadline");
        out.round = g.optInt("round", 1);
        out.admin = g.optBoolean("admin");
        JSONArray parts = g.optJSONArray("parts");
        for (int i = 0; i < 30; i++) {
            Part p = new Part();
            p.n = i + 1;
            JSONObject o = parts == null ? null : parts.optJSONObject(i);
            if (o != null) {
                p.n = o.optInt("n", i + 1);
                p.by = o.isNull("by") ? null : o.optString("by", null);
                if (p.by != null && p.by.isEmpty()) p.by = null;
                p.done = o.optBoolean("done");
                p.mine = o.optBoolean("mine");
            }
            out.parts[i] = p;
        }
        return out;
    }

    static Group create(Context c, String name, String owner, String deadline) throws Failure {
        try {
            JSONObject o = post(new JSONObject().put("action", "create").put("name", name).put("owner", owner)
                    .put("deadline", deadline == null ? "" : deadline).put("member", member(c)));
            Group g = parse(o.getJSONObject("group"));
            remember(c, g, o.optString("adminKey"));
            setMyName(c, owner);
            return g;
        } catch (Failure f) { throw f; } catch (Exception e) { throw new Failure(L.t("حدث خطأ، حاول مرة أخرى")); }
    }

    static Group get(Context c, String id) throws Failure {
        try {
            JSONObject o = post(new JSONObject().put("action", "get").put("id", id).put("member", member(c))
                    .put("adminKey", adminKey(c, id)));
            Group g = parse(o.getJSONObject("group"));
            remember(c, g, null);
            return g;
        } catch (Failure f) { throw f; } catch (Exception e) { throw new Failure(L.t("حدث خطأ، حاول مرة أخرى")); }
    }

    /** take / done / undo / release */
    static Group act(Context c, String action, String id, int part, String who) throws Failure {
        try {
            JSONObject o = post(new JSONObject().put("action", action).put("id", id).put("part", part)
                    .put("member", member(c)).put("who", who == null ? myName(c) : who));
            Group g = parse(o.getJSONObject("group"));
            g.admin = !adminKey(c, id).isEmpty();
            return g;
        } catch (Failure f) { throw f; } catch (Exception e) { throw new Failure(L.t("حدث خطأ، حاول مرة أخرى")); }
    }

    static Group newRound(Context c, String id) throws Failure {
        try {
            JSONObject o = post(new JSONObject().put("action", "newround").put("id", id).put("member", member(c))
                    .put("adminKey", adminKey(c, id)));
            return parse(o.getJSONObject("group"));
        } catch (Failure f) { throw f; } catch (Exception e) { throw new Failure(L.t("حدث خطأ، حاول مرة أخرى")); }
    }

    static void delete(Context c, String id) throws Failure {
        try {
            post(new JSONObject().put("action", "delete").put("id", id).put("member", member(c)).put("adminKey", adminKey(c, id)));
            forget(c, id);
        } catch (Failure f) { throw f; } catch (Exception e) { throw new Failure(L.t("حدث خطأ، حاول مرة أخرى")); }
    }
}
