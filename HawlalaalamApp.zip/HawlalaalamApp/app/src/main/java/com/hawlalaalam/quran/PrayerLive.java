package com.hawlalaalam.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/**
 * «الصلاة القادمة» إشعارًا حيًّا هادئًا: عدّاد تنازلي في شريط الإشعارات وشاشة القفل حتى دخول الوقت
 * (مثل الجزيرة الديناميكية في آيفون). صامت تمامًا، أولوية منخفضة، والعدّاد يرسمه النظام نفسه.
 * يُحدَّث عند فتح التطبيق وعند كل صلاة (Adhan.scheduleNext)، ومتوقف افتراضيًا: يفعّله المستخدم من «التنبيهات».
 */
final class PrayerLive {
    static final String KEY = "live_prayer";
    static final String CHANNEL = "prayer_live";
    private static final int ID = 40;

    private PrayerLive() { }

    static boolean enabled(Context c) { return App.prefs(c).getBoolean(KEY, false); }

    static void setEnabled(Context c, boolean on) {
        App.prefs(c).edit().putBoolean(KEY, on).apply();
        Adhan.scheduleNext(c);                       // يحدّث الإشعار ويضمن منبّه الصلاة التالية لتجديده
    }

    static void update(Context c) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm == null) return;
            if (!enabled(c) || !Adhan.hasLocation(c) || !Notifier.allowed(c)) { nm.cancel(ID); return; }
            NotificationChannel ch = new NotificationChannel(CHANNEL, "الصلاة القادمة (عدّاد)", NotificationManager.IMPORTANCE_LOW);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);

            long[] nx = Adhan.next(c);
            int idx = (int) nx[0];
            long at = nx[1];
            long now = System.currentTimeMillis();
            if (at <= now) { nm.cancel(ID); return; }
            String name = Adhan.NAMES[idx];
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTimeInMillis(at);
            if (idx == PrayerCalc.DHUHR && cal.get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.FRIDAY) name = "الجمعة";
            String city = Adhan.city(c);

            Intent open = new Intent(c, HomeActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            PendingIntent pi = PendingIntent.getActivity(c, 240, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            Notification n = new Notification.Builder(c, CHANNEL)
                    .setSmallIcon(R.drawable.ic_stat_quran)
                    .setColor(c.getColor(R.color.gold_deep))
                    .setContentTitle("الصلاة القادمة: " + name)
                    .setContentText("تدخل " + Adhan.clock(at) + (city.isEmpty() ? "" : " · " + city))
                    .setSubText("مواقيت الصلاة")
                    .setWhen(at)
                    .setShowWhen(true)
                    .setUsesChronometer(true)
                    .setChronometerCountDown(true)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setContentIntent(pi)
                    // يختفي وحده بعد دخول الوقت بدقيقتين إن لم يُجدَّد (الجوال مغلق مثلًا)
                    .setTimeoutAfter(at - now + 2 * 60_000L)
                    .build();
            nm.notify(ID, n);
        } catch (Exception ignored) { }
    }
}
