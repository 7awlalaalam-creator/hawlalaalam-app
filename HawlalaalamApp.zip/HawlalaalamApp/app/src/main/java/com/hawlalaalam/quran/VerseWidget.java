package com.hawlalaalam.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.widget.RemoteViews;

/**
 * ويدجت آية اليوم على الشاشة الرئيسية.
 * الويدجت لا يستطيع استخدام خطوط التطبيق، فنرسم الآية صورةً بخط مجمع الملك فهد
 * (بلون أبيض يُلوَّن في التخطيط بلون المظهر)، ونكيّف حجم الخط مع مساحة الويدجت.
 * المظهر يتبع اختيار المستخدم في التطبيق: تلقائي / نهاري / ليلي.
 */
public class VerseWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        Context c = context.getApplicationContext();
        PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                render(c, mgr, ids, VerseRepo.isFresh(c) ? VerseRepo.cached(c) : VerseRepo.fetchToday(c));
            } catch (Exception ignored) {
            } finally {
                pr.finish();
            }
        }).start();
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id, Bundle opts) {
        Context c = context.getApplicationContext();
        render(c, mgr, new int[]{id}, VerseRepo.cached(c));      // تغيّر الحجم: نعيد الرسم بالمقاس الجديد
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, VerseWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids, VerseRepo.cached(c));
    }

    private static int layoutFor(Context c) {
        int m = Ui.widgetMode(c);
        return m == 1 ? R.layout.widget_verse_l : m == 2 ? R.layout.widget_verse_d : R.layout.widget_verse;
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids, VerseRepo.Verse v) {
        PendingIntent pi = PendingIntent.getActivity(c, 301,
                new Intent(c, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean has = v != null && v.text != null && !v.text.isEmpty();
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), layoutFor(c));
            rv.setTextViewText(R.id.w_date, Ui.hijriShort());
            float density = c.getResources().getDisplayMetrics().density;
            Bundle o = mgr.getAppWidgetOptions(id);
            // في الوضع العمودي: العرض الأدنى والارتفاع الأقصى
            int wDp = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int hDp = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (wDp <= 0) wDp = 300;
            if (hDp <= 0) hDp = 150;
            int w = Math.round(Math.max(120, wDp - 32) * density);          // ناقص الحشوة الجانبية
            int h = Math.round(Math.max(40, hDp - 64) * density);           // ناقص العنوان والمرجع والحشوة
            // حد أعلى لحجم الصورة (قيود ذاكرة الويدجت)
            float scale = Math.min(1f, 900f / Math.max(w, h));
            w = Math.max(1, Math.round(w * scale));
            h = Math.max(1, Math.round(h * scale));
            if (has) {
                rv.setImageViewBitmap(R.id.w_img, draw(c, QuranText.withNumber(v.text, v.ayah),
                        QuranText.font(c), w, h, density * scale, 26f, 1.3f));
                rv.setContentDescription(R.id.w_img, v.text);
                rv.setTextViewText(R.id.w_ref, v.ref());
            } else {
                rv.setImageViewBitmap(R.id.w_img, draw(c, "افتح التطبيق لعرض آية اليوم",
                        Ui.font(c, 500), w, h, density * scale, 15f, 1.1f));
                rv.setTextViewText(R.id.w_ref, "حول العالم | القرآن الكريم");
            }
            rv.setOnClickPendingIntent(R.id.w_root, pi);
            mgr.updateAppWidget(id, rv);
        }
    }

    /** يرسم النص بأكبر حجم يتسع (حتى maxSp) في مستطيل w×h، أبيض على شفاف، وسط المساحة */
    static Bitmap draw(Context c, String s, Typeface tf, int w, int h, float density, float maxSp, float spacing) {
        TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        tp.setTypeface(tf);
        StaticLayout l = null;
        for (float sp = maxSp; sp >= 11f; sp -= 1f) {
            tp.setTextSize(sp * density);
            l = StaticLayout.Builder.obtain(s, 0, s.length(), tp, w)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(android.text.TextDirectionHeuristics.RTL)
                    .setLineSpacing(0, spacing)
                    .setIncludePad(true)
                    .build();
            if (l.getHeight() <= h) break;
        }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        if (l != null) {
            cv.save();
            cv.translate(0, Math.max(0, (h - l.getHeight()) / 2f));
            cv.clipRect(0, 0, w, h);
            l.draw(cv);
            cv.restore();
        }
        return b;
    }
}
