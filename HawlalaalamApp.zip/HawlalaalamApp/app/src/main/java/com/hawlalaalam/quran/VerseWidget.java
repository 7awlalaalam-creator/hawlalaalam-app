package com.hawlalaalam.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** ويدجت آية اليوم على الشاشة الرئيسية */
public class VerseWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        Context c = context.getApplicationContext();
        render(c, mgr, ids, VerseRepo.cached(c));
        if (!VerseRepo.isFresh(c)) {
            PendingResult pr = goAsync();
            new Thread(() -> {
                try {
                    render(c, mgr, ids, VerseRepo.fetchToday(c));
                } catch (Exception ignored) {
                } finally {
                    pr.finish();
                }
            }).start();
        }
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, VerseWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids, VerseRepo.cached(c));
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids, VerseRepo.Verse v) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_verse);
        String url = App.HOME;
        rv.setTextViewText(R.id.w_date, Ui.hijriShort());
        if (v != null && v.text != null && !v.text.isEmpty()) {
            rv.setTextViewText(R.id.w_text, "﴿ " + v.text + " ﴾");
            int len = v.text.length();
            rv.setTextViewTextSize(R.id.w_text, android.util.TypedValue.COMPLEX_UNIT_SP,
                    len < 60 ? 21f : len < 120 ? 19f : len < 200 ? 17f : 15f);
            rv.setTextViewText(R.id.w_ref, v.ref());
            url = v.tafsirUrl();
        } else {
            rv.setTextViewText(R.id.w_text, "افتح التطبيق لعرض آية اليوم");
            rv.setTextViewText(R.id.w_ref, "حول العالم | القرآن الكريم");
        }
        // الضغط يفتح شاشة «اليوم»: الآية مع أزرار المشاركة والتفسير
        PendingIntent pi = PendingIntent.getActivity(c, 301,
                new Intent(c, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.w_root, pi);
        mgr.updateAppWidget(ids, rv);
    }
}
