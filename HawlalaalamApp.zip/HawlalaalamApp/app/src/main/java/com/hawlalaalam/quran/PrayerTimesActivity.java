package com.hawlalaalam.quran;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

/** مواقيت الصلاة الأصلية (مثل شاشة آيفون): الصلاة القادمة بعدّاد، الخمس مع الشروق، الأسبوع، وطريقة الحساب */
public class PrayerTimesActivity extends Activity {

    @Override
    protected void attachBaseContext(Context base) { super.attachBaseContext(Ui.wrap(base)); }

    private static final int REQ_LOC = 61;
    private LinearLayout col;
    private TextView countdown;
    private long nextAt;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (countdown != null && nextAt > 0) {
                long ms = nextAt - System.currentTimeMillis();
                if (ms <= 0) { render(); }
                else countdown.setText(hms(ms));
            }
            main.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        col = Kit.scrollPage(this, new ScrollView[1]);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
        main.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        main.removeCallbacks(tick);
    }

    static String displayName(int idx, Calendar day) {
        if (idx == PrayerCalc.DHUHR && day.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) return "الجمعة";
        return Adhan.NAMES[idx];
    }

    private static String hms(long ms) {
        long s = ms / 1000;
        return Adhan.arabic(String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60));
    }

    private void render() {
        col.removeAllViews();
        int ink = getColor(R.color.ink), muted = getColor(R.color.muted), gold = getColor(R.color.gold_deep);
        String city = Adhan.city(this);
        col.addView(Kit.header(this, "مواقيت الصلاة", Ui.hijriToday() + (city.isEmpty() ? "" : " · " + city), null));

        if (!Adhan.hasLocation(this)) {
            LinearLayout c = Ui.card(this);
            c.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
            TextView t = Ui.text(this, "حدّد موقعك لعرض مواقيت الصلاة في مدينتك", 16, ink, 700);
            c.addView(t);
            TextView s = Ui.text(this, "نستخدم الموقع لحساب المواقيت والقبلة على جهازك فقط، ولا نرسله لأي جهة.", 13, muted, 400);
            s.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
            c.addView(s);
            View b = Ui.pill(this, R.drawable.ic_pin, "تحديد الموقع", true);
            b.setOnClickListener(v -> askLocation());
            c.addView(Ui.minH(b, 46), new LinearLayout.LayoutParams(-1, -2));
            col.addView(c, Kit.gap(this, 12));
            countdown = null;
            return;
        }

        Calendar today = Calendar.getInstance();
        long now = System.currentTimeMillis();
        long[] t = Adhan.times(this, today);
        long[] nx = Adhan.next(this);
        int nextIdx = (int) nx[0];
        nextAt = nx[1];
        Calendar nextDay = Calendar.getInstance();
        nextDay.setTimeInMillis(nextAt);
        boolean nextToday = nextDay.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR);

        LinearLayout h = Kit.hero(this);
        h.addView(Ui.text(this, "الصلاة القادمة", 13, getColor(R.color.gold), 700));
        TextView name = Ui.text(this, displayName(nextIdx, nextDay) + (nextToday ? "" : " · غدًا"), 28, 0xFFFFFFFF, 700);
        name.setPadding(0, Ui.dp(this, 4), 0, 0);
        h.addView(name);
        countdown = Ui.text(this, hms(nextAt - now), 34, getColor(R.color.gold), 700);
        countdown.setContentDescription("الوقت المتبقي " + Adhan.remaining(nextAt - now, false));
        h.addView(countdown);
        h.addView(Ui.text(this, "الساعة " + Adhan.clock(nextAt), 14, getColor(R.color.on_dark_muted), 400));
        col.addView(h, Kit.gap(this, 12));

        LinearLayout list = Ui.card(this);
        for (int i = 0; i < 6; i++) {
            boolean isNext = i == nextIdx && nextToday;
            boolean past = t[i] < now && !isNext;
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(0, Ui.dp(this, 13), 0, Ui.dp(this, 13));
            TextView n = Ui.text(this, displayName(i, today), 16, isNext ? gold : past ? muted : ink, isNext ? 700 : 500);
            r.addView(n);
            if (isNext) {
                TextView chip = Ui.text(this, Adhan.remaining(t[i] - now, true), 12, gold, 700);
                chip.setPadding(Ui.dp(this, 8), Ui.dp(this, 2), Ui.dp(this, 8), Ui.dp(this, 2));
                chip.setBackground(Ui.shape(getColor(R.color.chip), 10, 0, this));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
                cp.setMarginStart(Ui.dp(this, 8));
                r.addView(chip, cp);
            }
            View sp = new View(this);
            r.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
            r.addView(Ui.text(this, Adhan.clock(t[i]), 16, isNext ? gold : past ? muted : ink, isNext ? 700 : 400));
            r.setContentDescription(displayName(i, today) + " " + Adhan.clock(t[i]));
            if (i > 0) list.addView(Ui.divider(this));
            list.addView(r);
        }
        col.addView(list, Kit.gap(this, 12));

        // الأسبوع القادم
        col.addView(Kit.section(this, "الأيام القادمة"), Kit.gap(this, 18));
        LinearLayout wk = Ui.card(this);
        wk.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        wk.addView(weekRow(new String[]{"اليوم", "الفجر", "الظهر", "العصر", "المغرب", "العشاء"}, true, false));
        String[] days = {"الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"};
        for (int d = 1; d <= 7; d++) {
            Calendar day = Calendar.getInstance();
            day.add(Calendar.DAY_OF_MONTH, d);
            long[] x = Adhan.times(this, day);
            String[] cells = {days[day.get(Calendar.DAY_OF_WEEK) - 1] + " " + Ui.arabicNum(day.get(Calendar.DAY_OF_MONTH)),
                    shortClock(x[PrayerCalc.FAJR]), shortClock(x[PrayerCalc.DHUHR]), shortClock(x[PrayerCalc.ASR]),
                    shortClock(x[PrayerCalc.MAGHRIB]), shortClock(x[PrayerCalc.ISHA])};
            wk.addView(Ui.divider(this));
            wk.addView(weekRow(cells, false, day.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY));
        }
        col.addView(wk, Kit.gap(this, 6));

        PrayerCalc.Method m = Adhan.method(this);
        TextView meth = Ui.text(this, (Adhan.methodChoice(this) == 0 ? "تلقائي حسب دولتك · " : "") + m.name + "\n" + m.detail(),
                12, muted, 400);
        meth.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4), 0);
        col.addView(meth);

        LinearLayout btns = new LinearLayout(this);
        View loc = Ui.pill(this, R.drawable.ic_pin, "تحديث الموقع", false);
        loc.setOnClickListener(v -> askLocation());
        View notif = Ui.pill(this, R.drawable.ic_l_bell, Adhan.enabled(this) ? "تنبيه الأذان ✓" : "تنبيه الأذان", true);
        notif.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)
                .putExtra(SettingsActivity.EXTRA_NOTIF_ONLY, true)));
        View qibla = Ui.pill(this, R.drawable.ic_qibla, "القبلة", false);
        qibla.setOnClickListener(v -> startActivity(new Intent(this, QiblaActivity.class)));
        btns.addView(Ui.minH(notif, 46), new LinearLayout.LayoutParams(0, -2, 1.2f));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, -2, 1f);
        p2.setMarginStart(Ui.dp(this, 8));
        btns.addView(Ui.minH(qibla, 46), p2);
        col.addView(btns, Kit.gap(this, 16));
        col.addView(Ui.minH(loc, 46), Kit.gap(this, 8));
    }

    private static String shortClock(long millis) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(millis);
        int h = x.get(Calendar.HOUR_OF_DAY) % 12;
        if (h == 0) h = 12;
        return Adhan.arabic(String.format(java.util.Locale.US, "%d:%02d", h, x.get(Calendar.MINUTE)));
    }

    private View weekRow(String[] cells, boolean head, boolean friday) {
        LinearLayout r = new LinearLayout(this);
        r.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        for (int i = 0; i < cells.length; i++) {
            TextView t = Ui.text(this, cells[i], i == 0 ? 12 : 13,
                    head ? getColor(R.color.muted) : friday && i == 0 ? getColor(R.color.gold_deep) : getColor(R.color.ink),
                    head || i == 0 ? 700 : 400);
            t.setGravity(i == 0 ? Gravity.START : Gravity.CENTER);
            t.setMaxLines(1);
            Ui.capScale(t, i == 0 ? 12 : 13, 1.3f);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, i == 0 ? 1.5f : 1f));
        }
        return r;
    }

    private void askLocation() {
        if (!Loc.hasPermission(this)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            return;
        }
        Toast.makeText(this, "جارٍ تحديد موقعك…", Toast.LENGTH_SHORT).show();
        Loc.get(this, l -> {
            Context a = getApplicationContext();
            if (l == null) {
                if (!isFinishing()) Toast.makeText(this, "تعذّر تحديد الموقع، فعّل خدمة الموقع (GPS) ثم حاول مرة أخرى", Toast.LENGTH_LONG).show();
                return;
            }
            Adhan.saveLocation(a, l.getLatitude(), l.getLongitude());
            Adhan.scheduleNext(a);
            PrayerWidget.updateAll(a);
            if (!isFinishing()) render();
            new Thread(() -> {
                String city = Loc.cityName(a, l.getLatitude(), l.getLongitude());
                Adhan.saveCity(a, city);
                runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) render(); PrayerWidget.updateAll(a); });
            }).start();
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOC) {
            if (Loc.hasPermission(this)) askLocation();
            else Toast.makeText(this, "نحتاج موقعك لحساب مواقيت الصلاة بدقة", Toast.LENGTH_LONG).show();
        }
    }
}
