package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/** مواقيت الصلاة وتنبيه الأذان */
final class Adhan {
    static final String ACTION = "com.hawlalaalam.quran.ADHAN";
    static final String EXTRA_INDEX = "prayer";
    static final String[] NAMES = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final int[] ALERTS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    /** المنبّه يمرّ بالشروق أيضًا (إشعار الشروق وتحديث الويدجت) */
    private static final int[] SCHEDULE = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR,
            PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    private Adhan() { }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static boolean enabled(Context c) { return p(c).getBoolean("adhan_on", false); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("adhan_on", on).apply();
        scheduleNext(c);
    }

    static boolean hasLocation(Context c) { return p(c).contains("lat"); }

    /** إشعار الشروق وفضل الضحى (يتبع تفعيل الأذان) */
    static boolean sunriseOn(Context c) { return p(c).getBoolean("sunrise_on", true); }

    /** تذكير الصيام المسنون ليلة اليوم (عند العشاء) */
    static boolean fastingOn(Context c) { return p(c).getBoolean("fasting_on", true); }

    /** الحدث التالي بعد صلاة معيّنة: {الاسم، الوقت} لسطر «التالي» في الإشعار */
    static String[] after(Context c, int index) {
        if (!hasLocation(c)) return null;
        Calendar day = Calendar.getInstance();
        int nextIndex = index + 1;
        if (index >= PrayerCalc.ISHA) {
            day.add(Calendar.DAY_OF_MONTH, 1);
            nextIndex = PrayerCalc.FAJR;
        }
        long at = times(c, day)[nextIndex];
        boolean friday = day.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
        String name = (friday && nextIndex == PrayerCalc.DHUHR) ? "الجمعة" : NAMES[nextIndex];
        return new String[]{name, clock(at)};
    }

    static void saveLocation(Context c, double lat, double lng) {
        p(c).edit().putFloat("lat", (float) lat).putFloat("lng", (float) lng).apply();
    }

    static String city(Context c) { return p(c).getString("city", ""); }

    static void saveCity(Context c, String city) { p(c).edit().putString("city", city).apply(); }

    static boolean isRamadan(Calendar day) {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(day.getTimeInMillis());
            return ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN;
        } catch (Throwable t) {
            return false;
        }
    }

    /** مواقيت يوم معيّن كأوقات بالمللي ثانية */
    static long[] times(Context c, Calendar day) {
        double lat = p(c).getFloat("lat", 21.4225f), lng = p(c).getFloat("lng", 39.8262f);
        Calendar noon = (Calendar) day.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        double tz = TimeZone.getDefault().getOffset(noon.getTimeInMillis()) / 3_600_000.0;
        double[] h = PrayerCalc.compute(noon.get(Calendar.YEAR), noon.get(Calendar.MONTH) + 1,
                noon.get(Calendar.DAY_OF_MONTH), lat, lng, tz, isRamadan(noon));
        long[] out = new long[h.length];
        Calendar mid = (Calendar) noon.clone();
        mid.set(Calendar.HOUR_OF_DAY, 0);
        for (int i = 0; i < h.length; i++) out[i] = mid.getTimeInMillis() + Math.round(h[i] * 60) * 60_000L;
        return out;
    }

    /** «الفجر ٤:٥٨ ص · الظهر ...» */
    static String todaySummary(Context c) {
        if (!hasLocation(c)) return "حدّد موقعك لعرض مواقيت الصلاة";
        long[] t = times(c, Calendar.getInstance());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            Calendar x = Calendar.getInstance();
            x.setTimeInMillis(t[i]);
            if (sb.length() > 0) sb.append("\n");
            sb.append(NAMES[i]).append("   ")
              .append(arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE))));
        }
        return sb.toString();
    }

    /** الصلاة القادمة: {الفهرس، الوقت بالمللي} */
    static long[] next(Context c) {
        long now = System.currentTimeMillis();
        long[] t = times(c, Calendar.getInstance());
        for (int k : ALERTS) if (t[k] > now) return new long[]{k, t[k]};
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        return new long[]{PrayerCalc.FAJR, times(c, tomorrow)[PrayerCalc.FAJR]};
    }

    /** «٣:٣٧ م» */
    static String clock(long millis) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(millis);
        return arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE)));
    }

    static String arabic(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return sb.toString();
    }

    /** يُستدعى عند وصول المنبّه: كم دقيقة تأخر عن موعده؟ */
    static int markArrival(Context c) {
        long when = p(c).getLong("adhan_when", 0);
        int late = when > 0 ? (int) Math.max(0, (System.currentTimeMillis() - when) / 60_000L) : 0;
        p(c).edit().putInt("adhan_late", late).putLong("adhan_late_at", System.currentTimeMillis()).apply();
        return late;
    }

    /** وضع «ساعة المنبّه» لدقة الأذان (مفعّل افتراضيًا ويمكن إطفاؤه من الإعدادات) */
    static boolean alarmClockMode(Context c) { return p(c).getBoolean("adhan_alarm_clock", true); }

    /** آخر تأخير مسجّل خلال يومين (بالدقائق) */
    static int lastLate(Context c) {
        long at = p(c).getLong("adhan_late_at", 0);
        if (System.currentTimeMillis() - at > 2 * 86_400_000L) return 0;
        return p(c).getInt("adhan_late", 0);
    }

    /** هل يعمل التطبيق دون قيود توفير البطارية؟ */
    static boolean batteryFree(Context c) {
        android.os.PowerManager pm = c.getSystemService(android.os.PowerManager.class);
        return pm == null || pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    static boolean canExact(Context c) {
        return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }

    static void scheduleNext(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION);
        PendingIntent cancel = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        // يُجدول عند تفعيل الأذان أو وجود ويدجت المواقيت (لتحديثه عند كل صلاة)
        boolean ramadan = Ramadan.active() && App.prefs(c).getBoolean("iftar_on", true);
        boolean fasting = fastingOn(c) && Notifier.allowed(c);
        if (!hasLocation(c) || !(enabled(c) || fasting || PrayerWidget.hasWidgets(c) || RamadanWidget.hasWidgets(c) || ramadan)) {
            am.cancel(cancel);
            return;
        }
        // إن كان تذكير الصيام هو السبب الوحيد فلا داعي لإيقاظ الجهاز عند كل صلاة: العشاء فقط
        boolean onlyFasting = !(enabled(c) || PrayerWidget.hasWidgets(c) || RamadanWidget.hasWidgets(c) || ramadan);
        long now = System.currentTimeMillis() + 30_000;
        Calendar day = Calendar.getInstance();
        long when = -1;
        int index = PrayerCalc.FAJR;
        for (int d = 0; d < 2 && when < 0; d++) {
            long[] t = times(c, day);
            for (int k : SCHEDULE) {
                if (onlyFasting && k != PrayerCalc.ISHA) continue;
                if (t[k] > now) { when = t[k]; index = k; break; }
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        if (when < 0) return;
        i.putExtra(EXTRA_INDEX, index);
        PendingIntent pi = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        p(c).edit().putLong("adhan_when", when).apply();   // لقياس التأخير عند الوصول
        boolean exact = canExact(c);
        if (exact && enabled(c) && alarmClockMode(c)) {
            // منبّه «ساعة منبّه»: أعلى أولوية في أندرويد، يُخرج الجهاز من السكون ولا تؤجّله أنظمة توفير البطارية.
            // هو ما تستخدمه تطبيقات المنبّه نفسها، والأدق لوقت الأذان.
            PendingIntent show = PendingIntent.getActivity(c, 211,
                    App.openInApp(c, App.HOME + "prayer-times-ar.html"),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            try {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
                return;
            } catch (Exception ignored) { /* نكمل بالطريقة العادية */ }
        }
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }
}
