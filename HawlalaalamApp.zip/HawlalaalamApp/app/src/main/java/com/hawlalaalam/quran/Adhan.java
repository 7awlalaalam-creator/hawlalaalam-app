package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/** مواقيت الصلاة وتنبيه الأذان */
final class Adhan {
    static final String ACTION = "com.hawlalaalam.quran.ADHAN";
    static final String EXTRA_INDEX = "prayer";
    static final String[] NAMES = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final int[] ALERTS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
    /** المنبّه يمرّ بالشروق أيضًا (إشعار الشروق وتحديث الويدجت) */
    private static final int[] SCHEDULE = {PrayerCalc.FAJR, PrayerCalc.SUNRISE, PrayerCalc.DHUHR,
            PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    private Adhan() { }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static boolean enabled(Context c) { return p(c).getBoolean("adhan_on", false); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("adhan_on", on).apply();
        scheduleNext(c);
    }

    static boolean hasLocation(Context c) { return p(c).contains("lat"); }

    /** إشعار الشروق وفضل الضحى (يتبع تفعيل الأذان) */
    static boolean sunriseOn(Context c) { return p(c).getBoolean("sunrise_on", true); }

    /** تذكير الصيام المسنون ليلة اليوم (عند العشاء) */
    static boolean fastingOn(Context c) { return p(c).getBoolean("fasting_on", true); }

    /** الحدث التالي بعد صلاة معيّنة: {الاسم، الوقت} لسطر «التالي» في الإشعار */
    static String[] after(Context c, int index) {
        if (!hasLocation(c)) return null;
        Calendar day = Calendar.getInstance();
        int nextIndex = index + 1;
        if (index >= PrayerCalc.ISHA) {
            day.add(Calendar.DAY_OF_MONTH, 1);
            nextIndex = PrayerCalc.FAJR;
        }
        long at = times(c, day)[nextIndex];
        boolean friday = day.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
        String name = (friday && nextIndex == PrayerCalc.DHUHR) ? "الجمعة" : NAMES[nextIndex];
        return new String[]{name, clock(at)};
    }

    static void saveLocation(Context c, double lat, double lng) {
        p(c).edit().putFloat("lat", (float) lat).putFloat("lng", (float) lng).apply();
    }

    static String city(Context c) { return p(c).getString("city", ""); }

    static void saveCity(Context c, String city) { p(c).edit().putString("city", city).apply(); }

    // ------------------------------------------------ طريقة الحساب

    /** 0 = تلقائي حسب الدولة، وإلا فهرس في PrayerCalc.METHODS */
    static int methodChoice(Context c) {
        int m = p(c).getInt("calc_method", 0);
        return m >= 0 && m < PrayerCalc.METHODS.length ? m : 0;
    }

    static void setMethodChoice(Context c, int m) {
        p(c).edit().putInt("calc_method", m).apply();
        scheduleNext(c);
        try { PrayerWidget.updateAll(c); } catch (Exception ignored) { }
    }

    /** رمز الدولة: من عنوان الموقع المحفوظ، وإلا من منطقة التوقيت في الجوال (يعمل دون إنترنت) */
    static String country(Context c) {
        String cc = p(c).getString("country", "");
        if (!cc.isEmpty()) return cc;
        try {
            String r = android.icu.util.TimeZone.getRegion(TimeZone.getDefault().getID());
            if (r != null && r.length() == 2) return r;
        } catch (Exception ignored) { }
        return "";
    }

    static void saveCountry(Context c, String cc) {
        if (cc != null && cc.length() == 2) p(c).edit().putString("country", cc.toUpperCase(java.util.Locale.ROOT)).apply();
    }

    /** الفهرس الفعلي المستخدم (بعد حل «تلقائي») */
    static int methodIndex(Context c) {
        int m = methodChoice(c);
        return m != 0 ? m : PrayerCalc.forCountry(country(c));
    }

    static PrayerCalc.Method method(Context c) { return PrayerCalc.METHODS[methodIndex(c)]; }

    static boolean isRamadan(Calendar day) {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(day.getTimeInMillis());
            return ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN;
        } catch (Throwable t) {
            return false;
        }
    }

    /** مواقيت يوم معيّن كأوقات بالمللي ثانية */
    static long[] times(Context c, Calendar day) {
        double lat = p(c).getFloat("lat", 21.4225f), lng = p(c).getFloat("lng", 39.8262f);
        Calendar noon = (Calendar) day.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        double tz = TimeZone.getDefault().getOffset(noon.getTimeInMillis()) / 3_600_000.0;
        double[] h = PrayerCalc.compute(noon.get(Calendar.YEAR), noon.get(Calendar.MONTH) + 1,
                noon.get(Calendar.DAY_OF_MONTH), lat, lng, tz, isRamadan(noon), method(c));
        long[] out = new long[h.length];
        // نقيس من الظهر لا من منتصف الليل: في يوم تغيير الساعة (التوقيت الصيفي) يختلف فرق التوقيت
        // بين منتصف الليل والظهر، فتنزاح كل المواقيت ساعة كاملة
        long noonMs = noon.getTimeInMillis();
        for (int i = 0; i < h.length; i++) out[i] = noonMs + Math.round((h[i] - 12) * 60) * 60_000L;
        return out;
    }

    /** «الفجر ٤:٥٨ ص · الظهر ...» */
    static String todaySummary(Context c) {
        if (!hasLocation(c)) return "حدّد موقعك لعرض مواقيت الصلاة";
        long[] t = times(c, Calendar.getInstance());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            Calendar x = Calendar.getInstance();
            x.setTimeInMillis(t[i]);
            if (sb.length() > 0) sb.append("\n");
            sb.append(NAMES[i]).append("   ")
              .append(arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE))));
        }
        return sb.toString();
    }

    /** الصلاة القادمة: {الفهرس، الوقت بالمللي} */
    static long[] next(Context c) {
        long now = System.currentTimeMillis();
        long[] t = times(c, Calendar.getInstance());
        for (int k : ALERTS) if (t[k] > now) return new long[]{k, t[k]};
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        return new long[]{PrayerCalc.FAJR, times(c, tomorrow)[PrayerCalc.FAJR]};
    }

    /** «٣:٣٧ م» */
    static String clock(long millis) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(millis);
        return arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE)));
    }

    /**
     * الوقت المتبقي بوحدته: «٥٢ دقيقة»، «١:٠٥ ساعة»، «ساعتان».
     * after=true لصيغة «بعد …» (بعد دقيقتين، بعد ساعتين).
     */
    static String remaining(long ms, boolean after) {
        long m = (ms + 59_999L) / 60_000L;
        if (m <= 0) return "الآن";
        if (m < 60) {
            String t = m == 1 ? "دقيقة" : m == 2 ? (after ? "دقيقتين" : "دقيقتان")
                    : arabic(String.valueOf(m)) + (m <= 10 ? " دقائق" : " دقيقة");
            return after ? "بعد " + t : t;
        }
        long h = m / 60, mm = m % 60;
        String t;
        if (mm == 0) {
            t = h == 1 ? "ساعة" : h == 2 ? (after ? "ساعتين" : "ساعتان")
                    : arabic(String.valueOf(h)) + (h <= 10 ? " ساعات" : " ساعة");
        } else {
            t = arabic(h + ":" + (mm < 10 ? "0" : "") + mm) + " ساعة";
        }
        return after ? "بعد " + t : t;
    }

    static String arabic(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return sb.toString();
    }

    /** يُستدعى عند وصول المنبّه: كم دقيقة تأخر عن موعده؟ */
    static int markArrival(Context c) {
        long when = p(c).getLong("adhan_when", 0);
        int late = when > 0 ? (int) Math.max(0, (System.currentTimeMillis() - when) / 60_000L) : 0;
        p(c).edit().putInt("adhan_late", late).putLong("adhan_late_at", System.currentTimeMillis()).apply();
        return late;
    }

    /** وضع «ساعة المنبّه» لدقة الأذان (مفعّل افتراضيًا ويمكن إطفاؤه من الإعدادات) */
    static boolean alarmClockMode(Context c) { return p(c).getBoolean("adhan_alarm_clock", true); }

    /** آخر تأخير مسجّل خلال يومين (بالدقائق) */
    static int lastLate(Context c) {
        long at = p(c).getLong("adhan_late_at", 0);
        if (System.currentTimeMillis() - at > 2 * 86_400_000L) return 0;
        return p(c).getInt("adhan_late", 0);
    }

    /** هل يعمل التطبيق دون قيود توفير البطارية؟ */
    static boolean batteryFree(Context c) {
        android.os.PowerManager pm = c.getSystemService(android.os.PowerManager.class);
        return pm == null || pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    static boolean canExact(Context c) {
        return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }

    /**
     * لم يصل منبّه الأذان الماضي أبدًا؟ (سامسونج: «التطبيقات النائمة» توقف منبّهات التطبيق كليًا)
     * يُفحص قبل جدولة المنبّه التالي: موعد مضى عليه أكثر من ٣ دقائق ولم يُسجَّل وصوله.
     */
    private static void checkMissed(Context c) {
        long when = p(c).getLong("adhan_when", 0);
        long arrived = p(c).getLong("adhan_late_at", 0);
        long now = System.currentTimeMillis();
        if (enabled(c) && when > 0 && now > when + 3 * 60_000L && arrived < when) {
            p(c).edit().putLong("adhan_missed_at", now).putLong("adhan_when", 0).apply();
        }
    }

    /** بعد إقلاع الجهاز أو تغيير الوقت: الموعد السابق لا يُعدّ فائتًا */
    static void forgetPending(Context c) { p(c).edit().putLong("adhan_when", 0).apply(); }

    /** آخر مرة لم يصل فيها المنبّه خلال يومين (٠ = لا شيء) */
    static long lastMissed(Context c) {
        long at = p(c).getLong("adhan_missed_at", 0);
        long ok = p(c).getLong("adhan_late_at", 0);
        if (at <= ok || System.currentTimeMillis() - at > 2 * 86_400_000L) return 0;
        return at;
    }

    /** وصل المنبّه لكن الإشعار كان محجوبًا (خلال يومين) */
    static boolean lastBlocked(Context c) {
        long at = p(c).getLong("adhan_blocked_at", 0);
        return at > 0 && System.currentTimeMillis() - at < 2 * 86_400_000L && Notifier.adhanBlock(c) != null;
    }

    /** يحتاج تنبيه الأذان إصلاحًا من إعدادات الجوال؟ (لبطاقة التنبيه في «اليوم») */
    static boolean needsFix(Context c) {
        return enabled(c) && (Notifier.adhanBlock(c) != null || lastMissed(c) > 0);
    }

    static void scheduleNext(Context c) {
        checkMissed(c);
        PrayerLive.update(c);                            // عدّاد «الصلاة القادمة» في الإشعارات (إن فُعّل)
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION);
        PendingIntent cancel = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        // يُجدول عند تفعيل الأذان أو وجود ويدجت المواقيت (لتحديثه عند كل صلاة)
        boolean ramadan = Ramadan.active() && App.prefs(c).getBoolean("iftar_on", true);
        boolean fasting = fastingOn(c) && Notifier.allowed(c);
        boolean live = PrayerLive.enabled(c);
        if (!hasLocation(c) || !(enabled(c) || fasting || live || PrayerWidget.hasWidgets(c) || RamadanWidget.hasWidgets(c) || ramadan)) {
            am.cancel(cancel);
            return;
        }
        // إن كان تذكير الصيام هو السبب الوحيد فلا داعي لإيقاظ الجهاز عند كل صلاة: العشاء فقط
        boolean onlyFasting = !(enabled(c) || live || PrayerWidget.hasWidgets(c) || RamadanWidget.hasWidgets(c) || ramadan);
        long now = System.currentTimeMillis() + 30_000;
        Calendar day = Calendar.getInstance();
        long when = -1;
        int index = PrayerCalc.FAJR;
        for (int d = 0; d < 2 && when < 0; d++) {
            long[] t = times(c, day);
            for (int k : SCHEDULE) {
                if (onlyFasting && k != PrayerCalc.ISHA) continue;
                if (t[k] > now) { when = t[k]; index = k; break; }
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        if (when < 0) return;
        i.putExtra(EXTRA_INDEX, index);
        PendingIntent pi = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        p(c).edit().putLong("adhan_when", when).apply();   // لقياس التأخير عند الوصول
        boolean exact = canExact(c);
        // الويدجت وحده لا يستحق إيقاظ الجهاز: يتحدّث عند أول تشغيل للشاشة بعد الوقت (توفير البطارية)
        boolean needWake = enabled(c) || live || ramadan || fasting;
        if (!needWake) {
            am.set(AlarmManager.RTC, when, pi);
            return;
        }
        // «ساعة المنبّه» للصلوات الخمس فقط، لا للشروق
        if (exact && enabled(c) && alarmClockMode(c) && index != PrayerCalc.SUNRISE) {
            // منبّه «ساعة منبّه»: أعلى أولوية في أندرويد، يُخرج الجهاز من السكون ولا تؤجّله أنظمة توفير البطارية.
            // هو ما تستخدمه تطبيقات المنبّه نفسها، والأدق لوقت الأذان.
            PendingIntent show = PendingIntent.getActivity(c, 211,
                    App.openInApp(c, App.HOME + "prayer-times-ar.html"),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            try {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
                return;
            } catch (Exception ignored) { /* نكمل بالطريقة العادية */ }
        }
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }
}
