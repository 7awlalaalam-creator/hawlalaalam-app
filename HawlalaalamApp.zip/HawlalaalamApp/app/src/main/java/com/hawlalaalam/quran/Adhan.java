package com.hawlalaalam.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/** مواقيت الصلاة وتنبيه الأذان */
final class Adhan {
    static final String ACTION = "com.hawlalaalam.quran.ADHAN";
    static final String EXTRA_INDEX = "prayer";
    static final String[] NAMES = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final int[] ALERTS = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};

    private Adhan() { }

    private static SharedPreferences p(Context c) { return App.prefs(c); }

    static boolean enabled(Context c) { return p(c).getBoolean("adhan_on", false); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("adhan_on", on).apply();
        scheduleNext(c);
    }

    static boolean hasLocation(Context c) { return p(c).contains("lat"); }

    static void saveLocation(Context c, double lat, double lng) {
        p(c).edit().putFloat("lat", (float) lat).putFloat("lng", (float) lng).apply();
    }

    static String city(Context c) { return p(c).getString("city", ""); }

    static void saveCity(Context c, String city) { p(c).edit().putString("city", city).apply(); }

    static boolean isRamadan(Calendar day) {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(day.getTimeInMillis());
            return ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN;
        } catch (Throwable t) {
            return false;
        }
    }

    /** مواقيت يوم معيّن كأوقات بالمللي ثانية */
    static long[] times(Context c, Calendar day) {
        double lat = p(c).getFloat("lat", 21.4225f), lng = p(c).getFloat("lng", 39.8262f);
        Calendar noon = (Calendar) day.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        double tz = TimeZone.getDefault().getOffset(noon.getTimeInMillis()) / 3_600_000.0;
        double[] h = PrayerCalc.compute(noon.get(Calendar.YEAR), noon.get(Calendar.MONTH) + 1,
                noon.get(Calendar.DAY_OF_MONTH), lat, lng, tz, isRamadan(noon));
        long[] out = new long[h.length];
        Calendar mid = (Calendar) noon.clone();
        mid.set(Calendar.HOUR_OF_DAY, 0);
        for (int i = 0; i < h.length; i++) out[i] = mid.getTimeInMillis() + Math.round(h[i] * 60) * 60_000L;
        return out;
    }

    /** «الفجر ٤:٥٨ ص · الظهر ...» */
    static String todaySummary(Context c) {
        if (!hasLocation(c)) return "حدّد موقعك لعرض مواقيت الصلاة";
        long[] t = times(c, Calendar.getInstance());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            Calendar x = Calendar.getInstance();
            x.setTimeInMillis(t[i]);
            if (sb.length() > 0) sb.append("\n");
            sb.append(NAMES[i]).append("   ")
              .append(arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE))));
        }
        return sb.toString();
    }

    /** «٣:٣٧ م» */
    static String clock(long millis) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(millis);
        return arabic(App.formatTime(x.get(Calendar.HOUR_OF_DAY), x.get(Calendar.MINUTE)));
    }

    static String arabic(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return sb.toString();
    }

    static boolean canExact(Context c) {
        return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }

    static void scheduleNext(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION);
        PendingIntent cancel = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        // يُجدول عند تفعيل الأذان أو وجود ويدجت المواقيت (لتحديثه عند كل صلاة)
        if (!hasLocation(c) || !(enabled(c) || PrayerWidget.hasWidgets(c))) {
            am.cancel(cancel);
            return;
        }
        long now = System.currentTimeMillis() + 30_000;
        Calendar day = Calendar.getInstance();
        long when = -1;
        int index = PrayerCalc.FAJR;
        for (int d = 0; d < 2 && when < 0; d++) {
            long[] t = times(c, day);
            for (int k : ALERTS) {
                if (t[k] > now) { when = t[k]; index = k; break; }
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        if (when < 0) return;
        i.putExtra(EXTRA_INDEX, index);
        PendingIntent pi = PendingIntent.getBroadcast(c, 203, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }
}
