package com.hawlalaalam.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;

/** ويدجت رمضان: عدّاد الإفطار/الإمساك، وقبل رمضان: كم بقي عليه */
public class RamadanWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        render(context.getApplicationContext(), mgr, ids);
    }

    static boolean hasWidgets(Context c) {
        int[] ids = AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, RamadanWidget.class));
        return ids != null && ids.length > 0;
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, RamadanWidget.class));
        if (ids != null && ids.length > 0) render(c, mgr, ids);
    }

    private static void render(Context c, AppWidgetManager mgr, int[] ids) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_ramadan);
        Intent open = new Intent(c, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        rv.setOnClickPendingIntent(R.id.rw_root, PendingIntent.getActivity(c, 303, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));

        if (!Ramadan.active()) {
            int d = Ramadan.daysUntil();
            rv.setTextViewText(R.id.rw_label, "🌙 رمضان ١٤٤٨");
            rv.setTextViewText(R.id.rw_big, d > 0 ? "بعد " + Adhan.arabic(String.valueOf(d)) + " يومًا" : "قريبًا");
            rv.setViewVisibility(R.id.rw_timer, View.GONE);
            rv.setViewVisibility(R.id.rw_big, View.VISIBLE);
            rv.setTextViewText(R.id.rw_sub, "بلّغنا الله رمضان");
            rv.setTextViewText(R.id.rw_side, "");
            mgr.updateAppWidget(ids, rv);
            return;
        }
        rv.setTextViewText(R.id.rw_side, Ramadan.ordinal(Ramadan.day()) + "\nمن رمضان");
        if (!Adhan.hasLocation(c)) {
            rv.setTextViewText(R.id.rw_label, "🌙 رمضان كريم");
            rv.setTextViewText(R.id.rw_big, "حدّد موقعك");
            rv.setViewVisibility(R.id.rw_timer, View.GONE);
            rv.setViewVisibility(R.id.rw_big, View.VISIBLE);
            rv.setTextViewText(R.id.rw_sub, "لعرض الإمساك والإفطار");
            mgr.updateAppWidget(ids, rv);
            return;
        }
        long[] ev = Ramadan.nextEvent(c);
        long now = System.currentTimeMillis();
        rv.setTextViewText(R.id.rw_label, ev[0] == 1 ? "🌙 الإفطار بعد" : "🌙 الإمساك بعد");
        rv.setViewVisibility(R.id.rw_big, View.GONE);
        rv.setViewVisibility(R.id.rw_timer, View.VISIBLE);
        rv.setChronometer(R.id.rw_timer, SystemClock.elapsedRealtime() + (ev[1] - now), null, true);
        rv.setChronometerCountDown(R.id.rw_timer, true);
        Calendar today = Calendar.getInstance();
        String city = Adhan.city(c);
        rv.setTextViewText(R.id.rw_sub, "الإمساك " + Adhan.clock(Ramadan.imsak(c, today))
                + " · الإفطار " + Adhan.clock(Ramadan.iftar(c, today)) + (city.isEmpty() ? "" : " · " + city));
        mgr.updateAppWidget(ids, rv);
    }
}
