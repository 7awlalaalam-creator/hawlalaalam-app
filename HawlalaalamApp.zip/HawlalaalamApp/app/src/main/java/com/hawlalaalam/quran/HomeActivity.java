package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/**
 * شاشة «اليوم» — مرتّبة بلا تشتيت:
 * ١) الترويسة والصلاة القادمة، ٢) بطاقة واحدة «أكمل القراءة» مع حلقة الختمة،
 * ٣) بطاقة في وقتها فقط (رمضان أو الأذكار)، ٤) آية اليوم، ٥) أربع أدوات وباقيها في «الأدوات».
 */
public class HomeActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.wrap(base));                // المظهر المختار يُطبَّق فورًا
    }
    static final String EXTRA_FROM_HOME = "from_home";

    private LinearLayout col;
    private int ink, muted, gold, goldL, ivoryBorder, page;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!App.prefs(this).getBoolean("welcomed", false)) {
            startActivity(new Intent(this, WelcomeActivity.class));
        } else if (FeaturesActivity.shouldShow(this)) {
            FeaturesActivity.open(this);              // شرح المميزات مرة بعد التحديث
        }
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        ivoryBorder = getColor(R.color.ivory_border);
        page = getColor(R.color.page);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(page);
        root.setLayoutDirection(L.dir());

        ScrollView scroll = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(14), dp(16), dp(24));
        scroll.addView(col);
        root.addView(SiteServices.pullToRefresh(this, scroll, this::render), new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(bottomNav());

        setContentView(root);
        Ui.applyInsets(root, false);                     // الشريط السفلي بعرض الشاشة
        Ui.applyInsets(scroll);                          // والمحتوى بعرض مريح على الأجهزة اللوحية
        Notifier.ensureChannels(this);
        Reminders.scheduleAll(this);
        Announce.checkSoon(this);
        Adhan.scheduleNext(this);

        // «اليوم» هي الشاشة الرئيسية: الرجوع منها يخرج من التطبيق ويُبقيه جاهزًا في الخلفية
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, () -> moveTaskToBack(true));
        }
        // تسخين محرّك الصفحات أثناء الخمول: أول فتح للموقع يصبح أسرع بشكل ملحوظ
        android.os.Looper.myQueue().addIdleHandler(() -> {
            warmWebView(getApplicationContext());
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.isNight(this) != Ui.isNight(Ui.wrap(getApplicationContext()))) { recreate(); return; }
        render();
        SiteServices.refresh(this, this::render);
        PrayerLive.update(this);                     // يُجدَّد إن سحبه المستخدم أو تأخر منبّه الصلاة
        RamadanWidget.updateAll(this);
        KhatmaWidget.updateAll(this);
        UpdateChecker.check(this, false);
        Rate.maybeAsk(this);                         // نافذة تقييم Play بعد قراءة ورد اليوم (مرة كل ٤ أشهر على الأكثر)
        Stats.syncAsync(this);                       // لا يرسل شيئًا إلا بموافقة «الخريطة» أو رمز دعوة
        AdhanCheck.schedule(this);                   // الفحص الأسبوعي للأذان
        WearSync.push(this);                         // تطبيق الساعة: الموقع واللغة وآية اليوم (إن تغيّر شيء)
        if (!VerseRepo.isFresh(this)) {
            new Thread(() -> {
                VerseRepo.fetchToday(getApplicationContext());
                WearSync.push(getApplicationContext());
                runOnUiThread(() -> { if (!isFinishing()) render(); });
            }).start();
        }
    }

    // ------------------------------------------------------------------ البناء

    /**
     * تخطيط «بينتو»: خانات بأحجام حسب الأهمية.
     * الترويسة ← ورد اليوم (كبيرة) ← إعلان الموقع ← [الصلاة القادمة | السلسلة + خانة الوقت]
     * ← رمضان ← صلواتي اليوم مع المواقيت ← آية اليوم ← أدواتك
     */
    private void render() {
        col.removeAllViews();
        col.addView(header());
        col.addView(wirdCard(), gap(14));
        View ann = siteNotice();                         // إعلان من صفحة الإدارة في الموقع
        if (ann != null) col.addView(ann, gap(12));
        // إشعار الأذان محجوب أو لم يصل: نُظهر طريقة الإصلاح قبل أي شيء
        if (Adhan.needsFix(this)) col.addView(adhanFixCard(), gap(12));
        col.addView(nextRow(), gap(12));
        View ram = ramadanCard();
        if (ram != null) col.addView(ram, gap(12));
        if (Adhan.hasLocation(this)) col.addView(prayersCard(), gap(12));
        col.addView(verseCard(), gap(12));
        col.addView(toolsHeader(), gap(20));
        col.addView(toolsRow(), gap(10));
    }

    /** بطاقة «إعلان من الموقع»: تُدار من صفحة الإدارة، ويغلقها المستخدم بـ ✕ فلا تعود */
    private View siteNotice() {
        SiteServices.Notice n = SiteServices.notice(this);
        if (n == null) return null;
        android.widget.FrameLayout f = new android.widget.FrameLayout(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TR_BL, new int[]{0xFF7A5A20, 0xFFC9A24F});
        bg.setCornerRadius(dp(18));
        card.setBackground(bg);
        card.addView(Ui.text(this, L.t("إعلان من الموقع"), 11, 0xDDFFFFFF, 400));
        TextView t = Ui.text(this, n.title, 17, 0xFFFFFFFF, 700);
        t.setPadding(0, dp(4), dp(24), dp(2));
        card.addView(t);
        if (!n.body.isEmpty()) {
            TextView b = Ui.text(this, n.body, 13, 0xF2FFFFFF, 400);
            b.setLineSpacing(0, 1.25f);
            card.addView(b);
        }
        if (!n.url.isEmpty()) {
            TextView go = Ui.text(this, (n.button.isEmpty() ? L.t("افتح") : n.button) + "  ‹", 13, 0xFF7A5A20, 700);
            go.setPadding(dp(14), dp(6), dp(14), dp(6));
            go.setBackground(Ui.shape(0xFFFFFFFF, 14, 0, this));
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
            gl.topMargin = dp(10);
            card.addView(go, gl);
            card.setOnClickListener(v -> SiteServices.open(this, "", n.url));
        }
        f.addView(card, new android.widget.FrameLayout.LayoutParams(-1, -2));
        TextView x = Ui.text(this, "✕", 15, 0xE6FFFFFF, 700);
        x.setGravity(Gravity.CENTER);
        x.setContentDescription(L.t("إغلاق الإعلان"));
        x.setOnClickListener(v -> { SiteServices.close(this, n.id); render(); });
        f.addView(x, new android.widget.FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END));
        card.setContentDescription(L.t("إعلان من الموقع: ") + n.title);
        return f;
    }

    // ------------------------------------------------------------------ الترويسة

    /** ترويسة داكنة بزخرفة: التحية والتاريخ، زر المظهر والإعدادات، ثم شريط الصلاة القادمة */
    private View header() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), dp(4), dp(2), 0);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo_png);
        logo.setClipToOutline(true);
        logo.setBackground(Ui.shape(0xFF0E2C31, 14, 0x66C9A876, this));
        logo.setContentDescription(L.t("حول العالم"));
        row.addView(logo, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        texts.addView(Ui.text(this, h < 12 ? L.t("صباح الخير") : L.t("مساء الخير"), 23, ink, 700));
        String city = Adhan.city(this);
        TextView sub = Ui.text(this, Ui.hijriToday() + (city.isEmpty() ? "" : " · " + city), 13, muted, 400);
        sub.setMaxLines(1);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        texts.addView(sub);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));

        if (Ui.canSetTheme()) {                         // زر الوضع الليلي/النهاري
            boolean night = Ui.isNight(this);
            ImageView tb = headButton(night ? R.drawable.ic_l_sun : R.drawable.ic_l_moon,
                    night ? L.t("الوضع النهاري") : L.t("الوضع الليلي"));
            tb.setOnClickListener(v -> { Ui.applyTheme(this, night ? 1 : 2); recreate(); });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(dp(44), dp(44));
            tl.setMarginEnd(dp(8));
            row.addView(tb, tl);
        }
        ImageView st = headButton(R.drawable.ic_nav_settings, L.t("الإعدادات"));
        st.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        row.addView(st, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return row;
    }

    private ImageView headButton(int icon, String label) {
        ImageView b = Ui.icon(this, icon, gold, 20);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setBackground(Ui.shape(getColor(R.color.card), 15, getColor(R.color.line), this));
        b.setContentDescription(label);
        b.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        return b;
    }

    /** خانة بخلفية البطاقة وإطار (خانات «بينتو» الفاتحة) */
    private LinearLayout tileBox() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        b.setBackground(Ui.shape(getColor(R.color.card), 20, getColor(R.color.line), this));
        return b;
    }

    /** زر ذهبي (أساسي على الخانات الداكنة) */
    private TextView goldButton(String s) {
        TextView t = Ui.text(this, s, 15, 0xFF2B1D06, 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), 0, dp(16), 0);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFFF3DFA8, 0xFFC9A876});
        g.setCornerRadius(dp(15));
        t.setBackground(g);
        return t;
    }

    /** زر شفاف على الخانات الداكنة */
    private TextView glassButton(String s, int color) {
        TextView t = Ui.text(this, s, 14, color, 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), 0, dp(16), 0);
        t.setBackground(Ui.shape(0x1CFFFFFF, 14, 0x30FFFFFF, this));
        return t;
    }

    // ------------------------------------------------------------------ ورد اليوم

    /** الخانة الكبرى: ورد اليوم وحلقة الختمة و«أكمل القراءة» */
    private View wirdCard() {
        String url = Reading.lastUrl(this);
        boolean khatma = Khatma.active(this) && !Khatma.done(this);
        int lightGold = 0xFFE2C48E;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(new Ui.PatternDrawable(this, getColor(R.color.dark), 24));
        card.setElevation(dp(4));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        String label, title, line;
        if (khatma) {
            int target = Math.max(1, Khatma.dailyTarget(this));
            int doneToday = Math.min(target, Khatma.todayCount(this));
            label = L.t("ورد اليوم · ختمتي ") + Adhan.arabic(String.valueOf(Khatma.percent(this))) + L.t("٪");
            title = Adhan.arabic(String.valueOf(doneToday)) + L.t(" من ") + Adhan.arabic(String.valueOf(target))
                    + (target <= 10 && target >= 3 ? L.t(" صفحات") : L.t(" صفحة"));
            line = Khatma.todayLine(this);
        } else {
            label = url == null ? L.t("ابدأ القراءة") : L.t("أكمل من حيث توقفت");
            title = url == null ? L.t("المصحف الشريف") : Reading.lastTitle(this);
            line = L.t("ابدأ ختمة: نحسب وردك كل يوم ونذكّرك به");
        }
        t.addView(Ui.text(this, label, 12, lightGold, 700));
        TextView tt = Ui.text(this, title, 21, 0xFFFFFFFF, 700);
        tt.setMaxLines(2);
        tt.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tt.setPadding(0, dp(4), 0, dp(2));
        t.addView(tt);
        TextView ln = Ui.text(this, line, 13, getColor(R.color.on_dark_muted), 400);
        ln.setMaxLines(2);
        t.addView(ln);
        top.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        // الحلقة: نسبة الختمة، أو أيقونة المصحف إن لم تبدأ ختمة
        FrameLayout badge = new FrameLayout(this);
        if (khatma) {
            int pct = Khatma.percent(this);
            Ui.Ring ring = new Ui.Ring(this, 0x26FFFFFF, lightGold);
            ring.setFraction(pct / 100f);
            badge.addView(ring, new FrameLayout.LayoutParams(-1, -1));
            TextView p = Ui.text(this, Adhan.arabic(String.valueOf(pct)) + L.t("٪"), 16, 0xFFFFFFFF, 700);
            p.setGravity(Gravity.CENTER);
            badge.addView(p, new FrameLayout.LayoutParams(-1, -1));
            badge.setContentDescription(L.t("ختمتي ") + Adhan.arabic(String.valueOf(pct)) + L.t("٪"));
        } else {
            ImageView ic = Ui.icon(this, R.drawable.ic_mushaf_t, lightGold, 30);
            ic.setScaleType(ImageView.ScaleType.CENTER);
            ic.setBackground(Ui.shape(0x1CFFFFFF, 40, 0x30FFFFFF, this));
            badge.addView(ic, new FrameLayout.LayoutParams(-1, -1));
            badge.setContentDescription(L.t("ختمتي"));
        }
        badge.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(78), dp(78));
        bp.setMarginStart(dp(12));
        top.addView(badge, bp);
        card.addView(top);

        LinearLayout btns = new LinearLayout(this);
        TextView go = goldButton(url == null ? L.t("افتح المصحف") : L.t("أكمل القراءة"));
        go.setOnClickListener(v -> openWeb(url == null ? App.mushaf(this) : url));
        btns.addView(Ui.minH(go, 48), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView idx = glassButton(L.t("الفهرس"), 0xFFFFFFFF);
        idx.setContentDescription(L.t("فهرس السور والأجزاء"));
        idx.setOnClickListener(v -> startActivity(new Intent(this, SurahIndexActivity.class)));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2);
        pl.setMarginStart(dp(8));
        btns.addView(Ui.minH(idx, 48), pl);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = dp(16);
        card.addView(btns, bl);
        return card;
    }

    // ------------------------------------------------------------------ الصلاة القادمة والخانات الصغيرة

    /** صف: الصلاة القادمة (ذهبية) بجانب عمود فيه السلسلة وخانة الوقت */
    private View nextRow() {
        LinearLayout row = new LinearLayout(this);
        row.addView(nextPrayerCard(), new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.addView(streakTile(), new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, 0, 1f);
        cl.topMargin = dp(10);
        side.addView(contextTile(), cl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.setMarginStart(dp(10));
        row.addView(side, sl);
        return row;
    }

    private View nextPrayerCard() {
        int dk = 0xFF2B1D06, dk2 = 0xFF5A3F10;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{0xFFF3DFA8, 0xFFD9B46A, 0xFFB88A3E});
        g.setCornerRadius(dp(20));
        card.setBackground(g);
        card.setMinimumHeight(dp(164));

        if (!Adhan.hasLocation(this)) {
            card.addView(Ui.text(this, L.t("مواقيت الصلاة"), 12, dk2, 700));
            TextView t = Ui.text(this, L.t("فعّل المواقيت وتنبيه الأذان"), 18, dk, 700);
            t.setPadding(0, dp(8), 0, 0);
            card.addView(t, new LinearLayout.LayoutParams(-1, 0, 1f));
            card.addView(Ui.text(this, L.t("تفعيل ←"), 14, dk, 700));
            card.setContentDescription(L.t("فعّل مواقيت الصلاة"));
            card.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
            return card;
        }
        long[] nx = Adhan.next(this);
        int idx = (int) nx[0];
        long at = nx[1];
        String name = isFridayDhuhr(idx, at) ? L.t("الجمعة") : Adhan.NAMES[idx];
        card.addView(Ui.text(this, L.t("الصلاة القادمة"), 12, dk2, 700));
        TextView n = Ui.text(this, name, 32, dk, 700);
        n.setMaxLines(1);
        n.setPadding(0, dp(4), 0, 0);
        card.addView(n);
        card.addView(Ui.text(this, Adhan.clock(at), 15, dk, 700));
        card.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1f));
        Chronometer ch = new Chronometer(this);
        ch.setTextColor(dk);
        ch.setTextSize(14);
        ch.setTypeface(Ui.font(this, 700));
        ch.setCountDown(true);
        ch.setBase(SystemClock.elapsedRealtime() + (at - System.currentTimeMillis()));
        // «بعد ٥٢ دقيقة» / «بعد ١:٠٥ ساعة» بدل «٥٢:٠٩» بلا وحدة
        ch.setText(Adhan.remaining(at - System.currentTimeMillis(), true));
        ch.setOnChronometerTickListener(c -> {
            if (c.getBase() <= SystemClock.elapsedRealtime()) { render(); return; }
            c.setText(Adhan.remaining(at - System.currentTimeMillis(), true));
        });
        ch.start();
        card.addView(ch);
        card.setContentDescription(L.t("الصلاة القادمة ") + name + " " + Adhan.clock(at) + L.t("، اضغط لعرض المواقيت"));
        card.setOnClickListener(v -> openWeb(App.HOME + "prayer-times-ar.html"));
        return card;
    }

    /** السلسلة: أيام متتالية مع القرآن */
    private View streakTile() {
        int n = Reading.streak(this);
        LinearLayout b = tileBox();
        b.addView(Ui.text(this, L.t("متتالية"), 12, gold, 700));
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.BOTTOM);
        r.addView(Ui.text(this, Adhan.arabic(String.valueOf(n)), 28, ink, 700));
        int m = n % 100;
        String unit = n == 0 ? L.t("ابدأ اليوم") : n == 1 ? L.t("يوم مع القرآن") : n == 2 ? L.t("يومان مع القرآن")
                : (m >= 3 && m <= 10) ? L.t("أيام مع القرآن") : L.t("يومًا مع القرآن");
        TextView u = Ui.text(this, unit, 12, muted, 400);
        u.setPadding(dp(6), 0, 0, dp(6));
        u.setMaxLines(1);
        r.addView(u);
        b.addView(r);
        b.setContentDescription(Adhan.arabic(String.valueOf(n)) + " " + unit);
        b.setOnClickListener(v -> startActivity(new Intent(this, JourneyActivity.class)));
        return b;
    }

    /** خانة الوقت: مراجعة الحفظ إن حانت، وإلا الأذكار في وقتها، وإلا «رحلتي» */
    private View contextTile() {
        int total = App.prefs(this).getInt("hifz_total", 0), next = App.prefs(this).getInt("hifz_next", -1);
        long now = System.currentTimeMillis();
        int today = (int) Math.floor((now + java.util.TimeZone.getDefault().getOffset(now)) / 86_400_000.0);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int icon; String title, sub; View.OnClickListener open;
        if (total > 0 && next >= 0 && today >= next) {
            icon = R.drawable.ic_l_sprout; title = L.t("مراجعة الحفظ"); sub = L.t("آيات تنتظرك · راجع");
            open = v -> openWeb(App.mushaf(this) + "&hifz=1");
        } else if (h >= 4 && h < 11) {
            icon = R.drawable.ic_azkar_t; title = L.t("أذكار الصباح"); sub = L.t("حان وقتها · ابدأ");
            open = v -> openWeb(App.HOME + "azkar-morning-evening-ar.html");
        } else if (h >= 15 && h < 20) {
            icon = R.drawable.ic_azkar_t; title = L.t("أذكار المساء"); sub = L.t("حان وقتها · ابدأ");
            open = v -> openWeb(App.HOME + "azkar-morning-evening-ar.html");
        } else {
            icon = R.drawable.ic_impact; title = L.t("رحلتي"); sub = L.t("أيامك مع القرآن");
            open = v -> startActivity(new Intent(this, JourneyActivity.class));
        }
        LinearLayout b = tileBox();
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.addView(Ui.icon(this, icon, gold, 26));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(10), 0, 0, 0);
        TextView tt = Ui.text(this, title, 14, ink, 700);
        tt.setMaxLines(1);
        t.addView(tt);
        TextView ss = Ui.text(this, sub, 11, muted, 400);
        ss.setMaxLines(1);
        t.addView(ss);
        b.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        b.setContentDescription(title + "، " + sub);
        b.setOnClickListener(open);
        return b;
    }

    /** صلواتي اليوم مع المواقيت: المؤداة ✓، والقادمة ذهبية، والضغط يسجّل الصلاة */
    private View prayersCard() {
        long now = System.currentTimeMillis();
        long[] t = Adhan.times(this, Calendar.getInstance());
        int today = PrayerLog.day(now), m = PrayerLog.mask(this, today);
        int next = -1;
        for (int k = 0; k < 5; k++) if (t[PrayerLog.INDEX[k]] > now) { next = k; break; }

        LinearLayout card = tileBox();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, L.t("صلواتي اليوم"), 13, gold, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView j = Ui.text(this, Ui.arabicNum(PrayerLog.count(m)) + L.t(" من ٥ · رحلتي ←"), 12, muted, 400);
        j.setPadding(dp(8), dp(4), 0, dp(4));
        j.setOnClickListener(v -> startActivity(new Intent(this, JourneyActivity.class)));
        head.addView(j);
        card.addView(head);

        LinearLayout row = new LinearLayout(this);
        for (int k = 0; k < 5; k++) {
            final int i = k;
            int p = PrayerLog.INDEX[k];
            boolean on = (m & (1 << k)) != 0, due = t[p] <= now, isNext = k == next;
            String name = isFridayDhuhr(p, t[p]) ? L.t("الجمعة") : PrayerLog.NAMES[k];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(0, dp(7), 0, dp(7));
            int fg, fg2;
            if (isNext) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{0xFFF3DFA8, 0xFFC9A876});
                g.setCornerRadius(dp(12));
                cell.setBackground(g);
                fg = 0xFF2B1D06; fg2 = 0xFF5A3F10;
            } else if (on || due) {
                cell.setBackground(Ui.shape(getColor(R.color.primary), 12, 0, this));
                fg = 0xFFE2C48E; fg2 = 0xFFFFFFFF;
            } else {
                cell.setBackground(Ui.shape(getColor(R.color.chip), 12, 0, this));
                fg = muted; fg2 = muted;
            }
            TextView n = Ui.text(this, name, 12, fg, 700);
            n.setGravity(Gravity.CENTER);
            n.setMaxLines(1);
            cell.addView(n);
            TextView tm = Ui.text(this, Adhan.arabic(clockShort(t[p])), 12, fg2, 500);
            tm.setGravity(Gravity.CENTER);
            tm.setMaxLines(1);
            cell.addView(tm);
            TextView mk = Ui.text(this, on ? "✓" : isNext ? L.t("القادمة") : due ? "○" : "", on ? 14 : 11,
                    on ? 0xFF9FD8B8 : fg2, 700);
            mk.setGravity(Gravity.CENTER);
            mk.setMaxLines(1);
            cell.addView(mk);
            cell.setContentDescription(name + " " + Adhan.clock(t[p])
                    + (on ? L.t("، صلّيتها") : due ? L.t("، اضغط لتسجيلها") : L.t("، لم يدخل وقتها")));
            if (due || on) {
                cell.setOnClickListener(v -> {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                    PrayerLog.toggle(this, today, i);
                    render();
                });
            } else {
                cell.setOnClickListener(v -> openWeb(App.HOME + "prayer-times-ar.html"));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (k > 0) lp.setMarginStart(dp(5));
            row.addView(cell, lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(9);
        card.addView(row, rl);
        return card;
    }

    /** «٣:١٨» دون ص/م لخلية ضيقة */
    private static String clockShort(long millis) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(millis);
        int h = x.get(Calendar.HOUR_OF_DAY) % 12;
        return (h == 0 ? 12 : h) + ":" + String.format(java.util.Locale.US, "%02d", x.get(Calendar.MINUTE));
    }

    private static boolean isFridayDhuhr(int idx, long at) {
        if (idx != PrayerCalc.DHUHR) return false;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(at);
        return c.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
    }

    // ------------------------------------------------------------------ بطاقات في وقتها

    /** وضع رمضان: يظهر في رمضان، وقبله بعشرة أيام */
    private View ramadanCard() {
        boolean active = Ramadan.active();
        int until = active ? 0 : Ramadan.daysUntil();
        if (!active && (until < 1 || until > 10)) return null;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(Ui.shape(getColor(R.color.dark), 22, 0, this));
        if (!active) {
            card.addView(Ui.iconTitle(this, R.drawable.ic_l_moon, L.t("رمضان على الأبواب"), 13, goldL, 700, goldL));
            TextView t = Ui.text(this, L.t("بعد ") + Adhan.arabic(String.valueOf(until)) + (until <= 2 ? L.t(" يوم") : L.t(" أيام")), 26, 0xFFFFFFFF, 700);
            t.setPadding(0, dp(6), 0, dp(4));
            card.addView(t);
            card.addView(Ui.text(this, L.t("جهّز ختمة رمضان من الآن، ونذكّرك بوردك كل يوم."), 14, getColor(R.color.on_dark_muted), 400));
            TextView btn = pill(L.t("جهّز ختمتي"), true);
            btn.setBackground(Ui.shape(goldL, 21, 0, this));
            btn.setTextColor(getColor(R.color.dark));
            btn.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(12);
            card.addView(Ui.minH(btn, 42), lp);
            return card;
        }
        card.addView(Ui.iconTitle(this, R.drawable.ic_l_moon, L.t("رمضان كريم · ") + Ramadan.ordinal(Ramadan.day()), 13, goldL, 700, goldL));
        if (Adhan.hasLocation(this)) {
            long[] ev = Ramadan.nextEvent(this);
            TextView lbl = Ui.text(this, ev[0] == 1 ? L.t("الإفطار بعد") : L.t("الإمساك بعد"), 14, getColor(R.color.on_dark_muted), 400);
            lbl.setGravity(Gravity.CENTER);
            lbl.setPadding(0, dp(10), 0, 0);
            card.addView(lbl);
            Chronometer ch = new Chronometer(this);
            ch.setTextColor(0xFFFFFFFF);
            ch.setTextSize(40);
            ch.setTypeface(Ui.font(this, 700));
            ch.setGravity(Gravity.CENTER);
            ch.setCountDown(true);
            ch.setBase(SystemClock.elapsedRealtime() + (ev[1] - System.currentTimeMillis()));
            ch.setOnChronometerTickListener(c -> { if (c.getBase() <= SystemClock.elapsedRealtime()) render(); });
            ch.start();
            card.addView(ch, new LinearLayout.LayoutParams(-1, -2));
            Calendar today = Calendar.getInstance();
            LinearLayout times = new LinearLayout(this);
            times.setPadding(0, dp(10), 0, 0);
            String[][] cells = {{L.t("الإمساك"), Adhan.clock(Ramadan.imsak(this, today))}, {L.t("الإفطار"), Adhan.clock(Ramadan.iftar(this, today))}};
            for (int i = 0; i < 2; i++) {
                TextView cell = Ui.text(this, cells[i][0] + "\n" + cells[i][1], 15, i == 1 ? goldL : 0xFFFFFFFF, 700);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(0, dp(8), 0, dp(8));
                cell.setBackground(Ui.shape(0x14FFFFFF, 14, 0, this));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                if (i > 0) lp.setMarginStart(dp(8));
                times.addView(cell, lp);
            }
            card.addView(times);
        }
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(12), 0, 0);
        TextView tad = pill(L.t("تدبّر اليوم"), false);
        tad.setOnClickListener(v -> openWeb(Ramadan.tadabburUrl()));
        actions.addView(Ui.minH(tad, 42), new LinearLayout.LayoutParams(0, -1, 1f));
        TextView kh = pill(L.t("ختمة رمضان"), true);
        kh.setBackground(Ui.shape(goldL, 21, 0, this));
        kh.setTextColor(getColor(R.color.dark));
        kh.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -1, 1f);
        lp2.setMarginStart(dp(8));
        actions.addView(Ui.minH(kh, 42), lp2);
        card.addView(actions);
        return card;
    }

    /** تنبيه الأذان لا يظهر: الإشعارات أو فئة «الأذان» متوقفة، أو أوقفت «التطبيقات النائمة» المنبّه */
    private View adhanFixCard() {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(Ui.shape(getColor(R.color.ivory), 18, getColor(R.color.gold_deep), this));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(Ui.text(this, L.t("إشعار الأذان لا يظهر في جوالك"), 15, ink, 700));
        TextView s = Ui.text(this, L.t("يظهر رمز المنبّه فقط؟ اضغط لنريك طريقة الإصلاح في دقيقة"), 12, muted, 400);
        s.setPadding(0, dp(2), 0, 0);
        t.addView(s);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView go = pill(L.t("إصلاح"), true);
        card.addView(Ui.minH(go, 38), new LinearLayout.LayoutParams(-2, -2));
        View.OnClickListener open = v -> startActivity(new Intent(this, SettingsActivity.class)
                .putExtra(SettingsActivity.EXTRA_NOTIF_ONLY, true));
        card.setOnClickListener(open);
        go.setOnClickListener(open);
        card.setContentDescription(L.t("إشعار الأذان لا يظهر، اضغط لإصلاحه"));
        return card;
    }

    // ------------------------------------------------------------------ آية اليوم

    private View verseCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        card.setBackground(new Ui.PatternDrawable(this, getColor(R.color.dark), 24));
        VerseRepo.Verse v = VerseRepo.cached(this);
        int lightGold = 0xFFE2C48E;

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.iconTitle(this, R.drawable.ic_star, L.t("آية اليوم"), 13, lightGold, 700, lightGold), new LinearLayout.LayoutParams(0, -2, 1f));
        if (v != null) head.addView(Ui.text(this, v.ref(), 12, getColor(R.color.on_dark_muted), 400));
        card.addView(head);

        TextView verse = new TextView(this);
        verse.setTextColor(0xFFFFFFFF);
        verse.setGravity(Gravity.CENTER);
        verse.setPadding(0, dp(12), 0, dp(14));
        if (v != null && v.text != null && !v.text.isEmpty()) {
            // نص مجمع الملك فهد بخطه، مع علامة نهاية الآية برقمها كما في المصحف
            verse.setTypeface(QuranText.font(this));
            verse.setLineSpacing(0, 1.25f);
            verse.setText(QuranText.withNumber(v.text, v.ayah));
            verse.setTextSize(v.text.length() < 80 ? 25 : v.text.length() < 180 ? 22 : 19);
        } else {
            verse.setTypeface(Ui.font(this, 500));
            verse.setText(L.t("جارٍ تحميل آية اليوم…"));
            verse.setTextSize(16);
        }
        card.addView(verse);

        if (v != null) {
            // ثلاثة أزرار في صف واحد: الصورة، النص، التفسير
            LinearLayout btns = new LinearLayout(this);
            View share = glassButton(L.t("صورة"), lightGold);
            share.setContentDescription(L.t("شارك آية اليوم كصورة"));
            // مشاركة سريعة، أو تصميم البطاقة في الموقع (تغيير الخلفية وإضافة التفسير)
            share.setOnClickListener(x -> {
                android.app.AlertDialog d = new android.app.AlertDialog.Builder(this, Ui.dialogTheme(this))
                        .setTitle(L.t("شارك آية اليوم كصورة"))
                        .setItems(new String[]{L.t("شارك الصورة الآن"), L.t("صمّم البطاقة: الخلفية والتفسير")}, (dlg, which) -> {
                            if (which == 0) shareVerseImage(v); else openWeb(v.cardUrl());
                        })
                        .create();
                d.show();
                if (d.getWindow() != null) d.getWindow().getDecorView().setLayoutDirection(L.dir());
            });
            View shareText = glassButton(L.t("نص"), lightGold);
            shareText.setContentDescription(L.t("شارك آية اليوم نصًّا"));
            shareText.setOnClickListener(x -> {
                try {
                    startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, Notifier.verseShareText(v)), L.t("شارك آية اليوم")));
                } catch (Exception ignored) { }
            });
            View tafsir = glassButton(L.t("التفسير"), lightGold);
            tafsir.setContentDescription(L.t("اقرأ تفسير آية اليوم"));
            tafsir.setOnClickListener(x -> openWeb(v.tafsirUrl()));
            View[] all = {share, shareText, tafsir};
            for (int i = 0; i < all.length; i++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
                if (i > 0) lp.setMarginStart(dp(6));
                btns.addView(Ui.minH(all[i], 44), lp);
            }
            card.addView(btns);
        }
        return card;
    }

    /** بطاقة الآية صورةً تُرسم على الجهاز وتُشارك مباشرة؛ وإن تعذّر الرسم فصفحة البطاقة في الموقع */
    private void shareVerseImage(VerseRepo.Verse v) {
        android.graphics.Bitmap img = Notifier.verseShareImage(this, v);
        if (img == null) { openWeb(v.cardUrl()); return; }
        try {
            java.io.File dir = new java.io.File(getCacheDir(), "shared");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, "ayah-today.png");
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
                img.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
            }
            img.recycle();
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent send = new Intent(Intent.ACTION_SEND).setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_TEXT, Notifier.verseShareText(v))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newRawUri("", uri));
            startActivity(Intent.createChooser(send, L.t("شارك آية اليوم")));
        } catch (Exception e) {
            openWeb(v.cardUrl());
        }
    }

    // ------------------------------------------------------------------ الأدوات

    private View toolsHeader() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), 0, dp(4), 0);
        r.addView(Ui.text(this, L.t("أدواتك"), 16, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView all = Ui.text(this, L.t("كل الأدوات ←"), 13, gold, 700);
        all.setPadding(dp(8), dp(8), 0, dp(8));
        all.setOnClickListener(v -> startActivity(new Intent(this, ToolsActivity.class)));
        r.addView(all);
        return r;
    }

    /** أكثر أربع أدوات استخدامًا؛ الباقي في شاشة «الأدوات» */
    private View toolsRow() {
        Object[][] tools = {
                {L.t("آية لحالك"), R.drawable.ic_l_heart, MoodActivity.class},
                {L.t("الأذكار"), R.drawable.ic_azkar_t, App.HOME + "azkar-morning-evening-ar.html"},
                {L.t("القبلة"), R.drawable.ic_qibla, QiblaActivity.class},
                {L.t("المسبحة"), R.drawable.ic_tasbeeh, TasbeehActivity.class},
        };
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < tools.length; i++) {
            View tile = ToolsActivity.tile(this, (String) tools[i][0], (Integer) tools[i][1], tools[i][2]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.setMarginStart(dp(8));
            row.addView(tile, lp);
        }
        return row;
    }

    private View bottomNav() {
        return Ui.appNav(this, Ui.NAV_TODAY, idx -> {
            if (idx == Ui.NAV_MUSHAF) openWeb(App.mushaf(this));
            else if (idx == Ui.NAV_LISTEN) startActivity(new Intent(this, ListenActivity.class));
            else if (idx == Ui.NAV_TOOLS) startActivity(new Intent(this, ToolsActivity.class));
        });
    }

    // ------------------------------------------------------------------ أدوات

    /** رابط من الموقع: شاشته الأصلية، أو المصحف دون إنترنت، أو متصفح الجوال لما سواهما */
    private void openWeb(String url) {
        Intent i = Nav.intent(this, url);
        if (i.getComponent() != null && MainActivity.class.getName().equals(i.getComponent().getClassName())) {
            i.putExtra(EXTRA_FROM_HOME, true);
        }
        startActivity(i);
    }

    private TextView pill(String s, boolean primary) {
        TextView t = Ui.text(this, s, 14, primary ? 0xFFFFFFFF : ink, 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), 0, dp(16), 0);
        t.setBackground(primary ? Ui.shape(getColor(R.color.primary), 21, 0, this) : Ui.shape(getColor(R.color.card), 21, getColor(R.color.field_border), this));
        return t;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {   // أندرويد 12 وأقدم
        moveTaskToBack(true);
    }

    private static boolean webWarm;

    /** تحميل مكتبة WebView مسبقًا (مرة واحدة لكل تشغيل) */
    static void warmWebView(android.content.Context c) {
        if (webWarm) return;
        webWarm = true;
        try { android.webkit.WebSettings.getDefaultUserAgent(c); } catch (Throwable ignored) { }
    }
}
