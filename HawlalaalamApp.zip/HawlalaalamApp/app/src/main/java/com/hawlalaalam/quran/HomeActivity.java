package com.hawlalaalam.quran;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/** شاشة «اليوم»: الصلاة القادمة، آية اليوم، أكمل من حيث توقفت، الأدوات، والأيام المتتالية */
public class HomeActivity extends Activity {
    static final String EXTRA_FROM_HOME = "from_home";

    private LinearLayout col;
    private int ink, muted, gold, goldL, ivoryBorder, page;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (!App.prefs(this).getBoolean("welcomed", false)) {
            startActivity(new Intent(this, WelcomeActivity.class));
        }
        ink = getColor(R.color.ink);
        muted = getColor(R.color.muted);
        gold = getColor(R.color.gold_deep);
        goldL = getColor(R.color.gold);
        ivoryBorder = getColor(R.color.ivory_border);
        page = getColor(R.color.page);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(page);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(16), dp(18), dp(24));
        scroll.addView(col);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(bottomNav());

        setContentView(root);
        Ui.applyInsets(root);
        Notifier.ensureChannels(this);
        Reminders.scheduleAll(this);
        Adhan.scheduleNext(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
        RamadanWidget.updateAll(this);
        KhatmaWidget.updateAll(this);
        UpdateChecker.check(this, false);
        if (!VerseRepo.isFresh(this)) {
            new Thread(() -> {
                VerseRepo.fetchToday(getApplicationContext());
                runOnUiThread(() -> { if (!isFinishing()) render(); });
            }).start();
        }
    }

    // ------------------------------------------------------------------ البناء

    private void render() {
        col.removeAllViews();
        col.addView(header());
        View ram = ramadanCard();
        if (ram != null) col.addView(ram, gap(14));
        col.addView(prayerCard(), gap(14));
        col.addView(moodCard(), gap(14));
        col.addView(verseCard(), gap(14));
        col.addView(continueCard(), gap(14));
        col.addView(khatmaCard(), gap(14));
        View azkar = azkarPrompt();
        if (azkar != null) col.addView(azkar, gap(14));
        col.addView(sectionTitle("الأدوات"), gap(22));
        col.addView(toolsGrid(), gap(10));
        col.addView(streakCard(), gap(18));
        col.addView(dedicateCard(), gap(14));
    }

    /** وضع رمضان: يظهر في رمضان، وقبله بعشرة أيام */
    private View ramadanCard() {
        boolean active = Ramadan.active();
        int until = active ? 0 : Ramadan.daysUntil();
        if (!active && (until < 1 || until > 10)) return null;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(Ui.shape(getColor(R.color.dark), 22, 0, this));
        if (!active) {
            card.addView(Ui.iconTitle(this, R.drawable.ic_l_moon, "رمضان على الأبواب", 13, goldL, 700, goldL));
            TextView t = Ui.text(this, "بعد " + Adhan.arabic(String.valueOf(until)) + (until <= 2 ? " يوم" : " أيام"), 26, 0xFFFFFFFF, 700);
            t.setPadding(0, dp(6), 0, dp(4));
            card.addView(t);
            card.addView(Ui.text(this, "جهّز ختمة رمضان من الآن، ونذكّرك بوردك كل يوم.", 14, getColor(R.color.on_dark_muted), 400));
            TextView btn = pill("جهّز ختمتي", true);
            btn.setBackground(Ui.shape(goldL, 21, 0, this));
            btn.setTextColor(getColor(R.color.dark));
            btn.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42));
            lp.topMargin = dp(12);
            card.addView(btn, lp);
            return card;
        }
        card.addView(Ui.iconTitle(this, R.drawable.ic_l_moon, "رمضان كريم · " + Ramadan.ordinal(Ramadan.day()), 13, goldL, 700, goldL));
        if (Adhan.hasLocation(this)) {
            long[] ev = Ramadan.nextEvent(this);
            TextView lbl = Ui.text(this, ev[0] == 1 ? "الإفطار بعد" : "الإمساك بعد", 14, getColor(R.color.on_dark_muted), 400);
            lbl.setGravity(Gravity.CENTER);
            lbl.setPadding(0, dp(10), 0, 0);
            card.addView(lbl);
            Chronometer ch = new Chronometer(this);
            ch.setTextColor(0xFFFFFFFF);
            ch.setTextSize(40);
            ch.setTypeface(Ui.font(this, 700));
            ch.setGravity(Gravity.CENTER);
            ch.setCountDown(true);
            ch.setBase(SystemClock.elapsedRealtime() + (ev[1] - System.currentTimeMillis()));
            ch.setOnChronometerTickListener(c -> { if (c.getBase() <= SystemClock.elapsedRealtime()) render(); });
            ch.start();
            card.addView(ch, new LinearLayout.LayoutParams(-1, -2));
            Calendar today = Calendar.getInstance();
            LinearLayout times = new LinearLayout(this);
            times.setPadding(0, dp(10), 0, 0);
            String[][] cells = {{"الإمساك", Adhan.clock(Ramadan.imsak(this, today))}, {"الإفطار", Adhan.clock(Ramadan.iftar(this, today))}};
            for (int i = 0; i < 2; i++) {
                TextView cell = Ui.text(this, cells[i][0] + "\n" + cells[i][1], 15, i == 1 ? goldL : 0xFFFFFFFF, 700);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(0, dp(8), 0, dp(8));
                cell.setBackground(Ui.shape(0x14FFFFFF, 14, 0, this));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                if (i > 0) lp.setMarginStart(dp(8));
                times.addView(cell, lp);
            }
            card.addView(times);
        }
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(12), 0, 0);
        TextView tad = pill("تدبّر اليوم", false);
        tad.setOnClickListener(v -> openWeb(Ramadan.tadabburUrl()));
        actions.addView(tad, new LinearLayout.LayoutParams(0, dp(42), 1f));
        TextView kh = pill("ختمة رمضان", true);
        kh.setBackground(Ui.shape(goldL, 21, 0, this));
        kh.setTextColor(getColor(R.color.dark));
        kh.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp2.setMarginStart(dp(8));
        actions.addView(kh, lp2);
        card.addView(actions);
        return card;
    }

    /** «آية لحالك»: أسرع طريق لآية تواسيك */
    private View moodCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.ivory), 20, getColor(R.color.ivory_border), this));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(Ui.iconTitle(this, R.drawable.ic_l_heart, "كيف حالك اليوم؟", 16, ink, 700, gold), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = Ui.text(this, "آية لحالك ←", 13, gold, 700);
        more.setOnClickListener(v -> startActivity(new Intent(this, MoodActivity.class)));
        top.addView(more);
        card.addView(top);
        LinearLayout row = new LinearLayout(this);
        int[] quick = {0, 1, 2, 5};          // قلق، حزين، ضيق، متعب
        for (int i = 0; i < quick.length; i++) {
            final int m = quick[i];
            LinearLayout c = Ui.iconTitle(this, MoodActivity.ICONS[m], MoodActivity.MOODS[m][1], 13, ink, 500, gold);
            c.setGravity(Gravity.CENTER);
            c.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
            c.setOnClickListener(v -> startActivity(new Intent(this, MoodActivity.class).putExtra(MoodActivity.EXTRA_MOOD, m)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            if (i > 0) lp.setMarginStart(dp(6));
            row.addView(c, lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(10);
        card.addView(row, rl);
        return card;
    }

    /** بطاقة الختمة الذكية */
    private View khatmaCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setOnClickListener(v -> startActivity(new Intent(this, KhatmaActivity.class)));
        LinearLayout top = new LinearLayout(this);
        top.addView(Ui.iconTitle(this, R.drawable.ic_khatma_t, "ختمتي", 15, gold, 700, gold), new LinearLayout.LayoutParams(0, -2, 1f));
        if (!Khatma.active(this) || Khatma.done(this)) {
            card.addView(top);
            TextView t = Ui.text(this, "ابدأ ختمة: نحسب ورد كل يوم ونذكّرك به", 15, ink, 500);
            t.setPadding(0, dp(6), 0, 0);
            card.addView(t);
            return card;
        }
        int pct = Khatma.percent(this);
        top.addView(Ui.text(this, Adhan.arabic(String.valueOf(pct)) + "٪", 13, muted, 500));
        card.addView(top);
        android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress(pct);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(gold));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.chip)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(12));
        bl.topMargin = dp(8);
        bl.bottomMargin = dp(8);
        card.addView(bar, bl);
        int[] r = Khatma.todayRange(this);
        int left = Khatma.todayRemaining(this);
        card.addView(Ui.text(this, left == 0 ? "أتممت ورد اليوم ✓ بارك الله فيك"
                : "ورد اليوم: صفحة " + Adhan.arabic(String.valueOf(r[0])) + " إلى " + Adhan.arabic(String.valueOf(r[1])), 15, ink, 500));
        return card;
    }

    private View header() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        texts.addView(Ui.text(this, h < 12 ? "صباح الخير" : "مساء الخير", 26, ink, 700));
        String city = Adhan.city(this);
        TextView sub = Ui.text(this, Ui.hijriToday() + (city.isEmpty() ? "" : " · " + city), 14, muted, 400);
        sub.setPadding(0, dp(6), 0, 0);
        texts.addView(sub);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_logo);
        logo.setClipToOutline(true);
        logo.setBackground(Ui.shape(0xFF0E2C31, 12, 0, this));
        logo.setContentDescription("حول العالم");
        if (Ui.canSetTheme()) {                         // زر الوضع الليلي/النهاري
            boolean night = Ui.isNight(this);
            android.widget.ImageView tb = Ui.icon(this, night ? R.drawable.ic_l_sun : R.drawable.ic_l_moon, gold, 22);
            tb.setScaleType(android.widget.ImageView.ScaleType.CENTER);
            tb.setBackground(Ui.shape(getColor(R.color.card), 22, getColor(R.color.line), this));
            tb.setContentDescription(night ? "الوضع النهاري" : "الوضع الليلي");
            tb.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            tb.setOnClickListener(v -> Ui.applyTheme(this, night ? 1 : 2));
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(dp(44), dp(44));
            tl.setMarginEnd(dp(10));
            row.addView(tb, tl);
        }
        row.addView(logo, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(row);
        LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(-1, -2);
        ql.topMargin = dp(18);
        wrap.addView(quickActions(), ql);
        return wrap;
    }

    /** أربعة اختصارات بأيقونات موحّدة */
    private View quickActions() {
        LinearLayout row = new LinearLayout(this);
        Object[][] items = {
                {"المصحف", R.drawable.ic_mushaf_t, App.MUSHAF},
                {"استمع", R.drawable.ic_l_headphones, App.HOME + "quran-reciters-ar.html"},
                {"القبلة", R.drawable.ic_l_compass, QiblaActivity.class},
                {"آية لحالك", R.drawable.ic_l_heart, MoodActivity.class},
        };
        for (int i = 0; i < items.length; i++) {
            Object[] it = items[i];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setContentDescription((String) it[0]);
            android.widget.ImageView ic = Ui.icon(this, (Integer) it[1], gold, 26);
            ic.setScaleType(android.widget.ImageView.ScaleType.CENTER);
            ic.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
            ic.setLayoutParams(new LinearLayout.LayoutParams(dp(58), dp(58)));
            cell.addView(ic);
            TextView l = Ui.text(this, (String) it[0], 13, ink, 500);
            l.setPadding(0, dp(8), 0, 0);
            cell.addView(l);
            final Object target = it[2];
            cell.setOnClickListener(v -> {
                if (target instanceof String) openWeb((String) target);
                else startActivity(new Intent(this, (Class<?>) target));
            });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return row;
    }

    private View prayerCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(Ui.shape(getColor(R.color.dark), 22, 0, this));

        if (!Adhan.hasLocation(this)) {
            card.addView(Ui.text(this, "مواقيت الصلاة", 13, goldL, 700));
            TextView t = Ui.text(this, "حدّد موقعك لعرض الصلاة القادمة وتنبيه الأذان", 16, 0xFFFFFFFF, 500);
            t.setPadding(0, dp(8), 0, dp(12));
            card.addView(t);
            TextView btn = pill("فعّل المواقيت", true);
            btn.setBackground(Ui.shape(goldL, 21, 0, this));
            btn.setTextColor(getColor(R.color.dark));
            btn.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
            card.addView(btn, new LinearLayout.LayoutParams(-2, dp(42)));
            return card;
        }

        long[] nx = Adhan.next(this);
        int idx = (int) nx[0];
        long at = nx[1];
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.BOTTOM);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.addView(Ui.text(this, "الصلاة القادمة", 13, goldL, 700));
        TextView name = Ui.text(this, Adhan.NAMES[idx] + "  " + Adhan.clock(at), 26, 0xFFFFFFFF, 700);
        name.setPadding(0, dp(6), 0, 0);
        l.addView(name);
        top.addView(l, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.END);
        r.addView(Ui.text(this, "متبقٍّ", 12, getColor(R.color.on_dark_muted), 400));
        Chronometer ch = new Chronometer(this);
        ch.setTextColor(0xFFEFE4CF);              // ثابت: البطاقة داكنة دائمًا
        ch.setTextSize(18);
        ch.setTypeface(Ui.font(this, 700));
        ch.setCountDown(true);
        ch.setBase(SystemClock.elapsedRealtime() + (at - System.currentTimeMillis()));
        ch.setOnChronometerTickListener(c -> { if (c.getBase() <= SystemClock.elapsedRealtime()) render(); });
        ch.start();
        r.addView(ch);
        top.addView(r);
        card.addView(top);

        LinearLayout grid = new LinearLayout(this);
        grid.setPadding(0, dp(14), 0, 0);
        int[] ps = {PrayerCalc.FAJR, PrayerCalc.DHUHR, PrayerCalc.ASR, PrayerCalc.MAGHRIB, PrayerCalc.ISHA};
        long[] t = Adhan.times(this, Calendar.getInstance());
        for (int k = 0; k < ps.length; k++) {
            boolean isNext = ps[k] == idx && at - System.currentTimeMillis() < 20 * 3_600_000L;
            TextView cell = Ui.text(this, Adhan.NAMES[ps[k]] + "\n" + Adhan.clock(t[ps[k]]).replace(" ص", "").replace(" م", ""),
                    12, isNext ? goldL : getColor(R.color.on_dark_muted), isNext ? 700 : 400);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(0, dp(6), 0, dp(6));
            if (isNext) cell.setBackground(Ui.shape(0xFF1E4A55, 10, 0, this));
            grid.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        card.addView(grid);
        card.setOnClickListener(v -> openWeb(App.HOME + "prayer-times-ar.html"));
        return card;
    }

    private View verseCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.ivory), 22, ivoryBorder, this));
        VerseRepo.Verse v = VerseRepo.cached(this);

        LinearLayout head = new LinearLayout(this);
        head.addView(Ui.text(this, "✦ آية اليوم", 13, gold, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        if (v != null) head.addView(Ui.text(this, v.ref(), 12, muted, 400));
        card.addView(head);

        TextView verse = new TextView(this);
        verse.setTypeface(Ui.quran(this));
        verse.setTextColor(ink);
        verse.setGravity(Gravity.CENTER);
        verse.setLineSpacing(dp(4), 1f);
        verse.setPadding(0, dp(10), 0, dp(12));
        if (v != null && v.text != null && !v.text.isEmpty()) {
            verse.setText("﴿ " + v.text + " ﴾");
            verse.setTextSize(v.text.length() < 80 ? 24 : v.text.length() < 180 ? 21 : 18);
        } else {
            verse.setText("جارٍ تحميل آية اليوم…");
            verse.setTextSize(16);
        }
        card.addView(verse);

        if (v != null) {
            LinearLayout btns = new LinearLayout(this);
            TextView tafsir = pill("المعنى والتفسير", false);
            tafsir.setOnClickListener(x -> openWeb(v.tafsirUrl()));
            TextView share = pill("شارك كصورة", true);
            share.setOnClickListener(x -> openWeb(v.cardUrl()));
            LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(42), 1f);
            LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(42), 1f);
            b.setMarginStart(dp(8));
            btns.addView(share, a);
            btns.addView(tafsir, b);
            card.addView(btns);
        }
        return card;
    }

    private View continueCard() {
        String url = Reading.lastUrl(this);
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_mushaf_t);
        ic.setBackground(Ui.shape(getColor(R.color.chip), 14, 0, this));
        ic.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.addView(ic, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(12), 0);
        t.addView(Ui.text(this, url == null ? "ابدأ القراءة" : "أكمل من حيث توقفت", 12, gold, 700));
        TextView title = Ui.text(this, url == null ? "افتح المصحف الشريف" : Reading.lastTitle(this), 17, ink, 700);
        title.setPadding(0, dp(4), 0, 0);
        t.addView(title);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.ic_chevron);
        card.addView(chev, new LinearLayout.LayoutParams(dp(22), dp(22)));
        card.setOnClickListener(v -> openWeb(url == null ? App.MUSHAF : url));
        return card;
    }

    private View azkarPrompt() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String title;
        if (h >= 4 && h < 11) title = "حان وقت أذكار الصباح";
        else if (h >= 15 && h < 20) title = "حان وقت أذكار المساء";
        else return null;
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        card.setBackground(Ui.shape(getColor(R.color.chip), 18, ivoryBorder, this));
        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_azkar_t);
        card.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(12), 0);
        t.addView(Ui.text(this, title, 15, ink, 700));
        TextView s = Ui.text(this, "دقائق تحفظك طوال يومك", 12, muted, 400);
        s.setPadding(0, dp(3), 0, 0);
        t.addView(s);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(pill("ابدأ", true), new LinearLayout.LayoutParams(dp(74), dp(38)));
        card.setOnClickListener(v -> openWeb(App.HOME + "azkar-morning-evening-ar.html"));
        return card;
    }

    private View toolsGrid() {
        Object[][] tools = {
                {"المصحف", R.drawable.ic_mushaf_t, App.MUSHAF},
                {"الاستماع", R.drawable.ic_listen_t, App.HOME + "quran-reciters-ar.html"},
                {"القبلة", R.drawable.ic_qibla, QiblaActivity.class},
                {"المسبحة", R.drawable.ic_tasbeeh, TasbeehActivity.class},
                {"الأذكار", R.drawable.ic_azkar_t, App.HOME + "azkar-morning-evening-ar.html"},
                {"المحمّلة", R.drawable.ic_listen_t, DownloadsActivity.class},
                {"ختمتي", R.drawable.ic_khatma_t, KhatmaActivity.class},
                {"الترجمات", R.drawable.ic_globe_t, App.HOME + "languages.html"},
        };
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < tools.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                if (i > 0) lp.topMargin = dp(10);
                grid.addView(row, lp);
            }
            Object[] t = tools[i];
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(0, dp(12), 0, dp(10));
            tile.setBackground(Ui.shape(getColor(R.color.card), 16, getColor(R.color.line), this));
            ImageView ic = new ImageView(this);
            ic.setImageResource((Integer) t[1]);
            tile.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView label = Ui.text(this, (String) t[0], 12, ink, 500);
            label.setPadding(0, dp(8), 0, 0);
            tile.addView(label);
            final Object target = t[2];
            tile.setOnClickListener(v -> {
                if (target instanceof String) openWeb((String) target);
                else startActivity(new Intent(this, (Class<?>) target));
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i % 4 > 0) lp.setMarginStart(dp(8));
            row.addView(tile, lp);
        }
        return grid;
    }

    private View streakCard() {
        int n = Reading.streak(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.card), 18, getColor(R.color.line), this));
        String title = n == 0 ? "ابدأ سلسلتك اليوم مع القرآن"
                : n == 1 ? "يوم واحد مع القرآن" : n == 2 ? "يومان متتاليان مع القرآن"
                : Ui.arabicNum(n) + (n <= 10 ? " أيام متتالية مع القرآن" : " يومًا متتاليًا مع القرآن");
        card.addView(Ui.text(this, title, 16, ink, 700));
        TextView s = Ui.text(this, Reading.readOn(this, Calendar.getInstance()) ? "أحسنت، قرأت اليوم ✓" : "اقرأ ولو آية اليوم لتكملها", 12, muted, 400);
        s.setPadding(0, dp(4), 0, dp(10));
        card.addView(s);
        LinearLayout dots = new LinearLayout(this);
        String[] dn = {"ح", "ن", "ث", "ر", "خ", "ج", "س"}; // الأحد..السبت
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -6);
        for (int i = 0; i < 7; i++) {
            boolean on = Reading.readOn(this, c);
            boolean today = i == 6;
            LinearLayout d = new LinearLayout(this);
            d.setOrientation(LinearLayout.VERTICAL);
            d.setGravity(Gravity.CENTER);
            TextView dot = new TextView(this);
            dot.setBackground(Ui.shape(on ? gold : getColor(R.color.chip), 14, today ? gold : 0, this));
            dot.setText(on ? "✓" : "");
            dot.setTextColor(0xFFFFFFFF);
            dot.setGravity(Gravity.CENTER);
            d.addView(dot, new LinearLayout.LayoutParams(dp(28), dp(28)));
            TextView lbl = Ui.text(this, dn[c.get(Calendar.DAY_OF_WEEK) - 1], 11, today ? gold : muted, today ? 700 : 400);
            lbl.setPadding(0, dp(4), 0, 0);
            d.addView(lbl);
            dots.addView(d, new LinearLayout.LayoutParams(0, -2, 1f));
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        card.addView(dots);
        return card;
    }

    private View dedicateCard() {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.shape(getColor(R.color.dark), 18, 0, this));
        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_heart);
        card.addView(ic, new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), 0, dp(12), 0);
        t.addView(Ui.text(this, "اجعلها صدقة جارية", 16, 0xFFFFFFFF, 700));
        TextView s = Ui.text(this, "شارك التطبيق باسم من تحب، حيًّا أو ميتًا", 12, getColor(R.color.on_dark_muted), 400);
        s.setPadding(0, dp(3), 0, 0);
        t.addView(s);
        card.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView chev = new ImageView(this);
        chev.setImageResource(R.drawable.ic_chevron);
        card.addView(chev, new LinearLayout.LayoutParams(dp(22), dp(22)));
        card.setOnClickListener(v -> startActivity(new Intent(this, DedicateActivity.class)));
        return card;
    }

    private View bottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(getColor(R.color.card));
        nav.setElevation(dp(8));
        nav.setPadding(0, dp(6), 0, dp(6));
        Object[][] items = {
                {"اليوم", R.drawable.ic_nav_today, null},
                {"المصحف", R.drawable.ic_nav_mushaf, App.MUSHAF},
                {"الاستماع", R.drawable.ic_nav_listen, App.HOME + "quran-reciters-ar.html"},
                {"الموقع", R.drawable.ic_nav_more, App.HOME},
                {"الإعدادات", R.drawable.ic_nav_settings, SettingsActivity.class},
        };
        for (int i = 0; i < items.length; i++) {
            Object[] it = items[i];
            LinearLayout b = new LinearLayout(this);
            b.setOrientation(LinearLayout.VERTICAL);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(4), 0, dp(4));
            ImageView ic = new ImageView(this);
            ic.setImageResource((Integer) it[1]);
            if (i == 0) ic.setColorFilter(gold);
            b.addView(ic, new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView l = Ui.text(this, (String) it[0], 11, i == 0 ? gold : muted, i == 0 ? 700 : 500);
            l.setPadding(0, dp(3), 0, 0);
            b.addView(l);
            final Object target = it[2];
            b.setOnClickListener(v -> {
                if (target instanceof String) openWeb((String) target);
                else if (target instanceof Class) startActivity(new Intent(this, (Class<?>) target));
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return nav;
    }

    // ------------------------------------------------------------------ أدوات

    private void openWeb(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url), this, MainActivity.class)
                .putExtra(EXTRA_FROM_HOME, true));
    }

    private TextView pill(String s, boolean primary) {
        TextView t = Ui.text(this, s, 14, primary ? 0xFFFFFFFF : ink, 700);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), 0, dp(16), 0);
        t.setBackground(primary ? Ui.shape(getColor(R.color.primary), 21, 0, this) : Ui.shape(getColor(R.color.card), 21, getColor(R.color.field_border), this));
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s, 15, gold, 700);
        t.setPadding(dp(4), 0, dp(4), 0);
        return t;
    }

    private LinearLayout.LayoutParams gap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        return lp;
    }

    private int dp(int v) { return Ui.dp(this, v); }
}
