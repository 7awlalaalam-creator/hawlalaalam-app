package com.hawlalaalam.quran;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** يستقبل الإشعار الفوري (رسالة بيانات) ويعرضه بنفس قناة «أخبار وتنبيهات حول العالم» */
public class PushService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage msg) {
        Map<String, String> d = msg.getData();
        if (d == null || d.isEmpty()) return;
        long expires = 0;
        try { expires = Long.parseLong(d.get("expires")); } catch (Exception ignored) { }
        Announce.deliver(getApplicationContext(), d.get("id"), d.get("title"), d.get("body"), d.get("url"), expires);
    }

    @Override
    public void onNewToken(String token) {
        // الاشتراك بالموضوع يكفي؛ لا نحتاج حفظ المعرّف في أي مكان
        Push.init(getApplicationContext());
    }
}
