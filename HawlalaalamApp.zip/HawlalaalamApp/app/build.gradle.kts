plugins {
    id("com.android.application")
}

// التوقيع يُقرأ من متغيرات البيئة (أسرار GitHub) — لا تضع كلمات المرور هنا
val ksFile = System.getenv("KEYSTORE_FILE")
val hasSigning = !ksFile.isNullOrBlank() && file(ksFile).exists()

android {
    namespace = "com.hawlalaalam.quran"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.hawlalaalam.quran"
        minSdk = 26
        targetSdk = 36
        // رقم الإصدار يزيد تلقائيًا مع كل بناء على GitHub
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "2.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    signingConfigs {
        if (hasSigning) {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // تصغير الكود والموارد: حجم أصغر وتشغيل أسرع
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    androidResources {
        // الخط وجدول التحويل يُقرآن مباشرة من الأصول دون فك ضغط
        noCompress += listOf("woff2")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    // الإشعارات الفورية (Firebase Cloud Messaging) — تُفعَّل فقط حين تُملأ قيم res/values/firebase.xml
    implementation("com.google.firebase:firebase-messaging:24.1.0")
    // Firebase يجلب androidx.fragment 1.1.0 القديمة ضمنيًا (تنبيه Play Console «SDK قديم»)، فنفرض نسخة حديثة
    implementation("androidx.fragment:fragment:1.9.1")
    implementation("androidx.activity:activity:1.10.1")   // نفس السبب: activity 1.0.0 القديمة كانت تأتي ضمنيًا
    // نافذة التقييم داخل التطبيق (Google Play In-App Review) — تعمل فقط حين يكون التطبيق مثبّتًا من Play
    implementation("com.google.android.play:review:2.0.2")
    // مزامنة تطبيق الساعة (Wear OS): الموقع وطريقة الحساب واللغة وآية اليوم
    implementation("com.google.android.gms:play-services-wearable:19.0.0")
}
