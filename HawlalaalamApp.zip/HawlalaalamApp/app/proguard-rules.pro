# حول العالم | القرآن — قواعد R8
# أرقام الأسطر في تقارير الأعطال
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# الشاشات والمستقبِلات والخدمات والويدجت تُحفظ تلقائيًا من AndroidManifest.
# لا يوجد JavascriptInterface (الجسر عبر WebMessageListener) ولا انعكاس على كلاسات التطبيق.

# صفحة المقال في التطبيق تقرأ الخطوط من file:///android_res/font/ (يحتاج WebView صنف R$font)
-keep class com.hawlalaalam.quran.R$font { *; }

# «المساجد القريبة»: جسر JavascriptInterface لصفحة الخريطة
-keepclassmembers class com.hawlalaalam.quran.MosquesActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
