# حول العالم | القرآن — قواعد R8
# أرقام الأسطر في تقارير الأعطال
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# الشاشات والمستقبِلات والخدمات والويدجت تُحفظ تلقائيًا من AndroidManifest.
# لا يوجد JavascriptInterface (الجسر عبر WebMessageListener) ولا انعكاس على كلاسات التطبيق.
