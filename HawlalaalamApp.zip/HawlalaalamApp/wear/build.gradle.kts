plugins {
    id("com.android.application")
}

// تطبيق الساعة (Wear OS): نفس اسم الحزمة ومفتاح التوقيع حتى يتزامن مع تطبيق الجوال ويُنشر في نفس صفحة Google Play
val ksFile = System.getenv("KEYSTORE_FILE")
val hasSigning = !ksFile.isNullOrBlank() && file(ksFile).exists()
val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.hawlalaalam.quran.wear"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.hawlalaalam.quran"
        minSdk = 30
        targetSdk = 36
        // أرقام الساعة منفصلة عن الجوال (Google Play يشترط ألا يتكرر الرقم بين الملفات)
        versionCode = 1_000_000 + run
        versionName = "2.0.$run"
    }

    signingConfigs {
        if (hasSigning) {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.wear.tiles:tiles:1.4.1")
    implementation("androidx.wear.protolayout:protolayout:1.2.1")
    implementation("androidx.wear.watchface:watchface-complications-data-source:1.2.1")
    implementation("androidx.wear:wear-phone-interactions:1.0.1")
    implementation("androidx.concurrent:concurrent-futures:1.2.0")
    implementation("com.google.android.gms:play-services-wearable:19.0.0")
}
