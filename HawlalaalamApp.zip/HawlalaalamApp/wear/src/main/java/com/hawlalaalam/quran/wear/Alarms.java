package com.hawlalaalam.quran.wear;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.wear.phone.interactions.notifications.BridgingConfig;
import androidx.wear.phone.interactions.notifications.BridgingManager;

import java.util.List;

/**
 * تنبيه الأذان على الساعة: منبّه للصلاة القادمة فقط، ويُجدول التالي عند كل تنبيه.
 * حين يكون مفعّلًا نمنع إشعار أذان الجوال (وسمه «adhan») من الوصول للساعة حتى لا يتكرر الاهتزاز.
 */
final class Alarms {
    static final String ACTION = "com.hawlalaalam.quran.wear.ADHAN";
    private static final String CH = "adhan_watch";

    private Alarms() { }

    static boolean on(Context c) { return W.p(c).getBoolean("adhan_watch", true); }

    private static PendingIntent pi(Context c) {
        return PendingIntent.getBroadcast(c, 1, new Intent(c, Receiver.class).setAction(ACTION),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c) {
        bridging(c);
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        am.cancel(pi(c));
        if (!on(c)) return;
        List<long[]> up = Prayer.upcoming(c, System.currentTimeMillis() + 30_000, 1);
        if (up.isEmpty()) return;
        long[] n = up.get(0);
        W.p(c).edit().putInt("alarm_idx", (int) n[0]).putLong("alarm_at", n[1]).apply();
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n[1], pi(c));
            else
                am.setWindow(AlarmManager.RTC_WAKEUP, n[1], 60_000, pi(c));
        } catch (SecurityException e) {
            am.setWindow(AlarmManager.RTC_WAKEUP, n[1], 60_000, pi(c));
        }
    }

    private static void bridging(Context c) {
        try {
            BridgingConfig.Builder b = new BridgingConfig.Builder(c, true);
            if (on(c)) b.addExcludedTag("adhan");
            BridgingManager.fromContext(c).setConfig(b.build());
        } catch (Throwable ignored) { }
    }

    static void notify(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, W.t(c, "الأذان", "Adhan"), NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 600, 300, 600, 300, 600});
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        int idx = W.p(c).getInt("alarm_idx", Prayer.DHUHR);
        long at = W.p(c).getLong("alarm_at", System.currentTimeMillis());
        String name = Prayer.name(c, idx, at);
        List<long[]> after = Prayer.upcoming(c, at + 60_000, 1);
        String next = after.isEmpty() ? "" : W.t(c, "التالية: ", "Next: ") + Prayer.name(c, (int) after.get(0)[0], after.get(0)[1])
                + " " + W.clock(c, after.get(0)[1]);
        PendingIntent open = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent azkar = PendingIntent.getActivity(c, 3, AzkarActivity.intent(c, "prayer").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat_quran)
                .setColor(W.GOLD)
                .setContentTitle(W.t(c, "حان الآن موعد أذان ", "It's time for ") + name)
                .setContentText(next)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setTimeoutAfter(20 * 60_000L)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c, R.drawable.ic_stat_quran), W.t(c, "أذكار بعد الصلاة", "After-prayer adhkar"), azkar).build())
                .build();
        try { nm.notify(20, n); } catch (SecurityException ignored) { }
    }

    /** المنبّه، وإعادة الجدولة بعد إعادة التشغيل أو تغيير الوقت والمنطقة الزمنية */
    public static class Receiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            if (ACTION.equals(i.getAction())) {
                long at = W.p(c).getLong("alarm_at", 0);
                if (on(c) && Math.abs(System.currentTimeMillis() - at) < 15 * 60_000L) notify(c);
            }
            schedule(c);
            W.refreshSurfaces(c);
        }
    }
}
