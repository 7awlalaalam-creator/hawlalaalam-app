package com.hawlalaalam.quran.wear;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

/** الإعدادات: تنبيه الأذان على الساعة، وموقع الساعة بدل الجوال، واللغة */
public class SettingsActivity extends Screen {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private void build() {
        scrollList(true);
        add(W.text(this, W.t(this, "الإعدادات", "Settings"), 15, W.MUTE, 0), 0);

        boolean adhan = Alarms.on(this);
        chip((adhan ? "✓  " : "✕  ") + W.t(this, "تنبيه الأذان على الساعة", "Adhan alert on watch"), adhan ? W.CHIP : 0xFF1A1F1F, v -> {
            W.p(this).edit().putBoolean("adhan_watch", !Alarms.on(this)).apply();
            Alarms.schedule(this);
            build();
        });
        add(W.text(this, W.t(this, "اهتزاز على المعصم وقت كل صلاة، دون تكرار إشعار الجوال",
                "Vibrates at each prayer time, without duplicating the phone alert"), 11, W.MUTE, 0), 4);

        chip("📍  " + W.t(this, "استخدم موقع الساعة", "Use watch location"), W.CHIP, v -> locate());
        String city = Prayer.city(this);
        long sync = W.p(this).getLong("sync_at", 0);
        String where = Prayer.hasLocation(this) ? (city.isEmpty() ? W.t(this, "موقع محفوظ", "Saved location") : city)
                : W.t(this, "لم يُحدَّد الموقع (مكة افتراضيًا)", "No location yet (Makkah by default)");
        add(W.text(this, where + (sync > 0 ? W.t(this, "\nآخر مزامنة مع الجوال: ", "\nLast phone sync: ")
                + W.d(this, DateFormat.getDateInstance(DateFormat.SHORT).format(new Date(sync))) : ""), 11, W.MUTE, 0), 4);

        chip("🌐  " + (W.ar(this) ? "English" : "العربية"), 0xFF1A1F1F, v -> {
            W.p(this).edit().putString("lang", W.ar(this) ? "en" : "ar").putBoolean("lang_fixed", true).apply();
            W.refreshSurfaces(this);
            build();
        });
        String ver = "";
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        add(W.text(this, W.t(this, "القرآن حول العالم · ", "Quran Around the World · ") + ver, 10, 0xFF5F6F6C, 0), 14);
    }

    private void locate() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 2);
            return;
        }
        LocationManager lm = getSystemService(LocationManager.class);
        Location best = null;
        try {
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
        } catch (SecurityException ignored) { }
        if (best != null) { save(best); return; }
        try {
            String provider = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ? LocationManager.NETWORK_PROVIDER : LocationManager.GPS_PROVIDER;
            toast(W.t(this, "جارٍ تحديد الموقع…", "Locating…"));
            lm.getCurrentLocation(provider, null, getMainExecutor(), l -> {
                if (l != null) save(l);
                else toast(W.t(this, "تعذّر تحديد الموقع، افتح التطبيق في الجوال", "Couldn't get location, open the phone app"));
            });
        } catch (Exception e) {
            toast(W.t(this, "تعذّر تحديد الموقع", "Couldn't get location"));
        }
    }

    private void save(Location l) {
        W.p(this).edit().putFloat("lat", (float) l.getLatitude()).putFloat("lng", (float) l.getLongitude())
                .putString("city", W.t(this, "موقع الساعة", "Watch location")).putBoolean("loc_watch", true).apply();
        Alarms.schedule(this);
        W.refreshSurfaces(this);
        toast(W.t(this, "تم ✓", "Done ✓"));
        build();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 2 && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) locate();
    }
}
