package com.hawlalaalam.quran.wear;

import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** آية اليوم: نفس آية الجوال إن وصلت منه اليوم، وإلا آية من قائمة محفوظة على الساعة تتغيّر كل يوم */
public class VerseActivity extends Screen {

    static String asset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open(name); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        }
    }

    static String ref(Context c, int s, int a) {
        try {
            JSONArray names = new JSONArray(asset(c, "surahs.json")).getJSONArray(s - 1);
            return W.ar(c) ? "سورة " + names.getString(0) + " · " + W.d(c, a) : names.getString(1) + " · " + a;
        } catch (Exception e) {
            return W.d(c, s + ":" + a);
        }
    }

    /** {النص، المرجع} */
    static String[] today(Context c) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String t = W.p(c).getString("verse_text", "");
        if (!t.isEmpty() && today.equals(W.p(c).getString("verse_date", "")))
            return new String[]{t, ref(c, W.p(c).getInt("verse_s", 1), W.p(c).getInt("verse_a", 1))};
        try {
            JSONArray a = new JSONArray(asset(c, "verses.json"));
            JSONObject v = a.getJSONObject(Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % a.length());
            return new String[]{v.getString("t"), ref(c, v.getInt("s"), v.getInt("a"))};
        } catch (Exception e) {
            return new String[]{t, ""};
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        scrollList(true);
        add(W.text(this, W.t(this, "آية اليوم", "Verse of the day"), 13, W.MUTE, 0), 0);
        String[] v = today(this);
        TextView q = add(W.text(this, v[0], 21, 0xFFFFFFFF, 3), 10);
        q.setLineSpacing(0, 1.5f);
        q.setTextDirection(TextView.TEXT_DIRECTION_RTL);
        add(W.text(this, v[1], 13, W.GOLD, 1), 10);
    }
}
