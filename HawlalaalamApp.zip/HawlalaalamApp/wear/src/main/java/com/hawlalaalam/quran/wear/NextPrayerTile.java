package com.hawlalaalam.quran.wear;

import androidx.annotation.NonNull;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.wear.protolayout.ActionBuilders;
import androidx.wear.protolayout.ColorBuilders;
import androidx.wear.protolayout.DimensionBuilders;
import androidx.wear.protolayout.LayoutElementBuilders;
import androidx.wear.protolayout.ModifiersBuilders;
import androidx.wear.protolayout.ResourceBuilders;
import androidx.wear.protolayout.TimelineBuilders;
import androidx.wear.tiles.RequestBuilders;
import androidx.wear.tiles.TileBuilders;
import androidx.wear.tiles.TileService;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.List;

/**
 * بطاقة «الصلاة القادمة»: الاسم والوقت والمتبقي، وزرّا المسبحة والأذكار.
 * خط زمني بمدخل لكل صلاة قادمة، فتتبدّل البطاقة وحدها عند دخول كل وقت دون أن توقظ التطبيق.
 */
public class NextPrayerTile extends TileService {
    private static final String RES = "1";

    @NonNull
    @Override
    protected ListenableFuture<TileBuilders.Tile> onTileRequest(@NonNull RequestBuilders.TileRequest req) {
        long now = System.currentTimeMillis();
        List<long[]> up = Prayer.upcoming(this, now, 6);
        TimelineBuilders.Timeline.Builder tl = new TimelineBuilders.Timeline.Builder();
        long from = now;
        for (int k = 0; k < up.size(); k++) {
            long[] p = up.get(k);
            tl.addTimelineEntry(new TimelineBuilders.TimelineEntry.Builder()
                    .setValidity(new TimelineBuilders.TimeInterval.Builder().setStartMillis(k == 0 ? 0 : from).setEndMillis(p[1]).build())
                    .setLayout(new LayoutElementBuilders.Layout.Builder().setRoot(layout(p, k == 0 ? now : -1)).build())
                    .build());
            from = p[1];
        }
        TileBuilders.Tile tile = new TileBuilders.Tile.Builder()
                .setResourcesVersion(RES)
                .setFreshnessIntervalMillis(10 * 60_000L)   // لتحديث «بعد … ساعة»
                .setTileTimeline(tl.build())
                .build();
        return done(tile);
    }

    @NonNull
    @Override
    protected ListenableFuture<ResourceBuilders.Resources> onTileResourcesRequest(@NonNull RequestBuilders.ResourcesRequest req) {
        return done(new ResourceBuilders.Resources.Builder().setVersion(RES).build());
    }

    private static <T> ListenableFuture<T> done(T v) {
        return CallbackToFutureAdapter.getFuture(c -> { c.set(v); return "tile"; });
    }

    /** now<0: مدخل مستقبلي، فلا نكتب «المتبقي» لأنه سيكون قديمًا */
    private LayoutElementBuilders.LayoutElement layout(long[] p, long now) {
        LayoutElementBuilders.Column.Builder col = new LayoutElementBuilders.Column.Builder()
                .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER);
        col.addContent(text(W.t(this, "الصلاة القادمة", "Next prayer"), 13, W.MUTE, false));
        col.addContent(space(4));
        col.addContent(text(Prayer.name(this, (int) p[0], p[1]), 30, W.INK, true));
        col.addContent(space(2));
        col.addContent(text(W.clock(this, p[1]), 20, W.GOLD, true));
        if (now >= 0) {
            col.addContent(space(2));
            col.addContent(text(W.remaining(this, p[1] - now), 13, W.MUTE, false));
        }
        col.addContent(space(10));
        col.addContent(new LayoutElementBuilders.Row.Builder()
                .addContent(button(W.t(this, "المسبحة", "Tasbeeh"), TasbeehActivity.class.getName(), "tasbeeh"))
                .addContent(new LayoutElementBuilders.Spacer.Builder().setWidth(DimensionBuilders.dp(6)).build())
                .addContent(button(W.t(this, "الأذكار", "Adhkar"), AzkarActivity.class.getName(), "azkar"))
                .build());
        return new LayoutElementBuilders.Box.Builder()
                .setWidth(DimensionBuilders.expand())
                .setHeight(DimensionBuilders.expand())
                .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
                .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
                .setModifiers(new ModifiersBuilders.Modifiers.Builder()
                        .setClickable(click("open", MainActivity.class.getName())).build())
                .addContent(col.build())
                .build();
    }

    private LayoutElementBuilders.LayoutElement text(String s, float sp, int color, boolean bold) {
        return new LayoutElementBuilders.Text.Builder()
                .setText(s)
                .setMaxLines(1)
                .setFontStyle(new LayoutElementBuilders.FontStyle.Builder()
                        .setSize(DimensionBuilders.sp(sp))
                        .setColor(ColorBuilders.argb(color))
                        .setWeight(bold ? LayoutElementBuilders.FONT_WEIGHT_BOLD : LayoutElementBuilders.FONT_WEIGHT_NORMAL)
                        .build())
                .build();
    }

    private static LayoutElementBuilders.LayoutElement space(float dp) {
        return new LayoutElementBuilders.Spacer.Builder().setHeight(DimensionBuilders.dp(dp)).build();
    }

    private ModifiersBuilders.Clickable click(String id, String cls) {
        return new ModifiersBuilders.Clickable.Builder()
                .setId(id)
                .setOnClick(new ActionBuilders.LaunchAction.Builder()
                        .setAndroidActivity(new ActionBuilders.AndroidActivity.Builder()
                                .setPackageName(getPackageName())
                                .setClassName(cls)
                                .build())
                        .build())
                .build();
    }

    private LayoutElementBuilders.LayoutElement button(String label, String cls, String id) {
        return new LayoutElementBuilders.Box.Builder()
                .setWidth(DimensionBuilders.wrap())
                .setHeight(DimensionBuilders.dp(36))
                .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
                .setModifiers(new ModifiersBuilders.Modifiers.Builder()
                        .setClickable(click(id, cls))
                        .setBackground(new ModifiersBuilders.Background.Builder()
                                .setColor(ColorBuilders.argb(W.CHIP))
                                .setCorner(new ModifiersBuilders.Corner.Builder().setRadius(DimensionBuilders.dp(18)).build())
                                .build())
                        .setPadding(new ModifiersBuilders.Padding.Builder()
                                .setStart(DimensionBuilders.dp(12)).setEnd(DimensionBuilders.dp(12)).build())
                        .build())
                .addContent(text(label, 13, W.INK, true))
                .build();
    }
}
