package com.hawlalaalam.quran.wear;

import android.os.Bundle;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

/**
 * المسبحة: لمسة على الشاشة أو تدوير الإطار = تسبيحة. اهتزاز خفيف لكل تسبيحة، وأقوى عند كل ٣٣ وعند ١٠٠.
 * الضغط المطوّل يصفّر، ولمس اسم الذكر يغيّره. العدد يُحفظ لليوم.
 */
public class TasbeehActivity extends Screen {
    private static final String[][] PHRASES = {
            {"سبحان الله", "SubhanAllah"}, {"الحمد لله", "Alhamdulillah"}, {"الله أكبر", "Allahu Akbar"},
            {"لا إله إلا الله", "La ilaha illallah"}, {"أستغفر الله", "Astaghfirullah"},
            {"اللهم صلِّ على محمد", "Salawat"},
    };
    private Ring ring;
    private TextView phrase, count, sub;
    private int n, idx;
    private float rotary;

    private String day() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) + "-" + c.get(Calendar.DAY_OF_YEAR);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        idx = W.p(this).getInt("tb_idx", 0) % PHRASES.length;
        n = day().equals(W.p(this).getString("tb_day", "")) ? W.p(this).getInt("tb_n", 0) : 0;

        FrameLayout root = new FrameLayout(this);
        ring = new Ring(this, 0xFF2A2410, W.GOLD, 5);
        root.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        phrase = W.text(this, "", 15, W.MUTE, 1);
        phrase.setPadding(W.dp(this, 12), W.dp(this, 6), W.dp(this, 12), W.dp(this, 6));
        phrase.setOnClickListener(v -> {
            idx = (idx + 1) % PHRASES.length;
            n = 0;
            save();
            render();
        });
        count = W.text(this, "", 60, W.INK, 2);
        sub = W.text(this, "", 13, W.MUTE, 0);
        TextView hint = W.text(this, W.t(this, "المس الشاشة للتسبيح", "Tap to count"), 11, W.INK, 0);
        hint.setBackground(W.pill(W.CHIP, W.dp(this, 14)));
        hint.setPadding(W.dp(this, 10), W.dp(this, 4), W.dp(this, 10), W.dp(this, 4));
        col.addView(phrase);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = W.dp(this, 2);
        col.addView(count, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
        lp2.topMargin = W.dp(this, 6);
        col.addView(sub, lp2);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(-2, -2);
        lp3.topMargin = W.dp(this, 10);
        col.addView(hint, lp3);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        root.setOnClickListener(v -> add());
        root.setOnLongClickListener(v -> {
            n = 0;
            save();
            render();
            W.vibrate(this, new long[]{0, 60, 80, 60});
            return true;
        });
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        setContentView(root);
        root.requestFocus();
        render();
    }

    private void add() {
        n++;
        if (n % 100 == 0) W.vibrate(this, new long[]{0, 300, 120, 300});
        else if (n % 33 == 0) W.vibrate(this, new long[]{220});
        else W.tick(this);
        save();
        render();
    }

    private void render() {
        phrase.setText(W.ar(this) ? PHRASES[idx][0] : PHRASES[idx][1]);
        count.setText(W.d(this, n));
        int round = n / 33 + 1, inRound = n % 33;
        sub.setText(W.ar(this) ? "من " + W.d(this, 33) + " · الدورة " + W.d(this, round) : "of 33 · round " + round);
        ring.set(n > 0 && inRound == 0 ? 1f : inRound / 33f);
    }

    private void save() {
        W.p(this).edit().putInt("tb_n", n).putInt("tb_idx", idx).putString("tb_day", day()).apply();
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_SCROLL && ev.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)) {
            rotary += Math.abs(ev.getAxisValue(MotionEvent.AXIS_SCROLL));
            // درجة واحدة من الإطار = تسبيحة (الإطار المادي في سامسونج يعطي ١ لكل نقرة تقريبًا)
            while (rotary >= 1f) { rotary -= 1f; add(); }
            return true;
        }
        return super.onGenericMotionEvent(ev);
    }
}
