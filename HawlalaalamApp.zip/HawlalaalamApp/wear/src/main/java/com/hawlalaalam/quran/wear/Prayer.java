package com.hawlalaalam.quran.wear;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/**
 * مواقيت الصلاة على الساعة نفسها دون إنترنت — نفس حساب تطبيق الجوال (PrayerCalc) ونفس جدول الطرق،
 * والموقع وطريقة الحساب يصلان من الجوال (مكة افتراضيًا).
 */
final class Prayer {
    static final int FAJR = 0, SUNRISE = 1, DHUHR = 2, ASR = 3, MAGHRIB = 4, ISHA = 5;
    static final int[] ALERTS = {FAJR, DHUHR, ASR, MAGHRIB, ISHA};
    private static final String[] AR = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final String[] EN = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};

    /** {زاوية الفجر، زاوية العشاء، العشاء بعد المغرب بالدقائق، وفي رمضان} — بنفس ترتيب PrayerCalc.METHODS في الجوال */
    private static final double[][] M = {
            null,
            {18.5, 0, 90, 120}, {19.5, 17.5, 0, 0}, {18, 17, 0, 0}, {18, 18, 0, 0}, {15, 15, 0, 0},
            {18.2, 18.2, 0, 0}, {18, 17.5, 0, 0}, {18, 0, 90, 90}, {19.5, 0, 90, 90}, {19, 17, 0, 0},
            {18, 17, 0, 0}, {18, 18, 0, 0}, {18, 18, 0, 0}, {18, 17, 0, 0}, {20, 18, 0, 0}, {16, 15, 0, 0},
    };

    private Prayer() { }

    static String name(Context c, int i, long when) {
        if (i == DHUHR) {
            Calendar x = Calendar.getInstance();
            x.setTimeInMillis(when);
            if (x.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) return W.t(c, "الجمعة", "Jumuah");
        }
        return W.ar(c) ? AR[i] : EN[i];
    }

    private static SharedPreferences p(Context c) { return W.p(c); }

    static boolean hasLocation(Context c) { return p(c).contains("lat"); }

    static String city(Context c) { return p(c).getString("city", ""); }

    static String country(Context c) {
        String cc = p(c).getString("country", "");
        if (cc.length() == 2) return cc;
        try {
            String r = android.icu.util.TimeZone.getRegion(TimeZone.getDefault().getID());
            if (r != null && r.length() == 2) return r;
        } catch (Exception ignored) { }
        return "";
    }

    static int forCountry(String cc) {
        switch (cc == null ? "" : cc.toUpperCase(java.util.Locale.ROOT)) {
            case "SA": case "YE": return 1;
            case "AE": return 6;
            case "KW": return 7;
            case "QA": return 8;
            case "BH": case "OM": return 9;
            case "EG": case "SD": case "SS": case "LY": case "SY": case "LB": case "IQ": case "PS": return 2;
            case "JO": return 13;
            case "MA": return 10;
            case "DZ": return 11;
            case "TN": return 12;
            case "TR": return 14;
            case "PK": case "IN": case "BD": case "AF": return 4;
            case "US": case "CA": return 5;
            case "MY": case "SG": case "ID": case "BN": return 15;
            case "RU": return 16;
            default: return 3;
        }
    }

    static int method(Context c) {
        int m = p(c).getInt("method", 0);
        return m > 0 && m < M.length ? m : forCountry(country(c));
    }

    static boolean isRamadan(Calendar day) {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(day.getTimeInMillis());
            return ic.get(android.icu.util.Calendar.MONTH) == android.icu.util.IslamicCalendar.RAMADAN;
        } catch (Throwable t) {
            return false;
        }
    }

    /** مواقيت يوم كأوقات بالمللي ثانية: [الفجر، الشروق، الظهر، العصر، المغرب، العشاء] */
    static long[] times(Context c, Calendar day) {
        double lat = p(c).getFloat("lat", 21.4225f), lng = p(c).getFloat("lng", 39.8262f);
        Calendar noon = (Calendar) day.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        double tz = TimeZone.getDefault().getOffset(noon.getTimeInMillis()) / 3_600_000.0;
        double[] h = compute(noon.get(Calendar.YEAR), noon.get(Calendar.MONTH) + 1, noon.get(Calendar.DAY_OF_MONTH),
                lat, lng, tz, isRamadan(noon), M[method(c)]);
        long[] out = new long[h.length];
        long noonMs = noon.getTimeInMillis();
        for (int i = 0; i < h.length; i++) out[i] = noonMs + Math.round((h[i] - 12) * 60) * 60_000L;
        return out;
    }

    /** الصلوات القادمة من الآن: {الفهرس، الوقت} */
    static List<long[]> upcoming(Context c, long now, int count) {
        List<long[]> out = new ArrayList<>();
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(now);
        for (int d = 0; d < 4 && out.size() < count; d++) {
            long[] t = times(c, day);
            for (int k : ALERTS) if (t[k] > now && out.size() < count) out.add(new long[]{k, t[k]});
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        return out;
    }

    static long[] next(Context c) { return upcoming(c, System.currentTimeMillis(), 1).get(0); }

    /** وقت الصلاة السابقة (لحلقة التقدّم) */
    static long previous(Context c, long now) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(now);
        long best = 0;
        for (int d = 0; d < 2; d++) {
            long[] t = times(c, day);
            for (int k : ALERTS) if (t[k] <= now && t[k] > best) best = t[k];
            if (best > 0) return best;
            day.add(Calendar.DAY_OF_MONTH, -1);
        }
        return now - 6 * 3_600_000L;
    }

    // ------------------------------------------------ الحساب الفلكي (PrayTimes)

    private static double[] compute(int year, int month, int day, double lat, double lng, double tz, boolean ramadan, double[] m) {
        double jd = julian(year, month, day) - lng / (15.0 * 24.0);
        double fajr = sunAngleTime(jd, lat, m[0], 5 / 24.0, true);
        double sunrise = sunAngleTime(jd, lat, 0.833, 6 / 24.0, true);
        double dhuhr = midDay(jd, 12 / 24.0);
        double asr = asrTime(jd, lat, 1, 13 / 24.0);
        double sunset = sunAngleTime(jd, lat, 0.833, 18 / 24.0, false);
        double isha = m[2] > 0 ? sunset + (ramadan ? m[3] : m[2]) / 60.0 : sunAngleTime(jd, lat, m[1], 18 / 24.0, false);
        double night = 24 - (sunset - sunrise);
        double fajrLimit = m[0] / 60.0 * night;
        if (Double.isNaN(fajr) || sunrise - fajr > fajrLimit) fajr = sunrise - fajrLimit;
        if (m[2] == 0) {
            double ishaLimit = m[1] / 60.0 * night;
            if (Double.isNaN(isha) || isha - sunset > ishaLimit) isha = sunset + ishaLimit;
        }
        double adj = tz - lng / 15.0;
        return new double[]{fajr + adj, sunrise + adj, dhuhr + adj, asr + adj, sunset + adj, isha + adj};
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    private static double[] sunPosition(double jd) {
        double dd = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * dd);
        double q = fixAngle(280.459 + 0.98564736 * dd);
        double l = fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
        double e = 23.439 - 0.00000036 * dd;
        double ra = atan2(cos(e) * sin(l), cos(l)) / 15.0;
        double eqt = q / 15.0 - fixHour(ra);
        double decl = asin(sin(e) * sin(l));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jd, double t) { return fixHour(12 - sunPosition(jd + t)[1]); }

    private static double sunAngleTime(double jd, double lat, double angle, double t, boolean ccw) {
        double decl = sunPosition(jd + t)[0];
        double noon = midDay(jd, t);
        double x = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
        x = Math.max(-1, Math.min(1, x));
        double tt = acos(x) / 15.0;
        return noon + (ccw ? -tt : tt);
    }

    private static double asrTime(double jd, double lat, double factor, double t) {
        double decl = sunPosition(jd + t)[0];
        double angle = -acot(factor + tan(Math.abs(lat - decl)));
        return sunAngleTime(jd, lat, angle, t, false);
    }

    private static double sin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double cos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double tan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double asin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double acos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double atan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double acot(double x) { return Math.toDegrees(Math.atan(1 / x)); }
    private static double fixAngle(double a) { a = a - 360 * Math.floor(a / 360.0); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24 * Math.floor(a / 24.0); return a < 0 ? a + 24 : a; }
}
