package com.hawlalaalam.quran.wear;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

/**
 * يستقبل من تطبيق الجوال (المسار /hawl): الموقع والمدينة والدولة وطريقة الحساب واللغة وسلسلة الأيام وآية اليوم.
 * لا يُرسل شيء من الساعة.
 */
public class Sync extends WearableListenerService {
    static final String PATH = "/hawl";

    @Override
    public void onDataChanged(DataEventBuffer events) {
        for (DataEvent e : events) {
            if (e.getType() == DataEvent.TYPE_CHANGED && PATH.equals(e.getDataItem().getUri().getPath()))
                apply(this, DataMapItem.fromDataItem(e.getDataItem()).getDataMap());
        }
    }

    /** آخر بيانات من الجوال (عند فتح التطبيق، إن فاتنا حدث التغيير) */
    static void pull(Context c) {
        Context app = c.getApplicationContext();
        try {
            Wearable.getDataClient(app).getDataItems(Uri.parse("wear://*" + PATH)).addOnSuccessListener(buf -> {
                try {
                    for (DataItem i : buf) apply(app, DataMapItem.fromDataItem(i).getDataMap());
                } finally {
                    buf.release();
                }
            });
        } catch (Throwable ignored) { }
    }

    static void apply(Context c, DataMap m) {
        SharedPreferences.Editor e = W.p(c).edit();
        if (m.containsKey("lat") && m.containsKey("lng")) {
            e.putFloat("lat", (float) m.getDouble("lat")).putFloat("lng", (float) m.getDouble("lng")).putBoolean("loc_watch", false);
            e.putString("city", m.getString("city", ""));
        }
        if (m.containsKey("country")) e.putString("country", m.getString("country", ""));
        if (m.containsKey("method")) e.putInt("method", m.getInt("method"));
        if (m.containsKey("lang") && !W.p(c).getBoolean("lang_fixed", false)) e.putString("lang", m.getString("lang", ""));
        if (m.containsKey("streak")) e.putInt("streak", m.getInt("streak"));
        if (m.containsKey("verse_text")) {
            e.putString("verse_text", m.getString("verse_text", "")).putString("verse_date", m.getString("verse_date", ""))
                    .putInt("verse_s", m.getInt("verse_s")).putInt("verse_a", m.getInt("verse_a"));
        }
        e.putLong("sync_at", System.currentTimeMillis()).apply();
        Alarms.schedule(c);
        W.refreshSurfaces(c);
    }
}
