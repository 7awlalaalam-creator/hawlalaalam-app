package com.hawlalaalam.quran.wear;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;


/** الشاشة الرئيسية: الصلاة القادمة مع حلقة العدّ التنازلي، وتحتها قائمة الأقسام */
public class MainActivity extends Screen {
    private final Handler h = new Handler(Looper.getMainLooper());
    private Ring ring;
    private TextView clock, name, left, at;
    private final Runnable tick = new Runnable() {
        @Override public void run() { update(); h.postDelayed(this, 20_000); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Sync.pull(this);
        Alarms.schedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        build();
    }

    private String sig() { return Prayer.hasLocation(this) + "|" + W.ar(this) + "|" + W.p(this).getInt("streak", 0); }

    private String built = "";

    private void build() {
        built = sig();
        scrollList(false);
        int side = list.getPaddingLeft();

        FrameLayout head = new FrameLayout(this);
        ring = new Ring(this, W.TRACK, W.TEAL, 4);
        head.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        clock = W.text(this, "", 13, W.MUTE, 0);
        TextView label = W.text(this, W.t(this, "الصلاة القادمة", "Next prayer"), 13, W.MUTE, 0);
        name = W.text(this, "", 38, W.INK, 2);
        left = W.text(this, "", 17, W.GOLD, 2);
        at = W.text(this, "", 13, W.MUTE, 0);
        col.addView(label);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = W.dp(this, 6);
        col.addView(name, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -2);
        lp2.topMargin = W.dp(this, 6);
        col.addView(left, lp2);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(-2, -2);
        lp3.topMargin = W.dp(this, 6);
        col.addView(at, lp3);
        head.addView(col, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        cl.topMargin = Math.round(screenH * 0.09f);
        head.addView(clock, cl);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(screenW, screenH);
        hl.leftMargin = -side;
        hl.rightMargin = -side;
        list.addView(head, hl);
        head.setOnClickListener(v -> startActivity(new Intent(this, TimesActivity.class)));

        if (!Prayer.hasLocation(this)) {
            TextView n = add(W.text(this, W.t(this, "افتح التطبيق في جوالك لمزامنة موقعك، أو استخدم موقع الساعة من الإعدادات",
                    "Open the app on your phone to sync your location, or use the watch location in Settings"), 13, W.GOLD, 0), 4);
            n.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        }
        chip(W.t(this, "🕌  مواقيت الصلاة", "🕌  Prayer times"), W.CHIP, v -> startActivity(new Intent(this, TimesActivity.class)));
        chip(W.t(this, "📿  المسبحة", "📿  Tasbeeh"), W.CHIP, v -> startActivity(new Intent(this, TasbeehActivity.class)));
        chip(W.t(this, "☀️  الأذكار", "☀️  Adhkar"), W.CHIP, v -> startActivity(new Intent(this, AzkarActivity.class)));
        chip(W.t(this, "📖  آية اليوم", "📖  Verse of the day"), W.CHIP, v -> startActivity(new Intent(this, VerseActivity.class)));
        chip(W.t(this, "⚙️  الإعدادات", "⚙️  Settings"), 0xFF1A1F1F, v -> startActivity(new Intent(this, SettingsActivity.class)));
        int streak = W.p(this).getInt("streak", 0);
        if (streak > 0) add(W.text(this, W.ar(this) ? "🔥 " + W.d(this, streak) + (streak == 1 ? " يوم" : streak == 2 ? " يومان" : streak <= 10 ? " أيام" : " يومًا") + " مع القرآن"
                : "🔥 " + streak + (streak == 1 ? " day" : " days") + " with the Quran", 13, W.TEAL, 1), 12);
    }

    private void update() {
        long now = System.currentTimeMillis();
        long[] n = Prayer.next(this);
        long prev = Prayer.previous(this, now);
        ring.set((float) (now - prev) / Math.max(1, n[1] - prev));
        clock.setText(W.clockShort(this, now));
        name.setText(Prayer.name(this, (int) n[0], n[1]));
        left.setText(W.remaining(this, n[1] - now));
        String city = Prayer.city(this);
        at.setText(W.clock(this, n[1]) + (city.isEmpty() ? "" : " · " + city));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // وصل الموقع أو اللغة أو السلسلة من الجوال أثناء الغياب: نعيد بناء الشاشة
        if (!built.equals(sig())) build();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }
}
