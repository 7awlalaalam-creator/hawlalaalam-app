package com.hawlalaalam.quran.wear;

import android.os.RemoteException;

import androidx.wear.watchface.complications.data.ComplicationData;
import androidx.wear.watchface.complications.data.ComplicationText;
import androidx.wear.watchface.complications.data.ComplicationType;
import androidx.wear.watchface.complications.data.LongTextComplicationData;
import androidx.wear.watchface.complications.data.ShortTextComplicationData;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceService;
import androidx.wear.watchface.complications.datasource.ComplicationRequest;

/** على وجه الساعة: أيامك المتتالية مع القرآن (تصل من الجوال) */
public class StreakComplication extends ComplicationDataSourceService {

    private ComplicationData data(ComplicationType type, int n) {
        ComplicationText desc = NextPrayerComplication.plain(W.t(this, "أيامك مع القرآن", "Days with the Quran"));
        if (type == ComplicationType.LONG_TEXT) {
            String s = W.ar(this) ? "🔥 " + W.d(this, n) + (n == 1 ? " يوم" : n == 2 ? " يومان" : n >= 3 && n <= 10 ? " أيام" : " يومًا") + " مع القرآن"
                    : "🔥 " + n + (n == 1 ? " day" : " days") + " with the Quran";
            return new LongTextComplicationData.Builder(NextPrayerComplication.plain(s), desc).setTapAction(NextPrayerComplication.open(this)).build();
        }
        return new ShortTextComplicationData.Builder(NextPrayerComplication.plain("🔥" + W.d(this, n)), desc)
                .setTitle(NextPrayerComplication.plain(W.t(this, "أيام", "days")))
                .setTapAction(NextPrayerComplication.open(this))
                .build();
    }

    @Override
    public void onComplicationRequest(ComplicationRequest req, ComplicationRequestListener listener) {
        try {
            listener.onComplicationData(data(req.getComplicationType(), W.p(this).getInt("streak", 0)));
        } catch (RemoteException ignored) { }
    }

    @Override
    public ComplicationData getPreviewData(ComplicationType type) {
        if (type != ComplicationType.SHORT_TEXT && type != ComplicationType.LONG_TEXT) return null;
        return data(type, 7);
    }
}
