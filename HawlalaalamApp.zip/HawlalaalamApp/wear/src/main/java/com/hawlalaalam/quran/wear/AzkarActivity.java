package com.hawlalaalam.quran.wear;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;

/** الأذكار دون إنترنت: قائمة الأقسام، ثم ذكر بعد ذكر مع عدّاد (المس الزر للعدّ، ويهتز وينتقل عند الاكتمال) */
public class AzkarActivity extends Screen {
    static final String EXTRA = "section";
    private static final String[][] TITLES = {
            {"morning", "أذكار الصباح", "Morning adhkar"}, {"evening", "أذكار المساء", "Evening adhkar"},
            {"sleep", "أذكار النوم", "Before sleep"}, {"prayer", "بعد الصلاة", "After prayer"},
    };
    private JSONArray items;
    private String title;
    private int i, done;

    static Intent intent(Context c, String section) { return new Intent(c, AzkarActivity.class).putExtra(EXTRA, section); }

    static JSONArray load(Context c) {
        try (InputStream in = c.getAssets().open("azkar.json"); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new JSONArray(o.toString("UTF-8"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String sec = getIntent().getStringExtra(EXTRA);
        if (sec == null) { menu(); return; }
        JSONArray all = load(this);
        for (int k = 0; k < all.length(); k++) {
            JSONObject s = all.optJSONObject(k);
            if (s != null && sec.equals(s.optString("id"))) { items = s.optJSONArray("items"); title = titleOf(sec); }
        }
        if (items == null || items.length() == 0) { finish(); return; }
        if (b != null) { i = b.getInt("i"); done = b.getInt("done"); }
        show();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("i", i);
        out.putInt("done", done);
    }

    private String titleOf(String id) {
        for (String[] t : TITLES) if (t[0].equals(id)) return W.ar(this) ? t[1] : t[2];
        return "";
    }

    /** القسم المناسب للوقت أولًا: الصباح حتى العصر، ثم المساء، وبعد العشاء النوم */
    private void menu() {
        scrollList(true);
        add(W.text(this, W.t(this, "الأذكار", "Adhkar"), 15, W.MUTE, 0), 0);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String now = h >= 3 && h < 15 ? "morning" : h >= 15 && h < 21 ? "evening" : "sleep";
        for (String[] t : TITLES) {
            boolean on = t[0].equals(now);
            TextView c = chip((on ? "● " : "") + (W.ar(this) ? t[1] : t[2]), on ? W.CHIP : 0xFF1A1F1F,
                    v -> startActivity(intent(this, t[0])));
            if (on) c.setTextColor(0xFFFFFFFF);
        }
    }

    private void show() {
        JSONObject it = items.optJSONObject(i);
        int need = Math.max(1, it.optInt("n", 1));
        scrollList(true);
        add(W.text(this, title + " · " + W.d(this, i + 1) + "/" + W.d(this, items.length()), 12, W.MUTE, 0), 0);
        String note = it.optString("note", "");
        if (!note.isEmpty()) add(W.text(this, note, 12, W.GOLD, 1), 6);
        boolean q = it.optBoolean("q");
        TextView body = add(W.text(this, it.optString("t"), q ? 19 : 15, 0xFFFFFFFF, q ? 3 : 1), 8);
        body.setLineSpacing(0, q ? 1.45f : 1.35f);
        body.setTextDirection(TextView.TEXT_DIRECTION_RTL);
        String label = W.d(this, done) + " / " + W.d(this, need) + (i + 1 < items.length() ? W.t(this, "  ·  التالي ‹", "  ·  next ›") : "");
        TextView counter = chip(label, W.CHIP, v -> count(need));
        counter.setTextSize(17);
        TextView skip = W.text(this, W.t(this, "تخطَّ", "Skip"), 12, W.MUTE, 0);
        skip.setPadding(0, W.dp(this, 10), 0, W.dp(this, 4));
        skip.setOnClickListener(v -> next());
        list.addView(skip);
        scroll.requestFocus();
    }

    private void count(int need) {
        done++;
        if (done >= need) {
            W.vibrate(this, new long[]{120});
            next();
        } else {
            W.tick(this);
            show();
            scroll.post(() -> scroll.fullScroll(android.view.View.FOCUS_DOWN));
        }
    }

    private void next() {
        done = 0;
        if (i + 1 >= items.length()) { finishScreen(); return; }
        i++;
        show();
    }

    private void finishScreen() {
        W.vibrate(this, new long[]{0, 150, 100, 150});
        scrollList(true);
        add(W.text(this, "✓", 40, W.TEAL, 2), 10);
        add(W.text(this, W.t(this, "أتممت " + title + "\nتقبّل الله منك", "You completed " + title + "\nMay Allah accept it"), 16, W.INK, 1), 10);
        chip(W.t(this, "رجوع", "Back"), W.CHIP, v -> finish());
    }
}
