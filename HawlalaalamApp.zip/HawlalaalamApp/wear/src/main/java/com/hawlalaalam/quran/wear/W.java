package com.hawlalaalam.quran.wear;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import androidx.wear.tiles.TileService;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester;

import java.util.Calendar;
import java.util.Locale;

/** أدوات مشتركة لتطبيق الساعة: التخزين واللغة والأرقام والخطوط والألوان */
final class W {
    static final int GOLD = 0xFFD8B45A, TEAL = 0xFF2BB3A3, INK = 0xFFE9EFE9, MUTE = 0xFF8FA39F,
            CHIP = 0xFF123F3A, TRACK = 0xFF14302D, RED = 0xFF3A1D1D;

    private W() { }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("w", Context.MODE_PRIVATE); }

    /** العربية ما لم يختر المستخدم الإنجليزية في الجوال أو الساعة، أو كانت لغة الساعة غير عربية دون مزامنة */
    static boolean ar(Context c) {
        String l = p(c).getString("lang", "");
        return l.isEmpty() ? "ar".equals(Locale.getDefault().getLanguage()) : !"en".equals(l);
    }

    static String t(Context c, String ar, String en) { return ar(c) ? ar : en; }

    /** أرقام عربية في العربية */
    static String d(Context c, String s) {
        if (!ar(c)) return s;
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static String d(Context c, long n) { return d(c, String.valueOf(n)); }

    /** «٣:٢٣ م» أو «3:23 PM» */
    static String clock(Context c, long ms) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(ms);
        int h = x.get(Calendar.HOUR_OF_DAY), m = x.get(Calendar.MINUTE);
        int h12 = h % 12 == 0 ? 12 : h % 12;
        String s = h12 + ":" + (m < 10 ? "0" : "") + m;
        return ar(c) ? d(c, s) + (h < 12 ? " ص" : " م") : s + (h < 12 ? " AM" : " PM");
    }

    /** «٣:٢٣» دون ص/م (للمساحات الضيقة) */
    static String clockShort(Context c, long ms) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(ms);
        int h = x.get(Calendar.HOUR_OF_DAY) % 12, m = x.get(Calendar.MINUTE);
        return d(c, (h == 0 ? 12 : h) + ":" + (m < 10 ? "0" : "") + m);
    }

    /** «بعد ٣:١٢ ساعة» أو «بعد ٤٥ دقيقة» */
    static String remaining(Context c, long ms) {
        long m = (ms + 59_999L) / 60_000L;
        if (m <= 0) return t(c, "الآن", "now");
        long h = m / 60, mm = m % 60;
        if (!ar(c)) return m < 60 ? "in " + m + " min" : "in " + h + ":" + (mm < 10 ? "0" : "") + mm + " h";
        if (m < 60) return "بعد " + (m == 1 ? "دقيقة" : m == 2 ? "دقيقتين" : d(c, m) + (m <= 10 ? " دقائق" : " دقيقة"));
        if (mm == 0) return "بعد " + (h == 1 ? "ساعة" : h == 2 ? "ساعتين" : d(c, h) + (h <= 10 ? " ساعات" : " ساعة"));
        return "بعد " + d(c, h + ":" + (mm < 10 ? "0" : "") + mm) + " ساعة";
    }

    private static Typeface[] fonts;

    /** 0 عادي، 1 متوسط، 2 عريض، 3 خط المصحف */
    static Typeface font(Context c, int w) {
        if (fonts == null) {
            fonts = new Typeface[4];
            int[] ids = {R.font.tajawal_regular, R.font.tajawal_medium, R.font.tajawal_bold, R.font.hafs};
            for (int i = 0; i < 4; i++) {
                try { fonts[i] = c.getResources().getFont(ids[i]); } catch (Exception e) { fonts[i] = Typeface.DEFAULT; }
            }
        }
        return fonts[w];
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static TextView text(Context c, String s, float sp, int color, int weight) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(font(c, weight));
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        return t;
    }

    static GradientDrawable pill(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    static void vibrate(Context c, long[] pattern) {
        try {
            Vibrator v = c.getSystemService(Vibrator.class);
            if (v == null || !v.hasVibrator()) return;
            if (pattern.length == 1) v.vibrate(VibrationEffect.createOneShot(pattern[0], VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } catch (Exception ignored) { }
    }

    static void tick(Context c) {
        try {
            Vibrator v = c.getSystemService(Vibrator.class);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 29) v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK));
            else v.vibrate(VibrationEffect.createOneShot(15, 80));
        } catch (Exception ignored) { }
    }

    /** تحديث البطاقة والتعقيدات بعد تغيّر الموقع أو اللغة أو السلسلة */
    static void refreshSurfaces(Context c) {
        try { TileService.getUpdater(c).requestUpdate(NextPrayerTile.class); } catch (Throwable ignored) { }
        try {
            ComplicationDataSourceUpdateRequester.create(c, new ComponentName(c, NextPrayerComplication.class)).requestUpdateAll();
            ComplicationDataSourceUpdateRequester.create(c, new ComponentName(c, StreakComplication.class)).requestUpdateAll();
        } catch (Throwable ignored) { }
    }
}
