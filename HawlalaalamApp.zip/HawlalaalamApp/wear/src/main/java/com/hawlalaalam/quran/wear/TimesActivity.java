package com.hawlalaalam.quran.wear;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

/** مواقيت اليوم، والصلاة القادمة مظللة */
public class TimesActivity extends Screen {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        scrollList(true);
        add(W.text(this, W.t(this, "مواقيت اليوم", "Today's prayers"), 14, W.MUTE, 0), 0);
        long now = System.currentTimeMillis();
        long[] t = Prayer.times(this, Calendar.getInstance());
        long[] next = Prayer.next(this);
        for (int i = 0; i <= Prayer.ISHA; i++) {
            boolean on = t[i] == next[1];
            boolean sunrise = i == Prayer.SUNRISE;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(W.dp(this, 14), W.dp(this, 7), W.dp(this, 14), W.dp(this, 7));
            if (on) row.setBackground(W.pill(W.CHIP, W.dp(this, 20)));
            TextView n = W.text(this, Prayer.name(this, i, t[i]), sunrise ? 13 : 16, on ? 0xFFFFFFFF : sunrise ? W.MUTE : W.INK, on ? 2 : 1);
            n.setGravity(Gravity.START);
            TextView v = W.text(this, W.clock(this, t[i]), sunrise ? 13 : 16, on ? W.GOLD : W.MUTE, on ? 2 : 0);
            v.setGravity(Gravity.END);
            row.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(v, new LinearLayout.LayoutParams(-2, -2));
            if (t[i] < now && !on) { n.setAlpha(.6f); v.setAlpha(.6f); }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = W.dp(this, 3);
            list.addView(row, lp);
        }
        String city = Prayer.city(this);
        add(W.text(this, city.isEmpty() ? W.t(this, "حسب موقع مكة المكرمة (لم يُحدَّد موقعك)", "Using Makkah (location not set)") : city,
                12, W.MUTE, 0), 12);
    }
}
