package com.hawlalaalam.quran.wear;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** أساس الشاشات: خلفية سوداء، قائمة عمودية في الوسط مع هوامش الشاشة الدائرية، والتمرير بالإطار الدوّار */
abstract class Screen extends Activity {
    protected ScrollView scroll;
    protected LinearLayout list;
    protected int screenW, screenH;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        getWindow().getDecorView().setBackgroundColor(0xFF000000);
    }

    /** قائمة قابلة للتمرير؛ top=true يضيف هامشًا علويًا يناسب الدائرة */
    protected LinearLayout scrollList(boolean top) {
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setFillViewport(true);
        scroll.setLayoutDirection(W.ar(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setGravity(Gravity.CENTER_HORIZONTAL);
        int side = round() ? Math.round(screenW * 0.12f) : W.dp(this, 10);
        list.setPadding(side, top ? Math.round(screenH * 0.14f) : 0, side, Math.round(screenH * 0.22f));
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
        return list;
    }

    protected boolean round() { return getResources().getConfiguration().isScreenRound(); }

    @Override
    protected void onResume() {
        super.onResume();
        if (scroll != null) scroll.requestFocus();   // حتى يمرّر الإطار الدوّار القائمة
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        if (scroll != null && ev.getAction() == MotionEvent.ACTION_SCROLL && ev.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)) {
            float delta = -ev.getAxisValue(MotionEvent.AXIS_SCROLL) * W.dp(this, 48);
            scroll.smoothScrollBy(0, Math.round(delta));
            return true;
        }
        return super.onGenericMotionEvent(ev);
    }

    protected TextView add(TextView t, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = W.dp(this, topDp);
        list.addView(t, lp);
        return t;
    }

    /** زر كبسولة بعرض القائمة */
    protected TextView chip(String label, int bg, View.OnClickListener l) {
        TextView t = W.text(this, label, 15, W.INK, 1);
        t.setBackground(W.pill(bg, W.dp(this, 26)));
        t.setPadding(W.dp(this, 12), W.dp(this, 12), W.dp(this, 12), W.dp(this, 12));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = W.dp(this, 6);
        list.addView(t, lp);
        return t;
    }

    /** حلقة تقدّم دائرية حول حافة الشاشة */
    static final class Ring extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float progress;

        Ring(android.content.Context c, int trackColor, int arcColor, float strokeDp) {
            super(c);
            for (Paint p : new Paint[]{track, arc}) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(W.dp(c, strokeDp));
                p.setStrokeCap(Paint.Cap.ROUND);
            }
            track.setColor(trackColor);
            arc.setColor(arcColor);
        }

        void set(float p) { progress = Math.max(0, Math.min(1, p)); invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float s = arc.getStrokeWidth() / 2 + W.dp(getContext(), 3);
            r.set(s, s, getWidth() - s, getHeight() - s);
            c.drawOval(r, track);
            if (progress > 0) c.drawArc(r, -90, 360 * progress, false, arc);
        }
    }

    /** يملأ الشاشة كلها (للصفحة الأولى في القائمة) */
    protected ViewGroup.LayoutParams fullScreen() { return new LinearLayout.LayoutParams(-1, screenH); }
}
