package com.hawlalaalam.quran.wear;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;

import androidx.wear.watchface.complications.data.ComplicationData;
import androidx.wear.watchface.complications.data.ComplicationText;
import androidx.wear.watchface.complications.data.ComplicationType;
import androidx.wear.watchface.complications.data.LongTextComplicationData;
import androidx.wear.watchface.complications.data.PlainComplicationText;
import androidx.wear.watchface.complications.data.ShortTextComplicationData;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceService;
import androidx.wear.watchface.complications.datasource.ComplicationDataTimeline;
import androidx.wear.watchface.complications.datasource.ComplicationRequest;
import androidx.wear.watchface.complications.datasource.TimeInterval;
import androidx.wear.watchface.complications.datasource.TimelineEntry;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** على وجه الساعة: الصلاة القادمة ووقتها. خط زمني يبدّلها وحده عند دخول كل وقت. */
public class NextPrayerComplication extends ComplicationDataSourceService {

    static ComplicationText plain(String s) { return new PlainComplicationText.Builder(s).build(); }

    static PendingIntent open(Context c) {
        return PendingIntent.getActivity(c, 10, new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private ComplicationData data(ComplicationType type, long[] p) {
        String name = Prayer.name(this, (int) p[0], p[1]);
        ComplicationText desc = plain(W.t(this, "الصلاة القادمة ", "Next prayer ") + name);
        if (type == ComplicationType.LONG_TEXT)
            return new LongTextComplicationData.Builder(plain(name + "  " + W.clock(this, p[1])), desc)
                    .setTitle(plain(W.t(this, "الصلاة القادمة", "Next prayer")))
                    .setTapAction(open(this))
                    .build();
        return new ShortTextComplicationData.Builder(plain(W.clockShort(this, p[1])), desc)
                .setTitle(plain(name))
                .setTapAction(open(this))
                .build();
    }

    @Override
    public void onComplicationRequest(ComplicationRequest req, ComplicationRequestListener listener) {
        ComplicationType type = req.getComplicationType();
        long now = System.currentTimeMillis();
        List<long[]> up = Prayer.upcoming(this, now, 6);
        try {
            if (up.isEmpty()) { listener.onComplicationData(null); return; }
            List<TimelineEntry> entries = new ArrayList<>();
            for (int k = 1; k < up.size(); k++) {
                entries.add(new TimelineEntry(new TimeInterval(Instant.ofEpochMilli(up.get(k - 1)[1]), Instant.ofEpochMilli(up.get(k)[1])),
                        data(type, up.get(k))));
            }
            listener.onComplicationDataTimeline(new ComplicationDataTimeline(data(type, up.get(0)), entries));
        } catch (RemoteException ignored) { }
    }

    @Override
    public ComplicationData getPreviewData(ComplicationType type) {
        long[] p = {Prayer.ASR, System.currentTimeMillis() + 3 * 3_600_000L};
        if (type != ComplicationType.SHORT_TEXT && type != ComplicationType.LONG_TEXT) return null;
        return data(type, p);
    }
}
