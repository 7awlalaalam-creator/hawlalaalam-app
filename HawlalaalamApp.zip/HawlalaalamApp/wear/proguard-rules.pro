# مكتبات Guava/ListenableFuture تشير لتعليقات غير موجودة وقت التشغيل
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
