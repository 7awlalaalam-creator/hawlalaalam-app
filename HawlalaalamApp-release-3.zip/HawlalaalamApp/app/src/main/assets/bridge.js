/* جسر التطبيق: يضيف ميزة المشاركة (navigator.share) وحفظ الصور المولَّدة داخل WebView */
(function () {
  if (window.__hawlBridge) return;
  window.__hawlBridge = true;

  // 0) Google Analytics: تمييز زوار التطبيق (قبل تحميل gtag في الصفحة)
  try {
    window.dataLayer = window.dataLayer || [];
    var gt = function () { window.dataLayer.push(arguments); };
    gt('set', 'user_properties', { client_type: 'android_app' });
    gt('set', { client_type: 'android_app' });
    if (window.__hawlInternal) gt('set', { traffic_type: 'internal' });   // جوال صاحب الموقع
  } catch (e) {}

  // ---------------------------------------------------------------- داخل التطبيق
  // العلامة HawlalaalamApp في userAgent: نُعلم الموقع بالمظهر ونخفي شريطه السفلي
  // لأن التطبيق يعرض شريطه الثابت أسفل الشاشة.
  var IN_APP = /HawlalaalamApp\//.test(navigator.userAgent);
  if (IN_APP) {
    var root = document.documentElement;
    var theme = window.__hawlTheme === 'dark' ? 'dark' : 'light';
    try {
      root.classList.add('hawl-app', 'hawl-' + theme);
      root.setAttribute('data-app', 'android');
      root.setAttribute('data-app-theme', theme);
      // الأسماء الشائعة لمفتاح الثيم، ليلتقطها قالب الموقع أيًّا كان اسمه
      root.setAttribute('data-theme', theme);
      root.setAttribute('data-mode', theme);
      root.setAttribute('data-bs-theme', theme);
      if (theme === 'dark') root.classList.add('dark', 'dark-mode'); else root.classList.remove('dark', 'dark-mode');
      try { localStorage.setItem('theme', theme); } catch (e) {}
      // مفتاح الوضع الليلي الحقيقي في قالب الموقع: html[data-hw-mode] + التخزين hw-mode
      // (بدونه كان WebView يعتّم الصفحة الفاتحة آليًا فتظهر رمادية بنص أزرق)
      root.setAttribute('data-hw-mode', theme);
      try { localStorage.setItem('hw-mode', theme); localStorage.setItem('awl_mode_manual', theme); } catch (e) {}
      window.dispatchEvent(new CustomEvent('hawl-theme', { detail: theme }));
    } catch (e) {}

    // ------------------------------------------------ توحيد ألوان الموقع مع ألوان التطبيق
    // القيم نفسها في res/values و res/values-night للتطبيق
    // محددات بأولوية أعلى من قواعد القالب (html[data-hw-mode] body.hawl-themed …) دون إفراط في !important
    var D = 'html.hawl-app[data-app][data-hw-mode="dark"] body', L = 'html.hawl-app[data-app][data-hw-mode="light"] body',
        A = 'html.hawl-app[data-app][data-hw-mode] body';
    var unify = document.createElement('style');
    unify.id = 'hawl-unify';
    unify.textContent =
      // يمنع التعتيم الآلي في WebView لأن الصفحة صار لها وضع داكن حقيقي
      'html.hawl-app[data-hw-mode="dark"]{color-scheme:dark;background:#0B1A1E!important}' +
      'html.hawl-app[data-hw-mode="light"]{color-scheme:light;background:#F6F8F9!important}' +
      // رموز الصفحات الحديثة في القالب
      D + '{--bg:#0B1A1E;--surface:#12262B;--surface-2:#1A3439;--text:#E9EEF0;--text-muted:#8FA6AC;' +
          '--accent:#C9A876;--accent-soft:#E8D5A8;--border-soft:rgba(201,168,118,.22);background:#0B1A1E!important;color:#E9EEF0}' +
      L + '{--bg:#F6F8F9;--surface:#FFFFFF;--surface-2:#F5F1E6;--text:#16353D;--text-muted:#5D747C;' +
          '--accent:#9A7332;--accent-soft:#C9A876;--border-soft:rgba(154,115,50,.22);background:#F6F8F9!important;color:#16353D}' +
      // الهيدر بلون الصفحة مثل شاشات التطبيق
      D + ' .hw-header.hw-header{background:#0B1A1E!important;border-bottom:1px solid #1F3A41!important}' +
      L + ' .hw-header.hw-header{background:#FFFFFF!important;border-bottom:1px solid #EEF0F2!important}' +
      // البطاقات: نفس لون بطاقات التطبيق وزواياه
      D + ' :is(.card-custom,.listensora,.changesoraform,footer):not(#x){background:#12262B!important;border-color:#1F3A41!important;color:#E9EEF0!important}' +
      L + ' :is(.card-custom,.listensora,.changesoraform):not(#x){background:#FFFFFF!important;border-color:#E6E9EC!important}' +
      A + ' :is(.card-custom,.listensora,.changesoraform):not(#x){border-radius:22px!important;overflow:hidden}' +
      // الحاويات الوسيطة في القالب القديم (well, card-body) شفافة حتى لا تظهر طبقة بلون مختلف
      A + ' :is(.container.well,.card-custom > .card-body):not(#x){background:transparent!important;border-color:transparent!important;box-shadow:none!important}' +
      // شريط عنوان السورة
      D + ' .card-custom .card-header:not(#x){background:#123640!important;color:#FFFFFF!important;border-color:#1F3A41!important}' +
      // بطاقة النص القرآني: عاجي دافئ لا أزرق
      D + ' .surah-text:not(#x){background:#162E33!important;border-color:#2A4A50!important;color:#EFE4CF!important}' +
      D + ' .surah-text a:not(#x){color:#EFE4CF!important}' +
      L + ' .surah-text:not(#x){background:#FFFDF8!important;border-color:#EFE4CF!important;color:#16353D!important}' +
      // الحقول والقوائم المنسدلة
      D + ' :is(select,textarea,input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=submit]):not([type=button])):not(.btn):not(#x)' +
          '{background:#1A3439!important;border-color:#2A4A50!important;color:#E9EEF0!important}' +
      A + ' :is(select,input).form-control:not(.btn):not(#x){border-radius:14px!important;min-height:46px}' +
      // الأزرار الرئيسية: كبسولة ذهبية مثل أزرار التطبيق
      A + ' .btn.btn-primary:not(#x){background:#C9A876!important;border-color:#C9A876!important;color:#0E2C31!important;' +
          'border-radius:999px!important;font-weight:700;min-height:46px}' +
      // صفحة الفيديو في الوضع الليلي: قالب الموقع يثبّت العناوين بلون داكن (#16353d) فلا تُقرأ فوق البطاقة الداكنة
      D + '.hw-videos{--ink:#0B1A1E;--deep:#12262B;--panel:#12262B;--panel-2:#1A3439;--line:#1F3A41;--gold:#E8D5A8;' +
          '--gold-soft:#EFE4CF;--text:#E9EEF0;--muted:#8FA6AC}' +
      D + ' :is(.grid,.reel-row,.mini,.side) :is(.card h3,.card h3 a,h3 a,.mini a):not(#x){color:#E9EEF0!important}' +
      D + ' :is(.grid,.reel-row) .card h3 a:hover:not(#x){color:#E8D5A8!important}' +
      D + ' :is(.grid,.reel-row,.watch) .meta:not(#x){color:#8FA6AC!important}' +
      D + ' :is(.grid,.reel-row,.watch) .tag:not(#x){color:#E8D5A8!important}' +
      D + ' :is(.head p,.reel .sub,.crumbs,.crumbs a,.about,.facts dt,.verse .ref):not(#x){color:#8FA6AC!important}' +
      D + ' :is(.desc,.facts dd,.about h2,.watch h1):not(#x){color:#E9EEF0!important}' +
      // عناصر خاصة بالمتصفح لا داعي لها داخل التطبيق: زر تبديل الوضع (التطبيق يتحكم به)، ومسار التصفح، وزر «الرئيسية»
      A + ' :is(.hw-mode-btn,.breadcrumb,nav[aria-label="breadcrumb"],.hw-home):not(#x){display:none!important}';
    (document.head || root).appendChild(unify);

    // ------------------------------------------------ توحيد الأرقام
    // الموقع يخلط الأرقام الغربية بالعربية («الآية 9» بجانب «٢٨٦ آية»). داخل التطبيق نوحّدها بالعربية
    // في النصوص العربية فقط: لا نلمس الحقول ولا الأكواد ولا أي نص فيه حروف لاتينية (روابط، أسماء إنجليزية).
    (function () {
      var SKIP = /^(SCRIPT|STYLE|TEXTAREA|INPUT|CODE|PRE|KBD|SAMP|NOSCRIPT|SVG|MATH)$/;
      var AR = /[\u0600-\u06FF]/, LAT = /[A-Za-z]/, DIG = /[0-9]/;
      var conv = function (t) { return t.replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); };
      var ok = function (n) {
        for (var e = n.parentElement; e; e = e.parentElement) {
          if (SKIP.test(e.tagName) || e.isContentEditable) return false;
          var dir = e.getAttribute && e.getAttribute('dir');
          if (dir === 'ltr' || e.hasAttribute('data-hawl-latin')) return false;
          // عدّادات ومؤقتات يقرؤها سكربت الموقع كأرقام: لا نغيّرها حتى لا تتعطل حساباته
          if (/(time|timer|count|duration|clock|progress|player|audio|seek|tasbeeh|tasbih)/i.test((e.id || '') + ' ' + (typeof e.className === 'string' ? e.className : ''))) return false;
          if (e === document.body) break;
        }
        return true;
      };
      var walk = function (rootEl) {
        try {
          if (!rootEl) return;
          if (rootEl.nodeType === 3) rootEl = rootEl.parentElement;
          if (!rootEl) return;
          var tw = document.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT, null);
          var n, c = 0;
          while ((n = tw.nextNode()) && c < 8000) {
            c++;
            var t = n.data;
            if (!DIG.test(t) || LAT.test(t)) continue;
            // رقم منفرد بلا حروف: نحوّله إن كان سياقه عربيًا
            if (!AR.test(t)) {
              var ctx = n.parentElement && n.parentElement.closest('p,li,div,span,a,td,h1,h2,h3,h4,h5,h6,label');
              if (!ctx || !AR.test(ctx.textContent || '') || LAT.test(ctx.textContent || '')) continue;
            }
            if (ok(n)) n.data = conv(t);
          }
        } catch (e) {}
      };
      var queue = [], timer = 0;
      var start = function () {
        walk(document.body);
        try {
          new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
              if (muts[i].type === 'characterData') queue.push(muts[i].target);
              for (var j = 0; j < muts[i].addedNodes.length; j++) queue.push(muts[i].addedNodes[j]);
            }
            if (queue.length && !timer) timer = setTimeout(function () {
              var q = queue; queue = []; timer = 0;
              for (var k = 0; k < q.length; k++) if (q[k].isConnected) walk(q[k]);
            }, 250);
          }).observe(document.body, { childList: true, subtree: true, characterData: true });
        } catch (e) {}
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
    })();

    // قالب الموقع يدعم ألوانًا اختيارية (أزرق، بنفسجي…) ووضع body.mode-*؛ داخل التطبيق نثبّت هوية التطبيق
    var fixes = 0;   // حدّ أمان: إن كان سكربت القالب يعيد الوضع باستمرار، لا ندخل معه في حلقة لا تنتهي
    var syncBody = function () {
      var b = document.body;
      if (!b || fixes > 30) return;
      var want = 'mode-' + theme, other = theme === 'dark' ? 'mode-light' : 'mode-dark', changed = false;
      if (!b.classList.contains(want)) { b.classList.add(want); changed = true; }
      if (b.classList.contains(other)) { b.classList.remove(other); changed = true; }
      if (b.hasAttribute('data-theme')) { b.removeAttribute('data-theme'); changed = true; }
      if (root.getAttribute('data-hw-mode') !== theme) { root.setAttribute('data-hw-mode', theme); changed = true; }
      if (changed) fixes++;
    };
    var watchTheme = function () {
      syncBody();
      try {
        var mo = new MutationObserver(syncBody);
        mo.observe(document.body, { attributes: true, attributeFilter: ['class', 'data-theme'] });
        mo.observe(root, { attributes: true, attributeFilter: ['data-hw-mode'] });
      } catch (e) {}
    };
    if (document.body) watchTheme(); else document.addEventListener('DOMContentLoaded', watchTheme);

    // ------------------------------------------------ مصحّح التباين في الوضع الليلي
    // بعض صفحات الموقع (مثل الفيديوهات) تكتب العناوين بلون داكن ثابت فوق بطاقة داكنة فلا تُقرأ.
    // نفحص النصوص: إن كان تباين لون النص مع خلفيته الفعلية ضعيفًا نجعله فاتحًا.
    if (theme === 'dark') {
      var rgb = function (c) {
        var m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?/.exec(c || '');
        if (!m) return null;
        var a = m[4] === undefined ? 1 : (m[4].indexOf('%') > 0 ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
        return [+m[1], +m[2], +m[3], a];
      };
      var lum = function (c) {
        var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
        return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
      };
      // ذاكرة مؤقتة لخلفيات العناصر خلال الفحص الواحد (العناصر المتجاورة تتشارك الآباء)
      var bgCache = null;
      var bgOf = function (el) {
        var path = [], res = [11, 26, 30, 1];          // خلفية الصفحة في الوضع الليلي
        for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
          if (bgCache && bgCache.has(e)) { res = bgCache.get(e); break; }
          path.push(e);
          var r = bgOwn(e);
          if (r !== undefined) { res = r; break; }
        }
        if (bgCache) for (var i = 0; i < path.length; i++) bgCache.set(path[i], res);
        return res;
      };
      /** خلفية العنصر نفسه: لون، أو null لصورة، أو undefined إن كان شفافًا */
      var bgOwn = function (e) {
        {
          var cs = getComputedStyle(e);
          // نص فوق صورة: لا نحكم عليه
          if (cs.backgroundImage && cs.backgroundImage !== 'none' && cs.backgroundImage.indexOf('gradient') < 0) return null;
          var b = rgb(cs.backgroundColor);
          // ورقة بتدرّج (مثل ورقة المصحف): لونها الفعلي أول لون في التدرّج
          var gc = cs.backgroundImage && cs.backgroundImage.indexOf('gradient') >= 0 ? rgb(cs.backgroundImage) : null;
          if (gc && gc[3] >= 0.5) return gc;
          if (b && b[3] >= 0.5) return b;
        }
        return undefined;
      };
      // ---- مصحّح الأسطح الفاتحة: أقسام في الموقع خلفيتها بيضاء أو عاجية ثابتة (#fff) لا تتبع الوضع الليلي،
      // فيظهر النص الفاتح فوقها باهتًا (الترويسة، تبويبات الصفحة الرئيسية، بطاقات فهرس السور، بطاقة آية اليوم).
      // نجعل كل سطح فاتح بلون بطاقات التطبيق الليلي، ثم يعمل مصحّح التباين على نصوصه.
      var QSIG = /[\u0671\u06DF\u06E1\u06E5\u06E6\u06DE]/;          // حروف لا تظهر إلا في الرسم العثماني
      var STAGS = 'header,nav,section,article,aside,main,footer,form,div,ul,ol,li,a,button,label,table,tr,td,th,fieldset';
      var fixSurfaces = function (rootEl) {
        try {
          var base = rootEl && rootEl.querySelectorAll ? rootEl : document.body;
          var els = [base].concat(Array.prototype.slice.call(base.querySelectorAll(STAGS)));
          var vw = window.innerWidth, todo = [];
          // المرحلة ١: قراءة فقط (بلا كتابة) حتى لا يُعاد حساب التخطيط مع كل عنصر — أسرع بكثير على الصفحات الطويلة
          for (var i = 0; i < els.length && i < 6000; i++) {
            var el = els[i];
            if (el.nodeType !== 1 || el.hasAttribute('data-hawl-s') || el === document.body) continue;
            var cs = getComputedStyle(el);
            var img = cs.backgroundImage && cs.backgroundImage !== 'none';
            var grad = img && cs.backgroundImage.indexOf('gradient') >= 0;
            var big = el.offsetHeight >= 64 || el.offsetWidth >= vw * 0.6;
            if (img && !grad) {
              // ورقة مصحف بصورة (نسيج ورق) تحمل نصًا قرآنيًا: تُعتَّم ليلًا وإلا بقي النص الفاتح فوقها غير مقروء
              if (big && QSIG.test(el.textContent || '')) { todo.push([el, true, true, true, false]); continue; }
              todo.push([el]); continue;                                         // صور أخرى لا نلمسها
            }
            var b = grad ? rgb(cs.backgroundImage) : rgb(cs.backgroundColor);
            if (!b || b[3] < 0.5 || lum(b) < 0.45) { todo.push([el]); continue; } // ليست فاتحة
            // ذهبي/بيج صغير = زر مقصود؛ أما السطح الكبير البيج (ورقة المصحف) فيُعتَّم
            if (!big && b[0] > b[2] + 40 && lum(b) < 0.75) { todo.push([el]); continue; }
            var bc = rgb(cs.borderTopColor);
            todo.push([el, big, grad, big && b[0] > b[2] + 25, bc && parseFloat(cs.borderTopWidth) > 0 && lum(bc) > 0.5]);
          }
          // المرحلة ٢: الكتابة دفعة واحدة
          for (var t = 0; t < todo.length; t++) {
            var x = todo[t], e2 = x[0];
            e2.setAttribute('data-hawl-s', '1');
            if (x.length === 1) continue;
            if (x[2]) e2.style.setProperty('background-image', 'none', 'important');
            e2.style.setProperty('background-color', x[3] ? '#162E33' : x[1] ? '#12262B' : '#1A3439', 'important');
            if (x[4]) e2.style.setProperty('border-color', '#1F3A41', 'important');
            // أُعيد طلاء السطح: نعيد فحص تباين نصوصه
            var marked = e2.querySelectorAll('[data-hawl-c]');
            for (var k = 0; k < marked.length; k++) if (!marked[k].style.getPropertyValue('color')) marked[k].removeAttribute('data-hawl-c');
            if (e2.hasAttribute('data-hawl-c') && !e2.style.getPropertyValue('color')) e2.removeAttribute('data-hawl-c');
          }
        } catch (e) {}
      };
      var TAGS = 'h1,h2,h3,h4,h5,h6,p,a,span,strong,b,small,li,dt,dd,label,figcaption,div,td,th';
      var fixContrast = function (rootEl) {
        fixSurfaces(rootEl);
        bgCache = typeof Map === 'function' ? new Map() : null;
        try {
          var els = (rootEl && rootEl.querySelectorAll ? rootEl : document.body).querySelectorAll(TAGS);
          var n = 0, seen = [], todo = [];
          // قراءة كل الألوان أولًا ثم الكتابة دفعة واحدة (أسرع على الصفحات الطويلة)
          for (var i = 0; i < els.length && n < 4000; i++) {
            var el = els[i];
            if (el.hasAttribute('data-hawl-c')) continue;
            // نص مباشر داخل العنصر فقط
            var direct = false;
            for (var c = el.firstChild; c; c = c.nextSibling) {
              if (c.nodeType === 3 && c.data.trim()) { direct = true; break; }
            }
            if (!direct) continue;
            n++;
            seen.push(el);
            var cs = getComputedStyle(el);
            var fg = rgb(cs.color);
            if (!fg || fg[3] < 0.2 || cs.visibility === 'hidden') continue;
            var bg = bgOf(el);
            if (!bg) continue;
            var l1 = lum(fg), l2 = lum(bg);
            var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
            if (ratio < 3 && l1 >= 0.4 && l2 >= 0.4) {
              // نص فاتح فوق سطح فاتح لم يُعتَّم (احتياط): يصبح داكنًا ليُقرأ
              todo.push([el, '#16353D']);
            } else if (ratio < 3 && l1 < 0.25) {
              // العناوين والروابط ذهبية فاتحة كما في التطبيق، وبقية النص فاتح
              var gold = /^(A|SMALL)$/.test(el.tagName) && fg[0] > fg[2];
              todo.push([el, gold ? '#E8D5A8' : '#E9EEF0']);
            }
          }
          for (var s3 = 0; s3 < seen.length; s3++) seen[s3].setAttribute('data-hawl-c', '1');
          for (var t3 = 0; t3 < todo.length; t3++) todo[t3][0].style.setProperty('color', todo[t3][1], 'important');
        } catch (e) {}
        bgCache = null;
      };
      var cTimer = 0, cQueue = [];
      var startContrast = function () {
        fixContrast(document.body);
        try {
          new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
              for (var j = 0; j < muts[i].addedNodes.length; j++) {
                var nd = muts[i].addedNodes[j];
                if (nd.nodeType === 1) cQueue.push(nd); else if (nd.parentElement) cQueue.push(nd.parentElement);
              }
            }
            if (cQueue.length && !cTimer) cTimer = setTimeout(function () {
              var q = cQueue; cQueue = []; cTimer = 0;
              for (var k = 0; k < q.length; k++) { if (q[k].isConnected) { if (q[k].matches && q[k].matches(TAGS)) { q[k].removeAttribute('data-hawl-c'); } fixContrast(q[k].parentElement || q[k]); } }
            }, 300);
          }).observe(document.body, { childList: true, subtree: true });
        } catch (e) {}
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startContrast); else startContrast();
      // بعد تحميل أوراق الأنماط والخطوط: فحص أخير للعناصر التي لم تكتمل ألوانها
      window.addEventListener('load', function () {
        var sf = document.querySelectorAll('[data-hawl-s]');
        for (var s2 = 0; s2 < sf.length; s2++) if (!sf[s2].style.getPropertyValue('background-color')) sf[s2].removeAttribute('data-hawl-s');
        var all = document.querySelectorAll('[data-hawl-c]');
        for (var i = 0; i < all.length; i++) if (!all[i].style.getPropertyValue('color')) all[i].removeAttribute('data-hawl-c');
        fixContrast(document.body);
      });
    }

    var navCss = document.createElement('style');
    navCss.textContent =
      // محددات شائعة لشريط الجوال السفلي + ما يكتشفه الفحص أدناه
      '.hawl-app .bottom-nav,.hawl-app .mobile-nav,.hawl-app .bottom-bar,.hawl-app .tabbar,.hawl-app .tab-bar,' +
      '.hawl-app .nav-bottom,.hawl-app .mobile-bottom-nav,.hawl-app #bottom-nav,.hawl-app #mobile-nav,' +
      '.hawl-app [data-bottom-nav],.hawl-site-nav,.hawl-legacy{display:none!important}';
    (document.head || root).appendChild(navCss);

    // فحص ذكي: عنصر ثابت أسفل الشاشة بعرضها تقريبًا، قليل الارتفاع، وفيه 3 روابط أو أزرار فأكثر
    var hiddenH = 0;
    var scanSiteNav = function () {
      try {
        var vw = window.innerWidth, vh = window.innerHeight;
        if (!vw || !vh || !document.body) return;
        var xs = [vw * 0.15, vw * 0.5, vw * 0.85], seen = [];
        for (var k = 0; k < xs.length; k++) {
          var stack = document.elementsFromPoint(xs[k], vh - 6) || [];
          for (var n = 0; n < stack.length; n++) {
            for (var el = stack[n]; el && el !== document.body && el !== root; el = el.parentElement) {
              if (seen.indexOf(el) >= 0) break;
              seen.push(el);
              var cs = getComputedStyle(el);
              if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
              var r = el.getBoundingClientRect();
              if (r.width >= vw * 0.8 && r.height > 20 && r.height <= 140 && r.bottom >= vh - 8 &&
                  el.querySelectorAll('a,button').length >= 3) {
                el.classList.add('hawl-site-nav');
                hiddenH = Math.max(hiddenH, r.height);
              }
            }
          }
        }
        // المسافة التي حجزها الموقع أسفل الصفحة لشريطه لم تعد لازمة
        if (hiddenH && !document.body.hasAttribute('data-hawl-pad')) {
          var pb = parseFloat(getComputedStyle(document.body).paddingBottom) || 0;
          if (pb >= hiddenH - 12) {
            document.body.style.setProperty('padding-bottom', Math.max(0, pb - hiddenH) + 'px', 'important');
          }
          document.body.setAttribute('data-hawl-pad', '1');
        }
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', scanSiteNav);
    window.addEventListener('load', function () { scanSiteNav(); setTimeout(scanSiteNav, 800); setTimeout(scanSiteNav, 2000); });
    window.addEventListener('resize', scanSiteNav);

    // بقايا القالب القديم «القرآن الكريم للجميع» في صفحات السور: هيدر وشعار وبانر وسطر Powered by.
    // نخفيها داخل التطبيق فقط، مع حماية من إخفاء أي حاوية فيها عنوان الصفحة أو الآيات أو الهيدر الجديد.
    var cleanLegacy = function () {
      try {
        var vh = window.innerHeight || 800;
        var hide = function (el) {
          if (!el || el === document.body || el === root || el.classList.contains('hawl-legacy')) return;
          if (el.querySelector('h1,audio,article,img[src*="design-theme"]')) return;
          if (el.getBoundingClientRect().height > vh * 0.6) return;
          el.classList.add('hawl-legacy');
        };
        var each = function (sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); };
        each('img[src*="css/images/logo"]', function (img) {
          hide(img.closest('header,nav,.navbar,#header,.header,[class*="header"],[class*="navbar"]') || img.closest('a') || img);
        });
        each('img[src*="header-banner"]', function (img) {
          var w = img.parentElement;
          hide(w && w.children.length === 1 ? w : img);
        });
        each('a[href*="nwahy.com"]', function (a) {
          var p = a.parentElement;
          hide(p && p.textContent.trim().length < 80 ? p : a);
        });
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', cleanLegacy);
    window.addEventListener('load', cleanLegacy);

    // ------------------------------------------------ نص المصحف بخط مجمع الملك فهد ورسمه
    // نص الموقع بصيغة «تنزيل»؛ نحوّل كلماته داخل التطبيق إلى نص المجمع (KFGQPC Hafs v18)
    // ونعرضه بخطه الرسمي، فتظهر «وَٱلۡـَٔاخِرَةِ» وعلامات الوقف والتنوين كما في مصحف المدينة.
    // الخط وجدول التحويل يقدّمهما التطبيق من ملفاته عبر /__hawl/ (بدون إنترنت).
    try { hawlQuranFont(); } catch (e) {}

    // ------------------------------------------------ صفحات المصحف بأسطر مصحف المدينة
    // صفحة mushaf-page-N تُعرض بأسطرها الخمسة عشر كما في مصحف المدينة: البيانات (رقم الصفحة وسطر بداية كل آية
    // ونهايتها) من منصة مطوّري مجمع الملك فهد، والخط وعلامات الآيات خطّ المجمع. تُقدَّم من ملفات التطبيق.
    try { hawlMushafPages(); } catch (e) {}

    // ------------------------------------------------ علامات الآيات الرسمية في عرض السور
    // أرقام الآيات في صفحات السور تظهر بخط الموقع أرقامًا عادية؛ نعرضها بخط المجمع فتظهر بعلامة نهاية الآية المزخرفة.
    try { hawlAyahMarkers(); } catch (e) {}
  }

  function hawlMushafPages() {
    // رقم الصفحة من الرابط، أو من عنوان الصفحة «صفحة ٤ من المصحف الشريف»
    var toEn = function (t) { return String(t).replace(/[\u0660-\u0669]/g, function (d) { return d.charCodeAt(0) - 0x0660; }); };
    var m = /mushaf-page-(\d{1,3})(?:\.html)?/.exec(location.pathname + location.search);
    var N = m ? +m[1] : 0;
    var fromTitle = function () {
      var hs = document.querySelectorAll('h1,h2,h3,title');
      for (var i = 0; i < hs.length; i++) {
        var t = /صفحة\s+([0-9\u0660-\u0669]{1,3})\s+من\s+المصحف/.exec(hs[i].textContent || '');
        if (t) return +toEn(t[1]);
      }
      return 0;
    };
    var night = window.__hawlTheme === 'dark';
    var SIG = /[\u0671\u06DF\u06E1\u06E5\u06E6\u06DE]/;
/* صفحة المصحف بأسطر مصحف المدينة: البيانات من مجمع الملك فهد (رقم الصفحة وسطر بداية الآية ونهايتها) */
/* صفحة المصحف بأسطر مصحف المدينة: البيانات من مجمع الملك فهد (رقم الصفحة وسطر بداية الآية ونهايتها) */
  var HawlMushaf = (function () {
  var BASMALA = 'بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ';
  // عنوان السورة داخل خرطوشة مزخرفة (الألوان من متغيرات CSS: --mp-g ذهبي، --mp-d داكن، --mp-p الورقة، --mp-a زهري)
  var CART = '<svg viewBox="0 0 320 44" preserveAspectRatio="none" aria-hidden="true">' +
    '<path d="M2 22 L22 2 H298 L318 22 L298 42 H22Z" fill="var(--mp-d)" stroke="var(--mp-g)" stroke-width="1.6"/>' +
    '<path d="M14 22 L27 8 H293 L306 22 L293 36 H27Z" fill="var(--mp-p)" stroke="var(--mp-g)" stroke-width="1"/>' +
    '<path d="M30 22 l6 -6 l6 6 l-6 6Z M278 22 l6 -6 l6 6 l-6 6Z" fill="var(--mp-a)" stroke="var(--mp-g)" stroke-width=".8"/>' +
    '<circle cx="8" cy="22" r="2" fill="var(--mp-g)"/><circle cx="312" cy="22" r="2" fill="var(--mp-g)"/></svg>';
  function ar(n) { return String(n).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); }

  /** يحسب محتوى الأسطر ١..١٥ لصفحة: عنوان سورة، بسملة، أو كلمات */
  function layout(data, N, measure) {
    var page = data.pages[N - 1], lines = [], i, e;
    for (i = 0; i <= 15; i++) lines.push(null);
    for (i = 0; i < page.length; i++) {
      e = page[i];
      if (e[1] !== 1) continue;
      var s = e[0], ls = e[2];
      if (s === 1) { if (ls >= 2) lines[ls - 1] = { t: 'h', s: s }; }
      else if (s === 9) { if (ls >= 2) lines[ls - 1] = { t: 'h', s: s }; }
      else if (ls >= 3) { lines[ls - 2] = { t: 'h', s: s }; lines[ls - 1] = { t: 'b' }; }
      else if (ls === 2) lines[1] = { t: 'b' };
    }
    var next = data.pages[N];
    if (next && next[0][1] === 1) {
      var ns = next[0][0], nl = next[0][2];
      if (ns === 9 && nl === 1) lines[15] = { t: 'h', s: 9 };
      else if (ns !== 9 && ns !== 1) {
        if (nl === 1) { lines[14] = { t: 'h', s: ns }; lines[15] = { t: 'b' }; }
        else if (nl === 2) lines[15] = { t: 'h', s: ns };
      }
    }
    // الكلمات بقيود أسطرها
    var words = [];
    for (i = 0; i < page.length; i++) {
      e = page[i];
      var toks = e[4].split(' ').filter(function (x) { return x.length; });
      for (var k = 0; k < toks.length; k++) words.push({ w: toks[k], ls: e[2], le: e[3], f: k === 0, l: k === toks.length - 1 });
    }
    var used = {};
    for (i = 0; i < page.length; i++) for (var L = page[i][2]; L <= page[i][3]; L++) used[L] = 1;
    var T = [];
    for (L = 1; L <= 15; L++) if (used[L] && !(lines[L] && lines[L].t !== 'x')) T.push(L);
    var sp = measure(' '), total = 0;
    for (i = 0; i < words.length; i++) { words[i].px = measure(words[i].w); total += words[i].px + sp; }
    var W = total / Math.max(1, T.length), n = words.length, INF = 1e18;
    // برمجة ديناميكية: أفضل توزيع للكلمات على الأسطر يحقق قيود المجمع ويجعل الأسطر متساوية
    var f = [], back = [];
    for (var a = 0; a <= T.length; a++) { f.push(new Array(n + 1).fill(INF)); back.push(new Array(n + 1).fill(-1)); }
    f[0][0] = 0;
    for (a = 0; a < T.length; a++) {
      L = T[a];
      for (i = 0; i < n; i++) {
        if (f[a][i] >= INF) continue;
        var wsum = 0;
        for (var j = i; j < n; j++) {
          var wd = words[j];
          if (wd.ls > L || wd.le < L) break;
          if (wd.f && wd.ls !== L) break;
          wsum += wd.px + (j > i ? sp : 0);
          if (wd.l && wd.le !== L) continue;            // آخر كلمة في الآية يجب أن تكون في سطر نهايتها
          var d = W - wsum, cost = f[a][i] + d * d;
          // الآية التالية تبدأ في هذا السطر حسب المجمع: لا يصح إنهاؤه قبلها
          if (j + 1 < n && words[j + 1].f && words[j + 1].ls === L) continue;
          if (cost < f[a + 1][j + 1]) { f[a + 1][j + 1] = cost; back[a + 1][j + 1] = i; }
        }
      }
    }
    var ok = f[T.length][n] < INF;
    if (ok) {
      var end = n;
      for (a = T.length; a > 0; a--) {
        var st = back[a][end];
        lines[T[a - 1]] = { t: 'x', w: words.slice(st, end).map(function (x) { return x.w; }) };
        end = st;
      }
    } else {
      // احتياط: كل آية في سطر بدايتها
      for (i = 0; i < words.length; i++) {
        L = words[i].ls;
        if (!lines[L] || lines[L].t !== 'x') lines[L] = { t: 'x', w: [] };
        lines[L].w.push(words[i].w);
      }
    }
    var maxW = 0;
    for (L = 1; L <= 15; L++) if (lines[L] && lines[L].t === 'x') {
      var s2 = 0; for (i = 0; i < lines[L].w.length; i++) s2 += measure(lines[L].w[i]) + (i ? sp : 0);
      lines[L].px = s2; if (s2 > maxW) maxW = s2;
    }
    return { lines: lines, maxW: maxW, ok: ok };
  }

  function render(data, N, root, opt) {
    opt = opt || {};
    var cv = document.createElement('canvas').getContext('2d');
    cv.font = '100px HawlHafs';
    var measure = function (s) { return cv.measureText(s).width; };
    var r = layout(data, N, measure);
    var rcs = getComputedStyle(root);
    var cw = (root.clientWidth || 360) - (parseFloat(rcs.paddingLeft) || 0) - (parseFloat(rcs.paddingRight) || 0);
    var pad = Math.round(cw * (opt.pad != null ? opt.pad : 0.04));
    var inner = cw - pad * 2;
    var fs = Math.max(14, Math.min(42, inner * 0.985 / (r.maxW / 100)));
    var special = N <= 2;
    var page = data.pages[N - 1];
    var firstSura = page[0][0];
    var h = [];
    h.push('<div class="mp-top"><span>الجزء ' + ar(data.juz[N - 1]) + '</span><span>سورة ' + data.names[firstSura - 1] + '</span></div>');
    h.push('<div class="mp-page' + (special ? ' mp-special' : '') + '" style="font-size:' + fs.toFixed(2) + 'px;padding:0 ' + pad + 'px">');
    for (var L = 1; L <= 15; L++) {
      var ln = r.lines[L];
      if (!ln) { if (!special) h.push('<div class="mp-l mp-empty"></div>'); continue; }
      if (ln.t === 'h') h.push('<div class="mp-l mp-h"><div class="mp-cart">' + CART + '<span>سورة ' + data.names[ln.s - 1] + '</span></div></div>');
      else if (ln.t === 'b') h.push('<div class="mp-l mp-b">' + BASMALA + '</div>');
      else h.push('<div class="mp-l mp-x">' + ln.w.join(' ') + '</div>');
    }
    h.push('</div><div class="mp-num">' + ar(N) + '</div>');
    root.innerHTML = h.join('');
    // قياس المتصفح قد يختلف قليلًا عن قياس اللوحة: نصغّر الخط حتى لا ينكسر أي سطر
    var pg = root.querySelector('.mp-page'), xs = root.querySelectorAll('.mp-x');
    for (var tries = 0; tries < 20; tries++) {
      var broken = false;
      for (var q = 0; q < xs.length; q++) {
        var lh = parseFloat(getComputedStyle(xs[q]).lineHeight) || fs * 2.05;
        if (xs[q].scrollHeight > lh * 1.4) { broken = true; break; }
      }
      if (!broken) break;
      fs *= 0.97;
      pg.style.fontSize = fs.toFixed(2) + 'px';
    }
    return r;
  }

  var CSS =
    '.hawl-mp{direction:rtl;font-family:HawlHafs,serif;padding:12px 0 18px;border-radius:18px}' +
    '.hawl-mp .mp-top{display:flex;justify-content:space-between;font:500 13px/1.6 Tajawal,sans-serif;padding:0 16px 6px;opacity:.85}' +
    '.hawl-mp .mp-l{line-height:2.05;min-height:2.05em;overflow:hidden}' +
    '.hawl-mp .mp-x{text-align:justify;text-align-last:justify}' +
    '.hawl-mp .mp-special .mp-x{text-align:center;text-align-last:center}' +
    '.hawl-mp .mp-special{display:flex;flex-direction:column;justify-content:center;min-height:15em}' +
    '.hawl-mp .mp-b{text-align:center}' +
    '.hawl-mp .mp-h{display:flex;align-items:center;justify-content:center}' +
    '.hawl-mp .mp-cart{position:relative;width:86%;height:1.75em;display:flex;align-items:center;justify-content:center}' +
    '.hawl-mp .mp-cart svg{position:absolute;inset:0;width:100%;height:100%}' +
    '.hawl-mp .mp-cart span{position:relative;font-size:.95em;line-height:1;color:var(--mp-t)}' +
    '.hawl-mp .mp-num{text-align:center;font:700 14px/1 Tajawal,sans-serif;margin-top:8px;opacity:.85}';
  return { layout: layout, render: render, CSS: CSS };
})();
/* إطار احترافي على طراز التذهيب في المصاحف المخطوطة (تصميم أصلي، يُرسم بالكود) */
function hawlFrame(W0, H0, c) {
  var sc = c.scale || 1, w = W0 / sc, h = H0 / sc;
  var id = 'hf' + Math.random().toString(36).slice(2, 7), P = [];
  function star8(cx, cy, r, fill, stroke, sw) {
    var pts = [];
    for (var i = 0; i < 16; i++) {
      var a = Math.PI / 8 * i - Math.PI / 2, rr = i % 2 ? r * 0.72 : r;
      pts.push((cx + rr * Math.cos(a)).toFixed(2) + ',' + (cy + rr * Math.sin(a)).toFixed(2));
    }
    return '<polygon points="' + pts.join(' ') + '" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + sw + '" stroke-linejoin="round"/>';
  }
  function rosette(cx, cy, r) {
    var s = '';
    for (var i = 0; i < 8; i++) {
      s += '<ellipse cx="' + cx + '" cy="' + (cy - r * 0.5) + '" rx="' + (r * 0.2) + '" ry="' + (r * 0.42) + '" transform="rotate(' + (45 * i) + ' ' + cx + ' ' + cy + ')" fill="' + c.accent + '" stroke="' + c.gold + '" stroke-width="0.5"/>';
    }
    return s + '<circle cx="' + cx + '" cy="' + cy + '" r="' + (r * 0.22) + '" fill="' + c.gold + '"/>';
  }
  function corner(cx, cy) {
    var s = 18;
    return '<rect x="' + (cx - s) + '" y="' + (cy - s) + '" width="' + (2 * s) + '" height="' + (2 * s) + '" fill="' + c.deep + '" stroke="' + c.gold + '" stroke-width="1.4"/>' +
      '<rect x="' + (cx - s + 3) + '" y="' + (cy - s + 3) + '" width="' + (2 * s - 6) + '" height="' + (2 * s - 6) + '" fill="none" stroke="' + c.gold + '" stroke-width="0.6"/>' +
      star8(cx, cy, 14.5, c.paper, c.gold, 1.2) + star8(cx, cy, 9.8, c.deep, c.gold, 0.8) + rosette(cx, cy, 7.6);
  }
  function medallion(cx, cy, vertical) {
    var L = 34, H = 13, d;
    if (vertical) d = 'M' + cx + ' ' + (cy - L) + ' Q' + (cx + H * 1.6) + ' ' + cy + ' ' + cx + ' ' + (cy + L) + ' Q' + (cx - H * 1.6) + ' ' + cy + ' ' + cx + ' ' + (cy - L) + 'Z';
    else d = 'M' + (cx - L) + ' ' + cy + ' Q' + cx + ' ' + (cy - H * 1.6) + ' ' + (cx + L) + ' ' + cy + ' Q' + cx + ' ' + (cy + H * 1.6) + ' ' + (cx - L) + ' ' + cy + 'Z';
    var s = '<path d="' + d + '" fill="' + c.deep + '" stroke="' + c.gold + '" stroke-width="1.4"/>';
    var sc = 0.66;
    s += '<path d="' + d + '" transform="translate(' + cx * (1 - sc) + ' ' + cy * (1 - sc) + ') scale(' + sc + ')" fill="' + c.paper + '" stroke="' + c.gold + '" stroke-width="1.2"/>';
    return s + rosette(cx, cy, 8);
  }
  var o = 3, b1 = 7, b2 = 27, b3 = 30, b4 = 41, b5 = 45;
  P.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + W0 + '" height="' + H0 + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true"><defs>' +
    // سلسلة دوائر متشابكة (زخرفة هندسية) على شريط داكن
    '<pattern id="' + id + 'c" width="16" height="20" patternUnits="userSpaceOnUse">' +
      '<rect width="16" height="20" fill="' + c.deep + '"/>' +
      '<circle cx="8" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="0" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="16" cy="10" r="7.2" fill="none" stroke="' + c.gold + '" stroke-width="1"/>' +
      '<circle cx="4" cy="10" r="1.3" fill="' + c.accent + '"/><circle cx="12" cy="10" r="1.3" fill="' + c.accent + '"/>' +
    '</pattern>' +
    // شريط أزهار صغيرة على أرضية فاتحة
    '<pattern id="' + id + 'f" width="14" height="11" patternUnits="userSpaceOnUse">' +
      '<rect width="14" height="11" fill="' + c.band + '"/>' +
      '<circle cx="7" cy="3.6" r="1.5" fill="' + c.gold + '"/><circle cx="7" cy="7.4" r="1.5" fill="' + c.gold + '"/>' +
      '<circle cx="5.1" cy="5.5" r="1.5" fill="' + c.gold + '"/><circle cx="8.9" cy="5.5" r="1.5" fill="' + c.gold + '"/>' +
      '<circle cx="7" cy="5.5" r="0.9" fill="' + c.accent + '"/>' +
    '</pattern></defs>');
  function R(i, fill, stroke, sw) {
    return '<rect x="' + i + '" y="' + i + '" width="' + (w - 2 * i) + '" height="' + (h - 2 * i) + '" fill="' + fill + '"' +
      (stroke ? ' stroke="' + stroke + '" stroke-width="' + sw + '"' : '') + '/>';
  }
  P.push(R(o, c.paper, c.gold, 1.6));
  P.push(R(b1, 'url(#' + id + 'c)', c.gold, 1.2));
  P.push(R(b2, c.paper, c.gold, 0.8));
  P.push(R(b3, 'url(#' + id + 'f)', c.gold, 1));
  P.push(R(b4, c.paper, c.gold, 1.4));
  P.push(R(b5, 'none', c.deep, 0.6));
  var k = 20;
  P.push(corner(k, k) + corner(w - k, k) + corner(k, h - k) + corner(w - k, h - k));
  P.push(medallion(w / 2, k, false) + medallion(k, h / 2, true) + medallion(w - k, h / 2, true));
  // رقم الصفحة في ميدالية أسفل الإطار
  if (c.num) {
    // الميدالية تُكبَّر على الشاشات الصغيرة حتى يبقى رقم الصفحة واضحًا
    var m = Math.min(1.9, Math.max(1, 0.85 / sc)), cx = w / 2, cy = h - Math.max(k, 24 * m + 3);
    P.push('<path d="M' + (cx - 46 * m) + ' ' + cy + ' H' + (cx + 46 * m) + '" stroke="' + c.gold + '" stroke-width="1.2"/>' +
      '<circle cx="' + (cx - 40 * m) + '" cy="' + cy + '" r="' + 2.2 * m + '" fill="' + c.gold + '"/><circle cx="' + (cx + 40 * m) + '" cy="' + cy + '" r="' + 2.2 * m + '" fill="' + c.gold + '"/>' +
      star8(cx, cy, 24 * m, c.deep, c.gold, 1.4) +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + 16.5 * m + '" fill="' + c.paper + '" stroke="' + c.gold + '" stroke-width="1.2"/>' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + 13.8 * m + '" fill="none" stroke="' + c.gold + '" stroke-width="0.6"/>' +
      '<text x="' + cx + '" y="' + (cy + 5.2 * m) + '" text-anchor="middle" font-family="Tajawal,sans-serif" font-weight="700" font-size="' + ((c.num.length > 2 ? 12.5 : 15) * m) + '" fill="' + c.numColor + '">' + c.num + '</text>');
  } else P.push(medallion(w / 2, h - k, false));
  P.push('</svg>');
  return P.join('');
}


    var css = document.createElement('style');
    css.textContent = "@font-face{font-family:'HawlHafs';src:url('/__hawl/hafs.woff2?v=18') format('woff2');font-display:block}" +
      HawlMushaf.CSS +
      '.hawl-fw.hawl-q,.hawl-mp.hawl-q{font-size:inherit!important}' +
      '.hawl-fw{position:relative;margin:8px auto;max-width:720px}.hawl-fw>svg{position:absolute;top:0;left:0;pointer-events:none}' +
      '.hawl-fw .hawl-mp{position:relative;background:transparent!important;border:0!important;margin:0}' +
      '.hawl-fw .mp-num{display:none}.hawl-fw .mp-top{padding:0 4px 4px}' +
      (night
        ? '.hawl-fw{background:#142A2F}.hawl-mp{color:#EFE4CF!important;--mp-g:#C9A876;--mp-d:#0D2529;--mp-p:#142A2F;--mp-a:#A65444;--mp-t:#E2C892}' +
          '.hawl-mp .mp-top{color:#C9A876}'
        : '.hawl-fw{background:#FBF6E8}.hawl-mp{color:#1B1B1B!important;--mp-g:#B8924A;--mp-d:#1F4E4A;--mp-p:#FBF6E8;--mp-a:#9A3A2E;--mp-t:#6E5326}' +
          '.hawl-mp .mp-top{color:#6E5326}');
    var FC = night ? { paper: '#142A2F', gold: '#C9A876', deep: '#0D2529', band: '#1C383E', accent: '#A65444', numColor: '#E2C892' }
                   : { paper: '#FBF6E8', gold: '#B8924A', deep: '#1F4E4A', band: '#F2E6C9', accent: '#9A3A2E', numColor: '#6E5326' };
    (document.head || document.documentElement).appendChild(css);

    /** الحاوية التي فيها نص المصحف في صفحة الموقع: أعمق عنصر يضم معظم النص القرآني */
    function findBox() {
      var tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null), nodes = [], total = 0, n;
      while ((n = tw.nextNode())) {
        var pe = n.parentElement;
        // نص السكربتات والأنماط ليس نصًا معروضًا (قد يحوي آيات داخل كود الموقع)
        if (!pe || /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|TEXTAREA|TITLE)$/.test(pe.tagName)) continue;
        if (SIG.test(n.data)) { nodes.push(n); total += n.data.length; }
      }
      if (!nodes.length || total < 200) return null;
      var score = new Map();
      nodes.forEach(function (t) {
        for (var e = t.parentElement; e && e !== document.body; e = e.parentElement) score.set(e, (score.get(e) || 0) + t.data.length);
      });
      var best = null, depth = -1;
      score.forEach(function (v, e) {
        if (v < total * 0.85 || !e.offsetHeight) return;               // مرئي فقط
        var d = 0; for (var x = e; x; x = x.parentElement) d++;
        if (d > depth) { depth = d; best = e; }
      });
      return best;
    }

    var data = null, box = null, root = null, wrap = null;
    function draw() {
      if (!data || !root) return;
      try {
        // الإطار أنحف على الشاشات الصغيرة حتى يبقى للنص مساحة كافية
        // الإطار يتناسب مع عرض الشاشة: أنحف على الجوال حتى يبقى خط المصحف بحجم مريح للقراءة
        var sc = Math.max(0.45, Math.min(1, (wrap.clientWidth || 360) / 800));
        var mm = Math.min(1.9, Math.max(1, 0.85 / sc));       // حجم ميدالية رقم الصفحة (كما في hawlFrame)
        var bottom = Math.max(52, 48 * mm + 10) * sc;
        root.style.padding = Math.round(54 * sc) + 'px ' + Math.round(50 * sc) + 'px ' + Math.round(bottom) + 'px';
        HawlMushaf.render(data, N, root, { pad: 0.012 });
        var old = wrap.querySelector(':scope > svg');
        if (old) old.remove();
        var c = {}; for (var k in FC) c[k] = FC[k];
        c.scale = sc;
        c.num = String(N).replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); });
        wrap.insertAdjacentHTML('afterbegin', hawlFrame(wrap.clientWidth, wrap.clientHeight, c));
      } catch (e) {}
    }
    function mount() {
      if (root) return;
      if (!N) N = fromTitle();
      if (!(N >= 1 && N <= 604)) return;
      box = findBox();
      if (!box) return;
      // نصعد إلى «ورقة» الموقع التي لا تحوي إلا النص (لنستفيد من عرضها كاملًا بدل حشوها الداخلي)
      var bl = (box.textContent || '').trim().length;
      for (var up = 0; up < 3; up++) {
        var pr = box.parentElement;
        if (!pr || pr === document.body || pr.children.length !== 1) break;
        if ((pr.textContent || '').trim().length - bl > 20) break;
        box = pr;
      }
      ['padding', 'background', 'background-image', 'box-shadow', 'border'].forEach(function (k) {
        box.style.setProperty(k, k === 'padding' ? '0' : 'none', 'important');
      });
      box.setAttribute('data-hawl-s', '1');
      root = document.createElement('div');
      root.className = 'hawl-mp hawl-q';                 // hawl-q: لا يعيد محوّل الخط معالجته
      root.setAttribute('data-hawl-s', '1');
      root.setAttribute('data-hawl-c', '1');
      wrap = document.createElement('div');
      wrap.className = 'hawl-fw hawl-q';
      wrap.setAttribute('data-hawl-s', '1');
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'صفحة ' + N + ' من المصحف');
      wrap.appendChild(root);
      box.innerHTML = '';
      box.appendChild(wrap);
      Promise.all([
        fetch('/__hawl/mushaf.json?v=18').then(function (r) { return r.json(); }),
        document.fonts ? document.fonts.load("100px HawlHafs") : Promise.resolve()
      ]).then(function (res) { data = res[0]; draw(); }).catch(function () {});
    }
    var rt = 0;
    window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 200); });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();
    window.addEventListener('load', mount);
    // إن حمّل الموقع نص الصفحة متأخرًا بسكربت: نعيد المحاولة حتى ١٠ ثوانٍ
    var tries = 0, iv = setInterval(function () { if (root || ++tries > 20) clearInterval(iv); else mount(); }, 500);
  }

  function hawlAyahMarkers() {
    if (/mushaf-page-\d+/.test(location.pathname)) return;     // صفحات المصحف لها عرضها الخاص
    var SIG = /[\u0671\u06DF\u06E1\u06E5\u06E6\u06DE]/;
    var NUM = /^\s*[\uFD3E\uFD3F()\[\]\u06DD]*\s*([0-9\u0660-\u0669\u06F0-\u06F9]{1,3})\s*[\uFD3E\uFD3F()\[\]\u06DD]*\s*$/;
    var css = document.createElement('style');
    css.textContent = "@font-face{font-family:'HawlHafs';src:url('/__hawl/hafs.woff2?v=18') format('woff2');font-display:block}" +
      ".hawl-an{font-family:'HawlHafs',serif!important;font-weight:400!important;font-style:normal!important;" +
      "font-size:1.06em;letter-spacing:0!important;padding:0 .12em;white-space:nowrap}";
    (document.head || document.documentElement).appendChild(css);
    var toAr = function (d) {
      return d.replace(/[0-9]/g, function (x) { return String.fromCharCode(0x0660 + (+x)); })
              .replace(/[\u06F0-\u06F9]/g, function (x) { return String.fromCharCode(x.charCodeAt(0) - 0x06F0 + 0x0660); });
    };
    var scan = function (rootEl) {
      try {
        if (!rootEl) return;
        if (rootEl.nodeType === 3) rootEl = rootEl.parentElement;
        if (!rootEl || !rootEl.querySelectorAll) return;
        var tw = document.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT, null), n, hits = [], c = 0;
        while ((n = tw.nextNode()) && c < 20000) {
          c++;
          var m = NUM.exec(n.data);
          if (!m) continue;
          var el = n.parentElement;
          if (!el || el.closest('.hawl-an,.hawl-fw,.hawl-mp,input,textarea,select,button,nav,header,footer')) continue;
          // رقم بجوار نص قرآني فقط (لا أرقام الصفحات أو العدادات)
          var block = el.closest('p,div,section,article,li,td,blockquote');
          if (!block || !SIG.test(block.textContent || '')) continue;
          hits.push([n, m[1]]);
        }
        for (var i = 0; i < hits.length; i++) {
          var t = hits[i][0];
          if (!t.parentNode) continue;
          var sp = document.createElement('span');
          sp.className = 'hawl-an';
          sp.textContent = toAr(hits[i][1]);
          sp.setAttribute('aria-label', 'الآية ' + toAr(hits[i][1]));
          t.parentNode.replaceChild(sp, t);
        }
      } catch (e) {}
    };
    var queue = [], timer = 0;
    var start = function () {
      scan(document.body);
      try {
        new MutationObserver(function (muts) {
          for (var i = 0; i < muts.length; i++) {
            for (var j = 0; j < muts[i].addedNodes.length; j++) queue.push(muts[i].addedNodes[j]);
            if (muts[i].type === 'characterData') queue.push(muts[i].target);
          }
          if (queue.length && !timer) timer = setTimeout(function () {
            var q = queue; queue = []; timer = 0;
            for (var k = 0; k < q.length; k++) if (q[k].isConnected) scan(q[k]);
          }, 200);
        }).observe(document.body, { childList: true, subtree: true, characterData: true });
      } catch (e) {}
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
    window.addEventListener('load', function () { scan(document.body); });
  }

  function hawlQuranFont() {
    var MAP_URL = '/__hawl/qmap.json?v=1';
    var SIG = /[\u0671\u06DF\u06E1\u06E5\u06E6]/;          // ٱ وعلامات الرسم العثماني: نص قرآني
    var LETTERS = '\\u0610-\\u061A\\u0621-\\u065F\\u0670-\\u06D3\\u06D5-\\u06ED\\u0640';
    var WORD = new RegExp('[' + LETTERS + ']+', 'g');
    var RUN = new RegExp('[' + LETTERS + ']+(?:[ \\u00A0]+[' + LETTERS + ']+)*', 'g');
    var map = null, loading = false, pending = [];

    var css = document.createElement('style');
    css.textContent = "@font-face{font-family:'HawlHafs';src:url('/__hawl/hafs.woff2?v=18') format('woff2');font-display:block}" +
      ".hawl-q{font-family:'HawlHafs',serif!important;font-weight:400!important;font-style:normal!important;font-size:1.06em;" +
      "font-feature-settings:normal;letter-spacing:0!important;word-spacing:normal}";
    (document.head || document.documentElement).appendChild(css);

    function conv(t) {
      t = t.replace(/\uFEFF/g, '')
        .replace(/(^|[\s\u00A0]|\u0648\u064E)\u0645\u064E\u0627 \u0644\u0650\u0649\u064E/g, '$1\u0645\u064E\u0627\u0644\u0650\u064A\u064E')
        .replace(/\u0644\u0651\u064E\u0648\u0652 \u0645\u064E\u0627/g, '\u0644\u0651\u064E\u0648\u06E1\u0645\u064E\u0627');
      t = t.replace(WORD, function (w) {
        var r = map[w];
        return r ? r : w.replace(/\u0652/g, '\u06E1').replace(/\u06DF/g, '\u0652');
      });
      // علامات الوقف تلتصق بالكلمة قبلها كما في المصحف
      return t.replace(/[ \u00A0]+([\u06D6-\u06DC])/g, '$1');
    }

    function skip(el) {
      for (; el && el !== document.body; el = el.parentElement) {
        var tn = el.tagName;
        if (tn === 'SCRIPT' || tn === 'STYLE' || tn === 'TEXTAREA' || tn === 'INPUT' || tn === 'SELECT' ||
            tn === 'CODE' || tn === 'PRE' || el.isContentEditable) return true;
        if (el.classList && el.classList.contains('hawl-q')) return true;
      }
      return false;
    }

    function collect(root, out) {
      if (!root) return;
      if (root.nodeType === 3) { if (SIG.test(root.data) && !skip(root.parentElement)) out.push(root); return; }
      if (root.nodeType !== 1 || skip(root)) return;
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      for (var n = w.nextNode(); n; n = w.nextNode()) {
        if (SIG.test(n.data) && !skip(n.parentElement)) out.push(n);
      }
    }

    function apply(node) {
      if (!node.parentNode) return;
      var src = node.data;
      // نص بصيغة المجمع أصلًا (فيه سكون المجمع ۡ ولا علامة الألف الزائدة ۟): الخط فقط
      var t = (/\u06E1/.test(src) && !/\u06DF/.test(src)) ? src : conv(src);
      var frag = document.createDocumentFragment(), last = 0, m;
      RUN.lastIndex = 0;
      while ((m = RUN.exec(t))) {
        if (m.index > last) frag.appendChild(document.createTextNode(t.slice(last, m.index)));
        var sp = document.createElement('span');
        sp.className = 'hawl-q';
        sp.textContent = m[0];
        frag.appendChild(sp);
        last = m.index + m[0].length;
      }
      if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
      node.parentNode.replaceChild(frag, node);
    }

    function run(roots) {
      var nodes = [];
      for (var i = 0; i < roots.length; i++) collect(roots[i], nodes);
      if (!nodes.length) return;
      if (!map) {
        Array.prototype.push.apply(pending, nodes);
        if (loading) return;
        loading = true;
        fetch(MAP_URL).then(function (r) { return r.json(); }).then(function (j) {
          map = j;
          var p = pending; pending = [];
          for (var k = 0; k < p.length; k++) apply(p[k]);
        }).catch(function () { loading = false; pending = []; });
        return;
      }
      for (var k = 0; k < nodes.length; k++) apply(nodes[k]);
    }

    var queued = [], timer = 0;
    function start() {
      if (!document.body) return;
      run([document.body]);
      try {
        new MutationObserver(function (muts) {
          for (var i = 0; i < muts.length; i++) {
            var a = muts[i].addedNodes;
            for (var j = 0; j < a.length; j++) {
              var n = a[j];
              if (n.nodeType === 1 && n.classList && n.classList.contains('hawl-q')) continue;
              queued.push(n);
            }
          }
          if (queued.length && !timer) timer = setTimeout(function () { var q = queued; queued = []; timer = 0; run(q); }, 120);
        }).observe(document.body, { childList: true, subtree: true });
      } catch (e) {}
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  }

  // روابط الموقع المُشارَكة من التطبيق تحمل وسم المصدر
  function tagUrl(u) {
    try {
      if (!u) return u;
      var x = new URL(u, location.href);
      if (!/(^|\.)7awlalaalam\.com$/.test(x.hostname) || x.searchParams.has('utm_source')) return u;
      x.searchParams.set('utm_source', 'app_share');
      x.searchParams.set('utm_medium', 'share');
      return x.toString();
    } catch (e) { return u; }
  }
  function tagText(t) {
    return (t || '').replace(/https?:\/\/(www\.)?7awlalaalam\.com\/[^\s]*/g, function (m) { return tagUrl(m); });
  }

  // إخفاء مساحات الإعلانات داخل التطبيق (الإعلانات نفسها محجوبة من التطبيق)
  try {
    var st = document.createElement('style');
    st.textContent = 'ins.adsbygoogle,.adsbygoogle,.google-auto-placed,.ad-slot,.ads-wrap,[id^="aswift_"],' +
      'iframe[src*="googlesyndication"],iframe[id^="google_ads_iframe"]{display:none!important;height:0!important}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}

  function send(o) {
    var B = window.HawlApp;
    if (B && B.postMessage) B.postMessage(JSON.stringify(o));
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // 1) المشاركة: WebView لا يدعم navigator.share فنوفّرها عبر نافذة مشاركة أندرويد
  var share = function (d) {
    d = d || {};
    var files = Array.prototype.slice.call(d.files || []);
    return Promise.all(files.map(function (f) {
      return toB64(f).then(function (data) {
        return { name: f.name || 'file', type: f.type || 'application/octet-stream', data: data };
      });
    })).then(function (fs) {
      send({ cmd: 'share', title: d.title || '', text: tagText(d.text), url: tagUrl(d.url || ''), files: fs });
    });
  };
  try {
    Object.defineProperty(navigator, 'share', { value: share, configurable: true, writable: true });
    Object.defineProperty(navigator, 'canShare', { value: function () { return true; }, configurable: true, writable: true });
  } catch (e) { try { navigator.share = share; } catch (e2) {} }

  // 2) حفظ الملفات المولَّدة (blob: / data:) مثل بطاقات الآيات
  window.__hawlSaveBlob = function (url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (bl) {
      return toB64(bl).then(function (data) {
        send({ cmd: 'save', name: name || 'file', type: bl.type || 'application/octet-stream', data: data });
      });
    }).catch(function () {});
  };
  function isGenerated(h) { return h.indexOf('blob:') === 0 || h.indexOf('data:') === 0; }

  // روابط مُنشأة برمجيًا ثم a.click()
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var h = this.href || '';
    if (this.hasAttribute('download') && isGenerated(h)) {
      window.__hawlSaveBlob(h, this.getAttribute('download') || 'file');
      return;
    }
    return origClick.apply(this, arguments);
  };
  // روابط <a download> موجودة في الصفحة
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (isGenerated(h)) {
      e.preventDefault();
      window.__hawlSaveBlob(h, a.getAttribute('download') || 'file');
    }
  }, true);

  // 3) التحكم بالتلاوة من شاشة القفل: نراقب عناصر الصوت ونبلّغ التطبيق بحالتها
  var lastMedia = null;
  function mediaTitle(el) {
    var t = (el && (el.getAttribute && (el.getAttribute('title') || el.getAttribute('data-title')))) || '';
    if (!t) {
      var h = document.querySelector('h1');
      t = h ? h.textContent.replace(/\s+/g, ' ').trim() : document.title;
    }
    return (t || '').slice(0, 120);
  }
  function report(el, state) {
    if (!el || el.tagName === 'VIDEO') return;
    lastMedia = el;
    send({ cmd: 'media', state: state, title: mediaTitle(el) });
  }
  function hook(el) {
    if (!el || el.__hawlHooked) return;
    el.__hawlHooked = true;
    el.addEventListener('play', function () { report(el, 'playing'); });
    el.addEventListener('playing', function () { report(el, 'playing'); });
    el.addEventListener('pause', function () { report(el, 'paused'); });
    el.addEventListener('ended', function () { report(el, 'paused'); });
  }
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    hook(this);
    return origPlay.apply(this, arguments);
  };
  document.addEventListener('play', function (e) { hook(e.target); report(e.target, 'playing'); }, true);
  window.__hawlMedia = function (cmd) {
    var m = lastMedia;
    if (!m) return;
    try {
      if (cmd === 'play') m.play();
      else m.pause();
    } catch (e) {}
  };

  // 4) زر «تحميل للاستماع بدون إنترنت» تحت مشغّل التلاوة (داخل التطبيق فقط)
  var dlButtons = {};
  function surahTitle() {
    var t = (document.title || '').split(' - ')[0].split('|')[0].replace('كاملة', '').trim();
    return t || 'تلاوة';
  }
  function reciterName() {
    var parts = (document.title || '').split('|');
    return parts.length > 1 ? parts[parts.length - 1].trim() : '';
  }
  window.__hawlDlState = function (url, state) {
    var b = dlButtons[url];
    if (!b) return;
    b.dataset.state = state;
    if (state === 'done') { b.textContent = '✓ محمّلة، تعمل بدون إنترنت'; b.disabled = true; b.style.background = '#E8F5EE'; b.style.color = '#2E7D5B'; b.style.borderColor = '#BFE3CF'; }
    else if (state === 'running') { b.textContent = 'جارٍ التحميل… تابع من الإشعار'; b.disabled = true; }
    else { b.textContent = '⬇ تحميل للاستماع بدون إنترنت'; b.disabled = false; }
  };
  function addDownload(el) {
    if (!window.HawlApp || !el || el.__hawlDl) return;
    var src = el.currentSrc || el.getAttribute('src') || (el.querySelector('source') || {}).src || '';
    if (!/mp3quran\.net\/.+\.mp3$/i.test(src)) return;
    el.__hawlDl = true;
    var b = document.createElement('button');
    b.type = 'button';
    b.style.cssText = 'display:block;width:100%;margin:10px 0 4px;min-height:46px;border-radius:23px;border:1px solid #EFE4CF;' +
      'background:#FFFDF8;color:#8A6A33;font:inherit;font-size:15px;font-weight:700;cursor:pointer';
    b.textContent = '⬇ تحميل للاستماع بدون إنترنت';
    b.addEventListener('click', function () {
      if (b.disabled) return;
      b.disabled = true;
      b.textContent = 'جارٍ بدء التحميل…';
      send({ cmd: 'download', url: src, title: surahTitle(), reciter: reciterName() });
    });
    dlButtons[src] = b;
    el.insertAdjacentElement('afterend', b);
    send({ cmd: 'dl_query', url: src });
  }
  function scanAudio() { Array.prototype.forEach.call(document.querySelectorAll('audio'), addDownload); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanAudio);
  else scanAudio();
  window.addEventListener('load', scanAudio);

  // تأخير إلغاء روابط blob حتى نلحق بقراءتها
  var origRevoke = URL.revokeObjectURL;
  URL.revokeObjectURL = function (u) { setTimeout(function () { origRevoke.call(URL, u); }, 60000); };
})();
