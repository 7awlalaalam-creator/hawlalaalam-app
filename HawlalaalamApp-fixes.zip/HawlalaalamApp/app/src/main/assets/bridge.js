/* جسر التطبيق: يضيف ميزة المشاركة (navigator.share) وحفظ الصور المولَّدة داخل WebView */
(function () {
  if (window.__hawlBridge) return;
  window.__hawlBridge = true;

  // 0) Google Analytics: تمييز زوار التطبيق (قبل تحميل gtag في الصفحة)
  try {
    window.dataLayer = window.dataLayer || [];
    var gt = function () { window.dataLayer.push(arguments); };
    gt('set', 'user_properties', { client_type: 'android_app' });
    gt('set', { client_type: 'android_app' });
    if (window.__hawlInternal) gt('set', { traffic_type: 'internal' });   // جوال صاحب الموقع
  } catch (e) {}

  // ---------------------------------------------------------------- داخل التطبيق
  // العلامة HawlalaalamApp في userAgent: نُعلم الموقع بالمظهر ونخفي شريطه السفلي
  // لأن التطبيق يعرض شريطه الثابت أسفل الشاشة.
  var IN_APP = /HawlalaalamApp\//.test(navigator.userAgent);
  if (IN_APP) {
    var root = document.documentElement;
    var theme = window.__hawlTheme === 'dark' ? 'dark' : 'light';
    try {
      root.classList.add('hawl-app', 'hawl-' + theme);
      root.setAttribute('data-app', 'android');
      root.setAttribute('data-app-theme', theme);
      // الأسماء الشائعة لمفتاح الثيم، ليلتقطها قالب الموقع أيًّا كان اسمه
      root.setAttribute('data-theme', theme);
      root.setAttribute('data-mode', theme);
      root.setAttribute('data-bs-theme', theme);
      if (theme === 'dark') root.classList.add('dark', 'dark-mode'); else root.classList.remove('dark', 'dark-mode');
      try { localStorage.setItem('theme', theme); } catch (e) {}
      // مفتاح الوضع الليلي الحقيقي في قالب الموقع: html[data-hw-mode] + التخزين hw-mode
      // (بدونه كان WebView يعتّم الصفحة الفاتحة آليًا فتظهر رمادية بنص أزرق)
      root.setAttribute('data-hw-mode', theme);
      try { localStorage.setItem('hw-mode', theme); localStorage.setItem('awl_mode_manual', theme); } catch (e) {}
      window.dispatchEvent(new CustomEvent('hawl-theme', { detail: theme }));
    } catch (e) {}

    // ------------------------------------------------ توحيد ألوان الموقع مع ألوان التطبيق
    // القيم نفسها في res/values و res/values-night للتطبيق
    // محددات بأولوية أعلى من قواعد القالب (html[data-hw-mode] body.hawl-themed …) دون إفراط في !important
    var D = 'html.hawl-app[data-app][data-hw-mode="dark"] body', L = 'html.hawl-app[data-app][data-hw-mode="light"] body',
        A = 'html.hawl-app[data-app][data-hw-mode] body';
    var unify = document.createElement('style');
    unify.id = 'hawl-unify';
    unify.textContent =
      // يمنع التعتيم الآلي في WebView لأن الصفحة صار لها وضع داكن حقيقي
      'html.hawl-app[data-hw-mode="dark"]{color-scheme:dark;background:#0B1A1E!important}' +
      'html.hawl-app[data-hw-mode="light"]{color-scheme:light;background:#F6F8F9!important}' +
      // رموز الصفحات الحديثة في القالب
      D + '{--bg:#0B1A1E;--surface:#12262B;--surface-2:#1A3439;--text:#E9EEF0;--text-muted:#8FA6AC;' +
          '--accent:#C9A876;--accent-soft:#E8D5A8;--border-soft:rgba(201,168,118,.22);background:#0B1A1E!important;color:#E9EEF0}' +
      L + '{--bg:#F6F8F9;--surface:#FFFFFF;--surface-2:#F5F1E6;--text:#16353D;--text-muted:#5D747C;' +
          '--accent:#9A7332;--accent-soft:#C9A876;--border-soft:rgba(154,115,50,.22);background:#F6F8F9!important;color:#16353D}' +
      // الهيدر بلون الصفحة مثل شاشات التطبيق
      D + ' .hw-header.hw-header{background:#0B1A1E!important;border-bottom:1px solid #1F3A41!important}' +
      L + ' .hw-header.hw-header{background:#FFFFFF!important;border-bottom:1px solid #EEF0F2!important}' +
      // البطاقات: نفس لون بطاقات التطبيق وزواياه
      D + ' :is(.card-custom,.listensora,.changesoraform,footer):not(#x){background:#12262B!important;border-color:#1F3A41!important;color:#E9EEF0!important}' +
      L + ' :is(.card-custom,.listensora,.changesoraform):not(#x){background:#FFFFFF!important;border-color:#E6E9EC!important}' +
      A + ' :is(.card-custom,.listensora,.changesoraform):not(#x){border-radius:22px!important;overflow:hidden}' +
      // الحاويات الوسيطة في القالب القديم (well, card-body) شفافة حتى لا تظهر طبقة بلون مختلف
      A + ' :is(.container.well,.card-custom > .card-body):not(#x){background:transparent!important;border-color:transparent!important;box-shadow:none!important}' +
      // شريط عنوان السورة
      D + ' .card-custom .card-header:not(#x){background:#123640!important;color:#FFFFFF!important;border-color:#1F3A41!important}' +
      // بطاقة النص القرآني: عاجي دافئ لا أزرق
      D + ' .surah-text:not(#x){background:#162E33!important;border-color:#2A4A50!important;color:#EFE4CF!important}' +
      D + ' .surah-text a:not(#x){color:#EFE4CF!important}' +
      L + ' .surah-text:not(#x){background:#FFFDF8!important;border-color:#EFE4CF!important;color:#16353D!important}' +
      // الحقول والقوائم المنسدلة
      D + ' :is(select,textarea,input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=submit]):not([type=button])):not(.btn):not(#x)' +
          '{background:#1A3439!important;border-color:#2A4A50!important;color:#E9EEF0!important}' +
      A + ' :is(select,input).form-control:not(.btn):not(#x){border-radius:14px!important;min-height:46px}' +
      // الأزرار الرئيسية: كبسولة ذهبية مثل أزرار التطبيق
      A + ' .btn.btn-primary:not(#x){background:#C9A876!important;border-color:#C9A876!important;color:#0E2C31!important;' +
          'border-radius:999px!important;font-weight:700;min-height:46px}' +
      // صفحة الفيديو في الوضع الليلي: قالب الموقع يثبّت العناوين بلون داكن (#16353d) فلا تُقرأ فوق البطاقة الداكنة
      D + '.hw-videos{--ink:#0B1A1E;--deep:#12262B;--panel:#12262B;--panel-2:#1A3439;--line:#1F3A41;--gold:#E8D5A8;' +
          '--gold-soft:#EFE4CF;--text:#E9EEF0;--muted:#8FA6AC}' +
      D + ' :is(.grid,.reel-row,.mini,.side) :is(.card h3,.card h3 a,h3 a,.mini a):not(#x){color:#E9EEF0!important}' +
      D + ' :is(.grid,.reel-row) .card h3 a:hover:not(#x){color:#E8D5A8!important}' +
      D + ' :is(.grid,.reel-row,.watch) .meta:not(#x){color:#8FA6AC!important}' +
      D + ' :is(.grid,.reel-row,.watch) .tag:not(#x){color:#E8D5A8!important}' +
      D + ' :is(.head p,.reel .sub,.crumbs,.crumbs a,.about,.facts dt,.verse .ref):not(#x){color:#8FA6AC!important}' +
      D + ' :is(.desc,.facts dd,.about h2,.watch h1):not(#x){color:#E9EEF0!important}' +
      // عناصر خاصة بالمتصفح لا داعي لها داخل التطبيق: زر تبديل الوضع (التطبيق يتحكم به)، ومسار التصفح، وزر «الرئيسية»
      A + ' :is(.hw-mode-btn,.breadcrumb,nav[aria-label="breadcrumb"],.hw-home):not(#x){display:none!important}';
    (document.head || root).appendChild(unify);

    // ------------------------------------------------ توحيد الأرقام
    // الموقع يخلط الأرقام الغربية بالعربية («الآية 9» بجانب «٢٨٦ آية»). داخل التطبيق نوحّدها بالعربية
    // في النصوص العربية فقط: لا نلمس الحقول ولا الأكواد ولا أي نص فيه حروف لاتينية (روابط، أسماء إنجليزية).
    (function () {
      var SKIP = /^(SCRIPT|STYLE|TEXTAREA|INPUT|CODE|PRE|KBD|SAMP|NOSCRIPT|SVG|MATH)$/;
      var AR = /[\u0600-\u06FF]/, LAT = /[A-Za-z]/, DIG = /[0-9]/;
      var conv = function (t) { return t.replace(/[0-9]/g, function (d) { return String.fromCharCode(0x0660 + (+d)); }); };
      var ok = function (n) {
        for (var e = n.parentElement; e; e = e.parentElement) {
          if (SKIP.test(e.tagName) || e.isContentEditable) return false;
          var dir = e.getAttribute && e.getAttribute('dir');
          if (dir === 'ltr' || e.hasAttribute('data-hawl-latin')) return false;
          // عدّادات ومؤقتات يقرؤها سكربت الموقع كأرقام: لا نغيّرها حتى لا تتعطل حساباته
          if (/(time|timer|count|duration|clock|progress|player|audio|seek|tasbeeh|tasbih)/i.test((e.id || '') + ' ' + (typeof e.className === 'string' ? e.className : ''))) return false;
          if (e === document.body) break;
        }
        return true;
      };
      var walk = function (rootEl) {
        try {
          if (!rootEl) return;
          if (rootEl.nodeType === 3) rootEl = rootEl.parentElement;
          if (!rootEl) return;
          var tw = document.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT, null);
          var n, c = 0;
          while ((n = tw.nextNode()) && c < 8000) {
            c++;
            var t = n.data;
            if (!DIG.test(t) || LAT.test(t)) continue;
            // رقم منفرد بلا حروف: نحوّله إن كان سياقه عربيًا
            if (!AR.test(t)) {
              var ctx = n.parentElement && n.parentElement.closest('p,li,div,span,a,td,h1,h2,h3,h4,h5,h6,label');
              if (!ctx || !AR.test(ctx.textContent || '') || LAT.test(ctx.textContent || '')) continue;
            }
            if (ok(n)) n.data = conv(t);
          }
        } catch (e) {}
      };
      var queue = [], timer = 0;
      var start = function () {
        walk(document.body);
        try {
          new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
              if (muts[i].type === 'characterData') queue.push(muts[i].target);
              for (var j = 0; j < muts[i].addedNodes.length; j++) queue.push(muts[i].addedNodes[j]);
            }
            if (queue.length && !timer) timer = setTimeout(function () {
              var q = queue; queue = []; timer = 0;
              for (var k = 0; k < q.length; k++) if (q[k].isConnected) walk(q[k]);
            }, 250);
          }).observe(document.body, { childList: true, subtree: true, characterData: true });
        } catch (e) {}
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
    })();

    // قالب الموقع يدعم ألوانًا اختيارية (أزرق، بنفسجي…) ووضع body.mode-*؛ داخل التطبيق نثبّت هوية التطبيق
    var fixes = 0;   // حدّ أمان: إن كان سكربت القالب يعيد الوضع باستمرار، لا ندخل معه في حلقة لا تنتهي
    var syncBody = function () {
      var b = document.body;
      if (!b || fixes > 30) return;
      var want = 'mode-' + theme, other = theme === 'dark' ? 'mode-light' : 'mode-dark', changed = false;
      if (!b.classList.contains(want)) { b.classList.add(want); changed = true; }
      if (b.classList.contains(other)) { b.classList.remove(other); changed = true; }
      if (b.hasAttribute('data-theme')) { b.removeAttribute('data-theme'); changed = true; }
      if (root.getAttribute('data-hw-mode') !== theme) { root.setAttribute('data-hw-mode', theme); changed = true; }
      if (changed) fixes++;
    };
    var watchTheme = function () {
      syncBody();
      try {
        var mo = new MutationObserver(syncBody);
        mo.observe(document.body, { attributes: true, attributeFilter: ['class', 'data-theme'] });
        mo.observe(root, { attributes: true, attributeFilter: ['data-hw-mode'] });
      } catch (e) {}
    };
    if (document.body) watchTheme(); else document.addEventListener('DOMContentLoaded', watchTheme);

    // ------------------------------------------------ مصحّح التباين في الوضع الليلي
    // بعض صفحات الموقع (مثل الفيديوهات) تكتب العناوين بلون داكن ثابت فوق بطاقة داكنة فلا تُقرأ.
    // نفحص النصوص: إن كان تباين لون النص مع خلفيته الفعلية ضعيفًا نجعله فاتحًا.
    if (theme === 'dark') {
      var rgb = function (c) {
        var m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?/.exec(c || '');
        if (!m) return null;
        var a = m[4] === undefined ? 1 : (m[4].indexOf('%') > 0 ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
        return [+m[1], +m[2], +m[3], a];
      };
      var lum = function (c) {
        var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
        return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
      };
      var bgOf = function (el) {
        for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
          var cs = getComputedStyle(e);
          // نص فوق صورة: لا نحكم عليه
          if (cs.backgroundImage && cs.backgroundImage !== 'none' && cs.backgroundImage.indexOf('gradient') < 0) return null;
          var b = rgb(cs.backgroundColor);
          if (b && b[3] >= 0.5) return b;
        }
        return [11, 26, 30, 1];          // خلفية الصفحة في الوضع الليلي
      };
      // ---- مصحّح الأسطح الفاتحة: أقسام في الموقع خلفيتها بيضاء أو عاجية ثابتة (#fff) لا تتبع الوضع الليلي،
      // فيظهر النص الفاتح فوقها باهتًا (الترويسة، تبويبات الصفحة الرئيسية، بطاقات فهرس السور، بطاقة آية اليوم).
      // نجعل كل سطح فاتح بلون بطاقات التطبيق الليلي، ثم يعمل مصحّح التباين على نصوصه.
      var STAGS = 'header,nav,section,article,aside,main,footer,form,div,ul,ol,li,a,button,label,table,tr,td,th,fieldset';
      var fixSurfaces = function (rootEl) {
        try {
          var base = rootEl && rootEl.querySelectorAll ? rootEl : document.body;
          var els = [base].concat(Array.prototype.slice.call(base.querySelectorAll(STAGS)));
          for (var i = 0; i < els.length && i < 6000; i++) {
            var el = els[i];
            if (el.nodeType !== 1 || el.hasAttribute('data-hawl-s') || el === document.body) continue;
            el.setAttribute('data-hawl-s', '1');
            var cs = getComputedStyle(el);
            if (cs.backgroundImage && cs.backgroundImage !== 'none') continue;   // صور وتدرجات لا نلمسها
            var b = rgb(cs.backgroundColor);
            if (!b || b[3] < 0.5 || lum(b) < 0.6) continue;                      // ليست فاتحة
            if (b[0] > b[2] + 40 && lum(b) < 0.75) continue;                     // ذهبي مقصود (أزرار)
            var r = el.getBoundingClientRect();
            var big = r.height >= 64 || r.width >= window.innerWidth * 0.6;
            el.style.setProperty('background-color', big ? '#12262B' : '#1A3439', 'important');
            var bc = rgb(cs.borderTopColor);
            if (bc && parseFloat(cs.borderTopWidth) > 0 && lum(bc) > 0.5) el.style.setProperty('border-color', '#1F3A41', 'important');
            // أُعيد طلاء السطح: نعيد فحص تباين نصوصه
            var marked = el.querySelectorAll('[data-hawl-c]');
            for (var k = 0; k < marked.length; k++) if (!marked[k].style.getPropertyValue('color')) marked[k].removeAttribute('data-hawl-c');
            if (el.hasAttribute('data-hawl-c') && !el.style.getPropertyValue('color')) el.removeAttribute('data-hawl-c');
          }
        } catch (e) {}
      };
      var TAGS = 'h1,h2,h3,h4,h5,h6,p,a,span,strong,b,small,li,dt,dd,label,figcaption,div,td,th';
      var fixContrast = function (rootEl) {
        fixSurfaces(rootEl);
        try {
          var els = (rootEl && rootEl.querySelectorAll ? rootEl : document.body).querySelectorAll(TAGS);
          var n = 0;
          for (var i = 0; i < els.length && n < 4000; i++) {
            var el = els[i];
            if (el.hasAttribute('data-hawl-c')) continue;
            // نص مباشر داخل العنصر فقط
            var direct = false;
            for (var c = el.firstChild; c; c = c.nextSibling) {
              if (c.nodeType === 3 && c.data.trim()) { direct = true; break; }
            }
            if (!direct) continue;
            n++;
            el.setAttribute('data-hawl-c', '1');
            var cs = getComputedStyle(el);
            var fg = rgb(cs.color);
            if (!fg || fg[3] < 0.2 || cs.visibility === 'hidden') continue;
            var bg = bgOf(el);
            if (!bg) continue;
            var l1 = lum(fg), l2 = lum(bg);
            var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
            if (ratio < 3 && l1 < 0.25) {
              // العناوين والروابط ذهبية فاتحة كما في التطبيق، وبقية النص فاتح
              var gold = /^(A|SMALL)$/.test(el.tagName) && fg[0] > fg[2];
              el.style.setProperty('color', gold ? '#E8D5A8' : '#E9EEF0', 'important');
            }
          }
        } catch (e) {}
      };
      var cTimer = 0, cQueue = [];
      var startContrast = function () {
        fixContrast(document.body);
        try {
          new MutationObserver(function (muts) {
            for (var i = 0; i < muts.length; i++) {
              for (var j = 0; j < muts[i].addedNodes.length; j++) {
                var nd = muts[i].addedNodes[j];
                if (nd.nodeType === 1) cQueue.push(nd); else if (nd.parentElement) cQueue.push(nd.parentElement);
              }
            }
            if (cQueue.length && !cTimer) cTimer = setTimeout(function () {
              var q = cQueue; cQueue = []; cTimer = 0;
              for (var k = 0; k < q.length; k++) { if (q[k].isConnected) { if (q[k].matches && q[k].matches(TAGS)) { q[k].removeAttribute('data-hawl-c'); } fixContrast(q[k].parentElement || q[k]); } }
            }, 300);
          }).observe(document.body, { childList: true, subtree: true });
        } catch (e) {}
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startContrast); else startContrast();
      // بعد تحميل أوراق الأنماط والخطوط: فحص أخير للعناصر التي لم تكتمل ألوانها
      window.addEventListener('load', function () {
        var sf = document.querySelectorAll('[data-hawl-s]');
        for (var s2 = 0; s2 < sf.length; s2++) if (!sf[s2].style.getPropertyValue('background-color')) sf[s2].removeAttribute('data-hawl-s');
        var all = document.querySelectorAll('[data-hawl-c]');
        for (var i = 0; i < all.length; i++) if (!all[i].style.getPropertyValue('color')) all[i].removeAttribute('data-hawl-c');
        fixContrast(document.body);
      });
    }

    var navCss = document.createElement('style');
    navCss.textContent =
      // محددات شائعة لشريط الجوال السفلي + ما يكتشفه الفحص أدناه
      '.hawl-app .bottom-nav,.hawl-app .mobile-nav,.hawl-app .bottom-bar,.hawl-app .tabbar,.hawl-app .tab-bar,' +
      '.hawl-app .nav-bottom,.hawl-app .mobile-bottom-nav,.hawl-app #bottom-nav,.hawl-app #mobile-nav,' +
      '.hawl-app [data-bottom-nav],.hawl-site-nav,.hawl-legacy{display:none!important}';
    (document.head || root).appendChild(navCss);

    // فحص ذكي: عنصر ثابت أسفل الشاشة بعرضها تقريبًا، قليل الارتفاع، وفيه 3 روابط أو أزرار فأكثر
    var hiddenH = 0;
    var scanSiteNav = function () {
      try {
        var vw = window.innerWidth, vh = window.innerHeight;
        if (!vw || !vh || !document.body) return;
        var xs = [vw * 0.15, vw * 0.5, vw * 0.85], seen = [];
        for (var k = 0; k < xs.length; k++) {
          var stack = document.elementsFromPoint(xs[k], vh - 6) || [];
          for (var n = 0; n < stack.length; n++) {
            for (var el = stack[n]; el && el !== document.body && el !== root; el = el.parentElement) {
              if (seen.indexOf(el) >= 0) break;
              seen.push(el);
              var cs = getComputedStyle(el);
              if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
              var r = el.getBoundingClientRect();
              if (r.width >= vw * 0.8 && r.height > 20 && r.height <= 140 && r.bottom >= vh - 8 &&
                  el.querySelectorAll('a,button').length >= 3) {
                el.classList.add('hawl-site-nav');
                hiddenH = Math.max(hiddenH, r.height);
              }
            }
          }
        }
        // المسافة التي حجزها الموقع أسفل الصفحة لشريطه لم تعد لازمة
        if (hiddenH && !document.body.hasAttribute('data-hawl-pad')) {
          var pb = parseFloat(getComputedStyle(document.body).paddingBottom) || 0;
          if (pb >= hiddenH - 12) {
            document.body.style.setProperty('padding-bottom', Math.max(0, pb - hiddenH) + 'px', 'important');
          }
          document.body.setAttribute('data-hawl-pad', '1');
        }
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', scanSiteNav);
    window.addEventListener('load', function () { scanSiteNav(); setTimeout(scanSiteNav, 800); setTimeout(scanSiteNav, 2000); });
    window.addEventListener('resize', scanSiteNav);

    // بقايا القالب القديم «القرآن الكريم للجميع» في صفحات السور: هيدر وشعار وبانر وسطر Powered by.
    // نخفيها داخل التطبيق فقط، مع حماية من إخفاء أي حاوية فيها عنوان الصفحة أو الآيات أو الهيدر الجديد.
    var cleanLegacy = function () {
      try {
        var vh = window.innerHeight || 800;
        var hide = function (el) {
          if (!el || el === document.body || el === root || el.classList.contains('hawl-legacy')) return;
          if (el.querySelector('h1,audio,article,img[src*="design-theme"]')) return;
          if (el.getBoundingClientRect().height > vh * 0.6) return;
          el.classList.add('hawl-legacy');
        };
        var each = function (sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); };
        each('img[src*="css/images/logo"]', function (img) {
          hide(img.closest('header,nav,.navbar,#header,.header,[class*="header"],[class*="navbar"]') || img.closest('a') || img);
        });
        each('img[src*="header-banner"]', function (img) {
          var w = img.parentElement;
          hide(w && w.children.length === 1 ? w : img);
        });
        each('a[href*="nwahy.com"]', function (a) {
          var p = a.parentElement;
          hide(p && p.textContent.trim().length < 80 ? p : a);
        });
      } catch (e) {}
    };
    document.addEventListener('DOMContentLoaded', cleanLegacy);
    window.addEventListener('load', cleanLegacy);

    // ------------------------------------------------ نص المصحف بخط مجمع الملك فهد ورسمه
    // نص الموقع بصيغة «تنزيل»؛ نحوّل كلماته داخل التطبيق إلى نص المجمع (KFGQPC Hafs v18)
    // ونعرضه بخطه الرسمي، فتظهر «وَٱلۡـَٔاخِرَةِ» وعلامات الوقف والتنوين كما في مصحف المدينة.
    // الخط وجدول التحويل يقدّمهما التطبيق من ملفاته عبر /__hawl/ (بدون إنترنت).
    try { hawlQuranFont(); } catch (e) {}
  }

  function hawlQuranFont() {
    var MAP_URL = '/__hawl/qmap.json?v=1';
    var SIG = /[\u0671\u06DF\u06E1\u06E5\u06E6]/;          // ٱ وعلامات الرسم العثماني: نص قرآني
    var LETTERS = '\\u0610-\\u061A\\u0621-\\u065F\\u0670-\\u06D3\\u06D5-\\u06ED\\u0640';
    var WORD = new RegExp('[' + LETTERS + ']+', 'g');
    var RUN = new RegExp('[' + LETTERS + ']+(?:[ \\u00A0]+[' + LETTERS + ']+)*', 'g');
    var map = null, loading = false, pending = [];

    var css = document.createElement('style');
    css.textContent = "@font-face{font-family:'HawlHafs';src:url('/__hawl/hafs.woff2?v=18') format('woff2');font-display:block}" +
      ".hawl-q{font-family:'HawlHafs',serif!important;font-weight:400!important;font-style:normal!important;font-size:1.06em;" +
      "font-feature-settings:normal;letter-spacing:0!important;word-spacing:normal}";
    (document.head || document.documentElement).appendChild(css);

    function conv(t) {
      t = t.replace(/\uFEFF/g, '')
        .replace(/(^|[\s\u00A0]|\u0648\u064E)\u0645\u064E\u0627 \u0644\u0650\u0649\u064E/g, '$1\u0645\u064E\u0627\u0644\u0650\u064A\u064E')
        .replace(/\u0644\u0651\u064E\u0648\u0652 \u0645\u064E\u0627/g, '\u0644\u0651\u064E\u0648\u06E1\u0645\u064E\u0627');
      t = t.replace(WORD, function (w) {
        var r = map[w];
        return r ? r : w.replace(/\u0652/g, '\u06E1').replace(/\u06DF/g, '\u0652');
      });
      // علامات الوقف تلتصق بالكلمة قبلها كما في المصحف
      return t.replace(/[ \u00A0]+([\u06D6-\u06DC])/g, '$1');
    }

    function skip(el) {
      for (; el && el !== document.body; el = el.parentElement) {
        var tn = el.tagName;
        if (tn === 'SCRIPT' || tn === 'STYLE' || tn === 'TEXTAREA' || tn === 'INPUT' || tn === 'SELECT' ||
            tn === 'CODE' || tn === 'PRE' || el.isContentEditable) return true;
        if (el.classList && el.classList.contains('hawl-q')) return true;
      }
      return false;
    }

    function collect(root, out) {
      if (!root) return;
      if (root.nodeType === 3) { if (SIG.test(root.data) && !skip(root.parentElement)) out.push(root); return; }
      if (root.nodeType !== 1 || skip(root)) return;
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      for (var n = w.nextNode(); n; n = w.nextNode()) {
        if (SIG.test(n.data) && !skip(n.parentElement)) out.push(n);
      }
    }

    function apply(node) {
      if (!node.parentNode) return;
      var src = node.data;
      // نص بصيغة المجمع أصلًا (فيه سكون المجمع ۡ ولا علامة الألف الزائدة ۟): الخط فقط
      var t = (/\u06E1/.test(src) && !/\u06DF/.test(src)) ? src : conv(src);
      var frag = document.createDocumentFragment(), last = 0, m;
      RUN.lastIndex = 0;
      while ((m = RUN.exec(t))) {
        if (m.index > last) frag.appendChild(document.createTextNode(t.slice(last, m.index)));
        var sp = document.createElement('span');
        sp.className = 'hawl-q';
        sp.textContent = m[0];
        frag.appendChild(sp);
        last = m.index + m[0].length;
      }
      if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
      node.parentNode.replaceChild(frag, node);
    }

    function run(roots) {
      var nodes = [];
      for (var i = 0; i < roots.length; i++) collect(roots[i], nodes);
      if (!nodes.length) return;
      if (!map) {
        Array.prototype.push.apply(pending, nodes);
        if (loading) return;
        loading = true;
        fetch(MAP_URL).then(function (r) { return r.json(); }).then(function (j) {
          map = j;
          var p = pending; pending = [];
          for (var k = 0; k < p.length; k++) apply(p[k]);
        }).catch(function () { loading = false; pending = []; });
        return;
      }
      for (var k = 0; k < nodes.length; k++) apply(nodes[k]);
    }

    var queued = [], timer = 0;
    function start() {
      if (!document.body) return;
      run([document.body]);
      try {
        new MutationObserver(function (muts) {
          for (var i = 0; i < muts.length; i++) {
            var a = muts[i].addedNodes;
            for (var j = 0; j < a.length; j++) {
              var n = a[j];
              if (n.nodeType === 1 && n.classList && n.classList.contains('hawl-q')) continue;
              queued.push(n);
            }
          }
          if (queued.length && !timer) timer = setTimeout(function () { var q = queued; queued = []; timer = 0; run(q); }, 120);
        }).observe(document.body, { childList: true, subtree: true });
      } catch (e) {}
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  }

  // روابط الموقع المُشارَكة من التطبيق تحمل وسم المصدر
  function tagUrl(u) {
    try {
      if (!u) return u;
      var x = new URL(u, location.href);
      if (!/(^|\.)7awlalaalam\.com$/.test(x.hostname) || x.searchParams.has('utm_source')) return u;
      x.searchParams.set('utm_source', 'app_share');
      x.searchParams.set('utm_medium', 'share');
      return x.toString();
    } catch (e) { return u; }
  }
  function tagText(t) {
    return (t || '').replace(/https?:\/\/(www\.)?7awlalaalam\.com\/[^\s]*/g, function (m) { return tagUrl(m); });
  }

  // إخفاء مساحات الإعلانات داخل التطبيق (الإعلانات نفسها محجوبة من التطبيق)
  try {
    var st = document.createElement('style');
    st.textContent = 'ins.adsbygoogle,.adsbygoogle,.google-auto-placed,.ad-slot,.ads-wrap,[id^="aswift_"],' +
      'iframe[src*="googlesyndication"],iframe[id^="google_ads_iframe"]{display:none!important;height:0!important}';
    (document.head || document.documentElement).appendChild(st);
  } catch (e) {}

  function send(o) {
    var B = window.HawlApp;
    if (B && B.postMessage) B.postMessage(JSON.stringify(o));
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }

  // 1) المشاركة: WebView لا يدعم navigator.share فنوفّرها عبر نافذة مشاركة أندرويد
  var share = function (d) {
    d = d || {};
    var files = Array.prototype.slice.call(d.files || []);
    return Promise.all(files.map(function (f) {
      return toB64(f).then(function (data) {
        return { name: f.name || 'file', type: f.type || 'application/octet-stream', data: data };
      });
    })).then(function (fs) {
      send({ cmd: 'share', title: d.title || '', text: tagText(d.text), url: tagUrl(d.url || ''), files: fs });
    });
  };
  try {
    Object.defineProperty(navigator, 'share', { value: share, configurable: true, writable: true });
    Object.defineProperty(navigator, 'canShare', { value: function () { return true; }, configurable: true, writable: true });
  } catch (e) { try { navigator.share = share; } catch (e2) {} }

  // 2) حفظ الملفات المولَّدة (blob: / data:) مثل بطاقات الآيات
  window.__hawlSaveBlob = function (url, name) {
    fetch(url).then(function (r) { return r.blob(); }).then(function (bl) {
      return toB64(bl).then(function (data) {
        send({ cmd: 'save', name: name || 'file', type: bl.type || 'application/octet-stream', data: data });
      });
    }).catch(function () {});
  };
  function isGenerated(h) { return h.indexOf('blob:') === 0 || h.indexOf('data:') === 0; }

  // روابط مُنشأة برمجيًا ثم a.click()
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var h = this.href || '';
    if (this.hasAttribute('download') && isGenerated(h)) {
      window.__hawlSaveBlob(h, this.getAttribute('download') || 'file');
      return;
    }
    return origClick.apply(this, arguments);
  };
  // روابط <a download> موجودة في الصفحة
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (isGenerated(h)) {
      e.preventDefault();
      window.__hawlSaveBlob(h, a.getAttribute('download') || 'file');
    }
  }, true);

  // 3) التحكم بالتلاوة من شاشة القفل: نراقب عناصر الصوت ونبلّغ التطبيق بحالتها
  var lastMedia = null;
  function mediaTitle(el) {
    var t = (el && (el.getAttribute && (el.getAttribute('title') || el.getAttribute('data-title')))) || '';
    if (!t) {
      var h = document.querySelector('h1');
      t = h ? h.textContent.replace(/\s+/g, ' ').trim() : document.title;
    }
    return (t || '').slice(0, 120);
  }
  function report(el, state) {
    if (!el || el.tagName === 'VIDEO') return;
    lastMedia = el;
    send({ cmd: 'media', state: state, title: mediaTitle(el) });
  }
  function hook(el) {
    if (!el || el.__hawlHooked) return;
    el.__hawlHooked = true;
    el.addEventListener('play', function () { report(el, 'playing'); });
    el.addEventListener('playing', function () { report(el, 'playing'); });
    el.addEventListener('pause', function () { report(el, 'paused'); });
    el.addEventListener('ended', function () { report(el, 'paused'); });
  }
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    hook(this);
    return origPlay.apply(this, arguments);
  };
  document.addEventListener('play', function (e) { hook(e.target); report(e.target, 'playing'); }, true);
  window.__hawlMedia = function (cmd) {
    var m = lastMedia;
    if (!m) return;
    try {
      if (cmd === 'play') m.play();
      else m.pause();
    } catch (e) {}
  };

  // 4) زر «تحميل للاستماع بدون إنترنت» تحت مشغّل التلاوة (داخل التطبيق فقط)
  var dlButtons = {};
  function surahTitle() {
    var t = (document.title || '').split(' - ')[0].split('|')[0].replace('كاملة', '').trim();
    return t || 'تلاوة';
  }
  function reciterName() {
    var parts = (document.title || '').split('|');
    return parts.length > 1 ? parts[parts.length - 1].trim() : '';
  }
  window.__hawlDlState = function (url, state) {
    var b = dlButtons[url];
    if (!b) return;
    b.dataset.state = state;
    if (state === 'done') { b.textContent = '✓ محمّلة، تعمل بدون إنترنت'; b.disabled = true; b.style.background = '#E8F5EE'; b.style.color = '#2E7D5B'; b.style.borderColor = '#BFE3CF'; }
    else if (state === 'running') { b.textContent = 'جارٍ التحميل… تابع من الإشعار'; b.disabled = true; }
    else { b.textContent = '⬇ تحميل للاستماع بدون إنترنت'; b.disabled = false; }
  };
  function addDownload(el) {
    if (!window.HawlApp || !el || el.__hawlDl) return;
    var src = el.currentSrc || el.getAttribute('src') || (el.querySelector('source') || {}).src || '';
    if (!/mp3quran\.net\/.+\.mp3$/i.test(src)) return;
    el.__hawlDl = true;
    var b = document.createElement('button');
    b.type = 'button';
    b.style.cssText = 'display:block;width:100%;margin:10px 0 4px;min-height:46px;border-radius:23px;border:1px solid #EFE4CF;' +
      'background:#FFFDF8;color:#8A6A33;font:inherit;font-size:15px;font-weight:700;cursor:pointer';
    b.textContent = '⬇ تحميل للاستماع بدون إنترنت';
    b.addEventListener('click', function () {
      if (b.disabled) return;
      b.disabled = true;
      b.textContent = 'جارٍ بدء التحميل…';
      send({ cmd: 'download', url: src, title: surahTitle(), reciter: reciterName() });
    });
    dlButtons[src] = b;
    el.insertAdjacentElement('afterend', b);
    send({ cmd: 'dl_query', url: src });
  }
  function scanAudio() { Array.prototype.forEach.call(document.querySelectorAll('audio'), addDownload); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanAudio);
  else scanAudio();
  window.addEventListener('load', scanAudio);

  // تأخير إلغاء روابط blob حتى نلحق بقراءتها
  var origRevoke = URL.revokeObjectURL;
  URL.revokeObjectURL = function (u) { setTimeout(function () { origRevoke.call(URL, u); }, 60000); };
})();
