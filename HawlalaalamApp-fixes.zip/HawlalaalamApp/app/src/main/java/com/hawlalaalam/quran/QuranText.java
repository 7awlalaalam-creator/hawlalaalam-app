package com.hawlalaalam.quran;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * نص المصحف برواية حفص من مجمع الملك فهد (KFGQPC Uthmanic Hafs، الإصدار ١٨) مع خطه الرسمي.
 * النص مدمج في التطبيق: آية اليوم و«آية لحالك» تعمل فورًا وبدون إنترنت،
 * والخط نفسه يُقدَّم لصفحات الموقع داخل التطبيق عبر المسار /__hawl/.
 */
final class QuranText {
    private QuranText() { }

    /** عدد آيات كل سورة */
    static final int[] COUNTS = {7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98,
            135, 112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53, 89, 59, 37, 35,
            38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56,
            40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9,
            5, 4, 7, 3, 6, 3, 5, 4, 5, 6};

    /** أسماء السور بلا تشكيل (للعناوين بخط الواجهة) */
    static final String[] NAMES = {"الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف",
            "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم",
            "طه", "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
            "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر", "فصلت", "الشورى",
            "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق", "الذاريات", "الطور", "النجم",
            "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف", "الجمعة", "المنافقون",
            "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر",
            "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس", "التكوير", "الانفطار", "المطففين",
            "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس", "الليل", "الضحى", "الشرح",
            "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة",
            "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس"};

    static final int TOTAL = 6236;

    private static volatile String[] lines;
    private static Typeface hafs;

    static boolean valid(int s, int a) { return s >= 1 && s <= 114 && a >= 1 && a <= COUNTS[s - 1]; }

    static String surahName(int s) { return s >= 1 && s <= 114 ? NAMES[s - 1] : ""; }

    /** «سورة ق» */
    static String surahTitle(int s) { return "سورة " + surahName(s); }

    /** رقم الآية في المصحف كله (0..6235) */
    static int index(int s, int a) {
        int n = 0;
        for (int i = 0; i < s - 1; i++) n += COUNTS[i];
        return n + a - 1;
    }

    /** {سورة، آية} من الرقم العام */
    static int[] fromIndex(int idx) {
        idx = ((idx % TOTAL) + TOTAL) % TOTAL;
        int s = 0;
        while (idx >= COUNTS[s]) { idx -= COUNTS[s]; s++; }
        return new int[]{s + 1, idx + 1};
    }

    private static String[] load(Context c) {
        String[] l = lines;
        if (l != null) return l;
        synchronized (QuranText.class) {
            if (lines != null) return lines;
            String[] out = new String[TOTAL];
            try (BufferedReader r = new BufferedReader(new InputStreamReader(
                    c.getApplicationContext().getAssets().open("quran/hafs.txt"), StandardCharsets.UTF_8), 64 * 1024)) {
                String s;
                int i = 0;
                while ((s = r.readLine()) != null && i < TOTAL) out[i++] = s;
            } catch (Exception e) {
                return new String[0];
            }
            lines = out;
            return out;
        }
    }

    /** نص الآية بالرسم العثماني (بدون رقم)، أو null. يُفضّل استدعاؤه من خيط خلفي أول مرة. */
    static String verse(Context c, int s, int a) {
        if (!valid(s, a)) return null;
        String[] l = load(c);
        int i = index(s, a);
        return i < l.length ? l[i] : null;
    }

    /** النص مع علامة نهاية الآية برقمها كما في المصحف (يرسمها خط المجمع) */
    static String withNumber(String text, int a) {
        return text + "\u00A0" + VerseRepo.arabicDigits(a);
    }

    /** خط مصحف المدينة (مجمع الملك فهد) */
    static synchronized Typeface font(Context c) {
        if (hafs == null) {
            try { hafs = c.getApplicationContext().getResources().getFont(R.font.hafs); }
            catch (Exception e) { hafs = Ui.quran(c); }
        }
        return hafs;
    }

    // ------------------------------------------------------------------ لصفحات الموقع داخل التطبيق

    private static final Map<String, String[]> FILES = new HashMap<>();
    static {
        FILES.put("/__hawl/hafs.woff2", new String[]{"quran/hafs.woff2", "font/woff2"});
        FILES.put("/__hawl/qmap.json", new String[]{"quran/qmap.json", "application/json"});
    }

    /** يقدّم خط المجمع وجدول تحويل الرسم من ملفات التطبيق بدل الشبكة */
    static WebResourceResponse intercept(Context c, WebResourceRequest req) {
        Uri u = req.getUrl();
        String path = u.getPath();
        if (path == null || !path.startsWith("/__hawl/")) return null;
        String host = u.getHost();
        if (host == null || !host.toLowerCase().endsWith("7awlalaalam.com")) return null;
        String[] f = FILES.get(path);
        if (f == null) return null;
        try {
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "public, max-age=31536000, immutable");
            h.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse(f[1], f[1].startsWith("application") ? "utf-8" : null, 200, "OK", h,
                    c.getApplicationContext().getAssets().open(f[0]));
        } catch (Exception e) {
            return null;
        }
    }
}
